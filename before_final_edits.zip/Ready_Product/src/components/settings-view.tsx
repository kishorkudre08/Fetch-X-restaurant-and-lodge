"use client";

// ── t99 · SETTINGS — a whole page, not a pop-up ─────────────────────────────
// t104 — the theme gallery shows the REAL page screenshots again, arranged
// exactly the way the user asked (and matching the reference screenshot):
//   · ONE theme per column — each theme is its own individual block
//   · inside, the four REAL screenshots stack into a 1×4 rectangle (never
//     the 2×2 square) in the fixed order
//       PRE-LOGIN · LIGHT → DASHBOARD · LIGHT
//       → PRE-LOGIN · DARK → DASHBOARD · DARK
//   · each shot is its own framed cell with its own caption BELOW it, its
//     own motion, and the block carries the theme's tinted page colours
//     (combo's lighter colour = the light page, darker = the dark page).
// t108 — COMPACT GALLERY (user: "decrease the size of theme preview · 1×4
// meant 1 column and 4 rows"): the 4 shots stay a single 1-column stack but
// render as uniform 80px-tall thumbnails (object-cover, top-anchored), the
// per-theme blocks shrink (padding, type, chips) and the gallery re-flows to
// a denser responsive grid — 2 columns on phones, 3 on tablets, 4 on desktop.
// t109 — DIRECTION FIX (user: "theme should be left to right, not up to
// down"): the 4 REAL screenshots now flow LEFT → RIGHT as one 4-across strip
// (grid-cols-4) of the same uniform 80px thumbs; theme blocks need width for
// the strip, so the gallery re-flows to 1 column on phones and 2 on lg+.
// t110 — ONE THEME PER COLUMN (user: "only one per column … overcrowded …
// last change on themes"): the gallery drops the lg:2 split — every theme
// block takes the full column width on every viewport; blocks and titles
// unchanged. Below the gallery: the tenant profile rename.
// t111 — FINAL SHAPE (user sketch: wide rounded blocks stacked top→bottom):
// the ten theme blocks stack VERTICALLY — ONE theme per row at full column
// width on every viewport (the sketch's stack of wide rectangles) — while
// INSIDE each block its four REAL screenshots keep flowing in ONE left→right
// line (grid-cols-4, uniform 80px thumbs, fixed order). Blocks and titles
// unchanged from t109. This is the settled theme-gallery layout. Below the
// gallery: the tenant profile rename.
// t112 — NO-CROP THUMBS (user: "they get cut in half due to less height"):
// the fixed 80px height cropped each page shot, so every thumbnail now sits
// in an 8:5 frame with object-contain — the WHOLE screenshot always visible
// (prelogin 1100×560 and dashboard 880×620 both fit), slim surf bands where
// the aspect differs. Gallery stays one theme per row.
// t124 — CONTRACTED + REDIRECT (user: "contract the theme in settings,
// expand when clicked, and when selected a theme, redirect them to their
// home page — pos billing, lodge front desk or live dashboard"): the whole
// gallery now lives behind ONE contracted header row (active theme chip +
// chevron, collapsed by default); tapping the row expands the ten theme
// blocks, and tapping a block applies the theme AND bounces the account
// straight back to its home screen — Live Dashboard for the owner, POS
// Billing for the restaurant reception, Lodge Front Desk for the lodge
// reception — so the theme is seen where they actually work.

import * as React from "react";
import { Bot, CalendarCheck, CalendarRange, Check, ChevronDown, Loader2, ListChecks, Palette, Percent, Mic, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand } from "@/components/fx";
import { useHotel } from "@/components/hotel-context";
import { useToast } from "@/hooks/use-toast";
import {
  FX_THEMES,
  activeThemeId,
  applyTheme,
  currentAccount,
  type FxTheme,
  type FxThemeId,
} from "@/lib/fx-themes";
import { TASK_FAB_EVENT, TASK_FAB_KEY } from "@/components/task-tracker";
import { VoicePickerModal, VoicePickerTrigger } from "@/components/voice-picker-modal";
import { loadVoices, pickDefaultVoice, readStoredVoice, toFxVoices, type FxVoice } from "@/lib/voice";
import { getAiNameOrDefault, writeStoredAiName } from "@/lib/ai-name";
import { useCachedToggle } from "@/lib/view-state-cache";
import { RoomLevelsEditor } from "@/components/room-levels-editor";
import { useRegisterScreen } from "@/lib/screen-context";

/* one REAL screenshot cell — framed card, caption BELOW (like the reference),
   own motion, own dot; light shots framed in the theme's light surf, dark
   shots in the dark surf, captions always on the block's tinted page */
function ShotBlock({
  caption,
  dot,
  delay,
  testid,
  src,
  alt,
  surf,
  line,
  ink,
}: {
  caption: string;
  dot: string;
  delay: number;
  testid: string;
  src: string;
  alt: string;
  surf: string;
  line: string;
  ink: string;
}) {
  return (
    <figure
      className="fx-pop-in rounded-lg p-1"
      style={{ background: surf, border: `1px solid ${line}`, animationDelay: `${delay}ms` }}
      data-testid={testid}
    >
      {/* t112 — no-crop thumb (user: "cut in half due to less height"): one
          8:5 frame + object-contain shows the WHOLE page shot every time */}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        className="block w-full rounded-md object-contain"
        style={{ aspectRatio: "8 / 5", border: `1px solid ${line}` }}
      />
      <figcaption className="fx-label !text-[6.5px] !tracking-normal mt-0.5 flex items-center justify-center gap-1" style={{ color: ink }}>
        <i className="h-1 w-1 shrink-0 rounded-full" style={{ background: dot }} aria-hidden />
        {caption}
      </figcaption>
    </figure>
  );
}

/* ── one theme = ONE full-width ROW in the vertical stack of themes ── */

function ThemeCard({ t, active, index, onSelect }: { t: FxTheme; active: boolean; index: number; onSelect: () => void }) {
  return (
    <div
      className="fx-card fx-pop-in rounded-xl border p-2 shadow-[2px_3px_0_0_var(--fx-hard)]"
      style={{
        animationDelay: `${Math.min(index, 6) * 60}ms`,
        background: t.light.page,
        borderColor: active ? "var(--fx-purple)" : t.light.line,
      }}
      data-testid={`settings-theme-${t.id}`}
      aria-pressed={active}
      role="button"
      tabIndex={0}
      onClick={onSelect}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect();
        }
      }}
    >
      {/* theme header — one inline row for the full-width block: dots + title left, chip right */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-2">
          <span className="flex items-center -space-x-1">
            <i className="h-3 w-3 rounded-full border" style={{ background: t.light.a, borderColor: t.light.surf }} />
            <i className="h-3 w-3 rounded-full border" style={{ background: t.light.bHi, borderColor: t.light.surf }} />
          </span>
          <span className="flex items-center gap-1 text-[10px] font-extrabold leading-tight" style={{ color: t.light.ink }}>
            {t.name}
            {active && <Check className="h-3 w-3 shrink-0" style={{ color: t.light.aInk }} aria-label="Active theme" />}
          </span>
        </span>
        <span
          className="rounded-full px-1.5 py-0.5 text-[6.5px] font-extrabold tracking-widest"
          style={active ? { background: t.light.a, color: t.light.onA } : { background: t.light.lav, color: t.light.aInk }}
        >
          {active ? "ACTIVE" : "TAP TO APPLY"}
        </span>
      </div>

      {/* the 4-across strip — four REAL screenshots in ONE row, flowing LEFT → RIGHT */}
      <div className="mt-1.5 grid grid-cols-4 gap-1.5">
        <ShotBlock
          caption="PRE-LOGIN · LIGHT"
          dot={t.light.a}
          delay={0}
          testid={`settings-theme-${t.id}-light-prelogin`}
          src={`/theme-previews/${t.id}-light-prelogin.jpg`}
          alt={`${t.name} — pre-login page, light mode`}
          surf={t.light.surf}
          line={t.light.line}
          ink={t.light.muted}
        />
        <ShotBlock
          caption="DASHBOARD · LIGHT"
          dot={t.light.bHi}
          delay={70}
          testid={`settings-theme-${t.id}-light-dashboard`}
          src={`/theme-previews/${t.id}-light-dashboard.jpg`}
          alt={`${t.name} — live dashboard, light mode`}
          surf={t.light.surf}
          line={t.light.line}
          ink={t.light.muted}
        />
        <ShotBlock
          caption="PRE-LOGIN · DARK"
          dot={t.dark.a}
          delay={140}
          testid={`settings-theme-${t.id}-dark-prelogin`}
          src={`/theme-previews/${t.id}-dark-prelogin.jpg`}
          alt={`${t.name} — pre-login page, dark mode`}
          surf={t.dark.surf}
          line={t.dark.line}
          ink={t.light.muted}
        />
        <ShotBlock
          caption="DASHBOARD · DARK"
          dot={t.dark.bHi}
          delay={210}
          testid={`settings-theme-${t.id}-dark-dashboard`}
          src={`/theme-previews/${t.id}-dark-dashboard.jpg`}
          alt={`${t.name} — live dashboard, dark mode`}
          surf={t.dark.surf}
          line={t.dark.line}
          ink={t.light.muted}
        />
      </div>
    </div>
  );
}

export function SettingsView({
  roleName,
  onThemeApplied,
}: {
  roleName: string;
  /** t124 — fired after a theme lands: the shell bounces the account to its home screen */
  onThemeApplied?: () => void;
}) {
  useRegisterScreen("settings", "Settings", null);
  const { toast } = useToast();
  const { hotelName, saveHotelName } = useHotel();
  const [nameDraft, setNameDraft] = React.useState<string | null>(null);
  const [saving, setSaving] = React.useState(false);
  const [theme, setTheme] = React.useState<FxThemeId>("classic");
  /* t124 — the gallery lives contracted; the header row expands it */
  const [themesOpen, setThemesOpen] = React.useState(false);
  /* t118 — the floating task tracker's on/off switch (all three accounts) */
  const [taskFab, setTaskFab] = React.useState(true);
  /* t126 — the paid holidays limit (owner only): loaded from the server, saved to it */
  const [holCurrent, setHolCurrent] = React.useState(3);
  const [holDraft, setHolDraft] = React.useState("3");
  const [holSaving, setHolSaving] = React.useState(false);
  /* t143 — the discount limit % (owner only): loaded from the server, saved to it */
  const [discCurrent, setDiscCurrent] = React.useState(10);
  const [discDraft, setDiscDraft] = React.useState("10");
  const [discSaving, setDiscSaving] = React.useState(false);
  /* t147 — AI VOICE: per-account TTS voice for live talk. Opens a picker
     modal listing every voice the platform offers. */
  const [voiceOpen, setVoiceOpen] = React.useState(false);
  const [curVoice, setCurVoice] = React.useState<FxVoice | null>(null);
  /* t166 — AI NAME: per-account custom name for the AI copilot. The AI
     introduces itself with this name and uses it in its persona. */
  const [aiNameDraft, setAiNameDraft] = React.useState<string | null>(null);
  const [aiNameSaving, setAiNameSaving] = React.useState(false);

  React.useEffect(() => {
    let dead = false;
    loadVoices().then((vs) => {
      if (dead) return;
      const fx = toFxVoices(vs);
      const stored = readStoredVoice(currentAccount());
      const found = stored ? fx.find((v) => v.voiceURI === stored) : null;
      setCurVoice(found ?? pickDefaultVoice(fx));
    });
    // t166 — load the current AI name from localStorage
    setAiNameDraft(getAiNameOrDefault(currentAccount()));
    return () => { dead = true; };
  }, []);

  React.useEffect(() => {
    setTheme(activeThemeId());
    const on = () => setTheme(activeThemeId());
    window.addEventListener("fx-theme-change", on);
    setTaskFab(localStorage.getItem(TASK_FAB_KEY) !== "0");
    return () => window.removeEventListener("fx-theme-change", on);
  }, []);

  /* t126 — pull the stored paid holidays limit once (t143 — and the discount limit) */
  React.useEffect(() => {
    if (roleName !== "OWNER") return;
    fetch("/api/settings")
      .then((x) => x.json())
      .then((s) => {
        const n = Math.floor(Number(s?.paidHolidayLimit));
        const safe = Number.isFinite(n) && n >= 0 ? Math.min(n, 31) : 3;
        setHolCurrent(safe);
        setHolDraft(String(safe));
        const dn = Math.floor(Number(s?.discountLimit));
        const safeD = Number.isFinite(dn) && dn >= 0 ? Math.min(dn, 100) : 10;
        setDiscCurrent(safeD);
        setDiscDraft(String(safeD));
      })
      .catch(() => {
        /* the defaults of 3 holidays / 10% stand */
      });
  }, [roleName]);

  const flipTaskFab = (on: boolean) => {
    setTaskFab(on);
    try {
      localStorage.setItem(TASK_FAB_KEY, on ? "1" : "0");
    } catch {
      /* private mode */
    }
    window.dispatchEvent(new Event(TASK_FAB_EVENT));
  };

  /* t124 — apply + bounce home: the toast tells the account where it landed */
  const activeTheme = FX_THEMES.find((t) => t.id === theme) ?? FX_THEMES[0];
  const chooseTheme = (t: FxTheme) => {
    applyTheme(t.id, currentAccount());
    setTheme(t.id);
    toast({ title: `${t.name} applied — back to your home page` });
    onThemeApplied?.();
  };

  const nameValue = nameDraft ?? hotelName;
  const nameDirty = nameValue.trim() !== hotelName && nameValue.trim().length >= 2;

  /* t126 — persist the paid holidays limit (owner only) */
  const holDirty = holDraft.trim() !== "" && Number(holDraft) !== holCurrent;
  const saveHol = async () => {
    const n = Math.floor(Number(holDraft));
    if (!Number.isFinite(n) || n < 0 || n > 31) {
      toast({
        title: "Could not save the limit",
        description: "The limit must be a whole number between 0 and 31.",
        variant: "destructive",
      });
      return;
    }
    setHolSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paidHolidayLimit: n }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Request failed");
      setHolCurrent(n);
      setHolDraft(String(n));
      toast({ title: `Paid holidays limit set to ${n} ✅` });
    } catch (e) {
      toast({
        title: "Could not save the limit",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setHolSaving(false);
    }
  };

  /* t143 — persist the discount limit % (owner only) */
  const discDirty = discDraft.trim() !== "" && Number(discDraft) !== discCurrent;
  const saveDisc = async () => {
    const n = Math.floor(Number(discDraft));
    if (!Number.isFinite(n) || n < 0 || n > 100) {
      toast({
        title: "Could not save the limit",
        description: "The limit must be a whole number between 0 and 100.",
        variant: "destructive",
      });
      return;
    }
    setDiscSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ discountLimit: n }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Request failed");
      setDiscCurrent(n);
      setDiscDraft(String(n));
      toast({ title: `Discount limit set to ${n}% ✅` });
    } catch (e) {
      toast({
        title: "Could not save the limit",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setDiscSaving(false);
    }
  };

  const saveName = async () => {
    setSaving(true);
    const ok = await saveHotelName(nameValue);
    setSaving(false);
    if (ok) {
      setNameDraft(null);
      toast({ title: `Name updated — every screen now says “${nameValue.trim()}”` });
    } else {
      toast({
        title: "Could not rename",
        description: "Name needs at least 2 characters.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-5" data-testid="settings-view">
      <TierBand
        num={FX_TIERS.settings.num}
        eyebrow={tierEyebrow(FX_TIERS.settings)}
        title="Settings" data-tip="Settings"
        sub="Make the console yours — the ten themes stay CONTRACTED behind one header row until you tap it open; each theme stacks ONE per row with its four REAL page screenshots flowing left to right (pre-login and live dashboard, light and dark) in the combo's real colours. Picking a theme drops you straight back on your home screen — Live Dashboard, POS Billing or Lodge Front Desk. The tenant rename flows onto every screen; the Fetch-X platform brand stays fixed."
        tag={`${FX_THEMES.length} THEMES · TAP TO EXPAND · PICK → HOME`}
      />

      {/* ── t124 THEMES — CONTRACTED behind one row; expand on click; pick → home ──
          t146 — expand now opens a POPUP MODAL with blurred backdrop (same
          pattern as the landing login modal) instead of an inline expand. */}
      <div className="fx-card p-5" data-testid="settings-themes">
        <button
          onClick={() => setThemesOpen(true)}
          aria-expanded={themesOpen}
          data-testid="settings-themes-toggle"
          className="flex w-full flex-wrap items-center justify-between gap-2 text-left"
        >
          <span className="fx-label inline-flex items-center gap-2">
            <Palette className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            THEMES · TAP TO OPEN GALLERY
          </span>
          <span className="flex items-center gap-2">
            <span className="mut-chip inline-flex items-center gap-1.5">
              ACTIVE · {activeTheme.name.toUpperCase()}
            </span>
            <ChevronDown
              className={`h-4 w-4 shrink-0 text-[var(--fx-muted)] transition-transform duration-200`}
            />
          </span>
        </button>
        <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          Tap the row above to open the theme gallery in a pop-up — {FX_THEMES.length} themes, four
          real page screenshots each. Picking one applies it to this account and drops you straight
          back on your home screen. Remembered per account.
        </p>
      </div>

      {/* t146 — THEME GALLERY MODAL: blurred backdrop + scrollable card stack */}
      {themesOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Theme gallery"
          onMouseDown={(e) => { if (e.target === e.currentTarget) setThemesOpen(false); }}
          className="fixed inset-0 z-50 grid place-items-center bg-[rgba(23,20,50,.45)] p-4 backdrop-blur-sm"
        >
          <div className="fx-card fx-pop-in w-full max-w-[920px] p-5 md:p-6" data-fx-motion="1">
            {/* header */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
                  <Palette className="h-4 w-4" />
                </span>
                <div>
                  <div className="text-[16px] font-extrabold tracking-tight text-[var(--fx-ink)]">Theme Gallery</div>
                  <div className="text-[11px] font-semibold text-[var(--fx-muted)]">
                    {FX_THEMES.length} themes · one per row · 4 real page screenshots each
                  </div>
                </div>
              </div>
              <button
                onClick={() => setThemesOpen(false)}
                aria-label="Close theme gallery"
                className="inline-flex h-9 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[11px] font-extrabold tracking-[0.1em] text-[var(--fx-muted)] shadow-[2px_2px_0_0_var(--fx-hard)] transition hover:text-[var(--fx-ink)]"
              >
                CLOSE <ChevronDown className="h-3.5 w-3.5 rotate-180" />
              </button>
            </div>

            {/* gallery — scrollable */}
            <div className="mt-4 max-h-[70vh] overflow-y-auto pr-1">
              <div className="grid grid-cols-1 gap-4">
                {FX_THEMES.map((t, i) => (
                  <ThemeCard key={t.id} t={t} active={t.id === theme} index={i} onSelect={() => chooseTheme(t)} />
                ))}
              </div>
              <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
                Tap a block to apply that theme to this account — every shot is a real page screenshot
                in that theme&apos;s colours. Applying drops you straight back on your home screen —
                the Live Dashboard for the owner, POS Billing for the restaurant reception, Lodge
                Front Desk for the lodge reception.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ── t118 — FLOATING TASK TRACKER — the on/off switch (every account) ── */}
      <div className="fx-card p-5" data-testid="settings-task-fab">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <ListChecks className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            FLOATING TASK TRACKER
          </span>
          <button
            onClick={() => flipTaskFab(!taskFab)}
            aria-pressed={taskFab}
            data-testid="task-fab-toggle"
            className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] transition ${
              taskFab
                ? "bg-[var(--fx-green)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${taskFab ? "bg-[var(--fx-surf)]" : "bg-[var(--fx-muted)]"}`} aria-hidden />
            {taskFab ? "SHOWING · TAP TO HIDE" : "HIDDEN · TAP TO SHOW"}
          </button>
        </div>
        <p className="mt-3 text-[10.5px] font-semibold leading-relaxed text-[var(--fx-muted)]">
          The pocket version of the Tasks section — a compact 56×56 icon button floats over every
          screen on the RIGHT side (just above the AI button for the owner — AI stays owner-only;
          the receptions take the corner themselves), wearing its open-work count as an
          Android-style notification badge on the top-right corner. Inside, a TODAY · 3 · 7 · 15
          DAYS window toggle decides what the badge counts, and it taps into the full board. Turn
          it off and the button disappears everywhere; turn it back on here. Remembered per
          browser, for all three accounts.
        </p>
      </div>

      {/* ── t194 — ROOM LEVELS EDITOR (moved from Lodge/Rooms Overview) ── */}
      {/* t194 — ROOM LEVELS EDITOR (owner only) */}
      {roleName === "OWNER" && <RoomLevelsEditor />}

      {/* t193 — CUSTOM DATE RANGE (owner only) */}
      {roleName === "OWNER" && <DateRangeSection />}

      {/* ── t166 — AI NAME — customize what the AI calls itself (every account) ── */}
      <div className="fx-card p-5" data-testid="settings-ai-name">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <Bot className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            AI NAME · WHAT THE AI CALLS ITSELF
          </span>
        </div>
        <div className="mt-3 flex items-center gap-2">
          <Input
            value={aiNameDraft ?? ""}
            onChange={(e) => setAiNameDraft(e.target.value)}
            placeholder="Fetch-X"
            maxLength={40}
            aria-label="AI name"
            data-testid="ai-name-input"
            className="h-11 min-w-0 flex-1"
          />
          <Button
            onClick={() => {
              const name = (aiNameDraft ?? "").trim() || "Fetch-X";
              setAiNameSaving(true);
              writeStoredAiName(name, currentAccount());
              setTimeout(() => setAiNameSaving(false), 600);
              toast({ title: "AI name saved", description: `The AI will now introduce itself as "${name}".` });
            }}
            disabled={aiNameSaving || !aiNameDraft || aiNameDraft.trim() === getAiNameOrDefault(currentAccount())}
            data-testid="ai-name-save"
            className="h-11 shrink-0 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {aiNameSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : "SAVE"}
          </Button>
        </div>
        <p className="mt-3 text-[10.5px] font-semibold leading-relaxed text-[var(--fx-muted)]">
          When you open the AI panel, it will greet you: <i>"Hello, I am [name] — your personal
          assistant for your business. How may I help you today?"</i> The AI also uses this name
          in its replies and during live talk. Default is "Fetch-X". Remembered per account.
        </p>
      </div>

      {/* ── t147 — AI VOICE — pick the TTS voice for live talk (every account) ── */}
      <div className="fx-card p-5" data-testid="settings-ai-voice">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <Mic className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            AI VOICE · FOR LIVE TALK
          </span>
          <VoicePickerTrigger current={curVoice} onOpen={() => setVoiceOpen(true)} />
        </div>
        <p className="mt-3 text-[10.5px] font-semibold leading-relaxed text-[var(--fx-muted)]">
          The voice the AI uses to read its reply out loud during Live Talk. Tap the chip to open a
          pop-up listing every voice your browser offers — male and female, Microsoft David on
          Windows, Google voices on Android Chrome, Apple voices on iOS, and any extra voice your OS
          has installed. Each row has a SAMPLE button to hear it. The pick is remembered per account.
        </p>
      </div>

      {/* t147 — voice picker modal (same popup as the one in the AI panel header) */}
      <VoicePickerModal
        open={voiceOpen}
        onClose={() => setVoiceOpen(false)}
        account={currentAccount()}
        onPick={(v) => setCurVoice(v)}
      />

      {/* ── t126 — PAID HOLIDAYS LIMIT — the one salary rule the owner sets ── */}
      {roleName === "OWNER" && (
        <div className="fx-card p-5" data-testid="settings-holiday-limit">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="fx-label inline-flex items-center gap-2">
              <CalendarCheck className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
              PAID HOLIDAYS LIMIT · SALARY RULE
            </span>
            <span className="mut-chip">ATTENDANCE STAYS DERIVED FROM THE RECEPTIONS' REGISTER</span>
          </div>
          <div className="mt-3 flex max-w-[520px] items-center gap-2">
            <Input
              value={holDraft}
              onChange={(e) => setHolDraft(e.target.value.replace(/[^\d]/g, ""))}
              onKeyDown={(e) => {
                if (e.key === "Enter" && holDirty) void saveHol();
              }}
              inputMode="numeric"
              placeholder="3"
              aria-label="Paid holidays limit per employee per month"
              data-testid="settings-holiday-input"
              className="fx-num h-10 min-w-0 flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
            <Button
              onClick={() => void saveHol()}
              disabled={holSaving || !holDirty}
              data-testid="settings-holiday-save"
              className="h-10 shrink-0 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
            >
              {holSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              SAVE LIMIT
            </Button>
          </div>
          <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
            Every employee gets this many paid holidays a month before absences start cutting pay —
            the cut is (absent days − this limit) × per-day wage. The owner cannot hand-edit attendance
            or per-person holidays anywhere: present/absent comes only from what the receptions mark,
            and this limit is the single lever. Currently {holCurrent} per month (0–31 allowed).
          </p>
        </div>
      )}

      {/* ── t143 — DISCOUNT LIMIT · BILL RULE — what the receptions may shave off a bill ── */}
      {roleName === "OWNER" && (
        <div className="fx-card p-5" data-testid="settings-discount-limit">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="fx-label inline-flex items-center gap-2">
              <Percent className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
              DISCOUNT LIMIT · BILL RULE
            </span>
            <span className="mut-chip">RECEPTIONS CANNOT EXCEED THIS ON ANY BILL</span>
          </div>
          <div className="mt-3 flex max-w-[520px] items-center gap-2">
            <Input
              value={discDraft}
              onChange={(e) => setDiscDraft(e.target.value.replace(/[^\d]/g, ""))}
              onKeyDown={(e) => {
                if (e.key === "Enter" && discDirty) void saveDisc();
              }}
              inputMode="numeric"
              placeholder="10"
              aria-label="Maximum discount the receptions may give, percent of the bill"
              data-testid="settings-discount-input"
              className="fx-num h-10 min-w-0 flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
            <span className="fx-num shrink-0 text-[12px] font-extrabold text-[var(--fx-muted)]">%</span>
            <Button
              onClick={() => void saveDisc()}
              disabled={discSaving || !discDirty}
              data-testid="settings-discount-save"
              className="h-10 shrink-0 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
            >
              {discSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              SAVE LIMIT
            </Button>
          </div>
          <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
            When the restaurant counter or the lodge front desk types a discount, it is clamped to at
            most this % of that bill's value — the input refuses anything higher and the bill APIs
            re-check it server-side. You set the one number here; every discount input in the app
            follows it instantly. Currently {discCurrent}% of the bill (0–100 allowed).
          </p>
        </div>
      )}

      {/* ── PROFILE — the tenant name change ── */}
      <div className="fx-card p-5" data-testid="settings-profile">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <UserRound className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
            PROFILE · {roleName}
          </span>
          <span className="mut-chip">FLOWS ONTO THE SIDEBAR, BILLS &amp; DASHBOARDS</span>
        </div>
        <div className="mt-3 flex max-w-[520px] items-center gap-2">
          <Input
            value={nameValue}
            onChange={(e) => setNameDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && nameDirty) void saveName();
            }}
            placeholder="Display name…"
            aria-label="Display name"
            data-testid="settings-name-input"
            className="h-10 min-w-0 flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
          />
          <Button
            onClick={() => void saveName()}
            disabled={saving || !nameDirty}
            data-testid="settings-name-save"
            className="h-10 shrink-0 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
            SAVE NAME
          </Button>
        </div>
        <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          The name flows onto the sidebar, bills and dashboards — the Fetch-X platform brand stays
          fixed.
        </p>
      </div>
    </div>
  );
}

/* t194 — GLOBAL CUSTOM DATE RANGE with ON/OFF toggle.
 *
 * The owner asked: "do not make the user select custom dates in the live
 * dashboard itself, give a custom selector in the settings, and also a
 * toggle to turn it on/off, give the custom selector in live dashboard
 * itself if the custom selector is on, and if off, follow the one selected
 * in the settings."
 *
 * So:
 *   - The FROM/TO date pickers live HERE in Settings (never in the dashboard)
 *   - A toggle "Show CUSTOM tab in Dashboard/Tasks/Expenses" controls whether
 *     those views display the CUSTOM tab at all
 *   - When ON:  Dashboard/Tasks/Expenses show the CUSTOM tab. Clicking it
 *               loads data for the start→end window set here.
 *   - When OFF: the CUSTOM tab is hidden. Views just use their standard
 *               range tabs (today/7d/1m/3m/1y/3y/lifetime).
 */
function DateRangeSection() {
  const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const [customStart, setCustomStart] = useCachedToggle<string>("global", "customStart", "2020-01-01");
  const [customEnd, setCustomEnd] = useCachedToggle<string>("global", "customEnd", todayISO());
  // t194 — the master toggle. When false, Dashboard/Tasks/Expenses hide
  // their CUSTOM tab entirely.
  const [useCustom, setUseCustom] = useCachedToggle<boolean>("global", "useCustomRange", false);
  const days = Math.max(1, Math.round((new Date(customEnd).getTime() - new Date(customStart).getTime()) / 86_400_000) + 1);
  return (
    <div className="fx-card overflow-hidden" data-testid="settings-custom-range">
      {/* Header row — title + ON/OFF toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/40 px-5 py-3.5">
        <span className="fx-label inline-flex items-center gap-2">
          <CalendarRange className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
          CUSTOM DATE RANGE
        </span>
        <button
          onClick={() => setUseCustom(!useCustom)}
          aria-pressed={useCustom}
          data-testid="custom-range-toggle"
          className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] transition ${
            useCustom
              ? "bg-[var(--fx-green)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
              : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
          }`}
        >
          <span className={`h-2 w-2 rounded-full ${useCustom ? "bg-[var(--fx-surf)]" : "bg-[var(--fx-muted)]"}`} aria-hidden />
          {useCustom ? "ON · DATE PICKER IN DASHBOARD" : "OFF · DATES PRE-SET HERE ONLY"}
        </button>
      </div>

      {/* Date pickers — always visible (so the owner can pre-set the range
          even when the toggle is off). But the range only takes effect when
          the toggle is ON. */}
      <div className="p-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="rounded-full bg-[var(--fx-lav)] px-3 py-1.5 text-[10px] font-extrabold text-[var(--fx-muted)]">
            {days.toLocaleString("en-IN")} DAYS · {customStart} → {customEnd}
          </span>
        </div>
        <p className="mt-3 text-[10.5px] font-semibold leading-relaxed text-[var(--fx-muted)]">
          Pick the start and end dates here — they're always pre-set. The <strong>CUSTOM</strong> tab is
          always visible in Dashboard, Tasks, and Expenses. When the toggle is <strong>ON</strong>,
          clicking the CUSTOM tab shows inline date pickers right there in the dashboard. When
          <strong>OFF</strong>, the CUSTOM tab just uses the dates you set here (no inline pickers).
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 py-2 shadow-[2px_2px_0_0_var(--fx-hard)]">
            <span className="fx-label whitespace-nowrap">FROM</span>
            <input
              type="date"
              value={customStart}
              min="2020-01-01"
              max={customEnd}
              onChange={(e) => setCustomStart(e.target.value)}
              aria-label="Custom start date"
              className="bg-transparent text-[13px] font-bold text-[var(--fx-ink)] outline-none [color-scheme:light] dark:[color-scheme:dark]"
              style={{ fontSize: "13px", width: "140px" }}
            />
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 py-2 shadow-[2px_2px_0_0_var(--fx-hard)]">
            <span className="fx-label whitespace-nowrap">TO</span>
            <input
              type="date"
              value={customEnd}
              min={customStart}
              max={todayISO()}
              onChange={(e) => setCustomEnd(e.target.value)}
              aria-label="Custom end date"
              className="bg-transparent text-[13px] font-bold text-[var(--fx-ink)] outline-none [color-scheme:light] dark:[color-scheme:dark]"
              style={{ fontSize: "13px", width: "140px" }}
            />
          </div>
        </div>
        {!useCustom && (
          <p className="mt-3 rounded-xl bg-[var(--fx-amber)]/10 px-3 py-2 text-[10.5px] font-bold text-[var(--fx-amber)]">
            ⚠ Inline date pickers are hidden in the dashboard. The CUSTOM tab still shows — it uses
            the dates set above. Turn the toggle ON to show pickers in the dashboard too.
          </p>
        )}
      </div>
    </div>
  );
}
