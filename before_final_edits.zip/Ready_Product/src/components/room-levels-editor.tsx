"use client";

// ── t98 · ROOMS & RATES — the level categorizer, relocated ──────────────────
// Picked out of Management and pasted at the bottom of the Lodge Front Desk
// so the wall's own station edits its own levels. Same logic as before: name
// each level, set its room range and the 24-hour charge; ranges must cover
// every room exactly once (start at 1, end at the wall's max, no gaps or
// overlaps).
// t116 — the wall's MAX ROOMS is flexible: grow it anytime (new rooms arrive
// green), but a reduce only lands once every room being cut is FREE — until
// then the apply stays locked and the wait panel names the busy rooms.

import * as React from "react";
import { BedDouble, Loader2, Plus, Save } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { DEFAULT_LEVELS, LG_ROOMS, LG_ROOMS_MAX, LG_ROOMS_MIN, type Level } from "@/lib/lodge";
import type { Room } from "@/lib/types";

export function RoomLevelsEditor() {
  const { toast } = useToast();

  const [levels, setLevels] = React.useState<Level[] | null>(null);
  const [levelsDraft, setLevelsDraft] = React.useState<Array<{ name: string; from: string; to: string; rate: string }>>([]);
  const [levelsBusy, setLevelsBusy] = React.useState(false);
  const [armedRemove, setArmedRemove] = React.useState<number | null>(null);
  // t194 — 10-second warning/lock before applying level changes (like dish/employee delete)
  const [applyArmed, setApplyArmed] = React.useState(false);
  const [applyCountdown, setApplyCountdown] = React.useState(0);
  // t195 — read-only by default. EDIT unlocks fields. APPLY CHANGES → confirm popup.
  const [editMode, setEditMode] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  // t116 — the flexible wall size
  const [maxRooms, setMaxRooms] = React.useState<number>(LG_ROOMS);
  const [maxDraft, setMaxDraft] = React.useState<string>(String(LG_ROOMS));
  const [maxBusy, setMaxBusy] = React.useState(false);
  const [rooms, setRooms] = React.useState<Room[]>([]);

  const loadLevels = React.useCallback(async () => {
    try {
      const w = await fetch("/api/lodge", { cache: "no-store" }).then((x) => x.json());
      const lv: Level[] = Array.isArray(w.levels) && w.levels.length ? w.levels : DEFAULT_LEVELS;
      const mx = Math.round(Number(w.maxRooms));
      const live = Number.isFinite(mx) && mx > 0 ? mx : LG_ROOMS;
      setLevels(lv);
      setMaxRooms(live);
      setMaxDraft(String(live));
      setRooms(Array.isArray(w.rooms) ? w.rooms : []);
      setLevelsDraft(
        lv.map((l) => ({ name: l.name, from: String(l.from), to: String(l.to), rate: String(l.rate) })),
      );
    } catch {
      setLevels(null);
    }
  }, []);
  React.useEffect(() => {
    void loadLevels();
  }, [loadLevels]);

  // the wall breathes — re-check every minute so a reduce unlocks itself the
  // moment the rooms it wants to cut check out / finish maintenance
  React.useEffect(() => {
    const t = setInterval(() => void loadLevels(), 60000);
    return () => clearInterval(t);
  }, [loadLevels]);

  /* ── t116 · max-rooms guard — which rooms block a reduce right now ── */
  const newMax = Math.round(Number(maxDraft));
  const maxValid = Number.isFinite(newMax) && newMax >= LG_ROOMS_MIN && newMax <= LG_ROOMS_MAX;
  const cutBusy = React.useMemo(
    () =>
      maxValid && newMax < maxRooms
        ? rooms.filter((r) => r.number > newMax && r.status !== "avl").map((r) => ({ n: r.number, st: r.status }))
        : [],
    [rooms, newMax, maxRooms, maxValid],
  );
  const maxApplyable = maxValid && !maxBusy && cutBusy.length === 0;

  const applyMaxRooms = async () => {
    if (!maxApplyable) return;
    setMaxBusy(true);
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "max-rooms", maxRooms: newMax }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not change the wall size");
      toast({
        title: `Wall now runs room 1 – ${newMax}`,
        description:
          newMax > maxRooms
            ? "The new rooms joined the last level as free — the picker, tooltips and dashboard rebuilt."
            : "The cut rooms and their level boundary are gone — past bills keep their snapshots.",
      });
      window.dispatchEvent(new Event("fx-lodge-changed")); // t116 — the wall above rebuilds now
      await loadLevels();
    } catch (e) {
      toast({
        title: "Could not change the wall size",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
      await loadLevels();
    } finally {
      setMaxBusy(false);
    }
  };

  const setLvlAt = (i: number, patch: Partial<{ name: string; from: string; to: string; rate: string }>) =>
    setLevelsDraft((m) => m.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const levelsCheck = (): { ok: boolean; msg: string | null; bad: Set<number> } => {
    const bad = new Set<number>();
    const rows = levelsDraft.map((r) => ({
      name: r.name.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: Math.round(Number(r.to)),
      rate: Math.round(Number(r.rate)),
      i: 0,
    }));
    if (!rows.length) return { ok: false, msg: "Add at least one level.", bad };
    rows.forEach((r, i) => {
      r.i = i;
      if (!r.name) bad.add(i);
      if (!Number.isFinite(r.rate) || r.rate < 100) bad.add(i);
      if (!Number.isFinite(r.from) || !Number.isFinite(r.to) || r.from < 1 || r.to > maxRooms || r.from > r.to)
        bad.add(i);
    });
    const sorted = [...rows].sort((a, b) => a.from - b.from);
    let msg: string | null = null;
    if (sorted.some((r) => bad.has(r.i))) {
      msg = `Fix the highlighted rows — every level needs a name, a rate of at least ₹100, and a low → high range inside 1 – ${maxRooms}.`;
    } else {
      for (let j = 1; j < sorted.length; j++) {
        const prev = sorted[j - 1];
        const cur = sorted[j];
        if (cur.from <= prev.to) {
          bad.add(prev.i);
          bad.add(cur.i);
          msg = `OVERLAP — "${prev.name}" and "${cur.name}" both claim rooms ${cur.from}–${Math.min(prev.to, cur.to)}. No two levels may share a room.`;
          break;
        }
        if (cur.from > prev.to + 1) {
          bad.add(prev.i);
          bad.add(cur.i);
          msg = `GAP — rooms ${prev.to + 1}–${cur.from - 1} belong to no level. Extend "${prev.name}" or "${cur.name}" to cover them.`;
          break;
        }
      }
      if (!msg) {
        if (sorted[0].from !== 1) {
          bad.add(sorted[0].i);
          msg = `The first level must start at room 1 — it starts at ${sorted[0].from}.`;
        } else if (sorted[sorted.length - 1].to !== maxRooms) {
          bad.add(sorted[sorted.length - 1].i);
          msg = `The last level must end at room ${maxRooms} — it ends at ${sorted[sorted.length - 1].to}.`;
        } else {
          const names = rows.map((r) => r.name);
          if (new Set(names).size !== names.length) {
            rows.forEach((r, i) => {
              if (names.indexOf(r.name) !== i) bad.add(i);
            });
            msg = "Two levels share a name — rename one.";
          }
        }
      }
    }
    return { ok: !msg, msg, bad };
  };
  const lvCheck = levelsCheck();

  // t195 — 10-second LOCK. The CONFIRM button stays DISABLED for 10s
  // (matching the dish-delete pattern). At 0, the button unlocks — user must
  // click it. No auto-apply.
  React.useEffect(() => {
    if (!showConfirm || applyCountdown <= 0) return;
    const t = setTimeout(() => setApplyCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [showConfirm, applyCountdown]);
  const confirmLocked = applyCountdown > 0;

  const startApply = () => {
    if (!lvCheck.ok || levelsBusy) return;
    setShowConfirm(true);
    setApplyArmed(true);
    setApplyCountdown(10);
  };

  const cancelApply = () => {
    setShowConfirm(false);
    setApplyArmed(false);
    setApplyCountdown(0);
  };

  const cancelEdit = () => {
    setEditMode(false);
    setShowConfirm(false);
    setApplyArmed(false);
    setApplyCountdown(0);
    // Reload the saved levels (discard draft changes)
    void loadLevels();
  };

  const applyLevels = async () => {
    if (!lvCheck.ok || levelsBusy) return;
    const payload = levelsDraft.map((r) => ({
      name: r.name.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: Math.round(Number(r.to)),
      rate: Math.round(Number(r.rate)),
    }));
    setLevelsBusy(true);
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "levels-apply", levels: payload }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Apply failed");
      setLevels(out.levels ?? payload);
      window.dispatchEvent(new Event("fx-lodge-changed")); // t116 — the wall above rebuilds now
      toast({
        title: `Levels applied — ${payload.length} across ${maxRooms} rooms`,
        description: "The wall, check-in picker, tooltips and the dashboard's revenue-by-level all rebuild.",
      });
    } catch (e) {
      toast({
        title: "Could not apply levels",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setLevelsBusy(false);
    }
  };

  const addLevel = () => {
    if (levelsDraft.length >= 8) {
      toast({ title: "Eight levels is plenty", description: "Split further only if the wall really needs it." });
      return;
    }
    let wi = 0;
    let w = 0;
    levelsDraft.forEach((t, i) => {
      const sz = (Number(t.to) || 0) - (Number(t.from) || 0) + 1;
      if (sz > w) {
        w = sz;
        wi = i;
      }
    });
    if (w < 2) {
      toast({ title: "Nothing left to split", description: "Every level is a single room — remove one instead." });
      return;
    }
    const t = levelsDraft[wi];
    const mid = Math.round(Number(t.from)) + Math.ceil(w / 2) - 1;
    setLevelsDraft((m) => {
      const copy = [...m];
      copy.splice(
        wi,
        1,
        { name: `${t.name} A`, from: t.from, to: String(mid), rate: t.rate },
        { name: `${t.name} B`, from: String(mid + 1), to: t.to, rate: t.rate },
      );
      return copy;
    });
    toast({ title: "Level split — apply to save", description: "Rename both halves and set their charges, then APPLY LEVELS." });
  };

  const removeLevel = (i: number) => {
    setLevelsDraft((m) => {
      const copy = [...m];
      const gone = copy.splice(i, 1)[0];
      if (copy.length) {
        if (copy[i - 1]) copy[i - 1].to = gone.to; // merge into the previous neighbour
        else copy[0].from = gone.from; // first level merges forward into the next
      }
      return copy;
    });
  };

  return (
    <div className="fx-card fx-rise p-5" data-testid="room-levels-editor" data-fx-motion="1">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          <BedDouble className="h-3.5 w-3.5" /> ROOMS &amp; RATES · THE LEVEL CATEGORIZER
        </span>
        <div className="flex items-center gap-2">
          <span className="mut-chip">
            {maxRooms} ROOMS · {levels?.length ?? "–"} LEVELS
          </span>
          {!editMode && (
            <Button
              onClick={() => setEditMode(true)}
              className="h-8 rounded-xl bg-[var(--fx-purple)] px-4 text-[10px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
            >
              EDIT
            </Button>
          )}
          {editMode && (
            <Button
              onClick={cancelEdit}
              className="h-8 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            >
              CANCEL EDIT
            </Button>
          )}
        </div>
      </div>

      {/* ── READ-ONLY mode: show levels as static text ── */}
      {!editMode && levels && (
        <div className="mt-3 space-y-1.5">
          {levels.map((lv, i) => (
            <div key={i} className="flex items-center gap-2 rounded-xl bg-[var(--fx-lav)]/40 px-3 py-2">
              <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${i % 3 === 0 ? "bg-[var(--fx-green)]" : i % 3 === 1 ? "bg-[#f97316]" : "bg-[var(--fx-purple)]"}`} aria-hidden />
              <span className="min-w-[100px] flex-1 text-[13px] font-extrabold text-[var(--fx-ink)]">{lv.name}</span>
              <span className="text-[11px] font-bold text-[var(--fx-muted)]">ROOMS {lv.from} – {lv.to}</span>
              <span className="text-[11px] font-extrabold text-[var(--fx-accent-ink)]">₹{lv.rate.toLocaleString("en-IN")} / 24 H</span>
            </div>
          ))}
          <p className="mt-2 text-[10px] font-semibold text-[var(--fx-muted)]">
            Press EDIT to modify level names, room ranges, or rates. Changes require a confirmation popup + 10s lock before going live.
          </p>
        </div>
      )}

      {/* ── EDIT mode: editable inputs + ADD/REMOVE + APPLY CHANGES ── */}
      {editMode && (
        <>
          <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
            Name each level, set its room range and the 24-hour charge. Ranges must cover every room
            exactly once: start at room 1, end at room {maxRooms}, no gaps or overlaps.
          </p>
          <div className="mt-3 flex flex-col gap-2">
            {levelsDraft.map((t, i) => {
              const bad = lvCheck.bad.has(i);
              return (
                <div key={i} className="flex flex-wrap items-center gap-2">
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${bad ? "bg-[var(--fx-rose)]" : i % 3 === 0 ? "bg-[var(--fx-green)]" : i % 3 === 1 ? "bg-[#f97316]" : "bg-[var(--fx-purple)]"}`} aria-hidden />
                  <Input value={t.name} onChange={(e) => setLvlAt(i, { name: e.target.value })} placeholder="Level name" aria-label={`Level ${i + 1} name`} className={`h-9 min-w-[120px] flex-[1.4] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <Input value={t.from} onChange={(e) => setLvlAt(i, { from: e.target.value })} type="number" min={1} aria-label={`Level ${i + 1} first room`} className={`fx-num h-9 w-[76px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <Input value={t.to} onChange={(e) => setLvlAt(i, { to: e.target.value })} type="number" min={1} aria-label={`Level ${i + 1} last room`} className={`fx-num h-9 w-[76px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <Input value={t.rate} onChange={(e) => setLvlAt(i, { rate: e.target.value })} type="number" min={0} aria-label={`Level ${i + 1} charge per 24 hours`} className={`fx-num h-9 w-[92px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">₹ / 24 H</span>
                  {levelsDraft.length > 1 && (armedRemove === i ? (
                    <Button size="sm" onClick={() => { removeLevel(i); setArmedRemove(null); }} className="h-9 rounded-xl bg-[var(--fx-rose)] px-3 text-[10px] font-extrabold tracking-wider text-white">SURE?</Button>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => setArmedRemove(i)} title="Merge this level into its neighbour" data-tip="Merge this level into its neighbour" className="h-9 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)]">REMOVE</Button>
                  ))}
                </div>
              );
            })}
          </div>
          {lvCheck.msg && (
            <p role="alert" className="mt-3 rounded-xl border border-[var(--fx-rose)]/40 bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold text-[var(--fx-rose)]">{lvCheck.msg}</p>
          )}

          {/* MAX ROOMS — only in edit mode */}
          <div className="mt-4 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] p-3.5" data-testid="max-rooms-box">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label">MAX ROOMS · THE WALL'S SIZE</span>
              <span className="mut-chip">GROW ANYTIME · REDUCE ONLY WHEN FREE</span>
            </div>
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              <Input value={maxDraft} onChange={(e) => setMaxDraft(e.target.value)} type="number" min={LG_ROOMS_MIN} max={LG_ROOMS_MAX} aria-label="Maximum room number" data-testid="max-rooms-input" className={`fx-num h-9 w-[112px] rounded-xl bg-[var(--fx-surf)] font-bold ${maxValid ? "border-[var(--fx-line)]" : "border-[var(--fx-rose)]"}`} />
              <Button onClick={() => void applyMaxRooms()} disabled={!maxApplyable} data-testid="max-rooms-apply" className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50">
                {maxBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} APPLY MAX ROOMS
              </Button>
              {maxValid && newMax > maxRooms && (<span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-green)]">+{newMax - maxRooms} NEW ROOMS ARRIVE FREE</span>)}
            </div>
            {maxValid && newMax < maxRooms && cutBusy.length > 0 && (
              <div role="alert" data-testid="max-rooms-wait" className="mt-2.5 rounded-xl border border-[var(--fx-rose)]/40 bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold leading-snug text-[var(--fx-rose)]">
                WAIT — {cutBusy.slice(0, 8).map((b) => `Room ${b.n} (${b.st === "occ" ? "occupied" : "maintenance"})`).join(", ")}{cutBusy.length > 8 ? ` +${cutBusy.length - 8} more` : ""} must be free first.
              </div>
            )}
            {maxValid && newMax < maxRooms && cutBusy.length === 0 && (
              <div className="mt-2.5 text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">SHRINKING BY {maxRooms - newMax} ROOMS</div>
            )}
            {!maxValid && (<div className="mt-2.5 text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">WALL RUNS {LG_ROOMS_MIN}–{LG_ROOMS_MAX} ROOMS</div>)}
          </div>

          {/* Action buttons */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button onClick={addLevel} className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-lav)]">
              <Plus className="h-3.5 w-3.5" /> ADD LEVEL
            </Button>
            <Button onClick={startApply} disabled={!lvCheck.ok || levelsBusy} className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50">
              {levelsBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} APPLY CHANGES
            </Button>
            {!lvCheck.ok && (<span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">FIX THE RANGES TO ENABLE APPLY</span>)}
          </div>
        </>
      )}

      {/* ── CONFIRM POPUP (modal dialog with 10s countdown) ── */}
      <Dialog open={showConfirm} onOpenChange={(o) => { if (!o) cancelApply(); }}>
        <DialogContent className="max-w-[420px] rounded-2xl border-2 border-[var(--fx-rose)] bg-[var(--fx-surf)] p-6 shadow-[4px_6px_0_0_var(--fx-hard)]" data-testid="room-levels-confirm">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-[var(--fx-rose)] text-white animate-pulse">
                <Save className="h-5 w-5" />
              </span>
              <div>
                <DialogTitle className="text-[15px] font-black tracking-tight text-[var(--fx-ink)]">
                  CONFIRM ROOM LEVEL CHANGES
                </DialogTitle>
                <DialogDescription className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
                  {confirmLocked
                    ? `This cannot be undone — the CONFIRM button stays LOCKED for ${applyCountdown}s.`
                    : "The button is unlocked — click CONFIRM & APPLY to push the changes live."}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>
          <div className="mt-2 rounded-xl bg-[var(--fx-lav)]/50 px-4 py-3 text-[10.5px] font-bold leading-relaxed text-[var(--fx-muted)]">
            This will rename levels, re-tier rooms, and change rates for all future check-ins.
            Past bills keep their snapshots. The wall rebuilds instantly.
          </div>
          <div className="mt-4 flex gap-2">
            <Button onClick={cancelApply} className="h-10 flex-1 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)] hover:bg-[var(--fx-lav)]">
              CANCEL
            </Button>
            <Button
              onClick={() => { setShowConfirm(false); setApplyArmed(false); void applyLevels(); }}
              disabled={confirmLocked}
              className={`h-10 flex-1 rounded-xl text-[11px] font-extrabold tracking-wider text-white shadow-[2px_2px_0_0_var(--fx-hard)] transition disabled:opacity-50 ${
                confirmLocked
                  ? "bg-[var(--fx-muted)] cursor-not-allowed"
                  : "bg-[var(--fx-green)] hover:opacity-90"
              }`}
            >
              {confirmLocked ? `LOCKED · ${applyCountdown}s` : "CONFIRM & APPLY"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
