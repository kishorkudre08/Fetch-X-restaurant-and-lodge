"use client";

// ── t113 · ATTENDANCE — the receptions' 4th section ──────────────────────────
// An employee list with a date selector and attendance input, per the user's
// reference screenshot: stat cards on top (total / present / absent — NO late
// mechanism by request), a date bar with ALL PRESENT / ALL ABSENT quick
// actions, then the numbered staff roster with ✓PRESENT / ✗ABSENT chips that
// save per date. Each reception sees its own book's staff
// (reception_restaurant → rest, reception_lodge → lodge).
// t114 — by user request: marks are STAGED locally and a SUBMIT ATTENDANCE
// button registers the day with the toast "Attendance registered successfully ✅"
// (the register no longer saves silently on every tap).

import * as React from "react";
import { CalendarCheck, CalendarDays, Check, History, Loader2, Users, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { FxDatePicker, TierBand } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import type { Employee } from "@/lib/types";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";
import { AttendanceHistory } from "@/components/attendance-history";

type Mark = "present" | "absent";

/* local YYYY-MM-DD — never toISOString (UTC would shift the day after 19:00 IST) */
const localISO = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export function AttendanceView({ book }: { book: "rest" | "lodge" }) {
  // t184 — the selected date persists across section switches so the reception
  // can mark attendance, jump to Tasks to forward a thing, and come back to
  // the same date without re-picking it. (If the cached date is from a prior
  // day, the user can re-pick — we don't auto-advance it; marking past
  // attendance is a legit use case.)
  const [date, setDate] = useCachedToggle<string>("attendance", "date", localISO(new Date()));
  // TODAY vs HISTORY mode toggle (cached across section switches).
  const [mode, setMode] = useCachedToggle<"today" | "history">("attendance", "mode", "today");
  useRegisterScreen("attendance", "Attendance", { date, book, mode });
  const { toast } = useToast();

  const [employees, setEmployees] = React.useState<Employee[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [marks, setMarks] = React.useState<Record<string, Mark>>({}); // employeeId → status for `date`; STAGED only — t114

  const staff = React.useMemo(() => employees.filter((e) => e.active && e.book === book), [employees, book]);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const [em, at] = await Promise.all([
        fetch("/api/employees").then((x) => x.json()),
        fetch(`/api/attendance?date=${date}`).then((x) => x.json()),
      ]);
      setEmployees(Array.isArray(em) ? em : []);
      const map: Record<string, Mark> = {};
      if (Array.isArray(at)) for (const r of at) if (r.status === "present" || r.status === "absent") map[r.employeeId] = r.status;
      setMarks(map);
    } catch {
      // keep whatever we had on failure
    } finally {
      setLoading(false);
    }
  }, [date]);

  React.useEffect(() => {
    void load();
    // t123 — cross-device sync: marks made on another device land here too
    const t = setInterval(() => void load(), 20000);
    return () => clearInterval(t);
  }, [load]);

  /* t114 — SUBMIT registers every marked person for the date in one upsert
     batch, then toasts exactly what the user asked for. */
  const submit = async () => {
    const entries = staff
      .filter((e) => marks[e.id] === "present" || marks[e.id] === "absent")
      .map((e) => ({ employeeId: e.id, status: marks[e.id] as Mark }));
    if (!entries.length) return;
    setSaving(true);
    try {
      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, entries }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Request failed");
      }
      toast({ title: "Attendance registered successfully ✅" });
    } catch (e) {
      toast({
        title: "Could not save attendance",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      void load(); // snap back to the stored truth
    } finally {
      setSaving(false);
    }
  };

  /* staging only — no network on tap */
  const toggle = (emp: Employee) =>
    setMarks((m) => ({ ...m, [emp.id]: m[emp.id] === "present" ? "absent" : "present" }));
  const markAll = (status: Mark) =>
    setMarks(Object.fromEntries(staff.map((e) => [e.id, status])));

  const markedCount = staff.filter((e) => marks[e.id] === "present" || marks[e.id] === "absent").length;

  const presentCount = staff.filter((e) => marks[e.id] === "present").length;
  const absentCount = staff.filter((e) => marks[e.id] === "absent").length;
  const pct = (n: number) => (staff.length ? `${Math.round((n / staff.length) * 100)}%` : "0%");

  const statCard = (icon: React.ReactNode, tone: string, num: string, label: string, barCls: string, barW: string) => (
    <div className="fx-card rounded-2xl p-4">
      <span className={`grid h-9 w-9 place-items-center rounded-xl ${tone}`}>{icon}</span>
      <div className="fx-num mt-2 text-[26px] font-black leading-none text-[var(--fx-ink)]">{num}</div>
      <div className="fx-label mt-1.5">{label}</div>
      <div className="mt-2.5 h-1 rounded-full bg-[var(--fx-lav)]">
        <div className={`h-1 rounded-full transition-[width] ${barCls}`} style={{ width: barW }} />
      </div>
    </div>
  );

  return (
    <div className="space-y-5" data-testid="attendance-view">
      <TierBand
        num={FX_TIERS.attendance.num}
        eyebrow={tierEyebrow(FX_TIERS.attendance)}
        title="Attendance" data-tip="Attendance"
        sub="Mark daily attendance for your team — pick a date, tap Present or Absent beside every name (or fill the whole register at once), then press SUBMIT ATTENDANCE to register the day."
        tag={`${presentCount}/${staff.length} PRESENT · ${date.split("-").reverse().join("-")}`}
      />

      {/* TODAY vs HISTORY toggle. */}
      <div className="fx-card flex flex-wrap items-center gap-3 rounded-2xl p-3">
        <span className="fx-label flex items-center gap-2 px-1">
          <CalendarDays className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
          VIEW
        </span>
        <div className="inline-flex gap-1 rounded-xl bg-[var(--fx-page)] p-1 shadow-[inset_0_0_0_1px_var(--fx-line)]">
          <button
            onClick={() => setMode("today")}
            data-testid="attendance-mode-today"
            aria-pressed={mode === "today"}
            className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-[11px] font-extrabold tracking-[0.08em] transition ${
              mode === "today"
                ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]"
                : "text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            }`}
          >
            <CalendarCheck className="h-3.5 w-3.5" />
            TODAY
          </button>
          <button
            onClick={() => setMode("history")}
            data-testid="attendance-mode-history"
            aria-pressed={mode === "history"}
            className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-[11px] font-extrabold tracking-[0.08em] transition ${
              mode === "history"
                ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]"
                : "text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            }`}
          >
            <History className="h-3.5 w-3.5" />
            HISTORY
          </button>
        </div>
      </div>

      {mode === "history" ? (
        <AttendanceHistory book={book} />
      ) : (
        <>
      {/* ── stat cards — total / present / absent (no late, by request) ── */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {statCard(<Users className="h-4 w-4 text-[var(--fx-accent-ink)]" />, "bg-[var(--fx-lav)]", String(staff.length), "TOTAL STAFF", "bg-[var(--fx-purple)]", "100%")}
        {statCard(<Check className="h-4 w-4 text-[var(--fx-green)]" />, "bg-[var(--fx-green)]/10", String(presentCount), "PRESENT TODAY", "bg-[var(--fx-green)]", pct(presentCount))}
        {statCard(<X className="h-4 w-4 text-[var(--fx-rose)]" />, "bg-[var(--fx-rose)]/10", String(absentCount), "ABSENT TODAY", "bg-[var(--fx-rose)]", pct(absentCount))}
      </div>

      {/* ── date selector + whole-register quick actions ── */}
      <div className="fx-card flex flex-wrap items-center gap-3 rounded-2xl p-4">
        <span className="fx-label flex items-center gap-2">
          <CalendarDays className="h-3.5 w-3.5 text-[var(--fx-accent-ink)]" />
          DATE
        </span>
        <FxDatePicker
          value={date}
          onChange={setDate}
          ariaLabel="Attendance date"
        />
        <span data-testid="attendance-date" className="hidden" aria-hidden />
        <span className="ml-auto flex items-center gap-2">
          <Button
            onClick={() => markAll("present")}
            disabled={loading || !staff.length}
            data-testid="attendance-all-present"
            className="h-10 rounded-xl bg-[var(--fx-green)] px-4 text-[11px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:opacity-90 disabled:opacity-50"
          >
            <Check className="h-3.5 w-3.5" />
            ALL PRESENT
          </Button>
          <Button
            onClick={() => markAll("absent")}
            disabled={loading || !staff.length}
            data-testid="attendance-all-absent"
            variant="outline"
            className="h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[11px] font-extrabold text-[var(--fx-ink)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-lav)] disabled:opacity-50"
          >
            <X className="h-3.5 w-3.5" />
            ALL ABSENT
          </Button>
          {/* t114 — the register only saves when this is pressed */}
          <Button
            onClick={() => void submit()}
            disabled={saving || loading || markedCount === 0}
            aria-label="Submit attendance for this date"
            data-testid="attendance-submit"
            className="h-10 rounded-xl bg-[var(--fx-purple)] px-5 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CalendarCheck className="h-3.5 w-3.5" />}
            SUBMIT ATTENDANCE
          </Button>
        </span>
      </div>

      {/* ── the roster — numbered list with tap-to-toggle status chips ── */}
      <div className="fx-card overflow-hidden rounded-2xl">
        <div className="flex items-center gap-3 border-b border-[var(--fx-line)] bg-[var(--fx-lav)]/50 px-5 py-3">
          <span className="fx-label w-8 text-center">#</span>
          <span className="fx-label flex-1">STAFF MEMBER · {book === "lodge" ? "LODGE BOOK" : "RESTAURANT BOOK"}</span>
          <span className="fx-label hidden sm:inline">STATUS — TAP TO MARK</span>
        </div>
        <div className="fx-scroll max-h-[420px] overflow-y-auto">
          {loading && (
            <p className="flex items-center justify-center gap-2 py-10 text-[13px] font-bold text-[var(--fx-muted)]">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading the register…
            </p>
          )}
          {!loading && staff.length === 0 && (
            <p className="py-10 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
              No staff in this book yet — the owner adds the team in the Employee section.
            </p>
          )}
          {!loading &&
            staff.map((emp, i) => {
              const marked = marks[emp.id];
              const present = marked === "present";
              const absent = marked === "absent";
              return (
                <div
                  key={emp.id}
                  data-testid={`attendance-row-${emp.id}`}
                  className="flex items-center gap-3 border-b border-[var(--fx-line)] px-5 py-2.5 last:border-b-0"
                >
                  <span className="fx-num grid h-7 w-8 shrink-0 place-items-center rounded-lg bg-[var(--fx-lav)] text-[11px] font-black text-[var(--fx-accent-ink)]">
                    {i + 1}
                  </span>
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-[var(--fx-on-accent)]">
                    {emp.name.slice(0, 1).toUpperCase()}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13.5px] font-bold text-[var(--fx-ink)]">{emp.name}</span>
                    <span className="block truncate text-[10.5px] font-semibold text-[var(--fx-muted)]">{emp.role}</span>
                  </span>
                  <button
                    onClick={() => toggle(emp)}
                    disabled={saving}
                    aria-pressed={present}
                    aria-label={`Mark ${emp.name} ${present ? "absent" : "present"}`}
                    data-testid={`attendance-status-${emp.id}`}
                    className={`flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[10px] font-extrabold tracking-wider transition disabled:opacity-60 ${
                      present
                        ? "bg-[var(--fx-green)]/15 text-[var(--fx-green)] shadow-[inset_0_0_0_1px_var(--fx-green)]"
                        : absent
                          ? "bg-[var(--fx-rose)]/15 text-[var(--fx-rose)] shadow-[inset_0_0_0_1px_var(--fx-rose)]"
                          : "border border-dashed border-[var(--fx-line)] bg-[var(--fx-page)] text-[var(--fx-muted)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
                    }`}
                  >
                    {present ? (
                      <>
                        <Check className="h-3 w-3" /> PRESENT
                      </>
                    ) : absent ? (
                      <>
                        <X className="h-3 w-3" /> ABSENT
                      </>
                    ) : (
                      "NOT MARKED"
                    )}
                  </button>
                </div>
              );
            })}
        </div>
        <p className="border-t border-[var(--fx-line)] px-5 py-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          Marks are remembered per date — switch the date to review or fix any day. Stage
          Present / Absent for every name, then press SUBMIT ATTENDANCE to register the day.
        </p>
      </div>
        </>
      )}
    </div>
  );
}
