"use client";

// ── t98 · MANAGEMENT — slimmed down ─────────────────────────────────────────
// The menu editor lived here until the owner's menu editing moved into the
// POS view (add-category on top, a blank add-dish block in every category,
// edit/delete beside every dish). The rooms & rates editor moved to the bottom
// of the Lodge Front Desk.
// t113 — the section is renamed EMPLOYEE (nav + title) and the HOTEL PROFILE
// subsection is gone entirely — that rename already lives in Settings, so
// keeping it here was a duplicate. What remains: the team roster.

import * as React from "react";
import {
  Loader2,
  Plus,
  RotateCcw,
  Users,
  Save,
  Pencil,
  X,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Wallet,
  History,
  Undo2,
  CalendarDays,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import type { Employee } from "@/lib/types";
import { inr } from "@/lib/format";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";

// ── t119 · SALARY RUN types & month helpers ─────────────────────────────────
type SalaryRow = {
  employeeId: string;
  name: string;
  role: string;
  book: "rest" | "lodge";
  base: number;
  present: number;
  absent: number;
  days: number;
  paidHolidays: number;
  deduction: number;
  netPaid: number;
  status: "paid" | "unpaid";
  paidAt: string | null;
  paidBy: string | null;
  frozen: boolean;
};
type SalaryRun = { month: string; days: number; monthOver: boolean; holidayLimit: number; rows: SalaryRow[] };
type HistRow = {
  id: string;
  name: string;
  role: string;
  book: string;
  month: string;
  base: number;
  absentDays: number;
  paidHolidays: number;
  deduction: number;
  netPaid: number;
  paidAt: string | null;
};

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const MONTH_SHORT = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const monthKeyOf = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const monthLabel = (key: string) => {
  const [y, m] = key.split("-").map(Number);
  return `${MONTH_NAMES[m - 1].toUpperCase()} ${y}`;
};
const monthShortLabel = (key: string) => {
  const [, m] = key.split("-").map(Number);
  return `${MONTH_SHORT[m - 1]} ${key.slice(0, 4)}`;
};
const dateLabel = (iso: string) => {
  const d = new Date(iso);
  return `${String(d.getDate()).padStart(2, "0")} ${MONTH_SHORT[d.getMonth()]} ${d.getFullYear()}`;
};

export function ManagementView() {
  // t184 — salary month, collapsible-section map and the employee book filter
  // all persist across section switches. selMonth defaults to LAST month
  // (the most-recently settle-able month) on first load; empBook defaults to
  // "all" (owner sees both books). The collapsed/expanded state of the three
  // subsections (emp/sal/hist) survives a round-trip through Tasks/Expenses.
  const [selMonth, setSelMonth] = useCachedToggle<string>(
    "management",
    "selMonth",
    (() => {
      const d = new Date();
      return monthKeyOf(new Date(d.getFullYear(), d.getMonth() - 1, 1));
    })(),
  );
  // t188 — collapsible subsections. The "hist" (PAID HISTORY) section used
  // to default to collapsed, which made the owner think "no employee history"
  // existed. Now it's expanded on first load — the owner sees the salary
  // settlement history immediately. The state still persists across
  // section switches via useCachedToggle, so if the owner collapses it,
  // it stays collapsed.
  const [open, setOpen] = useCachedToggle<Record<string, boolean>>("management", "open", {
    emp: true,
    sal: true,
    hist: true,
  });
  const [empBook, setEmpBook] = useCachedToggle<"all" | "rest" | "lodge">("management", "empBook", "all");
  useRegisterScreen("management", "Management", { selMonth, empBook, open });
  const { toast } = useToast();

  // ── data ──────────────────────────────────────────────────────────────────
  const [employees, setEmployees] = React.useState<Employee[]>([]);
  const [opLoading, setOpLoading] = React.useState(false);
  const [confirming, setConfirming] = React.useState<string | null>(null); // two-step delete

  const loadOps = React.useCallback(async () => {
    try {
      const e = await fetch("/api/employees").then((x) => x.json());
      setEmployees(Array.isArray(e) ? e : []);
    } catch {
      // keep old data on failure
    }
  }, []);

  React.useEffect(() => {
    void loadOps();
  }, [loadOps]);

  // ── t119 · SALARY RUN state ────────────────────────────────────────────────
  // (selMonth itself is the cached toggle declared at the top; this is just
  // the salary-run data the month unlocks.)
  const [run, setRun] = React.useState<SalaryRun | null>(null);
  const [hist, setHist] = React.useState<HistRow[]>([]);
  const [salLoading, setSalLoading] = React.useState(false);
  // t129 — the hand-tuned PAY ₹ draft is GONE (user: "the recalculated paid
  // salary should be considered as the given business's employee salary"):
  // SALARY is the attendance-recalculated figure the server computes, and
  // MARK PAID settles exactly that.

  const loadSal = React.useCallback(async (month: string) => {
    try {
      const [r, h] = await Promise.all([
        fetch(`/api/salaries?month=${month}`).then((x) => x.json()),
        fetch("/api/salaries?history=1").then((x) => x.json()),
      ]);
      const runData = r as SalaryRun;
      if (runData && Array.isArray(runData.rows)) {
        setRun(runData);
      }
      if (h && Array.isArray(h.history)) setHist(h.history);
    } catch {
      // keep previous data on failure
    }
  }, []);

  React.useEffect(() => {
    setSalLoading(true);
    void loadSal(selMonth).finally(() => setSalLoading(false));
    // 30s poll — settles made on another device land here too (t123 sync)
    const t = setInterval(() => void loadSal(selMonth), 30_000);
    return () => clearInterval(t);
  }, [selMonth, loadSal]);

  const shiftMonth = (delta: number) => {
    const [y, m] = selMonth.split("-").map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    setSelMonth(monthKeyOf(d));
  };
  const nowKey = monthKeyOf(new Date());
  const nextMonthKey = (() => {
    const [y, m] = selMonth.split("-").map(Number);
    return monthKeyOf(new Date(y, m, 1));
  })();
  const [viewYear, viewMonth] = selMonth.split("-").map(Number);
  const futureMonth = (m: number) => selMonth.slice(0, 4) === nowKey.slice(0, 4) && m > Number(nowKey.slice(5, 7));

  const settle = async (row: SalaryRow) => {
    setSalLoading(true);
    try {
      const res = await fetch("/api/salaries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          employeeId: row.employeeId,
          month: selMonth,
          // t129 — no amount rides the body: the server recalculates from the
          // attendance register (paid-holidays limit applied) and THAT figure
          // is the salary that gets settled and reported everywhere.
          paidBy: "OWNER",
        }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not settle the salary");
      toast({
        title: "Salary settled",
        description: `${inr(row.netPaid)} paid to ${row.name} for ${monthShortLabel(selMonth)} — the recalculated salary after attendance cuts.`,
      });
      await loadSal(selMonth);
    } catch (e) {
      toast({
        title: "Settlement failed",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setSalLoading(false);
    }
  };

  const unsettle = async (row: SalaryRow) => {
    setSalLoading(true);
    try {
      const res = await fetch("/api/salaries", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeId: row.employeeId, month: selMonth }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not undo");
      toast({ title: "Settlement undone", description: `${row.name}'s ${monthShortLabel(selMonth)} salary is back to UNPAID.` });
      await loadSal(selMonth);
    } catch (e) {
      toast({
        title: "Undo failed",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setSalLoading(false);
    }
  };


  const activeEmployees = employees.filter((e) => e.active);
  const monthlySalary = activeEmployees.reduce((s, e) => s + e.salary, 0);

  // ── collapsible subsections ────────────────────────────────────────────────
  // (open is the cached toggle declared at the top of the component; the
  // toggle helper just flips one of its keys.)
  const toggle = (k: string) => setOpen((m) => ({ ...m, [k]: !m[k] }));

  // ── inline row editing (one row in edit mode at a time) ───────────────────
  const [editing, setEditing] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState<Record<string, Record<string, string>>>({});
  const setD = (k: string, patch: Record<string, string>) =>
    setDraft((m) => ({ ...m, [k]: { ...m[k], ...patch } }));

  const startEdit = (k: string, vals: Record<string, string>) => {
    setConfirming(null);
    setEditing(k);
    setDraft((m) => ({ ...m, [k]: vals }));
  };
  const cancelEdit = () => setEditing(null);

  // ── mutation helper ───────────────────────────────────────────────────────
  const mutate = async (
    url: string,
    method: string,
    body?: unknown,
    okMsg?: string,
    after?: () => Promise<void>,
  ): Promise<boolean> => {
    setOpLoading(true);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Request failed");
      }
      if (after) await after();
      if (okMsg) toast({ title: okMsg });
      return true;
    } catch (e) {
      toast({
        title: "Action failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      return false;
    } finally {
      setOpLoading(false);
    }
  };

  // two-step delete: first click arms the button, second click executes
  const confirmBtn = (key: string, onConfirm: () => void, label = "Remove") => {
    const armed = confirming === key;
    return (
      <Button
        size="sm"
        variant="ghost"
        disabled={opLoading}
        onClick={() => {
          if (armed) {
            setConfirming(null);
            onConfirm();
          } else {
            setConfirming(key);
            setTimeout(() => setConfirming((c) => (c === key ? null : c)), 3000); // auto-disarm
          }
        }}
        className={`h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider ${
          armed
            ? "bg-[var(--fx-rose)] text-white hover:bg-[var(--fx-rose)]"
            : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
        }`}
      >
        {armed ? "SURE?" : label.toUpperCase()}
      </Button>
    );
  };

  // shared row buttons: EDIT · SAVE · CANCEL · RESTORE
  const editBtn = (key: string, vals: Record<string, string>) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={() => startEdit(key, vals)}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
    >
      <Pencil className="mr-1 h-3 w-3" /> EDIT
    </Button>
  );
  const saveBtn = (onSave: () => void) => (
    <Button
      size="sm"
      disabled={opLoading}
      onClick={onSave}
      className="h-8 shrink-0 rounded-lg bg-[var(--fx-purple)] px-3 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
    >
      {opLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="mr-1 h-3 w-3" /> SAVE</>}
    </Button>
  );
  const cancelBtn = () => (
    <Button
      size="sm"
      variant="ghost"
      onClick={cancelEdit}
      aria-label="Cancel editing"
      className="h-8 w-8 shrink-0 rounded-lg p-0 text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
    >
      <X className="h-3.5 w-3.5" />
    </Button>
  );
  const restoreBtn = (onClick: () => void) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={onClick}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-green)]"
    >
      <RotateCcw className="mr-1 h-3 w-3" /> RESTORE
    </Button>
  );

  // collapsible numbered section shell
  const sectionHead = (
    num: string,
    icon: React.ReactNode,
    title: string,
    badge: string,
    isOpen: boolean,
  ) => (
    <span className="flex min-w-0 flex-1 flex-wrap items-center gap-2.5">
      <span className="fx-num grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
        {num}
      </span>
      <span className="fx-label flex items-center gap-2">
        {icon} {title}
      </span>
      <span className="fx-num ml-auto max-w-[240px] truncate rounded-full bg-[var(--fx-lav)] px-3 py-1 text-[10px] font-extrabold text-[var(--fx-muted)]">
        {badge}
      </span>
      <ChevronDown
        aria-hidden
        className={`h-4 w-4 shrink-0 text-[var(--fx-muted)] transition-transform ${isOpen ? "" : "-rotate-90"}`}
      />
    </span>
  );

  // ══ 01 · EMPLOYEE LIST ═══════════════════════════════════════════════════
  const [empName, setEmpName] = React.useState("");
  const [empRole, setEmpRole] = React.useState("");
  const [empSalary, setEmpSalary] = React.useState("");
  // (empBook is the cached toggle declared at the top of the component.)
  const [empNewBook, setEmpNewBook] = React.useState<"rest" | "lodge">("rest");

  const addEmployee = async () => {
    const salary = Number(empSalary);
    if (!empName.trim() || !Number.isFinite(salary) || salary <= 0) {
      toast({
        title: "Missing details",
        description: "Employee needs a name and a monthly salary above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/employees",
      "POST",
      { name: empName.trim(), role: empRole.trim() || "Staff", salary, book: empNewBook },
      `${empName.trim()} joined the team`,
      loadOps,
    );
    if (ok) {
      setEmpName("");
      setEmpRole("");
      setEmpSalary("");
    }
  };

  const saveEmployee = async (emp: Employee) => {
    const d = draft[`emp:${emp.id}`] ?? {};
    const name = (d.name ?? "").trim();
    const salary = Number(d.salary);
    if (!name || !Number.isFinite(salary) || salary <= 0) {
      toast({
        title: "Missing details",
        description: "Name and a monthly salary above zero are required.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/employees",
      "PATCH",
      { id: emp.id, name, role: (d.role ?? "").trim() || emp.role, salary },
      `${name} updated`,
      loadOps,
    );
    if (ok) setEditing(null);
  };

  const empRow = (emp: Employee) => {
    const ek = `emp:${emp.id}`;
    if (editing === ek) {
      const d = draft[ek] ?? {};
      return (
        <div
          key={emp.id}
          className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-purple)]/40 bg-[var(--fx-lav)] px-3 py-2"
        >
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] text-[12px] font-black text-[var(--fx-on-accent)]">
            {emp.name.slice(0, 1).toUpperCase()}
          </span>
          <Input
            value={d.name ?? ""}
            onChange={(e) => setD(ek, { name: e.target.value })}
            placeholder="Name"
            aria-label={`Edit name of ${emp.name}`}
            className="h-9 min-w-[120px] flex-[1.2] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={d.role ?? ""}
            onChange={(e) => setD(ek, { role: e.target.value })}
            placeholder="Role"
            aria-label={`Edit role of ${emp.name}`}
            className="h-9 min-w-[100px] flex-1 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
          />
          <Input
            value={d.salary ?? ""}
            onChange={(e) => setD(ek, { salary: e.target.value })}
            type="number"
            min={0}
            placeholder="₹/month"
            aria-label={`Edit monthly salary of ${emp.name}`}
            className="fx-num h-9 w-[104px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-bold"
          />
          {saveBtn(() => void saveEmployee(emp))}
          {cancelBtn()}
        </div>
      );
    }
    return (
      <div
        key={emp.id}
        className={`flex items-center gap-2.5 rounded-xl border border-[var(--fx-line)] px-3 py-2 ${
          emp.active ? "bg-[var(--fx-page)]" : "bg-[var(--fx-lav)] opacity-60"
        }`}
      >
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-lav)] text-[12px] font-black text-[var(--fx-accent-ink)]">
          {emp.name.slice(0, 1).toUpperCase()}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-bold text-[var(--fx-ink)]">
            {emp.name}
          </span>
          <span className="block truncate text-[10.5px] font-semibold text-[var(--fx-muted)]">
            {emp.role}
          </span>
        </span>
        <span className="fx-num shrink-0 text-right text-[13px] font-extrabold text-[var(--fx-ink)]">
          {inr(emp.salary)}
          <span className="text-[9.5px] font-bold text-[var(--fx-muted)]">/MO</span>
        </span>
        {emp.active ? (
          <>
            {editBtn(ek, { name: emp.name, role: emp.role, salary: String(emp.salary) })}
            {confirmBtn(ek, () =>
              void mutate("/api/employees", "DELETE", undefined, `${emp.name} removed`, loadOps),
            )}
          </>
        ) : (
          restoreBtn(() =>
            void mutate("/api/employees", "PATCH", { id: emp.id, active: true }, `${emp.name} restored`, loadOps),
          )
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5">
      <TierBand
        num={FX_TIERS.management.num}
        eyebrow={tierEyebrow(FX_TIERS.management)}
        title="Employee"
        sub="Your team roster — add, edit or remove staff and their salaries; salaries flow into the dashboards automatically. The menu lives on the POS screen, room rates at the bottom of the Lodge Front Desk, and the hotel profile now lives in Settings."
        tag={`${activeEmployees.length} EMPLOYEES · ${inr(monthlySalary)}/MO`}
      />

      {/* ── 01 · EMPLOYEE LIST ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("emp")}
          aria-expanded={open.emp}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead("01", <Users className="h-3.5 w-3.5" />, "EMPLOYEE LIST", `${activeEmployees.length} STAFF · ${inr(monthlySalary)}/MO`, open.emp)}
        </button>
        {open.emp && (
          <div className="border-t border-[var(--fx-line)] p-5">
            <div className="mb-3 flex flex-wrap items-center gap-1.5">
              {([["all", "ALL BOOKS"], ["rest", "RESTAURANT BOOK"], ["lodge", "LODGE BOOK"]] as const).map(([v, l]) => (
                <button
                  key={v}
                  onClick={() => setEmpBook(v)}
                  aria-pressed={empBook === v}
                  className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                    empBook === v
                      ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                      : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                  }`}
                >
                  {l}
                </button>
              ))}
              <span className="fx-label ml-auto hidden md:inline-flex">NEW STAFF JOINS</span>
              <select
                value={empNewBook}
                onChange={(e) => setEmpNewBook(e.target.value === "lodge" ? "lodge" : "rest")}
                aria-label="Book for the new employee"
                className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-2.5 text-[11px] font-extrabold text-[var(--fx-ink)]"
              >
                <option value="rest">RESTAURANT BOOK</option>
                <option value="lodge">LODGE BOOK</option>
              </select>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Input
                value={empName}
                onChange={(e) => setEmpName(e.target.value)}
                placeholder="Name…"
                aria-label="Employee name"
                className="h-10 min-w-[150px] flex-[1.2] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
              />
              <Input
                value={empRole}
                onChange={(e) => setEmpRole(e.target.value)}
                placeholder="Role e.g. Cook"
                aria-label="Employee role"
                className="h-10 min-w-[130px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
              />
              <Input
                value={empSalary}
                onChange={(e) => setEmpSalary(e.target.value)}
                placeholder="₹/month"
                type="number"
                min={0}
                aria-label="Monthly salary in rupees"
                className="fx-num h-10 w-[110px] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
              />
              <Button
                onClick={() => void addEmployee()}
                disabled={opLoading}
                className="ml-auto h-10 rounded-xl bg-[var(--fx-purple)] px-4 text-[12px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
              >
                {opLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                ADD
              </Button>
            </div>
            <div className="fx-scroll mt-3 max-h-[300px] space-y-1.5 overflow-y-auto pr-1">
              {(empBook === "all" ? employees : employees.filter((e) => e.book === empBook)).map(empRow)}
              {(empBook === "all" ? employees : employees.filter((e) => e.book === empBook)).length === 0 && (
                <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                  No employees yet — add your team above.
                </p>
              )}
            </div>
            <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              EDIT changes name, role or salary. Settle what was actually paid each month in the
              SALARY RUN below — the dashboards report those real figures. Both receptions mark
              this team's daily attendance in their own Attendance section.
            </p>
          </div>
        )}
      </div>

      {/* ── 02 · SALARY RUN — t119 · the owner's monthly settlement checklist ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("sal")}
          aria-expanded={open.sal}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead(
            "02",
            <Wallet className="h-3.5 w-3.5" />,
            "SALARY RUN",
            run ? `${run.rows.filter((r) => r.status === "paid").length}/${run.rows.length} PAID · ${monthShortLabel(run.month)}` : "MONTHLY SETTLEMENT",
            open.sal,
          )}
        </button>
        {open.sal && (
          <div className="border-t border-[var(--fx-line)] p-5">
            {/* ── polished month selector: chevrons + 12-month chip rail ── */}
            <div className="rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-page)] p-4" data-testid="salary-month-picker">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => shiftMonth(-1)}
                  aria-label="Previous month"
                  className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] transition hover:bg-[var(--fx-lav)]"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <span className="fx-label min-w-[190px] text-center text-[15px] font-black tracking-[0.14em] text-[var(--fx-ink)]">
                  {monthLabel(selMonth)}
                </span>
                <button
                  onClick={() => shiftMonth(1)}
                  disabled={nextMonthKey > nowKey}
                  aria-label="Next month"
                  className="grid h-9 w-9 place-items-center rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] transition hover:bg-[var(--fx-lav)] disabled:cursor-not-allowed disabled:opacity-35"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
                <div className="ml-auto flex items-center gap-2">
                  {/* t131 — the paid-holiday policy rides LEFT of the year chip */}
                  <span
                    className="rounded-full bg-[var(--fx-lav)] px-3 py-1 text-[10px] font-extrabold text-[var(--fx-muted)]"
                    data-testid="salary-hol-limit-chip"
                  >
                    {run?.holidayLimit ?? 3} PAID HOLIDAYS PER MONTH
                  </span>
                  <span className="rounded-full bg-[var(--fx-lav)] px-3 py-1 text-[10px] font-extrabold text-[var(--fx-muted)]">
                    {viewYear}
                  </span>
                  <span className="mut-chip hidden sm:inline-flex">
                    <CalendarDays className="mr-1 h-3 w-3" /> {run ? `${run.days} DAYS` : ""}
                  </span>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-6 gap-1.5 sm:grid-cols-12">
                {MONTH_SHORT.map((mShort, i) => {
                  const mNum = i + 1;
                  const key = `${viewYear}-${String(mNum).padStart(2, "0")}`;
                  const disabled = key > nowKey;
                  const active = key === selMonth;
                  return (
                    <button
                      key={mShort}
                      onClick={() => !disabled && setSelMonth(key)}
                      disabled={disabled}
                      aria-pressed={active}
                      aria-label={`${MONTH_NAMES[i]} ${viewYear}${disabled ? " (not over yet)" : ""}`}
                      className={`rounded-xl py-2 text-[10px] font-extrabold tracking-[0.08em] transition ${
                        active
                          ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                          : disabled
                            ? "cursor-not-allowed bg-[var(--fx-lav)] text-[var(--fx-muted)] opacity-45"
                            : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                      }`}
                    >
                      {mShort}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ── month-not-over banner ── */}
            {run && !run.monthOver && (
              <div className="mt-3 flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-gold)]/50 bg-[var(--fx-gold)]/10 px-4 py-2.5" data-testid="salary-month-not-over">
                <span className="rounded-full bg-[var(--fx-gold)] px-2.5 py-0.5 text-[9.5px] font-black tracking-[0.09em] text-white">
                  MONTH NOT OVER YET
                </span>
                <span className="text-[11px] font-semibold text-[var(--fx-ink)]">
                  {monthLabel(selMonth)} can only be settled after it ends — the checklist below is a preview.
                </span>
              </div>
            )}

            {/* ── settlement checklist — t129 column layout straight off the
                owner's sketch: name · ABSENT DAYS · PAID HOL USED · EXTRA HOL
                TAKEN · PAID HOL LEFT · SALARY · PAID · UNDO ── */}
            <div className="mt-3 hidden px-3 md:flex" data-testid="salary-run-head">
              <span className="w-[168px] shrink-0" />
              {[
                "ABSENT DAYS",
                "PAID HOL USED",
                "EXTRA HOL TAKEN",
                "PAID HOL LEFT",
                "SALARY",
                "PAID",
                "UNDO",
              ].map((h) => (
                /* t131 — column headers read bigger (8.5px → 10px) */
                <span key={h} className="min-w-0 flex-1 px-0.5 text-center text-[10px] font-black tracking-[0.1em] text-[var(--fx-muted)]">
                  {h}
                </span>
              ))}
            </div>
            <div className="fx-scroll mt-1.5 max-h-[440px] space-y-1.5 overflow-y-auto pr-1" data-testid="salary-run-list">
              {salLoading && !run && (
                <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                  <Loader2 className="mr-2 inline h-4 w-4 animate-spin" /> Loading the run…
                </p>
              )}
              {run?.rows.map((row) => {
                // t126/t129 — holidays applied = the global Settings limit capped
                // by the days actually missed; settled months keep frozen figures.
                // Attendance itself is DERIVED from the receptions' register.
                const limit = Number.isFinite(run.holidayLimit) ? run.holidayLimit : 3;
                const hol = row.frozen ? row.paidHolidays : Math.min(row.absent, limit);
                const extra = Math.max(0, row.absent - hol);
                const holLeft = Math.max(0, limit - hol);
                const salary = Math.max(0, Math.round(row.netPaid));
                const paid = row.status === "paid";
                return (
                  <div
                    key={row.employeeId}
                    data-testid={`salary-row-${row.name.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                    className={`flex flex-wrap items-center gap-x-2 gap-y-2 rounded-xl border px-3 py-2.5 ${
                      paid ? "border-[var(--fx-green)]/40 bg-[var(--fx-green)]/5" : "border-[var(--fx-line)] bg-[var(--fx-page)]"
                    }`}
                  >
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-lav)] text-[12px] font-black text-[var(--fx-accent-ink)]">
                      {row.name.slice(0, 1).toUpperCase()}
                    </span>
                    <span className="w-[136px] shrink-0">
                      <span className="block truncate text-[13px] font-bold text-[var(--fx-ink)]">{row.name}</span>
                      <span className="block truncate text-[10.5px] font-semibold text-[var(--fx-muted)]">
                        {row.role} · {row.book === "lodge" ? "LODGE" : "REST"}
                      </span>
                    </span>
                    {/* ABSENT DAYS · PAID HOL USED · EXTRA HOL TAKEN · PAID HOL LEFT — four even cells */}
                    <span className="fx-num flex min-w-[52px] flex-1 flex-col items-center text-center text-[13px] font-extrabold text-[var(--fx-ink)]">
                      {/* t131 — bare number, no "A" prefix */}
                      <span className="rounded-lg bg-[var(--fx-lav)] px-2 py-0.5">{row.absent}</span>
                    </span>
                    <span className="fx-num flex min-w-[52px] flex-1 flex-col items-center text-center text-[13px] font-extrabold text-[var(--fx-ink)]">
                      {hol}
                      <span className="text-[8px] font-bold text-[var(--fx-muted)]">{row.frozen ? "FROZEN" : `OF ${limit}`}</span>
                    </span>
                    <span className="fx-num flex min-w-[52px] flex-1 flex-col items-center text-center text-[13px] font-extrabold text-[var(--fx-rose)]">
                      {extra > 0 ? `− ${extra}d` : "0"}
                      {row.deduction > 0 && (
                        <span className="text-[8.5px] font-bold text-[var(--fx-rose)]">−{inr(row.deduction)}</span>
                      )}
                    </span>
                    <span className="fx-num flex min-w-[52px] flex-1 flex-col items-center text-center text-[13px] font-extrabold text-[var(--fx-green)]">
                      {holLeft}
                    </span>
                    {/* SALARY — the recalculated figure IS the salary (t129): read-only */}
                    <span className="fx-num flex min-w-[86px] flex-1 flex-col items-center text-center text-[13px] font-extrabold text-[var(--fx-ink)]" data-testid="salary-net">
                      {inr(salary)}
                    </span>
                    {/* PAID */}
                    <span className="flex min-w-[92px] flex-1 justify-center">
                      {paid ? (
                        <span
                          className="rounded-xl bg-[var(--fx-green)] px-2.5 py-2 text-center text-[9px] font-black leading-tight tracking-[0.06em] text-white"
                          data-testid={`salary-paid-chip-${row.name.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                        >
                          PAID ✓{row.paidAt ? ` ${dateLabel(row.paidAt)}` : ""}
                        </span>
                      ) : (
                        <Button
                          size="sm"
                          disabled={salLoading || !run.monthOver}
                          onClick={() => void settle(row)}
                          data-testid={`salary-pay-${row.name.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                          className="h-8 rounded-xl bg-[var(--fx-purple)] px-3 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          {salLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : "MARK PAID"}
                        </Button>
                      )}
                    </span>
                    {/* UNDO */}
                    <span className="flex min-w-[52px] flex-1 justify-center">
                      {paid ? (
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={salLoading}
                          onClick={() => void unsettle(row)}
                          className="h-8 rounded-lg px-2 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
                        >
                          <Undo2 className="h-3 w-3" />
                        </Button>
                      ) : (
                        <span className="text-[var(--fx-muted)]">—</span>
                      )}
                    </span>
                  </div>
                );
              })}
              {run && run.rows.length === 0 && (
                <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                  No active employees — add staff in the Employee List above.
                </p>
              )}
            </div>
            <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              Attendance comes straight from the receptions' register — it cannot be edited here. SALARY is the
              recalculated figure: base − (absent days − paid holidays, capped by the limit in Settings, currently{" "}
              {run?.holidayLimit ?? 3}) × per-day wage (base ÷ {run?.days ?? "days-in-month"} days) — and that recalculated
              salary is what the business counts. Settled months freeze into PAID HISTORY, and the dashboards report these figures.
            </p>
          </div>
        )}
      </div>

      {/* ── 03 · PAID HISTORY — every settled salary, newest first ── */}
      <div className="fx-card overflow-hidden">
        <button
          onClick={() => toggle("hist")}
          aria-expanded={open.hist}
          className="flex w-full flex-wrap items-center gap-2.5 px-5 py-4 text-left transition hover:bg-[var(--fx-lav)]/40"
        >
          {sectionHead(
            "03",
            <History className="h-3.5 w-3.5" />,
            "PAID HISTORY",
            `${hist.length} SETTLED · ${inr(hist.reduce((s, h) => s + h.netPaid, 0))} TOTAL`,
            open.hist,
          )}
        </button>
        {open.hist && (
          <div className="border-t border-[var(--fx-line)] p-5">
            <div className="fx-scroll max-h-[360px] space-y-1.5 overflow-y-auto pr-1" data-testid="salary-history-list">
              {hist.map((h) => (
                <div
                  key={h.id}
                  className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2"
                >
                  <span className="rounded-lg bg-[var(--fx-purple)] px-2.5 py-1 text-[9.5px] font-black tracking-[0.08em] text-[var(--fx-on-accent)]">
                    {monthShortLabel(h.month)}
                  </span>
                  <span className="min-w-[110px] flex-1">
                    <span className="block truncate text-[12.5px] font-bold text-[var(--fx-ink)]">{h.name}</span>
                    <span className="block truncate text-[10px] font-semibold text-[var(--fx-muted)]">
                      {h.role} · {h.book === "lodge" ? "LODGE" : "REST"} BOOK
                    </span>
                  </span>
                  <span className="fx-num text-[10.5px] font-bold text-[var(--fx-muted)]">
                    A {h.absentDays} · HOL {h.paidHolidays}
                  </span>
                  {h.deduction > 0 && (
                    <span className="fx-num text-[11px] font-extrabold text-[var(--fx-rose)]">−{inr(h.deduction)}</span>
                  )}
                  <span className="fx-num w-[92px] text-right text-[13px] font-black text-[var(--fx-green)]">
                    {inr(h.netPaid)}
                  </span>
                  <span className="w-[92px] text-right text-[9.5px] font-bold text-[var(--fx-muted)]">
                    {h.paidAt ? dateLabel(h.paidAt) : "—"}
                  </span>
                </div>
              ))}
              {hist.length === 0 && (
                <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                  No salaries settled yet — mark a month PAID in the Salary Run above.
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
