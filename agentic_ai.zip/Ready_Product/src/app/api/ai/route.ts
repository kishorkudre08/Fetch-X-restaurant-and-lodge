import { NextRequest, NextResponse } from "next/server";
import { aiChat } from "@/lib/ai-client";
import { db } from "@/lib/db";
import { getDashboardData, parseRange, RANGE_META } from "@/lib/analytics";
import { getHotelName } from "@/lib/settings";
import { parseLevels, parseMaxRooms, tierOfRoom, DEFAULT_LEVELS, MAX_ROOMS_KEY } from "@/lib/lodge";
import { istDateTime } from "@/lib/format";
import type { RangeKey } from "@/lib/analytics";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type ChatMsg = { role: "user" | "assistant"; content: string };

const round2 = (n: number) => Math.round(n * 100) / 100;
const IST_OFFSET_MS = 5.5 * 3600000;

// IST calendar helpers — every timestamp the AI sees is IST, time-wise.
const istDayKey = (ts: Date) => new Date(ts.getTime() + IST_OFFSET_MS).toISOString().slice(0, 10);
const istDayLabel = (key: string) => {
  const [y, m, d] = key.split("-").map(Number);
  const mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][m - 1];
  return `${String(d).padStart(2, "0")} ${mon}${y !== new Date().getFullYear() ? " '" + String(y).slice(2) : ""}`;
};
const istHourLabel = (h: number) => (h % 12 === 0 ? 12 : h % 12) + (h < 12 ? " AM" : " PM");
// t132 — IST month key N months back (0 = current) for the salary paid/unpaid board
const istMonthKeyOffset = (back: number) => {
  const d = new Date(Date.now() + IST_OFFSET_MS);
  d.setUTCMonth(d.getUTCMonth() - back);
  return d.toISOString().slice(0, 7);
};

// POST /api/ai — business copilot for the configured hotel (variable tenant).
// The AI receives the ENTIRE property record, time-wise: both books' full
// daily timelines, today hour-by-hour, every recent bill with its items and
// time, lodge stays with check-in/check-out, expenses tagged with the book
// they belong to, employees, menu, levels/rates and per-book net profit.
// Every entry the owner records exists to feed this copilot — it never
// invents numbers.
// Body: { message, history?: ChatMsg[], range?: RangeKey, liveMode?: boolean }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message = String(body.message ?? "").trim().slice(0, 600);
    if (!message) return NextResponse.json({ error: "Message is required" }, { status: 400 });

    const range: RangeKey = parseRange(typeof body.range === "string" ? body.range : null);
    const rawHistory: ChatMsg[] = Array.isArray(body.history) ? body.history : [];
    const history = rawHistory
      .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-8)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 1200) }));
    // t147 — live talk mode: AI replies in spoken natural language. The
    // spoken reply is later run through a TTS engine, so it must NOT contain
    // markdown, tables, code fences, asterisks or anything else that would
    // read as "star star star" or "pipe pipe pipe" out loud. When the user
    // stops live talk, the panel falls back to the formatted reply path
    // (the regular system prompt + Markdown rendering).
    const liveMode = body.liveMode === true;
    // t151 — screen context: tells the AI which page the user is on (route +
    // sectionId + sectionLabel), what viewState is selected (range tab, filter,
    // open bill, etc.) and the viewport size + zoom level. The AI injects this
    // as a [SCREEN CONTEXT] block in the system prompt so it can answer "what
    // am I looking at?" / "see my page" with the same context the user has.
    const screenContextRaw = typeof body.screenContext === "string" ? body.screenContext.trim() : "";
    const screenContextBlock = screenContextRaw ? `\n\n[SCREEN CONTEXT — what the user is looking at right now]\n${screenContextRaw}` : "";

    // t166 — custom AI name: the owner can set a custom name for the AI
    // in Settings. If provided, the AI uses this name instead of "Fetch-X"
    // in its self-introduction and persona. Default is "Fetch-X".
    const aiName = (typeof body.aiName === "string" ? body.aiName.trim().slice(0, 40) : "") || "Fetch-X";

    // Live, real data from the database — the AI never invents numbers.
    const [data, hotelName] = await Promise.all([getDashboardData(range), getHotelName()]);

    // ── The pieces the dashboard aggregates but the AI needs in full detail ──
    const since30 = new Date(Date.now() - 30 * 86400000);
    const nowIst = new Date(Date.now() + IST_OFFSET_MS);
    const monthStart = new Date(Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), 1) - IST_OFFSET_MS);
    const todayStart = new Date(Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate()) - IST_OFFSET_MS);

    const [
      dishes,
      expRows,
      occRooms,
      mntRooms,
      levelsSetting,
      maxSetting,
      lodgeAll,
      rest30,
      lodge30,
      restRecentFull,
      lodgeRecentFull,
      expMonthAgg,
      lodgeToday,
      // t152 — 365-day timelines so the AI can analyse "last X days" for ANY
      // X up to a year, regardless of the dashboard's selected range tab.
      rest365,
      lodge365,
      // t153 — full lodge history (every stay bill ever) for per-room stats
      lodgeHistory,
      // t119/t121 — ACTUAL salaries, attendance, owner tasks + crown spends
      salaryRecent,
      salaryAgg,
      taskCounts,
      taskRecent,
      crownRows,
      attMarks,
      teamEmps,
      // t132 — per-month PAID settlements so the copilot can answer "whose
      // salaries are pending?" with real names, not guesses
      salaryMonthRows,
    ] = await Promise.all([
      db.dish.findMany({
        where: { active: true },
        orderBy: [{ category: "asc" }, { name: "asc" }],
        select: { name: true, price: true, category: true },
      }),
      db.expense.findMany({
        orderBy: { spentOn: "desc" },
        take: 80,
        select: { kind: true, label: true, amount: true, book: true, spentOn: true },
      }),
      db.room.findMany({ where: { status: "occ" }, orderBy: { number: "asc" } }),
      db.room.findMany({ where: { status: "mnt" }, orderBy: { number: "asc" }, select: { number: true } }),
      db.setting.findUnique({ where: { key: "lodgeLevels" } }),
      db.setting.findUnique({ where: { key: MAX_ROOMS_KEY } }),
      db.lodgeBill.aggregate({ _count: true, _sum: { total: true } }),
      db.bill.findMany({ where: { createdAt: { gte: since30 } }, select: { createdAt: true, total: true, itemCount: true } }),
      db.lodgeBill.findMany({ where: { createdAt: { gte: since30 } }, select: { createdAt: true, total: true } }),
      db.bill.findMany({ orderBy: { createdAt: "desc" }, take: 25, include: { items: true } }),
      db.lodgeBill.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
      db.expense.groupBy({ by: ["book", "kind"], where: { spentOn: { gte: monthStart } }, _sum: { amount: true }, _count: true }),
      // t76 — every stay bill today IS one housekeeping turnaround task
      db.lodgeBill.findMany({ where: { createdAt: { gte: todayStart } }, select: { room: true } }),
      // t152 — 365-day timelines so the AI can answer "analyse my last X
      // days of sales" for ANY X up to a year. Lightweight (only totals +
      // timestamps), so the payload stays small even with a year of bills.
      db.bill.findMany({ where: { createdAt: { gte: new Date(Date.now() - 365 * 86400000) } }, select: { createdAt: true, total: true } }),
      db.lodgeBill.findMany({ where: { createdAt: { gte: new Date(Date.now() - 365 * 86400000) } }, select: { createdAt: true, total: true } }),
      // t153 — full lodge history: every stay bill ever, with room + check-in
      // + check-out + total. Powers per-room stats ("which room used the
      // least", "how many days has room X been under maintenance", "what's
      // the most-used room"). Light fields only — room, number, total,
      // checkInAt, checkOutAt, createdAt.
      db.lodgeBill.findMany({
        orderBy: { createdAt: "desc" },
        select: { room: true, number: true, total: true, checkInAt: true, checkOutAt: true, createdAt: true, tier: true, rate: true, hours: true },
        take: 5000,
      }),
      db.salaryPayment.findMany({
        where: { status: "paid" },
        orderBy: [{ paidAt: "desc" }],
        take: 44,
        select: {
          month: true, base: true, absentDays: true, paidHolidays: true,
          deduction: true, netPaid: true, paidAt: true,
          employee: { select: { name: true, role: true, book: true } },
        },
      }),
      db.salaryPayment.aggregate({ where: { status: "paid" }, _count: true, _sum: { netPaid: true, deduction: true } }),
      db.task.groupBy({ by: ["status"], _count: true }),
      db.task.findMany({
        orderBy: [{ createdAt: "desc" }],
        take: 15,
        select: {
          title: true, book: true, kind: true, maxBudget: true, status: true, actualCost: true, deadline: true, doneAt: true, createdBy: true,
          // t130 — the whole conversation on each task: the desk's updates/queries
          // and the owner's replies, so the copilot knows what was asked and answered
          updates: {
            orderBy: { createdAt: "desc" },
            take: 8,
            select: { author: true, role: true, message: true, createdAt: true },
          },
        },
      }),
      db.expense.findMany({
        where: { via: "task" },
        orderBy: { spentOn: "desc" },
        take: 20,
        select: { label: true, amount: true, kind: true, book: true, spentOn: true, taskId: true },
      }),
      db.attendance.groupBy({
        by: ["employeeId", "status"],
        where: { date: { gte: new Date(Date.now() + IST_OFFSET_MS - (RANGE_META[range].days - 1) * 86400000).toISOString().slice(0, 10) } },
        _count: true,
      }),
      db.employee.findMany({ where: { active: true }, orderBy: [{ book: "asc" }, { salary: "desc" }], select: { id: true, name: true, role: true, book: true, salary: true } }),
      db.salaryPayment.findMany({
        where: { status: "paid", month: { in: [
          new Date(Date.now() + IST_OFFSET_MS).toISOString().slice(0, 7),
          istMonthKeyOffset(1),
          istMonthKeyOffset(2),
        ] } },
        orderBy: [{ paidAt: "desc" }],
        select: { month: true, netPaid: true, paidAt: true, employee: { select: { name: true, book: true, role: true, salary: true, active: true } } },
      }),
    ]);
    const maxRooms = parseMaxRooms(maxSetting?.value);
    const levels = parseLevels(levelsSetting?.value, maxRooms) ?? DEFAULT_LEVELS;
    const now = Date.now();
    const hrsIn = (iso: Date | null) =>
      iso ? round2(Math.max(0, (now - new Date(iso).getTime()) / 3600000)) : 0;

    const menu = dishes.map((d) => ({ name: d.name, price: d.price, category: d.category }));

    // 30-day daily timeline — both books side by side, IST calendar days.
    const dayMap = new Map<string, { rest: number; lodge: number }>();
    for (let i = 29; i >= 0; i--) {
      const key = new Date(Date.now() - i * 86400000 + IST_OFFSET_MS).toISOString().slice(0, 10);
      dayMap.set(key, { rest: 0, lodge: 0 });
    }
    for (const b of rest30) {
      const k = istDayKey(b.createdAt);
      const e = dayMap.get(k);
      if (e) e.rest = round2(e.rest + b.total);
    }
    for (const b of lodge30) {
      const k = istDayKey(b.createdAt);
      const e = dayMap.get(k);
      if (e) e.lodge = round2(e.lodge + b.total);
    }
    const timeline = [...dayMap.entries()].map(([key, v]) => ({ day: istDayLabel(key), restaurant: v.rest, lodge: v.lodge }));

    // t152 — 365-day daily timeline — so the AI can answer "analyse my last
    // X days" for ANY X up to a year, regardless of the dashboard's
    // selected range tab. Same shape as the 30-day timeline. Lightweight:
    // every bill/stay only contributes its total + IST day key, so even a
    // full year of data stays small enough for the system prompt.
    const day365Map = new Map<string, { rest: number; lodge: number; restBills: number; lodgeStays: number }>();
    for (let i = 364; i >= 0; i--) {
      const key = new Date(Date.now() - i * 86400000 + IST_OFFSET_MS).toISOString().slice(0, 10);
      day365Map.set(key, { rest: 0, lodge: 0, restBills: 0, lodgeStays: 0 });
    }
    for (const b of rest365) {
      const k = istDayKey(b.createdAt);
      const e = day365Map.get(k);
      if (e) { e.rest = round2(e.rest + b.total); e.restBills += 1; }
    }
    for (const b of lodge365) {
      const k = istDayKey(b.createdAt);
      const e = day365Map.get(k);
      if (e) { e.lodge = round2(e.lodge + b.total); e.lodgeStays += 1; }
    }
    const timeline365 = [...day365Map.entries()].map(([key, v]) => ({
      day: istDayLabel(key),
      restaurant: v.rest,
      restaurantBills: v.restBills,
      lodge: v.lodge,
      lodgeStays: v.lodgeStays,
    }));
    // t152 — pre-computed COMMON window sums so the AI doesn't have to
    // sum the array for the questions owners actually ask. Each entry is
    // "last N days, summed" for both books — saves a lot of token math
    // and lets the AI answer "give me the last 15 days total" instantly.
    const sumLast = (days: number) => {
      const slice = timeline365.slice(-days);
      return {
        days,
        restaurant: round2(slice.reduce((s, d) => s + d.restaurant, 0)),
        restaurantBills: slice.reduce((s, d) => s + d.restaurantBills, 0),
        lodge: round2(slice.reduce((s, d) => s + d.lodge, 0)),
        lodgeStays: slice.reduce((s, d) => s + d.lodgeStays, 0),
        combined: round2(slice.reduce((s, d) => s + d.restaurant + d.lodge, 0)),
      };
    };
    const windowSums = [7, 14, 15, 21, 30, 60, 90, 180, 365].map(sumLast);

    // t153 — PER-ROOM LODGE HISTORY. For every room (1..maxRooms), aggregate:
    //   · totalStays, totalRevenue, avgStayValue
    //   · firstStayDate, lastStayDate (IST day labels)
    //   · daysSinceLastStay (how long since the room was last used)
    //   · currently maintenance? daysUnderMaintenance (computed as
    //     "now - lastStayCheckOut" for rooms flagged mnt — best proxy we
    //     have without a maintenance-log table)
    // The AI can answer:
    //   "which room has been used the least?" → sort by totalStays asc
    //   "how many days has room X been under maintenance?" → rooms[X].daysUnderMaintenance
    //   "which is the most popular room?" → sort by totalStays desc
    const maxRoomsSetting = (() => {
      try {
        const n = Number(JSON.parse(maxSetting?.value ?? "null"));
        return Number.isFinite(n) && n > 0 ? Math.min(n, 200) : 100;
      } catch { return 100; }
    })();
    const mntRoomSet = new Set(mntRooms.map((r) => r.number));
    type RoomAgg = {
      room: number; tier: string; rate: number;
      totalStays: number; totalRevenue: number; avgStayValue: number;
      firstStayDate: string | null; lastStayDate: string | null;
      lastStayCheckOut: string | null;
      daysSinceLastStay: number | null;
      maintenance: boolean; daysUnderMaintenance: number | null;
      recentStays: Array<{ number: string; guestName: string; checkIn: string; checkOut: string; hours: number; total: number }>;
    };
    // Build the aggregation map in one pass over lodgeHistory (already
    // sorted desc by createdAt, so first encounter = latest stay).
    const roomAggMap = new Map<number, RoomAgg>();
    for (const b of lodgeHistory) {
      const r = b.room;
      let a = roomAggMap.get(r);
      if (!a) {
        a = {
          room: r, tier: b.tier, rate: b.rate,
          totalStays: 0, totalRevenue: 0, avgStayValue: 0,
          firstStayDate: null, lastStayDate: null,
          lastStayCheckOut: null,
          daysSinceLastStay: null,
          maintenance: mntRoomSet.has(r), daysUnderMaintenance: null,
          recentStays: [],
        };
        roomAggMap.set(r, a);
      }
      a.totalStays += 1;
      a.totalRevenue = round2(a.totalRevenue + b.total);
      const checkInKey = b.checkInAt ? istDayKey(b.checkInAt) : null;
      const checkOutKey = b.checkOutAt ? istDayKey(b.checkOutAt) : null;
      // lodgeHistory is sorted desc, so the FIRST encounter has the latest
      // createdAt — capture firstStayDate/lastStayDate/checkOut here.
      if (a.lastStayDate === null) {
        a.lastStayDate = checkOutKey ? istDayLabel(checkOutKey) : null;
        a.lastStayCheckOut = b.checkOutAt ? b.checkOutAt.toISOString() : null;
      }
      // Track the oldest stay as firstStayDate.
      a.firstStayDate = checkInKey ? istDayLabel(checkInKey) : a.firstStayDate;
      // Push the most recent 5 stays (cap to keep digest small).
      if (a.recentStays.length < 5) {
        a.recentStays.push({
          number: `L-${b.number}`,
          guestName: "",
          checkIn: b.checkInAt ? istDateTime(b.checkInAt) : "",
          checkOut: b.checkOutAt ? istDateTime(b.checkOutAt) : "",
          hours: b.hours,
          total: b.total,
        });
      }
    }
    // Now finalise: avg, days since last stay, maintenance duration.
    const nowMs = Date.now();
    for (const a of roomAggMap.values()) {
      a.avgStayValue = a.totalStays > 0 ? round2(a.totalRevenue / a.totalStays) : 0;
      if (a.lastStayCheckOut) {
        const lastMs = new Date(a.lastStayCheckOut).getTime();
        a.daysSinceLastStay = Math.max(0, Math.floor((nowMs - lastMs) / 86400000));
        if (a.maintenance) {
          a.daysUnderMaintenance = a.daysSinceLastStay;
        }
      } else if (a.maintenance) {
        // Maintenance with no history — assume today.
        a.daysUnderMaintenance = 0;
      }
    }
    // Build the array sorted by room ASC (1..N), plus a few useful derived
    // lists: least-used, most-used, currently-maintenance with durations.
    const perRoom: RoomAgg[] = Array.from({ length: maxRoomsSetting }, (_, i) => i + 1).map((n) => {
      const a = roomAggMap.get(n);
      if (a) return a;
      // Room that has never had a stay bill — synthesise an empty agg.
      const tier = levels.find((l) => n >= l.from && n <= l.to) ?? levels[0];
      return {
        room: n, tier: tier.name, rate: tier.rate,
        totalStays: 0, totalRevenue: 0, avgStayValue: 0,
        firstStayDate: null, lastStayDate: null, lastStayCheckOut: null,
        daysSinceLastStay: null,
        maintenance: mntRoomSet.has(n), daysUnderMaintenance: mntRoomSet.has(n) ? null : null,
        recentStays: [],
      };
    });
    const leastUsedRooms = [...perRoom].filter((r) => r.totalStays > 0).sort((a, b) => a.totalStays - b.totalStays || a.totalRevenue - b.totalRevenue).slice(0, 10);
    const mostUsedRooms = [...perRoom].filter((r) => r.totalStays > 0).sort((a, b) => b.totalStays - a.totalStays || b.totalRevenue - a.totalRevenue).slice(0, 10);
    const maintenanceRooms = perRoom.filter((r) => r.maintenance).map((r) => ({
      room: r.room,
      tier: r.tier,
      daysUnderMaintenance: r.daysUnderMaintenance,
      lastUsedDate: r.lastStayDate,
    }));

    // Today hour by hour — restaurant bills + lodge checkouts (IST clock).
    const restHour = new Map<number, { revenue: number; bills: number }>();
    for (const b of restRecentFull) {
      const ts = new Date(b.createdAt).getTime();
      if (ts < todayStart.getTime()) continue;
      const h = new Date(ts + IST_OFFSET_MS).getUTCHours();
      const e = restHour.get(h) ?? { revenue: 0, bills: 0 };
      e.revenue = round2(e.revenue + b.total);
      e.bills += 1;
      restHour.set(h, e);
    }
    const lodgeHour = new Map<number, { revenue: number; checkouts: number }>();
    for (const b of lodgeRecentFull) {
      const ts = new Date(b.createdAt).getTime();
      if (ts < todayStart.getTime()) continue;
      const h = new Date(ts + IST_OFFSET_MS).getUTCHours();
      const e = lodgeHour.get(h) ?? { revenue: 0, checkouts: 0 };
      e.revenue = round2(e.revenue + b.total);
      e.checkouts += 1;
      lodgeHour.set(h, e);
    }
    const todayHourly = {
      restaurant: [...restHour.entries()].sort((a, b) => a[0] - b[0]).map(([h, v]) => ({ hour: istHourLabel(h), ...v })),
      lodgeCheckouts: [...lodgeHour.entries()].sort((a, b) => a[0] - b[0]).map(([h, v]) => ({ hour: istHourLabel(h), ...v })),
    };

    const inHouseGuests = occRooms.map((r) => {
      const t = tierOfRoom(r.number, levels);
      return {
        room: r.number,
        guest: r.guestName,
        phone: r.guestPhone,
        tier: t.name,
        rate24h: t.rate,
        checkedInAt: r.checkInAt ? istDateTime(r.checkInAt) : null,
        hoursInHouse: hrsIn(r.checkInAt),
      };
    });

    const netProfit = {
      restaurant: { revenue: data.stats.revenue, ...data.books.rest },
      lodge: { revenue: data.lodge.revenue, ...data.books.lodge },
      combined: round2(data.books.rest.profit + data.books.lodge.profit),
    };

    /* ── t76 · operations feed: task completion + budget utilization ──
       Task flow = room turnaround: every checkout opens one housekeeping task,
       "maintenance done" closes it. Budget = month-to-date spend vs revenue
       per book (lower % = leaner book). Both computed from the same books. */
    const mntSet = new Set(mntRooms.map((r) => r.number));
    const turnaroundsToday = lodgeToday.length;
    const stillPendingToday = lodgeToday.filter((b) => mntSet.has(b.room)).length;
    const completedToday = turnaroundsToday - stillPendingToday;
    const completionPct =
      turnaroundsToday > 0 ? Math.round((completedToday / turnaroundsToday) * 100) : mntRooms.length > 0 ? 0 : 100;
    const monthRevenueOf = (rows: Array<{ createdAt: Date; total: number }>) =>
      round2(rows.filter((r) => new Date(r.createdAt).getTime() >= monthStart.getTime()).reduce((s, r) => s + r.total, 0));
    const spendOfBook = (book: "restaurant" | "lodge") =>
      round2(
        expMonthAgg
          .filter((g) => (g.book === "lodge" ? "lodge" : "restaurant") === book)
          .reduce((s, g) => s + (g._sum.amount ?? 0), 0),
      );
    const restSpendM = spendOfBook("restaurant");
    const lodgeSpendM = spendOfBook("lodge");
    const restRevM = monthRevenueOf(rest30);
    const lodgeRevM = monthRevenueOf(lodge30);
    const utilPct = (spend: number, rev: number) => (rev > 0 ? Math.round((spend / rev) * 100) : null);

    const operations = {
      housekeeping: {
        definition: "one task = one checkout's room turnaround; 'maintenance done' completes it",
        tasksCreatedToday: turnaroundsToday,
        tasksCompletedToday: completedToday,
        completionRatePct: completionPct,
        pendingRightNow: mntRooms.length,
        pendingRooms: mntRooms.map((r) => r.number),
        roomsReadyNow: maxRooms - mntRooms.length,
        readinessPct: Math.round(((maxRooms - mntRooms.length) / maxRooms) * 100),
      },
      budgetUtilization: {
        definition: "month-to-date spend vs month-to-date revenue, per book — lower % is leaner",
        monthStartIST: istDateTime(monthStart),
        restaurant: { spend: restSpendM, revenue: restRevM, utilizationPct: utilPct(restSpendM, restRevM) },
        lodge: { spend: lodgeSpendM, revenue: lodgeRevM, utilizationPct: utilPct(lodgeSpendM, lodgeRevM) },
        combined: {
          spend: round2(restSpendM + lodgeSpendM),
          revenue: round2(restRevM + lodgeRevM),
          utilizationPct: utilPct(restSpendM + lodgeSpendM, restRevM + lodgeRevM),
        },
        payroll: { monthlyCommitment: data.team.monthlyTotal, periodCostSoFar: data.team.periodCost },
      },
    };

    const toExp = (kind: string) =>
      expRows
        .filter((e) => e.kind === kind)
        .map((e) => ({
          label: e.label || "(unlabelled)",
          amount: round2(e.amount),
          book: e.book === "lodge" ? "lodge" : "restaurant",
          date: istDateTime(e.spentOn),
        }));

    /* ── t132 · SALARY STATUS — who is PAID vs PENDING, per recent month.
       The Salary Run only marks a month paid after it ends, so the most
       recent OVER month is the one that can be fully pending. */
    const curMonthKey = new Date(Date.now() + IST_OFFSET_MS).toISOString().slice(0, 7);
    const prevMonthKey = istMonthKeyOffset(1);
    const prev2MonthKey = istMonthKeyOffset(2);
    const [cy, cm] = curMonthKey.split("-").map(Number);
    const daysInCurMonth = new Date(Date.UTC(cy, cm, 0)).getUTCDate();
    const curIstDay = Number(new Date(Date.now() + IST_OFFSET_MS).toISOString().slice(8, 10));
    const salaryStatus = {
      rule: "a month can be marked PAID only after it ends; an employee lists as PENDING for a month that is over without their settlement, and as IN PROGRESS for the running month",
      perMonth: [
        { month: prev2MonthKey, state: "over" },
        { month: prevMonthKey, state: "over" },
        { month: curMonthKey, state: curIstDay >= daysInCurMonth ? "over" : "running" },
      ].map((m) => {
        const paidRows = salaryMonthRows.filter((s) => s.month === m.month);
        const paidNames = new Set(paidRows.map((s) => s.employee.name));
        return {
          month: m.month,
          state: m.state,
          paid: paidRows.map((s) => ({ name: s.employee.name, book: s.employee.book, netPaid: round2(s.netPaid), paidOn: s.paidAt ? istDateTime(s.paidAt) : null })),
          pending: teamEmps
            .filter((e) => !paidNames.has(e.name))
            .map((e) => ({ name: e.name, book: e.book, role: e.role, monthlySalary: e.salary, status: m.state === "over" ? "PENDING" : "in progress — month not over yet" })),
        };
      }),
    };

    const digest = {
      hotel: {
        name: hotelName,
        setup: "pure-vegetarian restaurant (Counter 01) + 100-room lodge on the same property",
        books: { restaurant: "FOOD & BEV", lodge: "ROOMS & STAYS" },
        currency: "INR (₹)", timezone: "IST",
        dataNote: "Every entry below was recorded by the owner specifically to feed you — it is the complete ground truth, newest first, all times IST.",
      },
      period: RANGE_META[range].label,
      timeline: {
        daily30: timeline,
        // t152 — full 365-day timeline + pre-computed common window sums
        // (7/14/15/21/30/60/90/180/365 days). The AI can answer "analyse
        // my last X days of sales" for ANY X up to a year, even when the
        // dashboard's selected range tab is "today" or "7d". Each daily
        // entry carries: day label, restaurant revenue + bill count,
        // lodge revenue + stay count. windowSums gives the totals for
        // common asks so the AI doesn't have to sum the array.
        daily365: timeline365,
        windowSums,
        todayHourly,
        hourlyAverages: data.hourly.series,
      },
      restaurant: {
        stats: data.stats,
        peak: data.peakLabel,
        itemsSold: data.itemsSold.slice(0, 15),
        categoryMix: data.categoryMix,
        trend: data.buckets.filter((b) => b.revenue > 0).slice(-14),
        recentBills: restRecentFull.map((b) => ({
          number: b.number,
          time: istDateTime(b.createdAt),
          total: b.total,
          discount: b.discount || undefined,
          items: b.items.map((i) => `${i.name}×${i.qty}`).join(", "),
        })),
        allTime: data.allTime,
        menu,
      },
      lodge: {
        revenue: data.lodge.revenue,
        stays: data.lodge.stays,
        avgStayValue: data.lodge.avgStay,
        deltaPct: data.lodge.deltaPct,
        peak: data.lodge.peakLabel,
        occupancy: {
          inHouse: data.lodge.inHouse,
          pctFull: data.lodge.pctFull,
          maintenanceRooms: mntRooms.map((r) => r.number),
          tonightIfAllStay: data.lodge.tonight,
          curveToday: data.lodge.dayCurve,
        },
        levels: levels.map((l) => ({ tier: l.name, rooms: `${l.from}-${l.to}`, rate24h: l.rate })),
        inHouseGuests,
        recentStayBills: lodgeRecentFull.map((b) => ({
          number: `L-${b.number}`,
          room: b.room,
          guest: b.guestName,
          phone: b.guestPhone || undefined,
          tier: b.tier,
          rate24h: b.rate,
          checkIn: istDateTime(b.checkInAt),
          checkOut: istDateTime(b.checkOutAt),
          hours: b.hours,
          total: b.total,
        })),
        allTime: { bills: lodgeAll._count, revenue: round2(lodgeAll._sum.total ?? 0) },
        stayMix: data.lodge.stayMix,
        revenueByLevel: data.lodge.tierMix,
        // t153 — per-room history. `perRoom` is sorted by room number 1..N;
        // `leastUsedRooms` / `mostUsedRooms` are top-10 slices for the
        // questions owners actually ask; `maintenanceRooms` lists every
        // room currently under maintenance with how many days it's been
        // in that state (best proxy: days since last checkout).
        perRoom,
        leastUsedRooms,
        mostUsedRooms,
        maintenanceRooms,
      },
      team: {
        employees: data.team.employees,
        monthlyPayroll: data.team.monthlyTotal,
        periodSalaryCost: data.team.periodCost,
        periodProjectedCost: data.team.projectedCost,
        salaryNote: "periodSalaryCost is the ACTUAL money paid (settled SalaryPayments inside the window, after attendance cuts) — periodProjectedCost is only the roster proration.",
      },
      // t119 — the salary ledger the owner actually settles month by month
      salaries: {
        rules: "salaries settle monthly; a month can be marked PAID only after it ends; cut = (absent days − paid holidays) × base ÷ days-in-month; the owner may hand over a different amount and it is recorded as-is",
        allTimeActuallyPaid: round2(salaryAgg._sum.netPaid ?? 0),
        allTimeCuts: round2(salaryAgg._sum.deduction ?? 0),
        settlements: salaryAgg._count,
        currentMonthStatus: "unpaid — month not over yet",
        // t132 — PAID vs PENDING per employee for the recent months
        salaryStatus,
        recent: salaryRecent.map((s) => ({
          employee: s.employee.name,
          book: s.employee.book,
          month: s.month,
          base: s.base,
          absent: s.absentDays,
          paidHolidays: s.paidHolidays,
          cut: s.deduction,
          netPaid: s.netPaid,
          paidOn: s.paidAt ? istDateTime(s.paidAt) : null,
        })),
      },
      // t120 — attendance for the SELECTED window; total days = the window length
      attendance: {
        windowDays: RANGE_META[range].days,
        rule: "every employee is measured on the SAME calendar — total days always equal the window length (1 today, 7 a week, 30 a month, 91 three months, 365 a year); unmarked days count as absent",
        employees: teamEmps.map((e) => {
          const p = attMarks.find((m) => m.employeeId === e.id && m.status === "present")?._count ?? 0;
          const present = Math.min(p, RANGE_META[range].days);
          return { name: e.name, book: e.book, present, absent: RANGE_META[range].days - present, total: RANGE_META[range].days };
        }),
      },
      // t121 — the owner's forwarded task board + the crown spends it produces
      ownerTasks: {
        rules: {
          freeTask: "no budget attached means the max budget is ₹0 — a FREE job; the team closes it having spent nothing",
          budgetedTask: "a budgeted task MUST carry an expense type (raw material / upgrade / maintenance) + a description; the team may spend less than the cap, never above it",
          crown: "every rupee spent closing an owner task auto-registers in that book's expense ledger tagged via='task'",
          conversation: "each task carries a `conversation` trail of updates and replies",
        },
        counts: {
          open: taskCounts.find((t) => t.status === "open")?._count ?? 0,
          done: taskCounts.find((t) => t.status === "done")?._count ?? 0,
        },
        recent: taskRecent.map((t) => ({
          title: t.title,
          book: t.book,
          kind: t.kind ?? "free",
          maxBudget: t.maxBudget,
          status: t.status,
          actualCost: t.actualCost ?? undefined,
          deadline: istDateTime(t.deadline),
          closedAt: t.doneAt ? istDateTime(t.doneAt) : undefined,
          // t130 — the task's conversation trail, newest first: progress updates
          // and queries from the reception desk, answered by the owner's replies
          conversation: [...t.updates].reverse().map((u) => ({
            from: u.author,
            by: u.role === "owner" ? "owner" : "reception",
            message: u.message.slice(0, 240),
            at: istDateTime(u.createdAt),
          })),
        })),
      },
      crownSpends: {
        note: "these expenses were made on the owner's direct order (via a forwarded task) — in the Expenses UI they carry the highlighted crown badge",
        recent: crownRows.map((c) => ({ label: c.label, amount: round2(c.amount), kind: c.kind, book: c.book, date: istDateTime(c.spentOn) })),
      },
      expenses: {
        thisMonthByBookKind: expMonthAgg.map((g) => ({
          book: g.book === "lodge" ? "lodge" : "restaurant",
          kind: g.kind,
          total: round2(g._sum.amount ?? 0),
          entries: g._count,
        })),
        rawMaterials: toExp("raw_material"),
        maintenance: toExp("maintenance"),
      },
      netProfit,
      operations,
    };

    const system = [
      `You are ${aiName} — the AI copilot inside the dashboard of ${hotelName.toUpperCase()} — a pure-vegetarian restaurant (Counter 01, India, ₹, IST) WITH a 100-room lodge on the same property. Two books: FOOD & BEV (restaurant) and ROOMS & STAYS (lodge). ${aiName} is YOUR name; ${hotelName} is the hotel running on the platform.`,
      `Your name is ${aiName}. The owner addresses you as '${aiName}', 'hey ${aiName}', or just by name. When they say 'hey ${aiName}' or '${aiName}, ...', they're talking to YOU — respond naturally as a colleague would, not as a generic chatbot. You may refer to yourself as ${aiName} in your replies ('As ${aiName}, I'd suggest...' or 'I'm ${aiName} — your business copilot'). This is your identity inside the dashboard.`,
      // ── SITE KNOWLEDGE: you know this site inside-out ──
      "t181 — SITE KNOWLEDGE: you are the AI inside the Fetch-X platform — a restaurant + lodge management dashboard for the OWNER only. Here is what you know about the site's structure and how to interpret the owner's requests:\n\n" +
      "THE SITE HAS THESE SECTIONS (owner only sees these):\n" +
      "1. **Live Dashboard** (sectionId: 'dashboard') — the owner's command center. Shows: stat cards (total revenue, restaurant bills + avg ticket, lodge stays + avg stay, in-house occupancy %), a sales curve chart (revenue over time), two revenue-split donuts (one per book — cost heads as slices + net profit), two revenue-breakdown cards (one per book — each cost as a bar + % of revenue + ₹ amount, with MARGIN %), a task-completion donut (4 slices: completed/late completed/incomplete/late incomplete), a budget-utilization bar (spent vs assumed), and an attendance wall (present vs absent per employee). The owner switches time ranges: TODAY / 7 DAYS / 1 MONTH / 3 MONTHS / 1 YEAR.\n" +
      "2. **Menu Manager** (sectionId: 'menu') — the owner's menu control. Shows all dishes by category with prices. The owner can add/edit/reprice dishes and sections here.\n" +
      "3. **Rooms Overview** (sectionId: 'lodge') — the owner's room monitoring. Shows the live room wall: 100 rooms, green=free, black=occupied, red=maintenance. The owner taps rooms to see status. Room levels: BASIC (1-40, ₹2,499/24h), STANDARD (41-80, ₹2,999/24h), LUXURY (81-100, ₹3,999/24h). Minimum stay charge ₹1,000. 5% GST on stays.\n" +
      "4. **Tasks** (sectionId: 'tasks') — the owner's forwarded-work board. The owner creates tasks (title, book=rest|lodge, deadline, optional max budget). Tasks without a budget are FREE. Budgeted tasks need an expense type (raw_material / upgrade / maintenance). The team closes them with the actual cost — never above the cap. Time filters: TODAY / 7 DAYS / 1 MONTH / 3 MONTHS / 1 YEAR / LATE.\n" +
      "5. **Expenses** (sectionId: 'expenses') — both books' cost ledger. Expenses tagged by book (restaurant or lodge) and kind (raw_material / upgrade / maintenance). The owner enters these by hand. Some expenses come from task closures (tagged via='task', wearing the owner's crown badge).\n" +
      "6. **Employee** (sectionId: 'management') — team roster + salaries. Shows all 11 employees with name, role, monthly salary, department (restaurant or lodge). The owner can add/edit/remove staff. Salaries settle monthly — a month can be marked PAID only after it ends. Salary rules: cut = (absent days − paid holidays) × base ÷ days-in-month.\n" +
      "7. **Settings** (sectionId: 'settings') — themes (9 themes, each with light + dark), AI voice pick, AI name (custom), floating task tracker on/off, paid holidays limit, discount % limit, hotel name.\n\n" +
      "INTERPRETING THE OWNER'S REQUESTS: The owner speaks naturally — they might say 'how's business', 'what's selling', 'who hasn't shown up', 'is the lodge full', 'what needs doing', 'any room problems', 'how much did we make', 'who's salary pending'. Use your intelligence + the [SCREEN CONTEXT] + the live JSON data to figure out EXACTLY what they mean:\n" +
      "- 'how's business' / 'how are we doing' → summarize today's revenue (both books), occupancy, and compare to yesterday.\n" +
      "- 'what's selling' / 'what's popular' → read restaurant.itemsSold, name the top dishes with quantities.\n" +
      "- 'who hasn't shown up' / 'attendance' → read attendance, name absent employees.\n" +
      "- 'is the lodge full' / 'occupancy' → read lodge.inHouse / lodge.totalRooms, give the % full.\n" +
      "- 'what needs doing' / 'what's pending' → read ownerTasks, list open tasks with deadlines.\n" +
      "- 'any room problems' / 'maintenance' → read lodge.maintenanceRooms, list rooms under maintenance with how many days.\n" +
      "- 'how much did we make' / 'revenue' / 'sales' → read stats.revenue, give the combined total + per-book breakdown.\n" +
      "- 'who's salary pending' / 'salaries' → read salaries.salaryStatus.perMonth, name the pending employees for the most recent month.\n" +
      "- 'expenses' / 'costs' / 'spending' → read expenses, summarize by kind and book.\n" +
      "- 'menu' / 'dishes' / 'prices' → read menu, list categories with items and prices.\n" +
      "- 'rooms' / 'which room' / 'room usage' → read lodge.perRoom, answer least/most used, maintenance duration, last stay date.\n" +
      "- 'profit' / 'margin' / 'bottom line' → read books.rest.profit + books.lodge.profit, give the combined + per-book margin %.\n" +
      "- 'compare' / 'trend' / 'vs' → read timeline.daily365 or windowSums, compare periods.\n" +
      "When the owner's request is AMBIGUOUS (could mean multiple things), pick the MOST LIKELY interpretation based on the [SCREEN CONTEXT] — if they're on the dashboard, they probably want a revenue/operations summary; if on tasks, they want task status; if on expenses, they want cost breakdown; if on rooms, they want room/occupancy info. If still ambiguous, give the most useful answer and offer alternatives ('Did you mean X or Y? I can show you both.').",
      "You advise the owner using ONLY the live JSON data provided after the user's message — never invent numbers, names, bills or entries.",
      "The data covers EVERYTHING, time-wise: a 30-day daily revenue timeline for both books; t152 — ALSO a full 365-day daily timeline (`timeline.daily365`) so you can answer ANY 'last X days' question (X up to a year) even when the dashboard's selected range is today or 7d. `timeline.windowSums` carries pre-summed totals for common asks (7/14/15/21/30/60/90/180/365 days) for both books combined and per-book — read these FIRST when the user asks for 'last N days' totals, only fall back to summing `daily365` if N is not in windowSums. today hour by hour; hourly averages; the latest restaurant bills with their items and exact times; lodge stays with check-in/check-out times; occupancy live including every in-house guest with name and check-in time; every recent expense tagged with the book it belongs to (restaurant or lodge); employees with names, roles, salaries and books; the full menu with prices; room levels and rates; stay mix and revenue by level; net profit per book and combined; PLUS operations data — housekeeping task completion (each checkout opens a room-turnaround task, completing maintenance closes it) and month-to-date budget utilization (spend vs revenue per book).",
      "t119/t120/t121 coverage — ACTUAL salaries: `salaries` holds every settled payment (base, absents, paid holidays, the cut, net paid, paid-on date) and `team.periodSalaryCost` is the real money paid after the cuts, never the roster figure. SALARY STATUS: `salaries.salaryStatus.perMonth` lists EXACTLY who is PAID and who is PENDING (or in progress) for the last three months — when asked \"whose salaries are pending?\" name the pending employees of the most recent OVER month from that field, never guess. ATTENDANCE: `attendance` measures every employee on the SAME calendar — total days = the selected window (1/7/30/91/365). OWNER TASKS: `ownerTasks` carries the forwarded-task board (open/done counts, budgets, actual costs) and its rules — a task with no budget is a FREE job (max budget ₹0), a budgeted task can never be closed above its cap — plus each recent task's `conversation` trail (updates and replies). CROWN: `crownSpends` lists expenses made on the owner's direct order. When asked about salaries, attendance, tasks or expenses, quote these fields.",
      "The owner records every bill, stay and expense precisely so you can interpret the business — treat each entry as ground truth and quote real names, items and ₹ figures with their dates when you advise.",
      "t153 — LODGE HISTORY: `lodge.perRoom` is a per-room array (rooms 1..N) with every room's totalStays, totalRevenue, avgStayValue, firstStayDate, lastStayDate, daysSinceLastStay, recentStays (5 latest), and maintenance flag + daysUnderMaintenance. Use it to answer 'which room has been used the least?' (sort by totalStays asc — `lodge.leastUsedRooms` is pre-sorted), 'which is the most popular room?' (`lodge.mostUsedRooms`), 'how many days has room X been under maintenance?' (look up `lodge.maintenanceRooms` — every entry has `room`, `daysUnderMaintenance`, `lastUsedDate`), 'when was room X last used?' (perRoom[X-1].lastStayDate). For occupancy trends use `lodge.perRoom[X-1].daysSinceLastStay` to spot underused wings.",
      "If a question needs data genuinely absent from the JSON, say so plainly instead of guessing.",
      "t149/t152 — INDIAN MONEY SYSTEM (very important): every figure is in Indian Rupees (₹) using the INDIAN numbering system, NEVER the Western 'hundred thousand' or 'million'. The Indian place-value chain goes: units → tens → hundreds → thousands → ten-thousands → lakhs → ten-lakhs → crores → ten-crores. ALWAYS speak the FULL chain — NEVER use the 'point' shorthand. Examples: ₹1,34,000 is spoken and written as 'one lakh thirty-four thousand rupees' (NOT 'one point three four lakh' and NOT 'one hundred thirty-four thousand'). ₹12,34,567 is 'twelve lakh thirty-four thousand five hundred sixty-seven rupees'. ₹2,47,268 is 'two lakh forty-seven thousand two hundred sixty-eight rupees'. ₹1,50,00,000 is 'one crore fifty lakh rupees'. ₹2,64,812 is 'two lakh sixty-four thousand eight hundred twelve rupees'. Use Indian comma grouping everywhere (right-to-left: first three digits, then pairs): ₹12,34,567 not ₹123,4567. NEVER write or say 'hundred thousand', 'million', or 'billion' — always lakh / crore. For amounts below ₹1,000 just say the number normally ('₹501.24' = 'five hundred one rupees twenty-four paise'). If a sum lands on a round lakh (₹2,00,000) you may say 'two lakh rupees' — but if there are non-zero thousands/hundreds below it, ALWAYS spell them out: 'two lakh sixty-four thousand eight hundred twelve' — never 'two point six four lakh'.",
      "t151 — SCREEN AWARENESS (CRITICAL — NEVER HALLUCINATE THE PAGE): the system prompt ends with a [SCREEN CONTEXT] block telling you EXACTLY which page the user is on (route, sectionId, sectionLabel), what viewState is active (range tab, filter, etc.) and the viewport size + zoom level. When the user says 'what am I looking at?' / 'see my page' / 'this page' / 'the screen I'm on' or refers to the current view — READ the [SCREEN CONTEXT] block FIRST and use the sectionLabel as your answer. If sectionId is 'menu', say 'the Menu page'. If sectionId is 'dashboard', say 'the Live Dashboard'. If sectionId is 'tasks', say 'the Tasks board'. NEVER guess the page from the data — if the context says 'menu' but you see restaurant bills in the JSON, still say 'menu' (the user is viewing the menu, not the POS). Do NOT mention pages that aren't in the screen context. The viewState JSON gives you the EXACT thing being shown — read it before answering.",
      "Your answers render as rich Markdown in the panel, so format them well: **bold** the key figures, use short bullet lists, and use Markdown tables when comparing dishes, days, books or options. Be concise and practical, and end with a concrete recommendation (pricing, staffing, promotions, occupancy, cost control). Generic cooking questions are out of scope.",
      "t171 — DASHBOARD TOUR: when the owner asks 'how do I use the live dashboard', 'explain the dashboard', 'guide me through it', 'walk me through the dashboard', or similar — explain each block of the Live Dashboard section by section, using the LIVE DATA from the JSON to give real examples. Walk through in this order: (1) The STAT CARDS at the top — total revenue (restaurant + lodge combined), restaurant bills count + average ticket, lodge stays + average stay value, in-house occupancy %. Explain what each number means and why it matters. (2) The SALES CURVE chart — the revenue trend over the selected period (today hour-by-hour, or daily/weekly/monthly for longer ranges). Explain the peak and dip patterns. (3) The REVENUE SPLIT DONUT — the donut that shows how each book's revenue is divided across cost heads (salaries, raw materials, upgrades, maintenance, discounts) and net profit. Read the slices from the JSON and quote the actual percentages. (4) The REVENUE BREAKDOWN (cost book card) — the horizontal bars showing each cost as a % of revenue, with the ₹ amount and % text. Explain what 'margin' means (profit ÷ revenue × 100). (5) The TASK COMPLETION DONUT — the 4-slice donut (completed green, late completed amber, not completed purple/gold, late & open rose). Explain what each color means and quote the actual counts. (6) The BUDGET UTILIZATION BAR — how much of the owner's assumed budget the team actually spent. Explain that under 100% is good (spent less than assumed). (7) The ATTENDANCE WALL — the bar chart showing present vs absent days per employee. Explain the split. End the tour by saying: 'That's the full dashboard. Ask me about any block if you want me to explain it again or go deeper.' The owner can then ask follow-up questions about any specific block, and you re-explain THAT block using the live data.",
      "t177 — AGENTIC NAVIGATION: you can navigate the owner to any section. When the owner says 'open [section]', 'go to [section]', 'show [section]' etc., the CLIENT navigates automatically (a separate fast intent-detection LLM figures out the action from the user's message + current screen context, then executes it deterministically — no regex guessing). DO NOT summarize or explain the page unless the owner EXPLICITLY asks (e.g., 'what am I looking at?', 'summarize this', 'explain this page'). Just acknowledge briefly in ONE short sentence: 'Opening tasks.' or 'Here you go — menu manager is open.' or 'Switched to expenses.' Nothing more unless asked.",
      "t184/t187 — TOGGLE CACHE + AI INTENT DETECTION (very important): every section's view toggles (range tab, scope chip, filter chip, salary month, attendance date, etc.) now PERSIST across section switches — when the owner opens 'Live Dashboard in yearly view', switches to Tasks and back, the dashboard is STILL in yearly view. A separate fast intent-detection LLM (called before this main AI) reads every user message + the current screen context and decides whether to: (a) navigate to a section with specific toggles applied, (b) apply toggles to the current section, (c) resize the AI panel, (d) collapse/expand the sidebar, (e) close/clear, or (f) treat as a question and pass through to YOU (this main AI). The intent LLM's job is decision + execution; YOUR job (when the message is a question) is to ANSWER. Don't try to navigate yourself — the intent LLM already handled it before you see the message. When the owner asks 'what am I looking at?' / 'what toggle am I on?' — read the [SCREEN CONTEXT]'s viewState JSON: it shows the EXACT current values per kind (range/scope/filter/etc.). When in doubt about which toggle the owner means, read viewState first.",
    ].join(" ") + screenContextBlock;

    // t147 — LIVE TALK: swap to a spoken-language system prompt. The reply
    // is read aloud by a TTS engine, so it MUST be plain text — no markdown,
    // no asterisks, no bullet markers, no tables, no code fences. Short,
    // natural, conversational. Always one paragraph or two short ones,
    // never longer than ~70 words so the spoken reply stays snappy.
    //
    // t159 — the reply now carries TWO parts separated by a literal
    // delimiter line `---FORMAT---`:
    //   1) SPOKEN — plain prose for TTS (no markdown)
    //   2) FORMATTED — rich markdown (with tables, bullets) for the chat
    //      bubble that appears BELOW the spoken text
    // The client splits on the delimiter, reads the spoken part aloud,
    // and renders the formatted part as Markdown. The spoken reply should
    // REFER to the table ("refer the table below for the room-wise
    // breakdown...") so the user knows where to look.
    const liveSystem = [
      `You are ${aiName} — the AI copilot inside ${hotelName.toUpperCase()}, on a live voice call with the owner. The owner is talking to you out loud — you reply in spoken natural language.`,
      `Your name is ${aiName}. The owner calls you '${aiName}', 'hey ${aiName}', or just by name. When they say 'hey ${aiName}' or '${aiName}, ...' they're addressing YOU — respond naturally, like a colleague on the phone. You can refer to yourself as ${aiName} ('Hey, this is ${aiName} — your revenue today is...'). This is your identity inside the dashboard.`,
      "Use ONLY the live JSON data after the user's message. Never invent numbers, names or entries.",
      "t153 — LODGE HISTORY is in `lodge.perRoom` (rooms 1..N with totalStays, lastStayDate, daysSinceLastStay, maintenance flag + daysUnderMaintenance), `lodge.leastUsedRooms`, `lodge.mostUsedRooms`, and `lodge.maintenanceRooms`. When the owner asks 'which room is least used?' / 'how long has room X been under maintenance?' / 'when was room Y last booked?' — read these fields directly. Don't guess room numbers; quote the actual data.",
      "Speak in plain conversational English (or match the owner's language if they spoke in another). Keep it SHORT — one or two short paragraphs, ~70 words max. Sound natural, like you are on a phone call, not reading a report.",
      "t149/t152/t155/t156 — INDIAN MONEY (output ₹ NUMERALS, the TTS engine converts them to spoken words automatically): WRITE every rupee amount as a ₹ numeral with INDIAN comma grouping — e.g. write '₹2,64,812' NOT 'two lakh sixty-four thousand'. The text-to-speech layer on the client will read the numeral aloud as 'rupees two lakh sixty-four thousand eight hundred twelve' — you don't have to spell it out. NEVER write 'hundred thousand', 'million', or 'billion'. Use Indian comma grouping (right-to-left: first three digits, then pairs): ₹12,34,567 not ₹123,4567. For paise use a decimal point: '₹501.24' (the TTS reads as 'rupees five hundred one point two four'). Round-lakh totals are fine as '₹2,00,000' or '₹2L'; crore totals as '₹1,50,00,000' or '₹1.5Cr'. Just write the NUMERAL and the TTS handles the spoken chain. Examples of correct output: 'Today the restaurant made ₹17,543 from 35 bills, the lodge made ₹2,47,268 from 48 stays, combined ₹2,64,812.' — that's it, no need to spell the words out.",
      "t151 — SCREEN AWARENESS (CRITICAL — NEVER HALLUCINATE THE PAGE): the system prompt ends with a [SCREEN CONTEXT] block telling you EXACTLY which page the owner is on (route, sectionId, sectionLabel), what viewState is active (range tab, filter, etc.) and the viewport size + zoom level. When the owner says 'what am I looking at?' / 'see my page' / 'this page' / 'the screen I'm on' — READ the [SCREEN CONTEXT] block FIRST and use the sectionLabel as your answer. If sectionId is 'menu', say 'the Menu page'. If sectionId is 'dashboard', say 'the Live Dashboard'. NEVER guess the page from the data — if the context says 'menu' but you see restaurant bills in the JSON, still say 'menu'. Do NOT mention pages that aren't in the screen context.",
      "Quote real ₹ figures and real names where it matters, then end with ONE concrete recommendation as a plain sentence.",
      "t177 — AGENTIC NAVIGATION: when the owner says 'open [section]' etc., the CLIENT navigates automatically (a fast intent-detection LLM decides the action deterministically before this main AI sees the message). DO NOT summarize or explain the page unless the owner asks. Just say ONE short sentence: 'Opening tasks.' or 'Menu manager is open.' Nothing more unless asked.",
      "t184/t187 — TOGGLE CACHE + AI INTENT DETECTION: every section's view toggles now persist across section switches ('open dashboard in yearly view' → leaves to Tasks → comes back, dashboard is STILL yearly view). A separate fast intent-detection LLM (called before this main AI) reads every user message + the current screen context and decides whether to navigate, apply toggles, resize the panel, collapse/expand the sidebar, close/clear, or treat as a question and pass through to YOU. When the message IS a question, the intent LLM passes it through to you — answer normally. Read the [SCREEN CONTEXT]'s viewState JSON to know which toggles are currently active.",
      "t171 — DASHBOARD TOUR: when the owner asks 'how do I use the live dashboard' or 'explain the dashboard' — walk through each block using the LIVE DATA: stat cards (revenue, bills, occupancy), sales curve (peak/dip patterns), revenue split donut (cost heads + profit), revenue breakdown bars (% of revenue), task completion donut (4 colors: completed/late completed/not completed/late & open), budget utilization bar (spent vs assumed), and attendance wall (present vs absent). Use real numbers from the JSON. End with: 'That's the full dashboard — ask me about any block to go deeper.' The owner can ask follow-up questions about any specific block.",
      "t159 — REPLY FORMAT (very important): your reply MUST have TWO sections separated by a line that contains exactly `---FORMAT---` (three dashes, the word FORMAT, three dashes). The FIRST section is the SPOKEN reply — plain prose only, no markdown, no tables, no asterisks. ~70 words max. This is what the TTS reads aloud. The SECOND section is the FORMATTED reply — full rich Markdown with **bold** figures, bullet lists, and GFM tables where useful. This appears BELOW the spoken bubble in the chat. The spoken reply should REFER to the formatted section ('refer the table below for the room-wise breakdown...') so the user knows to look at the formatted version. Example shape: `Today the lodge made ₹2,47,268 — luxury and basic rooms drove most of it, standard rooms were quieter. Refer to the table below for the room-wise breakdown.\\n---FORMAT---\\n## Lodge Revenue Today\\n| Tier | Stays | Revenue |\\n|---|---|---|\\n| LUXURY | 18 | ₹1,20,000 |\\n| ...` — the spoken part is plain prose ending with a pointer to the table; the formatted part has the actual Markdown table.",
    ].join(" ") + screenContextBlock;

    const reply = await aiChat(
      [
        { role: "system", content: liveMode ? liveSystem : system },
        ...history,
        {
          role: "user",
          content: `${message}\n\n[LIVE DATA · period = ${RANGE_META[range].label}]\n${JSON.stringify(digest)}`,
        },
      ],
      // t159 — live mode now writes BOTH a spoken reply + a formatted
      // markdown section, so it needs more tokens than the old 600-cap.
      { temperature: 0.3, maxTokens: liveMode ? 1600 : 2048 }
    );
    if (!reply) return NextResponse.json({ error: "AI returned an empty response" }, { status: 502 });
    // t159 — in live mode, split the reply on the `---FORMAT---` delimiter
    // into a `spoken` (plain prose for TTS) and `formatted` (rich Markdown
    // for the bubble below). The client speaks the spoken part aloud AND
    // renders the formatted part as Markdown. Falls back gracefully if
    // the AI didn't emit the delimiter (treat the whole reply as spoken,
    // no formatted section).
    if (liveMode) {
      const delimIdx = reply.indexOf("---FORMAT---");
      let spoken: string;
      let formatted: string | null;
      if (delimIdx === -1) {
        spoken = reply.trim();
        formatted = null;
      } else {
        spoken = reply.slice(0, delimIdx).trim();
        formatted = reply.slice(delimIdx + "---FORMAT---".length).trim();
        if (!formatted) formatted = null;
      }
      return NextResponse.json({ reply: spoken, formatted, spoken });
    }
    return NextResponse.json({ reply });
  } catch (e) {
    console.error("AI route failed:", e);
    return NextResponse.json({ error: "The AI copilot is unavailable right now." }, { status: 500 });
  }
}
