import path from "node:path";
import { fileURLToPath } from "node:url";
import type { NextConfig } from "next";

/* The folder that physically contains this config file. Deliberately NOT
   process.cwd(): Next.js evaluates the config only after pre-inferring a
   "root" from lockfiles it finds in parent folders, and may evaluate the
   config with that other cwd — pinning the wrong root and silently loading
   the wrong .env / database. The config file's own location cannot lie. */
const projectRoot = path.dirname(fileURLToPath(import.meta.url));

const nextConfig: NextConfig = {
  output: "standalone",
  /* Pin the workspace root to THIS folder so .env, db/ and node_modules
     always resolve here, wherever the project is extracted. */
  turbopack: {
    root: projectRoot,
  },
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  /* The dev-tools "N" bubble sits bottom-left and blocks the sidebar's
     SIGN OUT button (and other corner controls) during preview. */
  devIndicators: false,
};

export default nextConfig;
