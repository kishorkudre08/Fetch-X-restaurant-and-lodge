#!/bin/bash
# "last demo" zip — same payload contract as the user's own
# make-last-prototype-zip.sh (source + db + docs, no build junk),
# snapshotted AFTER the attendance-split fix (t138), BEFORE the
# forced-landscape experiment.
set -e
cd /home/z/my-project

STAGE=$(mktemp -d)
NAME="last demo"
mkdir -p "$STAGE/$NAME"

rsync -a \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'download' \
  --exclude 'skills' \
  --exclude 'tool-results' \
  --exclude 'upload' \
  --exclude 'worklog.md' \
  --exclude 'server.log' \
  --exclude '*.log' \
  --exclude '.git' \
  --exclude 'ref-screenshot.png' \
  --exclude 'fetch-x' \
  --exclude 'tsconfig.tsbuildinfo' \
  ./ "$STAGE/$NAME/"

cd "$STAGE"
zip -rq9 "/home/z/my-project/download/last demo.zip" "$NAME"
cd /home/z/my-project
rm -rf "$STAGE"

ls -lh "download/last demo.zip"
unzip -l "download/last demo.zip" | tail -3
