#!/bin/bash
# "final product" zip — same payload contract as make-last-demo-zip.sh
# (source + db + docs, no build junk), snapshotted AFTER t142 (side-panel
# scroll shift), so it carries: attendance split, forced-landscape stage
# (t140), theme-preview-matched palettes (t141) and the panel shift.
set -e
cd /home/z/my-project

STAGE=$(mktemp -d)
NAME="final product"
mkdir -p "$STAGE/$NAME"

rsync -a \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'download' \
  --exclude 'skills' \
  --exclude 'tool-results' \
  --exclude 'upload' \
  --exclude 'worklog.md' \
  --exclude 'server.log' \
  --exclude '*.log' \
  --exclude '.git' \
  --exclude 'ref-screenshot.png' \
  --exclude 'fetch-x' \
  --exclude 'tsconfig.tsbuildinfo' \
  ./ "$STAGE/$NAME/"

cd "$STAGE"
# rm first — plain `zip -r` into an existing archive only ADDS/UPDATES entries,
# it never removes ones deleted from the source (bit us on the t142 revert)
rm -f "/home/z/my-project/download/final product.zip"
zip -rq9 "/home/z/my-project/download/final product.zip" "$NAME"
cd /home/z/my-project
rm -rf "$STAGE"

ls -lh "download/final product.zip"
unzip -l "download/final product.zip" | tail -3
