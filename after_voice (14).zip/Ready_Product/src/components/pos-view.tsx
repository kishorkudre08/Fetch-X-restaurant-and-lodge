"use client";

// ── POS Terminal — the counter bills, the owner runs the menu ───────────────
// t98: the menu editor moved here from Management. t115: the OWNER's screen is
// the MENU MANAGER — menu control only (no billing dock, no bills feed, no
// expense entry — the counter bills, the stations keep their own expenses).
// Every removal (a dish or a whole section) opens a WARNING dialog that stays
// LOCKED for 10 seconds before the delete can fire. The receptions keep the
// pure counter: tap dishes → generate the bill.

import * as React from "react";
import { Minus, Plus, Receipt, Search, Trash2, Loader2, Pencil, Zap, LayoutGrid, Check, X, AlertTriangle, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand, VegDot, ScrollFadeBox } from "@/components/fx";
import { BillsFeed } from "@/components/bills-feed";
import { useReceipt } from "@/components/receipt-dialog";
import { useHotel } from "@/components/hotel-context";
import { useToast } from "@/hooks/use-toast";
import type { Bill, Category, Dish } from "@/lib/types";
import { bindFxTouchScroll } from "@/lib/fx-touch";
import { inr, inr2, istDateLong, istTime } from "@/lib/format";

const GST_RATE = 0.05;

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-");

type CartLine = { dish: Dish; qty: number };

// ── the owner's blank add-dish block — one in every single-section view ──────
// t152 — the blended ALL grid no longer carries an ADD DISH block (owner's
// ask): adding happens from the SECTION view only — tap a category chip and
// use that section's trailing block.
function AddDishTile({
  category,
  onAdded,
}: {
  category: string;
  onAdded: () => void;
}) {
  const { toast } = useToast();
  const [cat, setCat] = React.useState(category);
  React.useEffect(() => setCat(category), [category]);
  const [name, setName] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [veg, setVeg] = React.useState(true);
  const [busy, setBusy] = React.useState(false);

  const add = async () => {
    const amt = Number(price);
    if (!name.trim() || !Number.isFinite(amt) || amt <= 0) {
      toast({
        title: "Missing details",
        description: "The dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/menu", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), price: amt, category: cat, veg }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not add the dish");
      toast({ title: `“${name.trim()}” added to ${cat}` });
      setName("");
      setPrice("");
      setVeg(true);
      onAdded();
    } catch (e) {
      toast({
        title: "Could not add the dish",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/45 px-3.5 py-3 text-left"
      data-testid={`pos-add-dish-${cat.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
    >
      <span className="fx-label flex flex-wrap items-center gap-1.5">
        <Plus className="h-3 w-3" /> ADD DISH · {category.toUpperCase()}
      </span>
      <div className="mt-2 space-y-1.5">
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Dish name…"
          aria-label={`New dish name for ${category}`}
          className="h-8 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-semibold"
        />
        <div className="flex items-center gap-1.5">
          <Input
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="₹"
            type="number"
            min={0}
            aria-label={`New dish price for ${category}`}
            className="fx-num h-8 w-[86px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-bold"
          />
          <label className="flex h-8 items-center gap-1.5 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2 text-[10px] font-extrabold text-[var(--fx-ink)]">
            <VegDot veg={veg} /> VEG
            <Switch checked={veg} onCheckedChange={setVeg} aria-label={`Vegetarian toggle for new ${category} dish`} />
          </label>
          <Button
            size="sm"
            onClick={() => void add()}
            disabled={busy}
            className="ml-auto h-8 rounded-lg bg-[var(--fx-purple)] px-2.5 text-[10px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />} ADD
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── the owner's edit-dish dialog ─────────────────────────────────────────────
function EditDishDialog({
  dish,
  onClose,
  onSaved,
}: {
  dish: Dish;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [name, setName] = React.useState(dish.name);
  const [price, setPrice] = React.useState(String(dish.price));
  const [veg, setVeg] = React.useState(dish.veg);
  const [busy, setBusy] = React.useState(false);

  const save = async () => {
    const amt = Number(price);
    if (!name.trim() || !Number.isFinite(amt) || amt <= 0) {
      toast({
        title: "Missing details",
        description: "Dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/menu/${dish.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), price: amt, veg }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Save failed");
      toast({
        title: name.trim() === dish.name ? `${name.trim()} → ${inr(amt)}` : `Renamed to “${name.trim()}” — past bills keep their history`,
      });
      onSaved();
      onClose();
    } catch (e) {
      toast({
        title: "Could not save",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent className="fx-pop-in max-w-[400px]" data-testid="pos-dish-edit-modal">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight">Edit “{dish.name}”</DialogTitle>
          <DialogDescription>
            Renames and price changes keep the dish's full sales history — old bills stay exactly as printed.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2.5">
          <div>
            <span className="fx-label">DISH NAME</span>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              aria-label="Dish name"
              data-testid="pos-dish-edit-name"
              className="mt-1.5 h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
            />
          </div>
          <div>
            <span className="fx-label">PRICE ₹</span>
            <Input
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              type="number"
              min={0}
              aria-label="Dish price"
              data-testid="pos-dish-edit-price"
              className="fx-num mt-1.5 h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
          </div>
          <label className="flex h-10 items-center justify-between rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 text-[11.5px] font-extrabold text-[var(--fx-ink)]">
            <span className="flex items-center gap-2"><VegDot veg={veg} /> VEGETARIAN</span>
            <Switch checked={veg} onCheckedChange={setVeg} aria-label="Toggle vegetarian" />
          </label>
        </div>
        <div className="flex items-center justify-end gap-2">
          <Button variant="ghost" onClick={onClose} className="rounded-xl text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)]">
            CANCEL
          </Button>
          <Button
            onClick={() => void save()}
            disabled={busy}
            data-testid="pos-dish-edit-save"
            className="rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} SAVE DISH
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── t115 — the delete WARNING dialog: armed deletions stay LOCKED for 10s ───
function DeleteWarningDialog({
  kind,
  name,
  live,
  busy,
  onClose,
  onConfirm,
}: {
  kind: "dish" | "category";
  name: string;
  live?: number;
  busy: boolean;
  onClose: () => void;
  onConfirm: () => void;
}) {
  /* the 10-second lock — the dialog remounts per target, so the countdown
     always restarts from 10 */
  const [left, setLeft] = React.useState(10);
  React.useEffect(() => {
    const t = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);
  const locked = left > 0;
  const catBlocked = kind === "category" && (live ?? 0) > 0;

  return (
    <Dialog open onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent
        className="fx-pop-in max-w-[430px]"
        data-testid={kind === "dish" ? "pos-delete-dish-modal" : "pos-delete-cat-modal"}
      >
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight">
            {kind === "dish" ? `Remove “${name}” from the menu?` : `Delete section “${name}”?`}
          </DialogTitle>
          <DialogDescription>
            {kind === "dish"
              ? `“${name}” leaves the counter immediately. Past bills keep their printed snapshots — history stays intact.`
              : catBlocked
                ? `“${name}” still has ${live} live ${live === 1 ? "dish" : "dishes"} — a section can only be deleted once its dishes are removed or moved. Already-removed dishes under it are purged with it.`
                : "The section closes at once — any already-removed dishes under it are purged with it. Past bills keep their printed snapshots."}
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-start gap-2 rounded-xl border border-dashed border-[var(--fx-rose)]/50 bg-[var(--fx-rose)]/5 px-3.5 py-2.5 text-[11.5px] font-bold leading-snug text-[var(--fx-rose)]">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            THIS CANNOT BE UNDONE — THE DELETE STAYS LOCKED FOR 10 SECONDS.
            {catBlocked ? " THE MENU GUARD WILL REFUSE WHILE LIVE DISHES REMAIN." : " READ THE WARNING BEFORE YOU FIRE."}
          </span>
        </div>
        <div className="flex items-center justify-end gap-2">
          <Button
            variant="ghost"
            onClick={onClose}
            data-testid={kind === "dish" ? "pos-delete-dish-cancel" : "pos-delete-cat-cancel"}
            className="rounded-xl text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)]"
          >
            KEEP IT
          </Button>
          <Button
            onClick={onConfirm}
            disabled={locked || busy}
            data-testid={kind === "dish" ? "pos-delete-dish-confirm" : "pos-delete-cat-confirm"}
            className="rounded-xl bg-[var(--fx-rose)] px-4 text-[11.5px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-rose)]/90 disabled:opacity-60"
          >
            {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : null}
            {locked ? `LOCKED · ${left}s` : "YES, DELETE"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── one dish tile — the counter's tap-to-bill card; the owner's menu card
//    carries ✎/🗑 corner controls instead (t115 — Menu Manager) ─────────────
function DishTile({
  d,
  qty,
  owner,
  onAdd,
  onDec,
  onInc,
  onEdit,
  onDelete,
}: {
  d: Dish;
  qty: number; // counter mode only — the menu card never bills
  owner: boolean;
  onAdd?: () => void;
  onDec?: () => void;
  onInc?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
}) {
  if (owner) {
    /* t115 — the owner's MENU CARD: name, price, edit + delete. No cart, no
       steppers — billing lives at the reception counter. */
    return (
      <div className="fx-tile group relative px-4 py-3.5 text-left" data-testid={`pos-dish-owner-${slug(d.name)}`}>
        <span className="absolute right-1.5 top-1.5 flex items-center gap-1 opacity-70 transition group-hover:opacity-100">
          <button
            aria-label={`Edit ${d.name}`}
            title="Edit dish"
            data-testid={`pos-dish-edit-${slug(d.name)}`}
            onClick={(e) => {
              e.stopPropagation();
              onEdit?.();
            }}
            className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] transition hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
          >
            <Pencil className="h-3 w-3" />
          </button>
          <button
            aria-label={`Delete ${d.name}`}
            title="Remove from the menu — a warning with a 10s lock opens first"
            data-testid={`pos-dish-delete-${slug(d.name)}`}
            onClick={(e) => {
              e.stopPropagation();
              onDelete?.();
            }}
            className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] transition hover:border-[var(--fx-rose)] hover:text-[var(--fx-rose)]"
          >
            <Trash2 className="h-3 w-3" />
          </button>
        </span>
        <div className="flex items-start gap-2 pr-16">
          <VegDot veg={d.veg} className="mt-0.5" />
          <span className="line-clamp-2 min-h-[32px] text-[13px] font-bold leading-snug text-[var(--fx-ink)]">
            {d.name}
          </span>
        </div>
        <div className="mt-2 flex items-center justify-between">
          <span className="fx-num text-[14px] font-extrabold text-[var(--fx-accent-ink)]">
            {inr(d.price)}
          </span>
        </div>
      </div>
    );
  }
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`Add ${d.name} to the bill`}
      onClick={onAdd}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onAdd?.();
        }
      }}
      className={`fx-tile group relative cursor-pointer px-4 py-3.5 text-left ${qty > 0 ? "in-cart" : ""}`}
    >
      {qty > 0 && (
        <span className="fx-num absolute -right-1.5 -top-1.5 grid h-6 min-w-6 place-items-center rounded-full bg-[var(--fx-purple)] px-1 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]">
          {qty}
        </span>
      )}
      <div className="flex items-start gap-2">
        <VegDot veg={d.veg} className="mt-0.5" />
        <span className="line-clamp-2 min-h-[32px] text-[13px] font-bold leading-snug text-[var(--fx-ink)]">
          {d.name}
        </span>
      </div>
      <div className="mt-2 flex items-center justify-between">
        <span className="fx-num text-[14px] font-extrabold text-[var(--fx-accent-ink)]">
          {inr(d.price)}
        </span>
        {qty === 0 ? (
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--fx-lav)] text-[var(--fx-accent-ink)] transition group-hover:bg-[var(--fx-purple)] group-hover:text-[var(--fx-on-accent)]">
            <Plus className="h-4 w-4" />
          </span>
        ) : (
          <span className="flex items-center gap-1">
            <span
              role="button"
              aria-label={`Decrease ${d.name}`}
              onClick={(e) => {
                e.stopPropagation();
                onDec?.();
              }}
              className="grid h-7 w-7 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)]"
            >
              <Minus className="h-3.5 w-3.5" />
            </span>
            <span
              role="button"
              aria-label={`Increase ${d.name}`}
              onClick={(e) => {
                e.stopPropagation();
                onInc?.();
              }}
              className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
            >
              <Plus className="h-3.5 w-3.5" />
            </span>
          </span>
        )}
      </div>
    </div>
  );
}

// ── Billing dock — lives at the BOTTOM of the POS screen ────────────────────
function BillingDock({
  lines,
  setQty,
  removeLine,
  discount,
  setDiscount,
  onGenerate,
  generating,
  billCount,
  discLimit,
}: {
  lines: CartLine[];
  setQty: (dishId: string, qty: number) => void;
  removeLine: (dishId: string) => void;
  discount: number;
  setDiscount: (n: number) => void;
  onGenerate: () => void;
  generating: boolean;
  billCount: number;
  /** t143 — the owner's discount limit % from Settings; inputs clamp to it */
  discLimit: number;
}) {
  const { toast } = useToast();
  const { upperName } = useHotel();
  const subtotal = lines.reduce((s, l) => s + l.dish.price * l.qty, 0);
  const disc = Math.min(discount || 0, subtotal);
  /* t143 — the reception may never discount more than the owner's limit % of
     this bill (paise-exact, rounded down). The input clamps live and the
     generate call + the API re-check it again. */
  const discCap = Math.floor(subtotal * discLimit) / 100;
  const taxable = subtotal - disc;
  const tax = Math.round(taxable * GST_RATE * 100) / 100;
  const total = taxable + tax;
  const items = lines.reduce((s, l) => s + l.qty, 0);

  return (
    <div className="space-y-3">
      {/* header row */}
      <div className="flex flex-wrap items-center gap-2.5">
        <div className="min-w-0">
          <div className="fx-label">CURRENT BILL · {upperName}</div>
          <div className="truncate text-[12.5px] font-bold text-[var(--fx-ink)]">
            Counter 01 · {istDateLong()}
          </div>
        </div>
        <span className="fx-num rounded-full bg-[var(--fx-purple)] px-3 py-1 text-[11px] font-extrabold text-[var(--fx-on-accent)]">
          {items} ITEM{items === 1 ? "" : "S"}
        </span>
        <span className="ml-auto hidden text-[10px] font-bold tracking-[0.1em] text-[var(--fx-muted)] md:block">
          {billCount > 0
            ? `${billCount} BILL${billCount === 1 ? "" : "S"} TODAY · AUTO-RECORDED`
            : "DISH · QTY · TIME AUTO-RECORDED"}
        </span>
      </div>

      {/* item chips — horizontal scroller */}
      <div className="fx-scroll -mx-1 flex gap-2 overflow-x-auto px-1 py-0.5">
        {lines.length === 0 ? (
          <p className="py-1.5 text-[12.5px] font-semibold text-[var(--fx-muted)]">
            Cart is empty — tap dishes above and they land here. The bill writes itself to the
            database.
          </p>
        ) : (
          lines.map((l) => (
            <div
              key={l.dish.id}
              className="flex shrink-0 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] py-1.5 pl-2.5 pr-2"
            >
              <VegDot veg={l.dish.veg} />
              <span className="max-w-[150px] truncate text-[12.5px] font-bold text-[var(--fx-ink)]">
                {l.dish.name}
              </span>
              <span className="flex items-center gap-1">
                <button
                  aria-label={`Decrease ${l.dish.name}`}
                  onClick={() => setQty(l.dish.id, l.qty - 1)}
                  className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
                >
                  <Minus className="h-3 w-3" />
                </button>
                <span className="fx-num w-5 text-center text-[12.5px] font-extrabold">{l.qty}</span>
                <button
                  aria-label={`Increase ${l.dish.name}`}
                  onClick={() => setQty(l.dish.id, l.qty + 1)}
                  className="grid h-6 w-6 place-items-center rounded-lg bg-[var(--fx-purple)] text-[var(--fx-on-accent)] hover:bg-[var(--fx-purple-deep)]"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </span>
              <span className="fx-num min-w-[52px] text-right text-[12px] font-extrabold text-[var(--fx-accent-ink)]">
                {inr(l.dish.price * l.qty)}
              </span>
              <button
                aria-label={`Remove ${l.dish.name}`}
                onClick={() => removeLine(l.dish.id)}
                className="grid h-6 w-6 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* totals row */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-3 border-t border-dashed border-[var(--fx-line)] pt-3">
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>SUBTOTAL</span>
          <span className="text-[var(--fx-ink)]">{inr2(subtotal)}</span>
        </div>
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>GST 5%</span>
          <span className="text-[var(--fx-ink)]">{inr2(tax)}</span>
        </div>
        <label className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>DISCOUNT ₹</span>
          <Input
            type="number"
            min={0}
            value={discount || ""}
            placeholder="0"
            onChange={(e) => {
              const next = Math.max(0, Number(e.target.value) || 0);
              if (next > discCap) {
                /* t143 — the owner's rule bites right at the keystroke */
                setDiscount(discCap);
                toast({
                  title: "Discount capped by the owner's limit",
                  description: `Receptions can discount at most ${discLimit}% of the bill — ${inr2(discCap)} on this one.`,
                });
              } else {
                setDiscount(next);
              }
            }}
            className="fx-num h-8 w-20 border-[var(--fx-line)] bg-[var(--fx-page)] text-right text-[12.5px] font-bold"
            aria-label="Discount in rupees"
          />
          {discLimit < 100 && subtotal > 0 && (
            <span
              className="fx-num whitespace-nowrap rounded-full border border-dashed border-[var(--fx-line)] px-2 py-0.5 text-[9.5px] font-extrabold tracking-wider text-[var(--fx-muted)]"
              title={`The owner allows at most ${discLimit}% of the bill as discount`}
            >
              MAX {inr2(discCap)}
            </span>
          )}
        </label>
        <div className="flex items-baseline gap-2">
          <span className="fx-label">TOTAL</span>
          <span className="fx-num text-xl font-extrabold text-[var(--fx-ink)]">{inr2(total)}</span>
        </div>
        <Button
          disabled={lines.length === 0 || generating}
          onClick={onGenerate}
          className="ml-auto h-12 rounded-2xl bg-[var(--fx-purple)] px-7 text-[13px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          {generating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> SAVING BILL…
            </>
          ) : (
            <>
              <Zap className="mr-2 h-4 w-4" /> GENERATE BILL · {inr2(total)}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

// ── The POS view ───────────────────────────────────────────────────────────
export function PosView({
  dishes,
  loading,
  role = "owner",
  onMenuChanged,
}: {
  dishes: Dish[];
  loading: boolean;
  role?: string;
  onMenuChanged?: () => void | Promise<void>;
}) {
  const { toast } = useToast();
  const { openReceipt } = useReceipt();
  const { hotelName, upperName } = useHotel();
  const isOwner = role === "owner";
  const [query, setQuery] = React.useState("");
  const [cat, setCat] = React.useState<string>("All");
  const [cart, setCart] = React.useState<Record<string, number>>({});
  const [discount, setDiscount] = React.useState(0);
  /* t143 — the owner's discount limit %, fetched from Settings; every discount
     the reception types is clamped to this % of the current bill */
  const [discLimit, setDiscLimit] = React.useState(10);
  const [generating, setGenerating] = React.useState(false);
  const [billsToday, setBillsToday] = React.useState(0);
  const [recent, setRecent] = React.useState<Bill[]>([]);

  /* t117 — the owner's own window into the restaurant bills: last 50, collapsible,
     read-only (no reprint, no undo — the counter does the billing actions) */
  const [ownerBills, setOwnerBills] = React.useState<Bill[]>([]);
  const [billsOpen, setBillsOpen] = React.useState(true);
  React.useEffect(() => {
    if (!isOwner) return;
    const load = () =>
      fetch("/api/bills?limit=50", { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : []))
        .then((d) => setOwnerBills(Array.isArray(d) ? d : []))
        .catch(() => undefined);
    void load();
    const t = setInterval(load, 60000); // stays live by itself, like the dashboard
    return () => clearInterval(t);
  }, [isOwner]);

  /* t143 — receptions pull the owner's discount limit once (owner doesn't bill) */
  React.useEffect(() => {
    if (isOwner) return;
    fetch("/api/settings")
      .then((x) => x.json())
      .then((s) => {
        const n = Math.floor(Number(s?.discountLimit));
        if (Number.isFinite(n) && n >= 0) setDiscLimit(Math.min(n, 100));
      })
      .catch(() => {
        /* the default of 10% stands */
      });
  }, [isOwner]);

  /* t98 — owner menu editing · t115 — warning-locked deletions */
  const [cats, setCats] = React.useState<Category[]>([]);
  const [addCatOpen, setAddCatOpen] = React.useState(false);
  const [newCat, setNewCat] = React.useState("");
  const [editDish, setEditDish] = React.useState<Dish | null>(null);
  const [confirmDish, setConfirmDish] = React.useState<Dish | null>(null);
  const [confirmCat, setConfirmCat] = React.useState<{ id: string; name: string; live: number } | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  const reloadCats = React.useCallback(async () => {
    try {
      const res = await fetch("/api/categories", { cache: "no-store" });
      const data = await res.json();
      setCats(Array.isArray(data) ? data : []);
    } catch {
      /* cosmetic */
    }
  }, []);
  React.useEffect(() => {
    if (isOwner) void reloadCats();
  }, [isOwner, reloadCats]);

  const menuChanged = React.useCallback(() => {
    void onMenuChanged?.();
    if (isOwner) void reloadCats();
  }, [onMenuChanged, isOwner, reloadCats]);

  const addCategory = async () => {
    const name = newCat.trim();
    if (!name) {
      toast({ title: "Section name needed", description: "Examples: Rice, Ice Cream, Smoothies…", variant: "destructive" });
      return;
    }
    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not add the category");
      toast({ title: `Category “${name}” added — its blank add-dish block is on the board` });
      setNewCat("");
      setAddCatOpen(false);
      setCat(name);
      await reloadCats();
      void onMenuChanged?.();
    } catch (e) {
      toast({
        title: "Could not add the category",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    }
  };

  /* t115 — the warning dialog owns the flow: this fires only after the 10s lock */
  const deleteDish = async (d: Dish) => {
    setDeleting(true);
    try {
      const res = await fetch(`/api/menu/${d.id}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Delete failed");
      toast({ title: `“${d.name}” removed from the menu — past bills keep their snapshots` });
      setConfirmDish(null);
      menuChanged();
    } catch (e) {
      toast({
        title: "Could not delete",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  };

  /* t115 — delete a whole SECTION. The server guard refuses while live dishes
     remain (409) — the dialog's warning says so up front. */
  const deleteCategory = async (c: { id: string; name: string }) => {
    setDeleting(true);
    try {
      const res = await fetch(`/api/categories?id=${encodeURIComponent(c.id)}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not delete the section");
      toast({
        title: `Section “${c.name}” deleted`,
        description:
          out.purged > 0
            ? `${out.purged} already-removed dish${out.purged === 1 ? "" : "es"} purged — past bills keep their snapshots`
            : "The menu re-flows at once.",
      });
      setConfirmCat(null);
      setCat((cur) => (cur === c.name ? "All" : cur));
      menuChanged();
    } catch (e) {
      toast({
        title: "Could not delete the section",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  };

  const active = React.useMemo(() => dishes.filter((d) => d.active), [dishes]);
  const dishCats = React.useMemo(() => [...new Set(active.map((d) => d.category))], [active]);
  const catNames = React.useMemo(() => {
    const fromDb = cats.map((c) => c.name);
    const orphans = dishCats.filter((c) => !fromDb.includes(c));
    return [...fromDb, ...orphans];
  }, [cats, dishCats]);
  const chipCats = React.useMemo(() => ["All", ...catNames], [catNames]);

  const filtered = React.useMemo(
    () =>
      active.filter(
        (d) =>
          (cat === "All" || d.category === cat) &&
          d.name.toLowerCase().includes(query.trim().toLowerCase()),
      ),
    [active, cat, query],
  );

  // owner renders grouped sections (every category gets its add-dish block)
  const ownerGroups = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return catNames
      .filter((c) => cat === "All" || c === cat)
      .map((c) => ({ cat: c, list: filtered.filter((d) => d.category === c) }))
      .filter((g) => g.list.length > 0 || !q); // keep empty sections when not searching
  }, [catNames, cat, filtered, query]);

  const lines: CartLine[] = React.useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const dish = active.find((d) => d.id === id);
          return dish ? { dish, qty } : null;
        })
        .filter((x): x is CartLine => x !== null),
    [cart, active],
  );

  // how many bills today (from the same auto-fed analytics the owner sees)
  React.useEffect(() => {
    if (isOwner) return; // t115 — the Menu Manager never bills
    fetch("/api/dashboard?range=today")
      .then((r) => r.json())
      .then((d) => setBillsToday(d?.stats?.bills ?? 0))
      .catch(() => {});
  }, [generating, isOwner]);

  // the register's own feed — newest restaurant bills, tap to reprint, UNDO to tear
  const loadRecent = React.useCallback(async () => {
    if (isOwner) return; // t115 — bills live on the counter, not in the menu
    try {
      const res = await fetch("/api/bills?limit=14", { cache: "no-store" });
      if (!res.ok) return;
      setRecent(await res.json());
    } catch {
      /* the feed is cosmetic — never block the counter */
    }
  }, [isOwner]);
  React.useEffect(() => {
    void loadRecent();
  }, [loadRecent, generating]);

  const undoBill = async (b: Bill) => {
    try {
      const res = await fetch(`/api/bills/${b.id}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Undo failed");
      toast({
        title: `Bill #${b.number} undone`,
        description: "Removed everywhere — totals, trends & top dishes recompute instantly.",
      });
    } catch (e) {
      toast({
        title: "Undo failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    }
    void loadRecent();
    fetch("/api/dashboard?range=today")
      .then((r) => r.json())
      .then((d) => setBillsToday(d?.stats?.bills ?? 0))
      .catch(() => {});
  };

  const add = (id: string) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const setQty = (id: string, qty: number) =>
    setCart((c) => {
      const next = { ...c };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  const removeLine = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      delete next[id];
      return next;
    });

  const generate = async () => {
    if (lines.length === 0) return;
    setGenerating(true);
    try {
      /* t143 — belt & braces: the POST re-checks server-side too, but never
         send more than the owner's limit % of the bill's value */
      const sub = lines.reduce((s, l) => s + l.dish.price * l.qty, 0);
      const safeDiscount = Math.min(discount, Math.floor(sub * discLimit) / 100);
      const res = await fetch("/api/bills", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: lines.map((l) => ({ dishId: l.dish.id, qty: l.qty })),
          discount: safeDiscount,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Bill generation failed");
      }
      const bill: Bill = await res.json();
      openReceipt(bill);
      setCart({});
      setDiscount(0);
      toast({
        title: `Bill #${bill.number} saved · ${hotelName}`,
        description: `${bill.itemCount} item(s) auto-fed to the database — no entry needed.`,
      });
    } catch (e) {
      toast({
        title: "Could not generate bill",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  /* t149 — the dish grid carries the JS touch driver too: inside the rotated
     stage its native pan is dead on the user's phone (same as the landing);
     the driver gives it the same 1:1 drag + natural fling. Dormant on
     desktops and whenever the grid has no overflow. */
  const gridRef = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    const g = gridRef.current;
    if (!g) return;
    return bindFxTouchScroll(g);
  }, []);

  return (
    <div className="space-y-5">
      <TierBand
        num={(isOwner ? FX_TIERS.menu : FX_TIERS.pos).num}
        eyebrow={tierEyebrow(isOwner ? FX_TIERS.menu : FX_TIERS.pos)}
        title={isOwner ? "Menu Manager" : "POS Terminal"}
        sub={
          isOwner
            ? "The menu runs from here — add categories on top, a blank add-dish block in every section, edit or remove any dish. Billing lives at the reception counter."
            : "Tap dishes → generate the bill. Everything else — prices, totals, timestamp, database — happens by itself."
        }
        tag={`${upperName} · PURE VEG · ${active.length} LIVE DISHES`}
      />

      {/* ── Dishes ── */}
      <div className="fx-card min-w-0 p-5" data-fx-motion="1">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--fx-muted)]" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dishes…"
              aria-label="Search dishes"
              className="h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] pl-9 font-semibold"
            />
          </div>
          <span className="fx-label hidden md:block">{filtered.length} SHOWN</span>
        </div>

        {/* category row — the ADD CATEGORY option lives on top of it (owner) */}
        <div className="fx-scroll mt-4 flex gap-2 overflow-x-auto pb-1">
          {chipCats.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`whitespace-nowrap rounded-full border px-4 py-2 text-[11.5px] font-extrabold tracking-wide transition ${
                cat === c
                  ? "border-[var(--fx-purple)] bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
              }`}
            >
              {c.toUpperCase()}
            </button>
          ))}
          {isOwner && (
            <button
              onClick={() => setAddCatOpen((o) => !o)}
              aria-expanded={addCatOpen}
              data-testid="pos-add-category"
              className={`inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border border-dashed px-4 py-2 text-[11.5px] font-extrabold tracking-wide transition ${
                addCatOpen
                  ? "border-[var(--fx-purple)] bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
                  : "border-[var(--fx-line)] bg-[var(--fx-page)] text-[var(--fx-muted)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
              }`}
            >
              {addCatOpen ? <X className="h-3.5 w-3.5" /> : <LayoutGrid className="h-3.5 w-3.5" />}
              {addCatOpen ? "CLOSE" : "ADD CATEGORY"}
            </button>
          )}
        </div>

        {/* the inline add-category form (owner) */}
        {isOwner && addCatOpen && (
          <div className="fx-pop-in mt-3 flex flex-wrap items-center gap-2 rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/60 p-3" data-testid="pos-add-category-form">
            <LayoutGrid className="h-4 w-4 text-[var(--fx-accent-ink)]" />
            <span className="text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)]">NEW CATEGORY</span>
            <Input
              value={newCat}
              onChange={(e) => setNewCat(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void addCategory();
              }}
              placeholder="e.g. Rice, Ice Cream, Smoothies, Combos…"
              aria-label="New category name"
              data-testid="pos-add-category-input"
              className="h-9 min-w-[200px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
            />
            <Button
              onClick={() => void addCategory()}
              data-testid="pos-add-category-create"
              className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
            >
              <Plus className="mr-1 h-4 w-4" /> CREATE
            </Button>
          </div>
        )}

        <div ref={gridRef} className="fx-scroll mt-4 max-h-[calc(100vh-500px)] min-h-[220px] overflow-y-auto pb-1 pl-1 pr-1 pt-2 xl:max-h-[calc(100vh-560px)]">
          {loading ? (
            <div className="grid place-items-center py-20 text-[var(--fx-muted)]">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : isOwner ? (
            cat === "All" ? (
              /* t152 — ALL blends every category into ONE seamless grid (the
               user: a new category's dishes must flow into the big grid, not
               start on a next line). NO ADD DISH here anymore (owner's ask) —
               adding happens on the single-SECTION view, which keeps headers,
               counts, section delete and its own ADD DISH block. */
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 2xl:grid-cols-4" data-testid="pos-owner-groups">
                {filtered.map((d) => (
                  <DishTile
                    key={d.id}
                    d={d}
                    qty={0}
                    owner
                    onEdit={() => setEditDish(d)}
                    onDelete={() => setConfirmDish(d)}
                  />
                ))}
                {filtered.length === 0 && (
                  <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                    No dishes match “{query}”.
                  </p>
                )}
              </div>
            ) : (
            /* single section — the original grouped rendering, header + controls */
            <div className="space-y-6" data-testid="pos-owner-groups">
              {ownerGroups.map(({ cat: c, list }) => {
                const catId = cats.find((x) => x.name === c)?.id;
                return (
                <div key={c}>
                  <div className="flex items-center gap-2">
                    <span className="text-[12px] font-extrabold tracking-wide text-[var(--fx-ink)]">{c.toUpperCase()}</span>
                    <span className="fx-num rounded-full bg-[var(--fx-lav)] px-2 py-0.5 text-[10px] font-extrabold text-[var(--fx-muted)]">
                      {list.length}
                    </span>
                    <span className="h-px flex-1 border-t border-dashed border-[var(--fx-line)]" />
                    {catId && (
                      <button
                        aria-label={`Delete section ${c}`}
                        title="Delete this section — a warning with a 10s lock opens first"
                        data-testid={`pos-cat-delete-${slug(c)}`}
                        onClick={() =>
                          setConfirmCat({ id: catId, name: c, live: active.filter((d) => d.category === c).length })
                        }
                        className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] transition hover:border-[var(--fx-rose)] hover:text-[var(--fx-rose)]"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  <div className="mt-2.5 grid grid-cols-2 gap-3 sm:grid-cols-3 2xl:grid-cols-4">
                    {list.map((d) => (
                      <DishTile
                        key={d.id}
                        d={d}
                        qty={0}
                        owner
                        onEdit={() => setEditDish(d)}
                        onDelete={() => setConfirmDish(d)}
                      />
                    ))}
                    <AddDishTile category={c} onAdded={menuChanged} />
                  </div>
                </div>
                );
              })}
              {ownerGroups.length === 0 && (
                <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                  No dishes match “{query}”.
                </p>
              )}
            </div>
            )
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 2xl:grid-cols-4">
              {filtered.map((d) => (
                <DishTile
                  key={d.id}
                  d={d}
                  qty={cart[d.id] ?? 0}
                  owner={false}
                  onAdd={() => add(d.id)}
                  onDec={() => setQty(d.id, (cart[d.id] ?? 0) - 1)}
                  onInc={() => add(d.id)}
                />
              ))}
              {filtered.length === 0 && (
                <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                  No dishes match “{query}”.
                </p>
              )}
            </div>
          )}
        </div>

        {/* ── t147 — THE MERGE, redone the way the user meant it: the CURRENT
           BILL is the BOTTOM SECTION of this very card — search on top, dishes
           in the middle, bill at the bottom — nothing changed position, they
           are one block. While the card runs under the fold the section rides
           sticky at the viewport bottom, exactly where the old floating dock
           always sat (same offsets, same z). ── */}
        {!isOwner && (
          <div
            data-testid="billing-dock"
            className="sticky bottom-[calc(76px+env(safe-area-inset-bottom))] z-30 -mx-5 -mb-5 mt-4 rounded-b-[18px] border-t border-[var(--fx-line)] bg-[var(--fx-surf)] p-4 md:bottom-3 md:p-5"
          >
            <BillingDock
              lines={lines}
              setQty={setQty}
              removeLine={removeLine}
              discount={discount}
              setDiscount={setDiscount}
              onGenerate={generate}
              generating={generating}
              billCount={billsToday}
              discLimit={discLimit}
            />
          </div>
        )}
        {isOwner && (
          <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
            OWNER MENU CONTROLS — ADD CATEGORY sits on top of the category row, every SECTION
            (tap a category chip) ends with a blank ADD DISH block — the blended ALL grid is
            browse/edit/delete only — each tile carries EDIT, and DELETE (tile or whole section)
            opens a WARNING that stays LOCKED for 10 seconds before it can fire. Billing lives at
            the reception counter.
          </p>
        )}
      </div>

      {/* t117 — LATEST RESTAURANT BILLS — the owner's collapsible read-only feed.
          Last 50 bills, no reprint, no undo — billing actions stay at the counter. */}
      {isOwner && (
        <div className="fx-card p-5" data-fx-motion="1" data-testid="menu-latest-bills">
          <button
            onClick={() => setBillsOpen((o) => !o)}
            aria-expanded={billsOpen}
            data-testid="menu-latest-bills-toggle"
            className="flex w-full flex-wrap items-center justify-between gap-2 text-left"
          >
            <span className="fx-label flex items-center gap-2">
              <Receipt className="h-3.5 w-3.5" /> LATEST RESTAURANT BILLS
            </span>
            <span className="flex items-center gap-2">
              <span className="mut-chip">LAST {ownerBills.length} · READ ONLY</span>
              <ChevronDown
                aria-hidden
                className={`h-4 w-4 text-[var(--fx-muted)] transition-transform ${billsOpen ? "" : "-rotate-90"}`}
              />
            </span>
          </button>
          {billsOpen && (
            <ScrollFadeBox className="mt-3" maxH={352}>
              <BillsFeed
                rows={ownerBills.map((b) => ({
                  key: b.id,
                  kind: "rest" as const,
                  bill: b,
                  title: `BILL #${b.number}`,
                  sub: `${b.itemCount} ${b.itemCount === 1 ? "ITEM" : "ITEMS"} · ${b.items.map((i) => i.name).slice(0, 2).join(", ")}${b.items.length > 2 ? "…" : ""}`,
                  amt: inr2(b.total),
                  at: istTime(b.createdAt),
                }))}
              />
            </ScrollFadeBox>
          )}
        </div>
      )}

      {/* ── t147 — the floating dock is gone for good: the CURRENT BILL now
           lives as the bottom section of the dishes card above — one block
           with the search + dishes, sticky at the viewport bottom. ── */}

      {/* ── Restaurant bills — the register's own feed, reprint + UNDO (counter only) ── */}
      {!isOwner && (
        <div className="fx-card p-5" data-fx-motion="1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="fx-label">RESTAURANT BILLS · TAP TO REPRINT</span>
            <span className="mut-chip">{billsToday} TODAY · TAP UNDO TWICE TO TEAR ONE</span>
          </div>
          <ScrollFadeBox className="mt-3" maxH={352}>
            <BillsFeed
              rows={recent.map((b) => ({
                key: b.id,
                kind: "rest" as const,
                bill: b,
                title: `BILL #${b.number}`,
                sub: `${b.itemCount} ${b.itemCount === 1 ? "ITEM" : "ITEMS"} · ${b.items.map((i) => i.name).slice(0, 2).join(", ")}${b.items.length > 2 ? "…" : ""}`,
                amt: inr2(b.total),
                at: istTime(b.createdAt),
              }))}
              onReprint={(b) => openReceipt(b, "reprint")}
              onUndo={(r) => void undoBill(r.bill)}
            />
          </ScrollFadeBox>
        </div>
      )}

      {/* t129 — the STATION EXPENSES entry block is gone from the desk: the
          reception enters spends on the Expenses page (one block, three
          toggles) instead of here. */}

      {editDish && (
        <EditDishDialog
          dish={editDish}
          onClose={() => setEditDish(null)}
          onSaved={menuChanged}
        />
      )}

      {/* t115 — the delete warnings: dish + whole section, both locked 10s */}
      {confirmDish && (
        <DeleteWarningDialog
          kind="dish"
          name={confirmDish.name}
          busy={deleting}
          onClose={() => setConfirmDish(null)}
          onConfirm={() => void deleteDish(confirmDish)}
        />
      )}
      {confirmCat && (
        <DeleteWarningDialog
          kind="category"
          name={confirmCat.name}
          live={confirmCat.live}
          busy={deleting}
          onClose={() => setConfirmCat(null)}
          onConfirm={() => void deleteCategory(confirmCat)}
        />
      )}
    </div>
  );
}
