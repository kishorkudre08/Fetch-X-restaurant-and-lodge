"use client";

/* t148 — LIVE ORB — the pulsing orb that signals live talk is on.
 *
 * Inspired by ChatGPT's voice-mode orb: a soft glowing sphere with a
 * swirling fog inside, themed to the active accent pair (purple + gold).
 * Listens to the mic level (via the recognition's volume proxy: it pulses
 * harder when the user is speaking). The orb is purely presentational —
 * the STT/TTS plumbing lives in ai-panel.tsx.
 *
 * Animation strategy: CSS keyframes (so they run off the main thread and
 * respect prefers-reduced-motion); JS only swaps a `speaking` flag.
 */

import * as React from "react";

export function LiveOrb({ speaking = false, listening = false }: { speaking?: boolean; listening?: boolean }) {
  return (
    <div
      className={`fx-orb${speaking ? " fx-orb--spk" : ""}${listening ? " fx-orb--mic" : ""}`}
      aria-hidden
      data-fx-motion="3"
    >
      <div className="fx-orb-glow" />
      <div className="fx-orb-fog1" />
      <div className="fx-orb-fog2" />
      <div className="fx-orb-fog3" />
      <div className="fx-orb-core" />
      <div className="fx-orb-ring" />
    </div>
  );
}
