"use client";

import * as React from "react";
import {
  ArrowRight,
  BarChart3,
  BedDouble,
  Bot,
  Check,
  ChefHat,
  Crown,
  IndianRupee,
  Loader2,
  Receipt,
  ShieldCheck,
  Users,
  UtensilsCrossed,
  X,
} from "lucide-react";
import { ThemeToggle } from "@/components/fx";
import { bindFxTouchScroll } from "@/lib/fx-touch";

export type AuthUser = { name: string; role: string; email?: string };

/* t152 — the signed-in app re-activates the forced-landscape stage (see the
   boot script in layout.tsx): the stage is signed-in ONLY, so signing in from
   this landing turns it on and signing out turns it back off. */
declare global {
  interface Window {
    __fxApplyStage?: () => void;
  }
}

/* t94 — the OWNER demo credentials stay the default one-tap experience on
   this storefront. t104 — the developer account is gone entirely: three
   demo accounts, no platform console. */
const DEMO = { email: "spiceowner@gmail.com", pass: "spiceowner" };
const FALLBACK_STATS = { bills: 10229, revenueL: 54.7, dishes: 46, team: 6 };

const DEMO_ACCOUNTS = [
  {
    label: "OWNER",
    email: "spiceowner@gmail.com",
    pass: "spiceowner",
    note: "Full platform access",
    color: "#b45f04",
    icon: "crown" as const,
  },
  {
    label: "RESTAURANT RECEPTION",
    email: "spicerestaurant@gmail.com",
    pass: "spicerestaurant",
    note: "POS billing station",
    color: "#5b4fe9",
    icon: "rest" as const,
  },
  {
    label: "LODGE RECEPTION",
    email: "spicelodge@gmail.com",
    pass: "spicelodge",
    note: "100-room front desk",
    color: "#d9a441",
    icon: "lodge" as const,
  },
];

const BTN_PRIMARY =
  "inline-flex items-center justify-center gap-2 rounded-[13px] bg-[var(--fx-purple)] px-5 py-3 text-[13.5px] font-bold text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)] active:translate-y-px disabled:opacity-70";
const BTN_GHOST =
  "inline-flex items-center justify-center gap-2 rounded-[13px] border border-[var(--fx-line)] bg-[var(--fx-surf)] px-5 py-3 text-[13.5px] font-bold text-[var(--fx-ink)] transition hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]";

const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "features", label: "Features" },
  { id: "privacy", label: "Privacy" },
];

/* ── Animated number (counts up when scrolled into view) ── */
function CountUp({
  to,
  decimals = 0,
  prefix = "",
  suffix = "",
}: {
  to: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
}) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const started = React.useRef(false);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fmt = (v: number) =>
      prefix +
      v.toLocaleString("en-IN", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }) +
      suffix;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.textContent = fmt(to);
      return;
    }
    const io = new IntersectionObserver(
      (es) =>
        es.forEach((e) => {
          if (!e.isIntersecting || started.current) return;
          started.current = true;
          const st = performance.now();
          const dur = 1300;
          const tick = (n: number) => {
            const p = Math.min(1, (n - st) / dur);
            const ease = 1 - Math.pow(1 - p, 3);
            el.textContent = fmt(to * ease);
            if (p < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
          io.unobserve(e.target);
        }),
      { threshold: 0.3 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [to, decimals, prefix, suffix]);

  return <span ref={ref}>{prefix + (0).toFixed(decimals) + suffix}</span>;
}

/* ── Pre-login landing — pure Fetch-X storefront (NO hotel branding: many
   tenants run on this platform; the demo hotel's name only appears INSIDE
   the signed-in app). Adapted from upload/index.html, creators kept. ── */
export function LandingView({ onSignedIn }: { onSignedIn: (u: AuthUser) => void }) {
  const [modalOpen, setModalOpen] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [pass, setPass] = React.useState("");
  const [err, setErr] = React.useState<string | null>(null);
  const [shakeKey, setShakeKey] = React.useState(0);
  const [busy, setBusy] = React.useState<string | null>(null);
  const [stats, setStats] = React.useState(FALLBACK_STATS);
  const [active, setActive] = React.useState("home");
  const emailRef = React.useRef<HTMLInputElement>(null);
  /* t154 — the landing runs INSIDE the forced-landscape stage again (the
     owner wants the whole site landscape-only on mobile), and it scrolls
     through .fx-landing-scroll — a constrained inner scroller with NO
     fixed descendants, the exact pattern of the signed-in shell's <main>,
     the one scroller this phone has always panned natively. The pill
     header, glow and modal are fixed layers OUTSIDE that scroller. */

  const closeModal = React.useCallback(() => {
    setModalOpen(false);
    setErr(null);
  }, []);

  const openModalSafe = () => {
    setErr(null);
    setModalOpen(true);
  };

  /* t155 — the landing scroller carries the t149 JS touch driver, the ONLY
     touch path that has ever scrolled on the owner's phone inside the stage
     (t144 pan-y, t148 auto and t154's native overflow all dead-ended there —
     the same phone scrolls the POS lists, which are driver-bound). Native
     overflow stays for wheel/keyboard; on touch the driver owns the pan:
     touch-action none while scrollable, 1:1 finger tracking, fling on
     release. On desktops the wrapper never overflows so the driver idles
     (touch-action ""), and the document scrolls exactly as before. */
  React.useEffect(() => {
    const el = document.getElementById("fx-landing-scroll");
    if (!el) return;
    return bindFxTouchScroll(el);
  }, []);

  /* reveal on scroll */
  React.useEffect(() => {
    const io = new IntersectionObserver(
      (es) =>
        es.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        }),
      { threshold: 0.12 },
    );
    document.querySelectorAll(".rv").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  /* scroll-spy for nav links — on desktops the DOCUMENT scrolls
     (window.scrollY); inside the t154 stage the page scrolls inside
     #fx-landing-scroll (the same native constrained-scroller pattern the
     signed-in shell uses), so the spy listens to both and reads whichever
     scroller actually moves. */
  React.useEffect(() => {
    const scroller =
      document.getElementById("fx-landing-scroll") ?? document.getElementById("fx-scroll");
    const onScroll = () => {
      const staged = scroller !== null && scroller.scrollHeight > scroller.clientHeight;
      const y = (staged ? scroller!.scrollTop : window.scrollY) + 160;
      let cur = "home";
      NAV_LINKS.forEach(({ id }) => {
        const s = document.getElementById(id);
        if (s && s.offsetTop <= y) cur = id;
      });
      setActive(cur);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    scroller?.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      scroller?.removeEventListener("scroll", onScroll);
    };
  }, []);

  /* live stats from the local database (falls back to seeded figures) */
  React.useEffect(() => {
    let dead = false;
    (async () => {
      const safe = <T,>(p: Promise<T>): Promise<T | null> => p.catch(() => null);
      type DashJson = { stats?: { bills?: number; revenue?: number } } | null;
      const [dRes, mRes, eRes] = await Promise.all([
        safe(fetch("/api/dashboard?range=1y").then((r) => (r.ok ? (r.json() as Promise<DashJson>) : null))),
        safe(fetch("/api/menu").then((r) => (r.ok ? (r.json() as Promise<unknown[]>) : null))),
        safe(fetch("/api/employees").then((r) => (r.ok ? (r.json() as Promise<unknown[]>) : null))),
      ]);
      if (dead) return;
      setStats((s) => ({
        bills: dRes?.stats?.bills ?? s.bills,
        revenueL:
          typeof dRes?.stats?.revenue === "number"
            ? Math.round((dRes.stats.revenue / 100000) * 10) / 10
            : s.revenueL,
        dishes: Array.isArray(mRes) ? mRes.length : s.dishes,
        team: Array.isArray(eRes)
          ? eRes.filter((x) => (x as { active?: boolean }).active !== false).length
          : s.team,
      }));
    })();
    return () => {
      dead = true;
    };
  }, []);

  /* esc closes modal + autofocus email */
  React.useEffect(() => {
    if (!modalOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeModal();
    };
    window.addEventListener("keydown", onKey);
    const t = setTimeout(() => emailRef.current?.focus(), 80);
    return () => {
      window.removeEventListener("keydown", onKey);
      clearTimeout(t);
    };
  }, [modalOpen, closeModal]);

  const persist = (u: AuthUser) => {
    try {
      // must match AUTH_KEY in page.tsx ("fx-auth") — legacy "jk-auth" is
      // actively deleted by the shell on boot, which used to log users out
      localStorage.setItem("fx-auth", JSON.stringify({ name: u.name, role: u.role, email: u.email }));
    } catch {
      /* private mode */
    }
    /* t152 — the app we're about to enter runs inside the forced-landscape
       stage; flip it on now (the boot script only staged signed-in loads). */
    try {
      window.__fxApplyStage?.();
    } catch {
      /* stage is cosmetic — never block the sign-in */
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const em = email.trim().toLowerCase();
    if (!em || !pass) {
      setErr("Enter both email and password.");
      setShakeKey((k) => k + 1);
      return;
    }
    setErr(null);
    setBusy("Signing in…");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: em, password: pass }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        setErr(data.error ?? "Wrong email or password.");
        setShakeKey((k) => k + 1);
        setBusy(null);
        return;
      }
      setBusy(`Signing in as ${String(data.user.name).toUpperCase()}…`);
      persist(data.user);
      setTimeout(() => onSignedIn(data.user), 650);
    } catch {
      setErr("Could not reach the server. Try again.");
      setShakeKey((k) => k + 1);
      setBusy(null);
    }
  };

  const liveDemo = async () => {
    if (busy) return;
    setErr(null);
    setEmail(DEMO.email);
    setPass(DEMO.pass);
    setModalOpen(true);
    setBusy("Loading demo…");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: DEMO.email, password: DEMO.pass }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) throw new Error("demo failed");
      persist(data.user);
      setTimeout(() => onSignedIn(data.user), 500);
    } catch {
      setBusy(null);
      setErr("Demo sign-in failed — please use the form.");
    }
  };

  const prefill = (a?: { email: string; pass: string }) => {
    setEmail(a?.email ?? DEMO.email);
    setPass(a?.pass ?? DEMO.pass);
    setErr(null);
  };

  const acctIcon = (icon: "crown" | "rest" | "lodge") =>
    icon === "crown" ? (
      <Crown className="h-4 w-4" aria-hidden />
    ) : icon === "rest" ? (
      <UtensilsCrossed className="h-4 w-4" aria-hidden />
    ) : (
      <BedDouble className="h-4 w-4" aria-hidden />
    );

  const brand = (
    <a href="#home" className="flex items-center gap-2.5">
      <span className="grid h-9 w-9 place-items-center rounded-[11px] bg-gradient-to-br from-[var(--fx-purple-hi)] to-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[0_8px_18px_-8px_color-mix(in_srgb,var(--fx-purple)_55%,transparent)]">
        <span className="text-[13px] font-black tracking-tight">FX</span>
      </span>
      <span className="flex flex-col leading-none">
        <span className="text-[17px] font-extrabold tracking-tight text-[var(--fx-ink)]">
          Fetch-X
        </span>
        <span className="mt-0.5 text-[9px] font-extrabold tracking-[0.22em] text-[var(--fx-muted)]">
          RESTAURANT OS
        </span>
      </span>
    </a>
  );

  return (
    <div className="fx-landing-root relative min-h-screen bg-[var(--fx-page)] text-[var(--fx-ink)]">
      <div className="jk-glow" aria-hidden />

      {/* ══════ NAV ══════ */}
      <header
        className="fixed left-1/2 top-4 z-40 w-[calc(100%-16px)] max-w-[1216px] -translate-x-1/2 rounded-[18px] border border-[var(--fx-line)] px-3.5 py-2.5 backdrop-blur-md"
        style={{
          background: "color-mix(in srgb, var(--fx-surf) 86%, transparent)",
          boxShadow: "0 14px 40px -22px rgba(30,27,75,.35)",
        }}
      >
        <div className="flex items-center gap-2.5">
          <span className="mr-auto">{brand}</span>
          <nav className="mr-2 hidden items-center gap-0.5 md:flex" aria-label="Landing sections">
            {NAV_LINKS.map((l) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                className={`rounded-[11px] px-3.5 py-2 text-[13.5px] font-semibold transition ${
                  active === l.id
                    ? "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
                    : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {l.label}
              </a>
            ))}
          </nav>
          <ThemeToggle />
          <button onClick={openModalSafe} className="inline-flex items-center gap-2 rounded-[13px] bg-[var(--fx-purple)] px-4 py-2.5 text-[13px] font-bold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)]">
            Sign In <ArrowRight className="h-3.5 w-3.5" aria-hidden />
          </button>
        </div>
      </header>

      {/* ══════ PAGE SCROLLER (t154) — main+footer live in this constrained
          box so stage-mode touch scrolling hits a plain overflow element
          with no fixed descendants; header/glow/modal stay outside it. On
          desktops it is an unstyled passthrough and the document scrolls. ══════ */}
      <div id="fx-landing-scroll" className="fx-landing-scroll">
      <main className="relative">
        {/* ══════ HERO ══════ */}
        <section id="home" className="pb-[80px] pt-[140px] md:pt-[170px]">
          <div className="mx-auto grid w-full max-w-[1200px] items-center gap-12 px-5 md:grid-cols-[1.05fr_.95fr] md:px-8">
            <div>
              <span className="rv inline-flex items-center gap-2 rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-3.5 py-1.5 text-[10px] font-extrabold tracking-[.12em] text-[var(--fx-accent-ink)]">
                ✦ AI-POWERED RESTAURANT INTELLIGENCE PLATFORM
              </span>
              <h1
                className="rv mt-5 text-[38px] font-extrabold leading-[1.06] tracking-[-.03em] md:text-[54px]"
                style={{ transitionDelay: ".06s" }}
              >
                Restaurant management,
                <br />
                <span className="jk-grad">finally intelligent.</span>
              </h1>
              <p
                className="rv mt-5 max-w-[540px] text-[15px] leading-[1.7] text-[var(--fx-muted)] md:text-[15.5px]"
                style={{ transitionDelay: ".12s" }}
              >
                One platform for billing, menu, team, and profit analytics. Built for owners — the
                cashier just bills, and every {"{dish, quantity, time}"} flows into your dashboard
                automatically.
              </p>
              <div className="rv mt-7 flex flex-wrap items-center gap-3" style={{ transitionDelay: ".18s" }}>
                <button onClick={openModalSafe} className={BTN_PRIMARY}>
                  Get Started <ArrowRight className="h-4 w-4" aria-hidden />
                </button>
                <button onClick={liveDemo} className={BTN_GHOST}>
                  <span className="grid h-5 w-5 place-items-center rounded-full bg-[var(--fx-purple)] text-[var(--fx-on-accent)]">
                    <ArrowRight className="h-3 w-3 rotate-90" aria-hidden />
                  </span>
                  Live Demo
                </button>
              </div>
              <div className="rv mt-7 flex flex-wrap gap-x-6 gap-y-2" style={{ transitionDelay: ".24s" }}>
                {["Zero data entry", "Insights in seconds", "Live profit tracking"].map((c) => (
                  <span key={c} className="inline-flex items-center gap-1.5 text-[12.5px] font-bold text-[var(--fx-muted)]">
                    <Check className="h-3.5 w-3.5 text-[var(--fx-green)]" strokeWidth={3} aria-hidden />
                    {c}
                  </span>
                ))}
              </div>
            </div>

            <div
              className="rv relative mx-auto hidden min-h-[330px] w-full max-w-[420px] place-items-center md:grid"
              style={{ transitionDelay: ".15s" }}
            >
              <div
                className="jk-float grid h-[270px] w-[270px] place-items-center rounded-[64px] bg-gradient-to-br from-[var(--fx-purple-hi)] to-[var(--fx-purple)] shadow-[0_30px_60px_-30px_color-mix(in_srgb,var(--fx-purple)_50%,transparent)]"
                data-fx-motion="3"
              >
                <ChefHat className="h-28 w-28 text-[var(--fx-on-accent)]" strokeWidth={1.1} aria-hidden />
              </div>
              <div className="fx-card-soft absolute -bottom-2 left-0 flex items-center gap-2.5 px-3.5 py-2.5" data-fx-motion="2">
                <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                  <Receipt className="h-4 w-4" aria-hidden />
                </span>
                <span>
                  <span className="fx-label block">LIVE BILL</span>
                  <span className="text-[12.5px] font-extrabold">
                    PAID · ₹603.75 <span className="text-[var(--fx-green)]">✓</span>
                  </span>
                </span>
              </div>
              <div className="fx-card-soft absolute -top-3 right-0 px-3.5 py-2.5" data-fx-motion="2">
                <span className="fx-label block">NET PROFIT · TODAY</span>
                <span className="text-[12.5px] font-extrabold text-[var(--fx-green)]">+18.2% ↑</span>
              </div>
            </div>
          </div>
        </section>

        {/* ══════ TEAM — creators kept from the attachment ══════ */}
        <section id="about" className="py-[72px]">
          <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
            <div className="rv mx-auto max-w-[640px] text-center">
              <h2 className="text-[26px] font-extrabold tracking-tight md:text-[32px]">
                The people behind Fetch-X
              </h2>
              <p className="mt-2.5 text-[14.5px] text-[var(--fx-muted)]">
                Two builders, one mission — make business data actually useful.
              </p>
            </div>
            <div className="mt-10 grid gap-5 md:grid-cols-2">
              <div className="rv fx-card p-6">
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-[var(--fx-purple-hi)] to-[var(--fx-purple)] text-[20px] font-black text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
                  K
                </div>
                <div className="mt-4 text-[17px] font-extrabold">Kishor Kudre</div>
                <div className="fx-label mt-1">CEO · VISION &amp; GROWTH</div>
                <p className="mt-3 text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                  Multi-talented CEO driving product vision and execution. From pitching and
                  presentation to scaling — Kishor turns Fetch-X&apos;s capability into impact for
                  every business it reaches.
                </p>
              </div>
              <div className="rv fx-card p-6" style={{ transitionDelay: ".1s" }}>
                {/* t145 — A's avatar is now visually identical to K's:
                    same purple family gradient, same text colour, same
                    shadow. Was hardcoded teal/green, then gold family —
                    user asked for full visual parity with K. */}
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-[var(--fx-purple-hi)] to-[var(--fx-purple)] text-[20px] font-black text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
                  A
                </div>
                <div className="mt-4 text-[17px] font-extrabold">Adhish Biradar</div>
                <div className="fx-label mt-1">CTO · BACKEND &amp; OPERATIONS</div>
                <p className="mt-3 text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                  Adhish is the Nerdy CTO who brings vision into reality by architecting the data
                  engine, keeping every metric honest, and operating the platform end-to-end to keep
                  Fetch-X operating smoothly.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ══════ FEATURES + LIVE STATS ══════ */}
        <section id="features" className="py-[72px]">
          <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
            <div className="rv mx-auto max-w-[640px] text-center">
              <h2 className="text-[26px] font-extrabold tracking-tight md:text-[32px]">
                Everything a restaurant needs, in one place
              </h2>
              <p className="mt-2.5 text-[14.5px] text-[var(--fx-muted)]">
                From the billing counter to the owner&apos;s pocket — purpose-built for every role.
              </p>
            </div>
            <div className="mt-10 grid gap-5 md:grid-cols-3">
              <div className="rv fx-card p-6">
                <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                  <BarChart3 className="h-5 w-5" aria-hidden />
                </div>
                <h3 className="mt-4 text-[16px] font-extrabold">Analytics that matter</h3>
                <p className="mt-2 text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                  Real-time dashboards for sales, dishes, peak hours, and profit — the dashboard
                  literally builds itself from every bill your cashier generates.
                </p>
              </div>
              <div className="rv fx-card p-6" style={{ transitionDelay: ".08s" }}>
                <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                  <Bot className="h-5 w-5" aria-hidden />
                </div>
                <h3 className="mt-4 text-[16px] font-extrabold">AI Assistant</h3>
                <p className="mt-2 text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                  Ask plain-English questions about your restaurant. Get answers with named dishes,
                  specific numbers, and action recommendations.
                </p>
              </div>
              <div className="rv fx-card p-6" style={{ transitionDelay: ".16s" }}>
                <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[rgba(14,159,110,.1)] text-[var(--fx-green)]">
                  <Receipt className="h-5 w-5" aria-hidden />
                </div>
                <h3 className="mt-4 text-[16px] font-extrabold">Zero-entry billing</h3>
                <p className="mt-2 text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                  A built-in POS where the cashier generates bills; {"{dish, quantity, time}"} is
                  captured automatically. No data entry, ever.
                </p>
              </div>
            </div>

            <div className="rv fx-card mt-8 grid grid-cols-2 gap-y-8 px-6 py-9 md:grid-cols-4">
              {[
                {
                  icon: <Receipt className="h-4 w-4" aria-hidden />,
                  el: <CountUp to={stats.bills} />,
                  lab: "Bills generated",
                },
                {
                  icon: <IndianRupee className="h-4 w-4" aria-hidden />,
                  el: <CountUp to={stats.revenueL} decimals={1} prefix="₹" suffix="L" />,
                  lab: "Revenue tracked",
                },
                {
                  icon: <UtensilsCrossed className="h-4 w-4" aria-hidden />,
                  el: <CountUp to={stats.dishes} />,
                  lab: "Dishes on menu",
                },
                {
                  icon: <Users className="h-4 w-4" aria-hidden />,
                  el: <CountUp to={stats.team} />,
                  lab: "Team members",
                },
              ].map((s) => (
                <div key={s.lab} className="text-center">
                  <span className="mx-auto mb-2 grid h-9 w-9 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                    {s.icon}
                  </span>
                  <div className="fx-num text-[28px] font-extrabold tracking-tight md:text-[32px]">
                    {s.el}
                  </div>
                  <div className="mt-1 text-[11.5px] font-semibold text-[var(--fx-muted)]">{s.lab}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ══════ CTA ══════ */}
        <section className="pt-[26px]">
          <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
            <div className="rv fx-card relative overflow-hidden px-6 py-12 text-center">
              <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-[var(--fx-purple-soft)]" aria-hidden />
              <div className="relative">
                <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
                  <Users className="h-5 w-5" aria-hidden />
                </span>
                <h2 className="mt-4 text-[24px] font-extrabold tracking-tight md:text-[28px]">
                  Ready to modernize your restaurant?
                </h2>
                <p className="mx-auto mt-2 max-w-[520px] text-[14px] leading-[1.7] text-[var(--fx-muted)]">
                  Sign in with your owner account to explore the full experience — every bill, every
                  dish, every rupee.
                </p>
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <button onClick={openModalSafe} className={BTN_PRIMARY}>
                    Sign In <ArrowRight className="h-4 w-4" aria-hidden />
                  </button>
                  <a href="#features" className={BTN_GHOST}>
                    Learn More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══════ PRIVACY ══════ */}
        <section id="privacy" className="py-[46px]">
          <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
            <div className="rv fx-card flex flex-col items-start gap-4 p-6 md:flex-row md:items-center">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                <ShieldCheck className="h-5 w-5" aria-hidden />
              </span>
              <div>
                <h3 className="text-[16px] font-extrabold">Privacy first, always</h3>
                <p className="mt-1.5 text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                  This demo runs on your own machine — bills, menu, and team data live in your local
                  database, nothing leaves your device, and the single owner account below is the
                  only key to the console.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ══════ DEMO ACCESS ══════ */}
        <section className="pb-[64px] pt-[20px]">
          <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
            <div className="rv text-center">
              <span className="fx-label">LIVE DEMO</span>
              <h2 className="mt-1.5 text-[24px] font-extrabold tracking-tight">
                Demo access — all three accounts
              </h2>
              <p className="mx-auto mt-2 max-w-[520px] text-[13.5px] leading-[1.7] text-[var(--fx-muted)]">
                Tap sign in on any row —
                every role keeps its own station, data and theme.
              </p>
            </div>
            <div className="rv fx-card mt-7 overflow-hidden">
              <div className="hidden grid-cols-[1.1fr_1.1fr_.8fr_auto] gap-3 border-b border-[var(--fx-line)] bg-[var(--fx-lav)] px-5 py-3 md:grid">
                <span className="fx-label">ROLE</span>
                <span className="fx-label">EMAIL</span>
                <span className="fx-label">PASSWORD</span>
                <span className="fx-label" aria-hidden>
                  {""}
                </span>
              </div>
              {DEMO_ACCOUNTS.map((a) => (
                <div
                  key={a.label}
                  className="grid gap-3 border-b border-[var(--fx-line)] px-5 py-4 last:border-b-0 md:grid-cols-[1.1fr_1.1fr_.8fr_auto] md:items-center"
                >
                  <span className="flex items-center gap-2.5">
                    <span
                      className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                      style={{ background: a.color }}
                    >
                      {acctIcon(a.icon)}
                    </span>
                    <span className="min-w-0">
                      <b className="block text-[13px] font-extrabold">{a.label}</b>
                      <em className="block text-[11px] font-semibold not-italic text-[var(--fx-muted)]">
                        {a.note}
                      </em>
                    </span>
                  </span>
                  <code className="fx-num truncate rounded-lg bg-[var(--fx-lav)] px-2.5 py-1.5 text-[11.5px] font-bold">
                    {a.email}
                  </code>
                  <code className="fx-num rounded-lg bg-[var(--fx-lav)] px-2.5 py-1.5 text-[11.5px] font-bold">
                    {a.pass}
                  </code>
                  <button
                    onClick={() => {
                      prefill(a);
                      setModalOpen(true);
                    }}
                    className="justify-self-start rounded-[11px] border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 py-2 text-[12px] font-bold transition hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)] md:justify-self-end"
                  >
                    Sign in
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* ══════ FOOTER ══════ */}
      <footer className="border-t border-[var(--fx-line)] py-8">
        <div className="mx-auto w-full max-w-[1200px] px-5 md:px-8">
          <div className="flex flex-col items-center gap-4 md:flex-row">
            {brand}
            <span className="text-[12.5px] font-semibold text-[var(--fx-muted)] md:ml-3">
              Intelligent restaurant management.
            </span>
            <nav className="flex gap-4 text-[12.5px] font-bold text-[var(--fx-muted)] md:ml-auto">
              <a href="#about" className="hover:text-[var(--fx-accent-ink)]">
                About
              </a>
              <a href="#features" className="hover:text-[var(--fx-accent-ink)]">
                Features
              </a>
              <button onClick={openModalSafe} className="font-bold hover:text-[var(--fx-accent-ink)]">
                Sign In
              </button>
            </nav>
          </div>
          <p className="mt-5 text-[11.5px] font-medium text-[var(--fx-muted)]">
            © 2026 Fetch-X — Data Intelligence Platform. All rights reserved.
          </p>
        </div>
      </footer>
      </div>

      {/* ══════ SIGN-IN MODAL ══════ */}
      {modalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Sign in"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) closeModal();
          }}
          className="fixed inset-0 z-50 grid place-items-center bg-[rgba(23,20,50,.45)] p-4 backdrop-blur-sm"
        >
          {/* t99 — THE CREDENTIALS PAGE: stretched a little wider (the 4-time ask),
              while the pre-login page around it stays at its contained measure */}
          <div className="fx-card fx-pop-in w-full max-w-[600px] p-6 md:p-7" data-fx-motion="1">
            <div className="flex items-start justify-between">
              <h3 className="text-[19px] font-extrabold tracking-tight">Welcome back</h3>
              <button
                onClick={closeModal}
                aria-label="Close"
                className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
              >
                <X className="h-4 w-4" aria-hidden />
              </button>
            </div>
            <p className="mt-1 text-[12.5px] font-medium text-[var(--fx-muted)]">
              Sign in to your dashboard.
            </p>
            <form onSubmit={submit} className="mt-5 space-y-3.5">
              {/* t117 — email and password stack one below another */}
              <div className="grid gap-3.5">
                <div>
                  <label htmlFor="lk-email" className="fx-label">
                    EMAIL
                  </label>
                  <input
                    id="lk-email"
                    ref={emailRef}
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@restaurant.in"
                    autoComplete="username"
                    required
                    className="mt-1.5 h-11 w-full rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3.5 text-[13.5px] font-semibold text-[var(--fx-ink)] outline-none placeholder:text-[var(--fx-muted)] focus:border-[var(--fx-purple)]"
                  />
                </div>
                <div>
                  <label htmlFor="lk-pass" className="fx-label">
                    PASSWORD
                  </label>
                  <input
                    id="lk-pass"
                    type="password"
                    value={pass}
                    onChange={(e) => setPass(e.target.value)}
                    placeholder="••••••••"
                    autoComplete="current-password"
                    required
                    className="mt-1.5 h-11 w-full rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3.5 text-[13.5px] font-semibold text-[var(--fx-ink)] outline-none placeholder:text-[var(--fx-muted)] focus:border-[var(--fx-purple)]"
                  />
                </div>
              </div>
              {err && (
                <div
                  key={shakeKey}
                  role="alert"
                  className="jk-shake rounded-[9px] border border-[rgba(220,38,38,.3)] bg-[rgba(220,38,38,.08)] px-3 py-2.5 text-center text-[12px] font-bold text-[#dc2626]"
                >
                  {err}
                </div>
              )}
              <button type="submit" disabled={!!busy} className={`${BTN_PRIMARY} w-full`}>
                {busy ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> {busy}
                  </>
                ) : (
                  <>
                    Sign In <ArrowRight className="h-4 w-4" aria-hidden />
                  </>
                )}
              </button>
            </form>
            <div className="mt-4 rounded-xl border border-dashed border-[var(--fx-line)] p-3">
              <div className="fx-label mb-2">DEMO ACCOUNTS — TAP TO FILL</div>
              <div className="grid gap-1">
                {DEMO_ACCOUNTS.map((a) => (
                  <button
                    key={a.label}
                    type="button"
                    onClick={() => prefill(a)}
                    className="flex w-full flex-wrap items-center gap-2 rounded-lg px-1 py-1 text-left transition hover:bg-[var(--fx-lav)]"
                  >
                    <span
                      className="h-2.5 w-2.5 shrink-0 rounded-full"
                      style={{ background: a.color }}
                      aria-hidden
                    />
                    <span className="text-[12px] font-extrabold">{a.label}</span>
                    <code className="fx-num text-[11px] font-bold text-[var(--fx-muted)]">{a.email}</code>
                    <code className="fx-num ml-auto text-[11px] font-bold text-[var(--fx-accent-ink)]">{a.pass}</code>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
