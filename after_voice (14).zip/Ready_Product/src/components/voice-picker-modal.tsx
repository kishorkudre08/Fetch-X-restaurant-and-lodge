"use client";

/* t147 — VOICE PICKER MODAL — opens with the same blurred-backdrop pattern
 * as the landing login modal. Lists every TTS voice the platform offers,
 * filters by gender / vendor, plays a short sample on tap, and saves the
 * pick per-account.
 *
 * Mounted by SettingsView's "AI VOICE" block AND by the AI panel's voice
 * affordance.
 */
import * as React from "react";
import { Check, ChevronDown, Mic, Volume2, X } from "lucide-react";
import {
  loadVoices,
  pickDefaultVoice,
  readStoredVoice,
  speak,
  toFxVoices,
  writeStoredVoice,
  type FxVoice,
} from "@/lib/voice";

type Props = {
  open: boolean;
  onClose: () => void;
  onPick?: (v: FxVoice) => void;
  /** Account for per-account storage; null = guest */
  account?: string | null;
};

export function VoicePickerModal({ open, onClose, onPick, account }: Props) {
  const [voices, setVoices] = React.useState<FxVoice[]>([]);
  const [sel, setSel] = React.useState<string | null>(null);
  const [filter, setFilter] = React.useState<"all" | "male" | "female">("all");
  const [busyURI, setBusyURI] = React.useState<string | null>(null);

  // Load voices on mount + when modal opens
  React.useEffect(() => {
    if (!open) return;
    let dead = false;
    loadVoices().then((vs) => {
      if (dead) return;
      const fx = toFxVoices(vs);
      setVoices(fx);
      const stored = readStoredVoice(account);
      if (stored) setSel(stored);
      else {
        const def = pickDefaultVoice(fx);
        if (def) setSel(def.voiceURI);
      }
    });
    return () => {
      dead = true;
      // cancel any in-flight speech when the modal closes
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [open, account]);

  // Escape to close
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const shown = voices.filter((v) => filter === "all" || v.gender === filter);

  const sample = (v: FxVoice) => {
    setBusyURI(v.voiceURI);
    const synth = window.speechSynthesis;
    const real = synth.getVoices().find((rv) => rv.voiceURI === v.voiceURI) ?? null;
    speak(
      `Hi, this is ${v.name}. I'll be your Fetch-X copilot voice.`,
      real,
      {
        onEnd: () => setBusyURI(null),
        onError: () => setBusyURI(null),
      },
    );
  };

  const apply = (v: FxVoice) => {
    setSel(v.voiceURI);
    writeStoredVoice(v.voiceURI, account);
    onPick?.(v);
  };

  // group by vendor
  const vendors = Array.from(new Set(shown.map((v) => v.vendor))).sort();

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="AI voice picker"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) {
          // cancel sample speech + close on backdrop click
          if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
          onClose();
        }
      }}
      className="fixed inset-0 z-[60] grid place-items-center bg-[rgba(23,20,50,.45)] p-4 backdrop-blur-sm"
    >
      <div className="fx-card fx-pop-in w-full max-w-[680px] p-5 md:p-6" data-fx-motion="1">
        {/* header */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
              <Mic className="h-4 w-4" />
            </span>
            <div>
              <div className="text-[16px] font-extrabold tracking-tight text-[var(--fx-ink)]">AI Voice</div>
              <div className="text-[11px] font-semibold text-[var(--fx-muted)]">
                {voices.length ? `${voices.length} voices on this device` : "Loading voices…"}
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
              onClose();
            }}
            aria-label="Close voice picker"
            className="inline-flex h-9 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[11px] font-extrabold tracking-[0.1em] text-[var(--fx-muted)] shadow-[2px_2px_0_0_var(--fx-hard)] transition hover:text-[var(--fx-ink)]"
          >
            CLOSE <X className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* filter chips */}
        <div className="mt-4 flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Filter voices by gender">
          {([
            ["all", "ALL"],
            ["male", "MALE · like David"],
            ["female", "FEMALE"],
          ] as const).map(([v, l]) => (
            <button
              key={v}
              role="tab"
              aria-selected={filter === v}
              onClick={() => setFilter(v)}
              className={`rounded-full px-3.5 py-1.5 text-[10px] font-extrabold tracking-[0.09em] transition ${
                filter === v
                  ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
              }`}
            >
              {l}
            </button>
          ))}
        </div>

        {/* voice list — grouped by vendor, scrollable */}
        <div className="mt-4 max-h-[60vh] overflow-y-auto pr-1 space-y-4">
          {vendors.length === 0 && (
            <div className="fx-card grid place-items-center px-6 py-10 text-center" data-testid="voice-empty">
              <span className="fx-label inline-flex items-center gap-2">
                <Volume2 className="h-4 w-4" /> NO TTS VOICES ON THIS DEVICE
              </span>
              <p className="mt-2 text-[11px] font-semibold text-[var(--fx-muted)]">
                Your browser has no SpeechSynthesis voices installed. On Chrome desktop, install OS voices
                (Windows: Settings → Time &amp; Language → Speech); on Linux install speech-dispatcher or
                use a Chrome variant that ships voices.
              </p>
            </div>
          )}
          {vendors.map((vendor) => (
            <div key={vendor}>
              <div className="fx-label mb-1.5">{vendor.toUpperCase()}</div>
              <div className="grid gap-2">
                {shown.filter((v) => v.vendor === vendor).map((v) => {
                  const active = sel === v.voiceURI;
                  return (
                    <div
                      key={v.voiceURI}
                      onClick={() => apply(v)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          apply(v);
                        }
                      }}
                      data-testid={`voice-row-${v.voiceURI}`}
                      className={`fx-card fx-pop-in flex items-center gap-3 rounded-xl border p-3 transition ${
                        active ? "border-[var(--fx-purple)] ring-2 ring-[var(--fx-purple)] ring-offset-2 ring-offset-[var(--fx-page)]" : ""
                      }`}
                      style={{ background: "var(--fx-surf)" }}
                    >
                      <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[var(--fx-on-accent)] ${v.gender === "female" ? "bg-gradient-to-br from-[var(--fx-gold-hi)] to-[var(--fx-gold)]" : "bg-gradient-to-br from-[var(--fx-purple-hi)] to-[var(--fx-purple)]"}`}>
                        <Mic className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[13px] font-extrabold text-[var(--fx-ink)]">{v.name}</div>
                        <div className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
                          {v.lang} · {v.gender}
                        </div>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); sample(v); }}
                        disabled={busyURI === v.voiceURI}
                        aria-label={`Play a sample of ${v.name}`}
                        className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2.5 text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-accent-ink)] shadow-[1px_2px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-lav)]"
                      >
                        {busyURI === v.voiceURI ? (
                          <span className="fx-live-dot" aria-hidden />
                        ) : (
                          <Volume2 className="h-3.5 w-3.5" />
                        )}
                        SAMPLE
                      </button>
                      {active && <Check className="h-4 w-4 shrink-0 text-[var(--fx-green)]" strokeWidth={3} aria-hidden />}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          Tap a voice to select it (it saves per-account). Tap SAMPLE to hear it. In Live Talk the AI will
          reply in this voice — the live reply is natural conversation, no markdown formatting; tables and
          lists come back only when you stop the live talk.
        </p>
      </div>
    </div>
  );
}

/* Voice-picker trigger button — reused by SettingsView. Shows the current
 * voice name + a chevron. */
export function VoicePickerTrigger({
  current,
  onOpen,
}: {
  current: FxVoice | null;
  onOpen: () => void;
}) {
  return (
    <button
      onClick={onOpen}
      aria-haspopup="dialog"
      className="inline-flex h-9 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[11px] font-extrabold tracking-[0.08em] text-[var(--fx-accent-ink)] shadow-[2px_2px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-lav)]"
    >
      <Mic className="h-3.5 w-3.5" />
      {current ? current.name : "PICK A VOICE"}
      <ChevronDown className="h-3.5 w-3.5 text-[var(--fx-muted)]" />
    </button>
  );
}
