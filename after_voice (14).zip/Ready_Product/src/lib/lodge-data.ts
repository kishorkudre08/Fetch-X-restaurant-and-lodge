// ═══════════════════════════════════════════════════════════════════════════
// LODGE DATASET — Imperial Spices Hotel · 100 rooms · 5 floors.
// Deterministic literal so every screen (and the client demo) agrees on the
// numbers. Check-in dates are OFFSETS from today, so the demo never goes stale.
//   Room statuses:  avl available · occ occupied · res reserved (arriving today)
//                   dirty checkout-cleaning · mnt maintenance
//   Booking states: in in-house · arr arriving today · up upcoming · out checked-out
//   ci = check-in offset in days from today (−2 = two nights ago) · nts = nights
//   mb / ld / dn = running folio extras (mini-bar / laundry / restaurant tab)
// ═══════════════════════════════════════════════════════════════════════════

export type LodgeTypeId = "std" | "dlx" | "clb" | "sui" | "pre";
export type LodgeStatus = "avl" | "occ" | "res" | "dirty" | "mnt";
export type BookingState = "in" | "arr" | "up" | "out";

export type LodgeBooking = {
  id: string;
  g: string; // guest name
  ph: string; // phone
  t: LodgeTypeId;
  rm: number | null; // room number (null until check-in for upcoming bookings)
  ci: number; // check-in day offset
  nts: number; // nights
  gx: number; // guests in party
  src: string; // booking source
  st: BookingState;
  mb: number;
  ld: number;
  dn: number;
  eta: number; // arrival hour (0 when not arriving today)
};

export const LODGE_TYPES: Record<LodgeTypeId, { name: string; rate: number; occ: number }> = {
  std: { name: "Standard", rate: 1800, occ: 58 },
  dlx: { name: "Deluxe", rate: 2800, occ: 66 },
  clb: { name: "Club Executive", rate: 4200, occ: 71 },
  sui: { name: "Suite", rate: 6500, occ: 64 },
  pre: { name: "Presidential", rate: 12000, occ: 40 },
};

export const LODGE_ROOMS: Array<[number, LodgeTypeId, LodgeStatus]> = [
  [101, "std", "res"],
  [102, "std", "occ"],
  [103, "std", "res"],
  [104, "std", "occ"],
  [105, "std", "occ"],
  [106, "std", "dirty"],
  [107, "std", "occ"],
  [108, "std", "dirty"],
  [109, "std", "occ"],
  [110, "std", "occ"],
  [111, "std", "occ"],
  [112, "std", "occ"],
  [113, "std", "occ"],
  [114, "std", "avl"],
  [115, "std", "occ"],
  [116, "std", "occ"],
  [117, "std", "res"],
  [118, "std", "avl"],
  [119, "std", "occ"],
  [120, "std", "res"],
  [201, "std", "dirty"],
  [202, "std", "occ"],
  [203, "std", "dirty"],
  [204, "std", "avl"],
  [205, "std", "avl"],
  [206, "std", "avl"],
  [207, "std", "occ"],
  [208, "std", "avl"],
  [209, "std", "avl"],
  [210, "std", "avl"],
  [211, "std", "occ"],
  [212, "std", "occ"],
  [213, "std", "occ"],
  [214, "std", "avl"],
  [215, "std", "res"],
  [216, "std", "res"],
  [217, "std", "occ"],
  [218, "std", "occ"],
  [219, "std", "occ"],
  [220, "std", "occ"],
  [301, "dlx", "occ"],
  [302, "dlx", "occ"],
  [303, "dlx", "mnt"],
  [304, "dlx", "occ"],
  [305, "dlx", "occ"],
  [306, "dlx", "dirty"],
  [307, "dlx", "occ"],
  [308, "dlx", "occ"],
  [309, "dlx", "avl"],
  [310, "dlx", "avl"],
  [311, "dlx", "occ"],
  [312, "dlx", "occ"],
  [313, "dlx", "res"],
  [314, "dlx", "occ"],
  [315, "dlx", "occ"],
  [316, "dlx", "occ"],
  [317, "dlx", "occ"],
  [318, "dlx", "res"],
  [319, "dlx", "occ"],
  [320, "dlx", "occ"],
  [401, "dlx", "avl"],
  [402, "dlx", "occ"],
  [403, "dlx", "occ"],
  [404, "dlx", "occ"],
  [405, "dlx", "occ"],
  [406, "dlx", "occ"],
  [407, "dlx", "occ"],
  [408, "dlx", "avl"],
  [409, "dlx", "occ"],
  [410, "dlx", "occ"],
  [411, "clb", "occ"],
  [412, "clb", "occ"],
  [413, "clb", "occ"],
  [414, "clb", "occ"],
  [415, "clb", "occ"],
  [416, "clb", "dirty"],
  [417, "clb", "occ"],
  [418, "clb", "occ"],
  [419, "clb", "occ"],
  [420, "clb", "occ"],
  [501, "clb", "mnt"],
  [502, "clb", "dirty"],
  [503, "clb", "occ"],
  [504, "clb", "dirty"],
  [505, "clb", "occ"],
  [506, "sui", "occ"],
  [507, "sui", "avl"],
  [508, "sui", "occ"],
  [509, "sui", "res"],
  [510, "sui", "occ"],
  [511, "sui", "occ"],
  [512, "sui", "avl"],
  [513, "sui", "occ"],
  [514, "sui", "occ"],
  [515, "sui", "avl"],
  [516, "pre", "occ"],
  [517, "pre", "occ"],
  [518, "pre", "res"],
  [519, "pre", "res"],
  [520, "pre", "occ"],
];

export const LODGE_BOOKINGS: LodgeBooking[] = [
  { id: "BK-2411", g: "Preeti Sinha", ph: "+91 91974 37671", t: "dlx", rm: 311, ci: -4, nts: 4, gx: 1, src: "Phone", st: "in", mb: 250, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2412", g: "Aditi Rane", ph: "+91 99954 82588", t: "dlx", rm: 316, ci: -3, nts: 3, gx: 3, src: "Booking.com", st: "in", mb: 0, ld: 200, dn: 0, eta: 0 },
  { id: "BK-2413", g: "Vikram Deshpande", ph: "+91 95135 80885", t: "std", rm: 104, ci: -4, nts: 4, gx: 1, src: "Phone", st: "in", mb: 150, ld: 450, dn: 1200, eta: 0 },
  { id: "BK-2414", g: "Girish Prabhu", ph: "+91 91653 68139", t: "dlx", rm: 405, ci: -2, nts: 2, gx: 3, src: "Corporate", st: "in", mb: 400, ld: 0, dn: 1200, eta: 0 },
  { id: "BK-2415", g: "Farhan Ali", ph: "+91 96172 90568", t: "std", rm: 107, ci: -1, nts: 1, gx: 3, src: "Booking.com", st: "in", mb: 0, ld: 0, dn: 1200, eta: 0 },
  { id: "BK-2416", g: "Kiran Majumdar", ph: "+91 98608 16050", t: "sui", rm: 510, ci: -4, nts: 4, gx: 2, src: "Corporate", st: "in", mb: 250, ld: 350, dn: 2400, eta: 0 },
  { id: "BK-2417", g: "Sameer Kulkarni", ph: "+91 93594 32952", t: "clb", rm: 503, ci: -4, nts: 4, gx: 2, src: "Booking.com", st: "in", mb: 250, ld: 200, dn: 450, eta: 0 },
  { id: "BK-2418", g: "Robert Wilson", ph: "+91 96353 62944", t: "std", rm: 220, ci: -1, nts: 1, gx: 2, src: "Goibibo", st: "in", mb: 400, ld: 200, dn: 1200, eta: 0 },
  { id: "BK-2419", g: "Ann Kurian", ph: "+91 97056 55019", t: "clb", rm: 505, ci: -4, nts: 4, gx: 3, src: "MakeMyTrip", st: "in", mb: 0, ld: 450, dn: 1800, eta: 0 },
  { id: "BK-2420", g: "Sharvari Kadam", ph: "+91 91200 62408", t: "pre", rm: 516, ci: -1, nts: 3, gx: 4, src: "Corporate", st: "in", mb: 250, ld: 0, dn: 850, eta: 0 },
  { id: "BK-2421", g: "Sunita Joshi", ph: "+91 96417 30399", t: "clb", rm: 411, ci: -2, nts: 4, gx: 1, src: "MakeMyTrip", st: "in", mb: 0, ld: 200, dn: 850, eta: 0 },
  { id: "BK-2422", g: "Daniel Fernandes", ph: "+91 92957 62906", t: "pre", rm: 520, ci: -4, nts: 8, gx: 3, src: "MakeMyTrip", st: "in", mb: 0, ld: 350, dn: 1200, eta: 0 },
  { id: "BK-2423", g: "Kavya Reddy", ph: "+91 98460 58474", t: "std", rm: 112, ci: -3, nts: 5, gx: 3, src: "Goibibo", st: "in", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2424", g: "George Mathew", ph: "+91 98693 39297", t: "clb", rm: 412, ci: -2, nts: 6, gx: 3, src: "Goibibo", st: "in", mb: 600, ld: 120, dn: 450, eta: 0 },
  { id: "BK-2425", g: "Tarun Sethi", ph: "+91 91336 09894", t: "clb", rm: 414, ci: -2, nts: 6, gx: 2, src: "Website", st: "in", mb: 0, ld: 350, dn: 0, eta: 0 },
  { id: "BK-2426", g: "Vivek Anand", ph: "+91 91759 57479", t: "dlx", rm: 407, ci: -1, nts: 2, gx: 2, src: "MakeMyTrip", st: "in", mb: 0, ld: 120, dn: 0, eta: 0 },
  { id: "BK-2427", g: "Naveen Kumar", ph: "+91 94937 53313", t: "sui", rm: 514, ci: -4, nts: 6, gx: 4, src: "Walk-in", st: "in", mb: 150, ld: 0, dn: 850, eta: 0 },
  { id: "BK-2428", g: "Chaitanya Dev", ph: "+91 94702 49594", t: "std", rm: 207, ci: -4, nts: 7, gx: 1, src: "Agoda", st: "in", mb: 0, ld: 120, dn: 0, eta: 0 },
  { id: "BK-2429", g: "Mala Chandrasekhar", ph: "+91 93249 47033", t: "std", rm: 202, ci: -3, nts: 6, gx: 2, src: "Phone", st: "in", mb: 0, ld: 450, dn: 0, eta: 0 },
  { id: "BK-2430", g: "Shruti Bhat", ph: "+91 94845 66010", t: "clb", rm: 418, ci: -1, nts: 4, gx: 3, src: "Corporate", st: "in", mb: 600, ld: 200, dn: 1800, eta: 0 },
  { id: "BK-2431", g: "Gaurav Mhambrey", ph: "+91 99931 29703", t: "dlx", rm: 317, ci: -4, nts: 6, gx: 1, src: "Walk-in", st: "in", mb: 0, ld: 0, dn: 850, eta: 0 },
  { id: "BK-2432", g: "Raghavendra Kulkarni", ph: "+91 94136 27119", t: "clb", rm: 417, ci: -3, nts: 5, gx: 3, src: "Walk-in", st: "in", mb: 0, ld: 200, dn: 1200, eta: 0 },
  { id: "BK-2433", g: "Poornima Rao", ph: "+91 99065 48731", t: "dlx", rm: 319, ci: -2, nts: 6, gx: 3, src: "Goibibo", st: "in", mb: 400, ld: 0, dn: 1800, eta: 0 },
  { id: "BK-2434", g: "Anita Menon", ph: "+91 96827 16450", t: "dlx", rm: 314, ci: -2, nts: 3, gx: 2, src: "Booking.com", st: "in", mb: 400, ld: 450, dn: 850, eta: 0 },
  { id: "BK-2435", g: "Sanjay Patil", ph: "+91 92449 29047", t: "dlx", rm: 308, ci: -4, nts: 5, gx: 2, src: "Goibibo", st: "in", mb: 150, ld: 350, dn: 0, eta: 0 },
  { id: "BK-2436", g: "Chandran Menon", ph: "+91 92831 56700", t: "std", rm: 212, ci: -3, nts: 5, gx: 1, src: "Phone", st: "in", mb: 0, ld: 450, dn: 0, eta: 0 },
  { id: "BK-2437", g: "Karthik Subramanian", ph: "+91 95463 36168", t: "std", rm: 218, ci: -4, nts: 8, gx: 2, src: "Website", st: "in", mb: 400, ld: 200, dn: 1200, eta: 0 },
  { id: "BK-2438", g: "Vishwanath Alluri", ph: "+91 92054 95523", t: "std", rm: 219, ci: -3, nts: 6, gx: 3, src: "Website", st: "in", mb: 0, ld: 200, dn: 450, eta: 0 },
  { id: "BK-2439", g: "Neha Sabharwal", ph: "+91 94332 85478", t: "std", rm: 119, ci: -1, nts: 5, gx: 1, src: "MakeMyTrip", st: "in", mb: 250, ld: 200, dn: 450, eta: 0 },
  { id: "BK-2440", g: "Vidya Vyas", ph: "+91 97828 69079", t: "clb", rm: 413, ci: -1, nts: 5, gx: 1, src: "Corporate", st: "in", mb: 400, ld: 0, dn: 850, eta: 0 },
  { id: "BK-2441", g: "Vasanth Kumar", ph: "+91 95833 68090", t: "std", rm: 115, ci: -2, nts: 5, gx: 2, src: "Website", st: "in", mb: 0, ld: 450, dn: 0, eta: 0 },
  { id: "BK-2442", g: "Ramesh Kamat", ph: "+91 93351 16485", t: "dlx", rm: 406, ci: -4, nts: 8, gx: 1, src: "Booking.com", st: "in", mb: 250, ld: 120, dn: 2400, eta: 0 },
  { id: "BK-2443", g: "Pallavi Dhumal", ph: "+91 92836 27775", t: "std", rm: 211, ci: -1, nts: 5, gx: 3, src: "Corporate", st: "in", mb: 0, ld: 0, dn: 1800, eta: 0 },
  { id: "BK-2444", g: "Sridhar Iyengar", ph: "+91 99427 81533", t: "sui", rm: 511, ci: -1, nts: 4, gx: 3, src: "Website", st: "in", mb: 250, ld: 450, dn: 0, eta: 0 },
  { id: "BK-2445", g: "Meera Nair", ph: "+91 98615 43106", t: "dlx", rm: 409, ci: -3, nts: 7, gx: 2, src: "Phone", st: "in", mb: 0, ld: 0, dn: 450, eta: 0 },
  { id: "BK-2446", g: "Prakash Gowda", ph: "+91 93164 73148", t: "dlx", rm: 312, ci: -3, nts: 5, gx: 3, src: "Website", st: "in", mb: 600, ld: 120, dn: 0, eta: 0 },
  { id: "BK-2447", g: "Sharat Chandra", ph: "+91 97459 91796", t: "dlx", rm: 307, ci: -1, nts: 3, gx: 3, src: "MakeMyTrip", st: "in", mb: 400, ld: 0, dn: 1800, eta: 0 },
  { id: "BK-2448", g: "Harish Chandra", ph: "+91 99210 60129", t: "std", rm: 102, ci: -4, nts: 5, gx: 3, src: "MakeMyTrip", st: "in", mb: 0, ld: 0, dn: 2400, eta: 0 },
  { id: "BK-2449", g: "Aparna Das", ph: "+91 95921 34333", t: "std", rm: 116, ci: -4, nts: 5, gx: 3, src: "Phone", st: "in", mb: 0, ld: 450, dn: 850, eta: 0 },
  { id: "BK-2450", g: "Ashwin Mahadevan", ph: "+91 96238 73355", t: "std", rm: 111, ci: -3, nts: 5, gx: 2, src: "Agoda", st: "in", mb: 150, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2451", g: "Girija Raghavan", ph: "+91 95718 18235", t: "dlx", rm: 410, ci: -2, nts: 5, gx: 1, src: "Website", st: "in", mb: 150, ld: 0, dn: 2400, eta: 0 },
  { id: "BK-2452", g: "Padma Venkat", ph: "+91 94264 37142", t: "dlx", rm: 305, ci: -2, nts: 3, gx: 3, src: "Phone", st: "in", mb: 0, ld: 200, dn: 450, eta: 0 },
  { id: "BK-2453", g: "Omkar Desai", ph: "+91 93600 22529", t: "sui", rm: 508, ci: -2, nts: 5, gx: 2, src: "Website", st: "in", mb: 600, ld: 0, dn: 1800, eta: 0 },
  { id: "BK-2454", g: "Suresh Babu", ph: "+91 93528 02307", t: "dlx", rm: 315, ci: -1, nts: 5, gx: 3, src: "Booking.com", st: "in", mb: 400, ld: 120, dn: 1200, eta: 0 },
  { id: "BK-2455", g: "Latha Krishnan", ph: "+91 91488 42723", t: "dlx", rm: 404, ci: -1, nts: 5, gx: 3, src: "Booking.com", st: "in", mb: 0, ld: 0, dn: 450, eta: 0 },
  { id: "BK-2456", g: "Indira Bhattacharya", ph: "+91 97920 65318", t: "dlx", rm: 304, ci: -1, nts: 4, gx: 1, src: "Agoda", st: "in", mb: 250, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2457", g: "Ravi Varma", ph: "+91 95785 46165", t: "std", rm: 213, ci: -1, nts: 4, gx: 1, src: "Walk-in", st: "in", mb: 150, ld: 350, dn: 450, eta: 0 },
  { id: "BK-2458", g: "Vinayak Joshi", ph: "+91 91066 28404", t: "dlx", rm: 403, ci: -3, nts: 5, gx: 2, src: "Booking.com", st: "in", mb: 600, ld: 450, dn: 0, eta: 0 },
  { id: "BK-2459", g: "Bhairavi Joshi", ph: "+91 92024 00602", t: "std", rm: 105, ci: -4, nts: 8, gx: 2, src: "Walk-in", st: "in", mb: 250, ld: 120, dn: 850, eta: 0 },
  { id: "BK-2460", g: "Ayesha Khan", ph: "+91 99207 04198", t: "sui", rm: 506, ci: -4, nts: 5, gx: 2, src: "MakeMyTrip", st: "in", mb: 0, ld: 120, dn: 450, eta: 0 },
  { id: "BK-2461", g: "Swati Tiwari", ph: "+91 96903 22696", t: "dlx", rm: 320, ci: -1, nts: 2, gx: 3, src: "Website", st: "in", mb: 150, ld: 200, dn: 0, eta: 0 },
  { id: "BK-2462", g: "Emily Carter", ph: "+91 98389 81861", t: "clb", rm: 420, ci: -4, nts: 7, gx: 3, src: "Phone", st: "in", mb: 0, ld: 350, dn: 850, eta: 0 },
  { id: "BK-2463", g: "Yash Agarwal", ph: "+91 91897 89270", t: "std", rm: 113, ci: -2, nts: 6, gx: 3, src: "Agoda", st: "in", mb: 150, ld: 200, dn: 850, eta: 0 },
  { id: "BK-2464", g: "Ganesh Aithal", ph: "+91 98899 61277", t: "std", rm: 217, ci: -4, nts: 7, gx: 3, src: "Walk-in", st: "in", mb: 250, ld: 350, dn: 1200, eta: 0 },
  { id: "BK-2465", g: "Sriram Vaidyanathan", ph: "+91 91922 13712", t: "sui", rm: 513, ci: -3, nts: 6, gx: 3, src: "Corporate", st: "in", mb: 0, ld: 0, dn: 850, eta: 0 },
  { id: "BK-2466", g: "Michael D'Souza", ph: "+91 95794 51577", t: "pre", rm: 517, ci: -4, nts: 5, gx: 3, src: "Phone", st: "in", mb: 250, ld: 350, dn: 850, eta: 0 },
  { id: "BK-2467", g: "Divya Hegde", ph: "+91 99537 69227", t: "std", rm: 109, ci: -3, nts: 7, gx: 1, src: "MakeMyTrip", st: "in", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2468", g: "Amit Malhotra", ph: "+91 94238 21869", t: "std", rm: 110, ci: -1, nts: 2, gx: 1, src: "Corporate", st: "in", mb: 400, ld: 450, dn: 0, eta: 0 },
  { id: "BK-2469", g: "Hans Meier", ph: "+91 97410 37838", t: "dlx", rm: 402, ci: -3, nts: 4, gx: 1, src: "Walk-in", st: "in", mb: 0, ld: 350, dn: 2400, eta: 0 },
  { id: "BK-2470", g: "Radhika Shetty", ph: "+91 91484 78549", t: "dlx", rm: 302, ci: -1, nts: 3, gx: 2, src: "Phone", st: "in", mb: 150, ld: 450, dn: 1200, eta: 0 },
  { id: "BK-2471", g: "Yuki Tanaka", ph: "+91 94132 23557", t: "dlx", rm: 301, ci: -4, nts: 8, gx: 3, src: "Goibibo", st: "in", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2472", g: "Dinesh Shenoy", ph: "+91 98113 87031", t: "clb", rm: 419, ci: -2, nts: 5, gx: 3, src: "Phone", st: "in", mb: 0, ld: 350, dn: 850, eta: 0 },
  { id: "BK-2473", g: "Bala Murugan", ph: "+91 91628 64560", t: "clb", rm: 415, ci: -3, nts: 4, gx: 3, src: "Phone", st: "in", mb: 0, ld: 120, dn: 1200, eta: 0 },
  { id: "BK-2474", g: "Nikhil Barot", ph: "+91 99610 91362", t: "pre", rm: 519, ci: 0, nts: 1, gx: 3, src: "Corporate", st: "arr", mb: 0, ld: 0, dn: 0, eta: 18 },
  { id: "BK-2475", g: "Arjun Hegde", ph: "+91 91336 28295", t: "std", rm: 215, ci: 0, nts: 1, gx: 2, src: "Website", st: "arr", mb: 0, ld: 0, dn: 0, eta: 20 },
  { id: "BK-2476", g: "Jennifer Pinto", ph: "+91 98763 97289", t: "sui", rm: 509, ci: 0, nts: 4, gx: 3, src: "Walk-in", st: "arr", mb: 0, ld: 0, dn: 0, eta: 16 },
  { id: "BK-2477", g: "Pooja Trivedi", ph: "+91 91810 46722", t: "std", rm: 120, ci: 0, nts: 1, gx: 2, src: "Booking.com", st: "arr", mb: 0, ld: 0, dn: 0, eta: 11 },
  { id: "BK-2478", g: "Ritu Bakshi", ph: "+91 92267 07812", t: "dlx", rm: 313, ci: 0, nts: 1, gx: 2, src: "Booking.com", st: "arr", mb: 0, ld: 0, dn: 0, eta: 20 },
  { id: "BK-2479", g: "Gayathri Ram", ph: "+91 98369 85959", t: "std", rm: 216, ci: 0, nts: 1, gx: 1, src: "Walk-in", st: "arr", mb: 0, ld: 0, dn: 0, eta: 12 },
  { id: "BK-2480", g: "Deepa Sharma", ph: "+91 94178 21931", t: "std", rm: 101, ci: 0, nts: 1, gx: 2, src: "Booking.com", st: "arr", mb: 0, ld: 0, dn: 0, eta: 10 },
  { id: "BK-2481", g: "Uma Mahesh", ph: "+91 94528 68001", t: "std", rm: 103, ci: 0, nts: 4, gx: 3, src: "Corporate", st: "arr", mb: 0, ld: 0, dn: 0, eta: 17 },
  { id: "BK-2482", g: "Bhavani Shankar", ph: "+91 92243 36720", t: "std", rm: 117, ci: 0, nts: 3, gx: 3, src: "Corporate", st: "arr", mb: 0, ld: 0, dn: 0, eta: 17 },
  { id: "BK-2483", g: "Rohit Shet", ph: "+91 98768 66692", t: "dlx", rm: 318, ci: 0, nts: 2, gx: 3, src: "Walk-in", st: "arr", mb: 0, ld: 0, dn: 0, eta: 11 },
  { id: "BK-2484", g: "Prasad Rao", ph: "+91 96960 80275", t: "pre", rm: 518, ci: 0, nts: 2, gx: 3, src: "Booking.com", st: "arr", mb: 0, ld: 0, dn: 0, eta: 14 },
  { id: "BK-2485", g: "Subhash Ghosal", ph: "+91 95805 50424", t: "clb", rm: 502, ci: -3, nts: 3, gx: 1, src: "Goibibo", st: "out", mb: 150, ld: 120, dn: 850, eta: 0 },
  { id: "BK-2486", g: "Tanya Doshi", ph: "+91 91337 08542", t: "std", rm: 201, ci: -1, nts: 1, gx: 3, src: "Corporate", st: "out", mb: 0, ld: 350, dn: 850, eta: 0 },
  { id: "BK-2487", g: "Tejaswi Halmidi", ph: "+91 99399 57623", t: "std", rm: 106, ci: -1, nts: 1, gx: 2, src: "Goibibo", st: "out", mb: 150, ld: 0, dn: 1200, eta: 0 },
  { id: "BK-2488", g: "Arvind Rao", ph: "+91 98238 13434", t: "clb", rm: 504, ci: -2, nts: 2, gx: 3, src: "Walk-in", st: "out", mb: 150, ld: 0, dn: 450, eta: 0 },
  { id: "BK-2489", g: "Anil Sahay", ph: "+91 93005 58655", t: "std", rm: 203, ci: -2, nts: 2, gx: 2, src: "Phone", st: "out", mb: 0, ld: 350, dn: 1200, eta: 0 },
  { id: "BK-2490", g: "Sneha Kulkarni", ph: "+91 92681 67234", t: "clb", rm: 416, ci: -4, nts: 4, gx: 3, src: "Phone", st: "out", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2491", g: "Nandini Rao", ph: "+91 91558 37111", t: "dlx", rm: 306, ci: -2, nts: 2, gx: 2, src: "Walk-in", st: "out", mb: 150, ld: 120, dn: 1200, eta: 0 },
  { id: "BK-2492", g: "Deepthi Suresh", ph: "+91 99874 23336", t: "std", rm: 108, ci: -2, nts: 2, gx: 2, src: "Website", st: "out", mb: 0, ld: 120, dn: 450, eta: 0 },
  { id: "BK-2493", g: "Zoya Sheikh", ph: "+91 97341 50905", t: "dlx", rm: null, ci: 3, nts: 1, gx: 1, src: "MakeMyTrip", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2494", g: "Prosenjit Dutta", ph: "+91 99339 41032", t: "sui", rm: null, ci: 4, nts: 1, gx: 1, src: "Corporate", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2495", g: "Devi Priya", ph: "+91 96748 32610", t: "pre", rm: null, ci: 6, nts: 2, gx: 1, src: "Walk-in", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2496", g: "Sunanda Pillai", ph: "+91 93182 86048", t: "std", rm: null, ci: 6, nts: 1, gx: 3, src: "MakeMyTrip", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2497", g: "Nagaraj Shastri", ph: "+91 95852 36592", t: "clb", rm: null, ci: 6, nts: 3, gx: 1, src: "Goibibo", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2498", g: "Mohan Urs", ph: "+91 97336 72332", t: "dlx", rm: null, ci: 3, nts: 3, gx: 3, src: "MakeMyTrip", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2499", g: "Sarah Thomas", ph: "+91 97853 60956", t: "std", rm: null, ci: 2, nts: 2, gx: 2, src: "Corporate", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2500", g: "Gopal Krishna", ph: "+91 94538 54375", t: "clb", rm: null, ci: 5, nts: 1, gx: 3, src: "Phone", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2501", g: "Manoj Pillai", ph: "+91 94899 44091", t: "clb", rm: null, ci: 4, nts: 3, gx: 1, src: "Corporate", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2502", g: "Nitin Gokhale", ph: "+91 93367 73271", t: "sui", rm: null, ci: 6, nts: 3, gx: 2, src: "Booking.com", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2503", g: "Kritika Jain", ph: "+91 98118 53580", t: "sui", rm: null, ci: 4, nts: 3, gx: 2, src: "Agoda", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2504", g: "Ilana Pereira", ph: "+91 93682 55491", t: "std", rm: null, ci: 3, nts: 1, gx: 3, src: "Booking.com", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2505", g: "Vijay Anand", ph: "+91 99956 49364", t: "clb", rm: null, ci: 6, nts: 3, gx: 1, src: "Phone", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
  { id: "BK-2506", g: "Lakshmi Narayan", ph: "+91 92645 29639", t: "pre", rm: null, ci: 4, nts: 1, gx: 1, src: "Corporate", st: "up", mb: 0, ld: 0, dn: 0, eta: 0 },
];

export const LODGE_MNT_NOTES: Record<number, string> = {
  303: "AC compressor servicing",
  501: "AC compressor servicing",
};

/** Occupancy % over the last 7 days — today is the last entry. */
export const LODGE_TREND = [58, 61, 64, 59, 72, 77, 63];

/** "21 Sep" — a date offset in days from today (IST). */
export function lodgeDateLabel(offset: number): string {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  return new Date(d.getTime() + offset * 86400000).toLocaleDateString("en-IN", {
    timeZone: "Asia/Calcutta",
    day: "numeric",
    month: "short",
  });
}

/** Running folio: room + extras + GST (12% · 18% above ₹7,500/night). */
export function folioOf(b: LodgeBooking, rates: Record<LodgeTypeId, { rate: number }>): {
  room: number;
  extras: number;
  tax: number;
  total: number;
  pct: number;
} {
  const room = b.nts * rates[b.t].rate;
  const extras = (b.mb || 0) + (b.ld || 0) + (b.dn || 0);
  const pct = rates[b.t].rate > 7500 ? 18 : 12;
  const tax = Math.round((room * pct) / 100);
  return { room, extras, tax, total: room + extras + tax, pct };
}
