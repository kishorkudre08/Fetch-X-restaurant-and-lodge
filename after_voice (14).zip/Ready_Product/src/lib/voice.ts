"use client";

/* t147 — VOICE — Web Speech API plumbing + voice preference storage.
 *
 * The Fetch-X live-talk feature uses the browser's built-in:
 *   · SpeechRecognition (SpeechRecognition || webkitSpeechRecognition) for STT
 *   · speechSynthesis for TTS
 *
 * Voices are OS-dependent — Chrome surfaces OS voices (Microsoft David,
 * Microsoft Zira, Google US English, etc.). The picker enumerates whatever
 * the platform offers and lets the user pick one. Stored per-account so
 * each reception/owner keeps their own voice.
 */

const VOICE_KEY_PREFIX = "fx-ai-voice";

export function voiceStorageKey(account?: string | null): string {
  const who = (account ?? "").trim().toLowerCase();
  return `${VOICE_KEY_PREFIX}:${who || "guest"}`;
}

export function readStoredVoice(account?: string | null): string | null {
  try {
    return localStorage.getItem(voiceStorageKey(account));
  } catch {
    return null;
  }
}

export function writeStoredVoice(voiceURI: string, account?: string | null): void {
  try {
    localStorage.setItem(voiceStorageKey(account), voiceURI);
  } catch {
    /* private mode */
  }
}

export type FxVoice = {
  voiceURI: string;
  name: string;
  lang: string;
  /** heuristic: "male" | "female" | "neutral" — best-effort from name tokens */
  gender: "male" | "female" | "neutral";
  /** "Microsoft" / "Google" / "Apple" — vendor prefix where available */
  vendor: string;
};

/* Name tokens that hint at gender. Imperfect; the user can override by
 * picking any voice regardless of the label. */
const MALE_HINTS = ["david", "mark", "george", "james", "fred", "ravi", "mahesh", "hemanth", "alex", "daniel", "thomas", "arthur", "oliver"];
const FEMALE_HINTS = ["zira", "susan", "hazel", "catherine", "linda", "heather", "veena", "sangeeta", "rishi", "anjali", "priya", "aria", "jenny", "samantha", "tessa", "serena"];

function guessGender(name: string): "male" | "female" | "neutral" {
  const lc = name.toLowerCase();
  if (MALE_HINTS.some((h) => lc.includes(h))) return "male";
  if (FEMALE_HINTS.some((h) => lc.includes(h))) return "female";
  return "neutral";
}

function vendorOf(name: string): string {
  if (/^microsoft/i.test(name)) return "Microsoft";
  if (/^google/i.test(name)) return "Google";
  if (/^apple/i.test(name)) return "Apple";
  if (/^amazon/i.test(name)) return "Amazon";
  return "System";
}

/** Wait for speechSynthesis to populate voices (Chrome loads them async). */
export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve([]);
      return;
    }
    const cur = window.speechSynthesis.getVoices();
    if (cur.length) {
      resolve(cur);
      return;
    }
    let done = false;
    const finish = (v: SpeechSynthesisVoice[]) => {
      if (done) return;
      done = true;
      resolve(v);
    };
    window.speechSynthesis.onvoiceschanged = () => finish(window.speechSynthesis.getVoices());
    // Fallback: some browsers fire the event before the listener is attached.
    setTimeout(() => finish(window.speechSynthesis.getVoices()), 1200);
  });
}

/** Map platform voices to FxVoice objects. */
export function toFxVoices(voices: SpeechSynthesisVoice[]): FxVoice[] {
  return voices
    .filter((v) => v.lang.toLowerCase().startsWith("en") || /india|hindi/i.test(v.name))
    .map((v) => ({
      voiceURI: v.voiceURI,
      name: v.name,
      lang: v.lang,
      gender: guessGender(v.name),
      vendor: vendorOf(v.name),
    }));
}

/** Find a sensible default — prefer Microsoft David (deep male), else a
 *  Microsoft female voice, else any English voice, else the first one. */
export function pickDefaultVoice(voices: FxVoice[]): FxVoice | null {
  if (!voices.length) return null;
  const david = voices.find((v) => /microsoft david/i.test(v.name));
  if (david) return david;
  const msFemale = voices.find((v) => v.vendor === "Microsoft" && v.gender === "female");
  if (msFemale) return msFemale;
  const enUS = voices.find((v) => v.lang === "en-US");
  if (enUS) return enUS;
  return voices[0];
}

/** Resolve a stored voiceURI to a real SpeechSynthesisVoice (or null). */
export function findVoice(voices: SpeechSynthesisVoice[], voiceURI: string | null): SpeechSynthesisVoice | null {
  if (!voiceURI) return null;
  return voices.find((v) => v.voiceURI === voiceURI) ?? null;
}

/** Speak text using the chosen voice. Cancels any in-flight speech first.
 *  Returns a promise that resolves when speech finishes (or errors). */
export function speak(
  text: string,
  voice: SpeechSynthesisVoice | null,
  opts: { rate?: number; pitch?: number; volume?: number; onStart?: () => void; onEnd?: () => void; onError?: () => void } = {},
): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve();
      return;
    }
    const synth = window.speechSynthesis;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(stripForSpeech(text));
    if (voice) u.voice = voice;
    u.rate = opts.rate ?? 1.0;
    u.pitch = opts.pitch ?? 1.0;
    u.volume = opts.volume ?? 1.0;
    u.onstart = () => opts.onStart?.();
    u.onend = () => {
      opts.onEnd?.();
      resolve();
    };
    u.onerror = () => {
      opts.onError?.();
      resolve();
    };
    synth.speak(u);
  });
}

/** Strip markdown/code fences for speech — the live-talk reply is plain
 *  text already, but if a stray table leaks through, we don't want the
 *  TTS reading "pipe pipe pipe" out loud. */
export function stripForSpeech(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " ") // code fences
    .replace(/`([^`]+)`/g, "$1") // inline code
    .replace(/!\[[^\]]*\]\([^)]+\)/g, " ") // images
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1") // links → label
    .replace(/^\s*\|.*\|\s*$/gm, " ") // table rows
    .replace(/^\s*[-*+]\s+/gm, "") // bullets
    .replace(/^\s*\d+\.\s+/gm, "") // numbered
    .replace(/[*_~#]/g, "") // emphasis marks
    .replace(/\n{2,}/g, ". ")
    .replace(/\s+/g, " ")
    .trim();
}

/* ── SPEECH RECOGNITION (STT) ──────────────────────────────────────────────── */

type AnyRec = typeof SpeechRecognition;

export function newRecognition(): AnyRec | null {
  if (typeof window === "undefined") return null;
  const Ctor = (window as unknown as { SpeechRecognition?: AnyRec; webkitSpeechRecognition?: AnyRec }).SpeechRecognition
    ?? (window as unknown as { webkitSpeechRecognition?: AnyRec }).webkitSpeechRecognition;
  if (!Ctor) return null;
  const r = new Ctor();
  r.lang = "en-IN"; // India English — matches the project's IST locale + INR
  r.continuous = true;
  r.interimResults = true;
  r.maxAlternatives = 1;
  return r;
}

export function isSttSupported(): boolean {
  if (typeof window === "undefined") return false;
  return !!(
    (window as unknown as { SpeechRecognition?: AnyRec }).SpeechRecognition
    ?? (window as unknown as { webkitSpeechRecognition?: AnyRec }).webkitSpeechRecognition
  );
}

export function isTtsSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}
