// ── Two-book + lodge analytics — extends the restaurant-only dashboard ─────
// Everything here is computed from real rows: salaries split by Employee.book,
// expenses split by Expense.book, and the lodge's own ledger from LodgeBill.
import { db } from "@/lib/db";
import { type RangeKey, RANGE_META } from "@/lib/analytics";
import { parseLevels, parseMaxRooms, tierOfRoom, DEFAULT_LEVELS, MAX_ROOMS_KEY } from "@/lib/lodge";

const round2 = (n: number) => Math.round(n * 100) / 100;

// ── IST helpers (kept in sync with analytics.ts) ───────────────────────────
const IST_OFFSET_MIN = 330;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function istShift(d: Date): Date {
  return new Date(d.getTime() + IST_OFFSET_MIN * 60000);
}
function istDayStart(d: Date): Date {
  const s = istShift(d);
  s.setUTCHours(0, 0, 0, 0);
  return new Date(s.getTime() - IST_OFFSET_MIN * 60000);
}
function istHour(d: Date): number {
  return istShift(d).getUTCHours();
}
function istDateKey(d: Date): string {
  return istShift(d).toISOString().slice(0, 10);
}
function hourLabel(h: number): string {
  const suffix = h >= 12 ? "PM" : "AM";
  const base = h % 12 === 0 ? 12 : h % 12;
  return `${base} ${suffix}`;
}
function dateKeyLabel(key: string): string {
  const parts = key.split("-").map(Number);
  const m = parts[1];
  const d = parts[2];
  return `${d} ${MONTHS[m - 1]}`;
}
function monthKeyLabel(key: string): string {
  const parts = key.split("-").map(Number);
  const y = parts[0];
  const m = parts[1];
  return `${MONTHS[m - 1]} '${String(y).slice(2)}`;
}
function weekStartOf(d: Date): Date {
  const s = istDayStart(d);
  s.setUTCDate(s.getUTCDate() - s.getUTCDay());
  return s;
}

export type BookCosts = {
  salaries: number;
  rawMaterials: number;
  upgrades: number; // t98 — the receptions' third expense type
  maintenance: number;
  // t132 — discounts given at billing (restaurant POS input / lodge checkout
  // input). Not an expense row — money the bill WASN'T collected — shown as
  // its own deduction line + donut slice in the revenue breakdown.
  discounts: number;
  profit: number;
};

export type LodgeBucket = { label: string; revenue: number; stays: number };

/** t133 — one row of the discount history: a checkout that gave money off. */
export type LodgeDiscountRow = {
  number: number;
  room: number;
  guestName: string;
  total: number;
  discount: number;
  createdAt: string;
};

/** t91 — room-hours wall split: how the 100-room house spent the window. */
export type RoomHoursData = {
  /** room-hours the wall hosted guests inside the window */
  guests: number;
  /** room-hours rooms spent under maintenance inside the window */
  mnt: number;
  /** totalRh − guests − mnt (never negative) */
  free: number;
  /** totalRooms × windowHours */
  total: number;
  /** the wall size (100) — the donut's three slices always sum to this */
  totalRooms: number;
  /** windowMs in hours (today = elapsed hours since IST midnight) */
  windowHours: number;
  /** "TODAY" / "LAST 7 DAYS" … for the donut centre + card label */
  windowLabel: string;
};

export type LodgeBlock = {
  revenue: number;
  stays: number;
  avgStay: number;
  deltaPct: number | null;
  // t132 — discounts typed into the front desk's checkout input
  discounts: number;
  // t133 — the newest discounted checkouts (the discount history feed)
  discountRows: LodgeDiscountRow[];
  buckets: LodgeBucket[];
  peakLabel: string | null;
  dayCurve: Array<{ label: string; pct: number }>;
  dayPeak: string | null;
  inHouse: number;
  pctFull: number;
  mnt: number;
  tonight: number;
  stayMix: Array<{ label: string; share: number }>;
  tierMix: Array<{ tier: string; revenue: number; share: number }>;
  /** t91 — room-hours split of the wall for the selected window */
  roomHours: RoomHoursData;
  recent: Array<{
    number: number;
    room: number;
    guestName: string;
    total: number;
    createdAt: string;
    hours: number;
  }>;
};

/** t91 — human label for the analytics window, mirroring the dashboard tabs. */
const WINDOW_LABEL: Record<RangeKey, string> = {
  today: "TODAY",
  "7d": "LAST 7 DAYS",
  "1m": "LAST 30 DAYS",
  "3m": "LAST 3 MONTHS",
  "1y": "LAST 12 MONTHS",
};

/** Per-book cost books — t119 kept actual settled payments; t129: salaries are
    the ATTENDANCE-RECALCULATED accrual (passed in from buildDashboard so the
    total and the per-book split come from ONE computation). Expenses stay
    actuals. */
export async function getBookCosts(range: RangeKey, days: number, accrual?: { rest: number; lodge: number }) {
  const start = istDayStart(new Date(Date.now() - (days - 1) * 86400000));
  const [expAgg, pays, restDisc, lodgeDisc] = await Promise.all([
    db.expense.groupBy({
      by: ["kind", "book"],
      where: { spentOn: { gte: start } },
      _sum: { amount: true },
    }),
    // settled payments still tell us WHICH book each rupee belongs to when no
    // accrual was passed (legacy callers)
    accrual
      ? Promise.resolve([])
      : db.salaryPayment.findMany({
          where: { status: "paid", paidAt: { gte: start } },
          select: { netPaid: true, employee: { select: { book: true } } },
        }),
    // t132 — discounts the receptions typed into the billing inputs
    db.bill.aggregate({ where: { createdAt: { gte: start } }, _sum: { discount: true } }),
    db.lodgeBill.aggregate({ where: { createdAt: { gte: start } }, _sum: { discount: true } }),
  ]);
  const out: Record<"rest" | "lodge", BookCosts> = {
    rest: { salaries: 0, rawMaterials: 0, upgrades: 0, maintenance: 0, discounts: 0, profit: 0 },
    lodge: { salaries: 0, rawMaterials: 0, upgrades: 0, maintenance: 0, discounts: 0, profit: 0 },
  };
  out.rest.discounts = round2(restDisc._sum.discount ?? 0);
  out.lodge.discounts = round2(lodgeDisc._sum.discount ?? 0);
  // RECALCULATED salary money per book — attendance-derived (t129).
  if (accrual) {
    out.rest.salaries = round2(accrual.rest);
    out.lodge.salaries = round2(accrual.lodge);
  } else {
    for (const p of pays) {
      const book = p.employee.book === "lodge" ? "lodge" : "rest";
      out[book].salaries += p.netPaid;
    }
    for (const book of ["rest", "lodge"] as const) out[book].salaries = round2(out[book].salaries);
  }
  for (const book of ["rest", "lodge"] as const) {
    const raw = expAgg.find((e) => e.kind === "raw_material" && e.book === book)?._sum.amount ?? 0;
    const upg = expAgg.find((e) => e.kind === "upgrade" && e.book === book)?._sum.amount ?? 0;
    const mnt = expAgg.find((e) => e.kind === "maintenance" && e.book === book)?._sum.amount ?? 0;
    out[book].rawMaterials = round2(raw);
    out[book].upgrades = round2(upg);
    out[book].maintenance = round2(mnt);
  }
  return out;
}

/** The lodge's own block — revenue, buckets, average-day occupancy curve. */
export async function getLodgeBlock(range: RangeKey): Promise<LodgeBlock> {
  const meta = RANGE_META[range];
  const now = new Date();
  const start = istDayStart(new Date(now.getTime() - (meta.days - 1) * 86400000));
  const prevStart = istDayStart(new Date(start.getTime() - meta.days * 86400000));

  const [bills, prevAgg, rooms, stayRows, recent, levelsSetting, maxSetting, occRateRows, discRows] = await Promise.all([
    db.lodgeBill.findMany({
      where: { createdAt: { gte: start } },
      select: { total: true, discount: true, createdAt: true, hours: true },
    }),
    db.lodgeBill.aggregate({
      where: { createdAt: { gte: prevStart, lt: start } },
      _count: true,
      _sum: { total: true },
    }),
    db.room.findMany({ select: { number: true, status: true, updatedAt: true } }),
    db.lodgeBill.findMany({
      where: { createdAt: { gte: new Date(now.getTime() - 90 * 86400000) } },
      select: { hours: true },
    }),
    db.lodgeBill.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
      select: { number: true, room: true, guestName: true, total: true, createdAt: true, hours: true },
    }),
    db.setting.findUnique({ where: { key: "lodgeLevels" } }),
    db.setting.findUnique({ where: { key: MAX_ROOMS_KEY } }),
    db.room.findMany({
      where: { status: "occ" },
      select: { number: true },
    }),
    // t133 — the newest discounted checkouts for the discount history feed
    db.lodgeBill.findMany({
      where: { createdAt: { gte: start }, discount: { gt: 0 } },
      orderBy: { createdAt: "desc" },
      take: 12,
      select: { number: true, room: true, guestName: true, total: true, discount: true, createdAt: true },
    }),
  ]);
  const maxRooms = parseMaxRooms(maxSetting?.value);
  const levels = parseLevels(levelsSetting?.value, maxRooms) ?? DEFAULT_LEVELS;
  const tonight = occRateRows.reduce((sum, r) => sum + tierOfRoom(r.number, levels).rate, 0);

  const revenue = round2(bills.reduce((s, b) => s + b.total, 0));
  // t132 — money given away through the checkout's DISCOUNT ₹ input
  const discounts = round2(bills.reduce((s, b) => s + (b.discount ?? 0), 0));
  const discountRows: LodgeDiscountRow[] = discRows.map((b) => ({
    number: b.number,
    room: b.room,
    guestName: b.guestName,
    total: round2(b.total),
    discount: round2(b.discount),
    createdAt: b.createdAt.toISOString(),
  }));
  const stays = bills.length;
  const avgStay = stays ? round2(revenue / stays) : 0;
  const prevRevenue = round2(prevAgg._sum.total ?? 0);
  const deltaPct =
    prevRevenue > 0 ? round2(((revenue - prevRevenue) / prevRevenue) * 100) : null;

  // buckets on the same axis as the restaurant trend
  const bucketMap = new Map<string, LodgeBucket>();
  const bucketKeyOf = (d: Date): string => {
    if (meta.bucket === "hour") return String(istHour(d));
    if (meta.bucket === "day") return istDateKey(d);
    if (meta.bucket === "week") return istDateKey(weekStartOf(d));
    return istDateKey(d).slice(0, 7);
  };
  for (const b of bills) {
    const key = bucketKeyOf(b.createdAt);
    const bk = bucketMap.get(key) ?? { label: "", revenue: 0, stays: 0 };
    bk.revenue += b.total;
    bk.stays += 1;
    bucketMap.set(key, bk);
  }
  const buckets: LodgeBucket[] = [];
  if (meta.bucket === "hour") {
    for (let h = 7; h <= 23; h++) {
      const bk = bucketMap.get(String(h));
      buckets.push({ label: hourLabel(h), revenue: round2(bk?.revenue ?? 0), stays: bk?.stays ?? 0 });
    }
  } else if (meta.bucket === "day") {
    for (let i = meta.days - 1; i >= 0; i--) {
      const key = istDateKey(new Date(now.getTime() - i * 86400000));
      const bk = bucketMap.get(key);
      buckets.push({ label: dateKeyLabel(key), revenue: round2(bk?.revenue ?? 0), stays: bk?.stays ?? 0 });
    }
  } else if (meta.bucket === "week") {
    const first = weekStartOf(start).getTime();
    const last = weekStartOf(now).getTime();
    for (let t = first; t <= last; t += 7 * 86400000) {
      const key = istDateKey(new Date(t));
      const bk = bucketMap.get(key);
      buckets.push({ label: dateKeyLabel(key), revenue: round2(bk?.revenue ?? 0), stays: bk?.stays ?? 0 });
    }
  } else {
    for (let m = 11; m >= 0; m--) {
      const d = new Date(Date.UTC(istShift(now).getUTCFullYear(), istShift(now).getUTCMonth() - m, 1));
      const key = d.toISOString().slice(0, 7);
      const bk = bucketMap.get(key);
      buckets.push({ label: monthKeyLabel(key), revenue: round2(bk?.revenue ?? 0), stays: bk?.stays ?? 0 });
    }
  }
  const peakBucket = buckets.reduce(
    (best, b) => (b.revenue > best.revenue ? b : best),
    buckets[0] ?? { label: "", revenue: 0, stays: 0 },
  );

  // ── Average-day occupancy curve — rooms in house by hour of day ──
  // Real spans: closed stays from LodgeBill + open spans (guests still in).
  const mntCount = rooms.filter((r) => r.status === "mnt").length;
  const spans: Array<{ inAt: Date; outAt: Date }> = await db.lodgeBill
    .findMany({
      where: { checkOutAt: { gte: start } },
      select: { checkInAt: true, checkOutAt: true },
    })
    .then((rows) =>
      rows.map((r) => ({ inAt: r.checkInAt, outAt: r.checkOutAt })),
    );
  const occRows = await db.room.findMany({
    where: { status: "occ", checkInAt: { not: null } },
    select: { checkInAt: true },
  });
  for (const r of occRows) {
    if (r.checkInAt) spans.push({ inAt: r.checkInAt, outAt: now });
  }
  const days = meta.days;
  const hits = new Array(24).fill(0);
  for (const sp of spans) {
    const firstDay = istDayStart(sp.inAt).getTime();
    const lastDay = istDayStart(sp.outAt).getTime();
    for (let day = firstDay; day <= lastDay && day <= now.getTime(); day += 86400000) {
      if (day < start.getTime()) continue;
      const dayEnd = day + 86400000;
      const from = Math.max(sp.inAt.getTime(), day);
      const to = Math.min(sp.outAt.getTime(), dayEnd);
      if (to <= from) continue;
      const hFrom = Math.floor((from - day) / 3600000);
      const hTo = Math.ceil((to - day) / 3600000);
      for (let h = hFrom; h < Math.min(hTo, 24); h++) hits[h] += 1;
    }
  }
  const dayCurve: Array<{ label: string; pct: number }> = [];
  for (let h = 9; h <= 23; h++) {
    dayCurve.push({
      label: hourLabel(h),
      // rooms in house ÷ the wall's rooms = occupancy %
      pct: Math.min(100, Math.round((hits[h] / Math.max(1, days)) * 100 / maxRooms)),
    });
  }
  const dayPeak = dayCurve.reduce(
    (best, c) => (c.pct > best.pct ? c : best),
    dayCurve[0] ?? { label: "", pct: 0 },
  ).label;

  // ── t91: room-hours wall split — the whole wall expressed in room-hours ──
  // guests: closed stays (LodgeBill spans) + open stays ∩ [start, now]
  // mnt:    rooms sitting in maintenance since their status flipped (updatedAt)
  // free:   the wall's leftover room-hours — totalRh − guests − mnt
  const windowMs = Math.max(1, now.getTime() - start.getTime());
  const totalRh = maxRooms * (windowMs / 3600000);
  let guestsRh = 0;
  for (const sp of spans) {
    const from = Math.max(sp.inAt.getTime(), start.getTime());
    const to = Math.min(sp.outAt.getTime(), now.getTime());
    if (to > from) guestsRh += (to - from) / 3600000;
  }
  let mntRh = 0;
  for (const r of rooms) {
    if (r.status !== "mnt") continue;
    const from = Math.max(r.updatedAt.getTime(), start.getTime());
    mntRh += Math.max(0, (now.getTime() - from) / 3600000);
  }
  const freeRh = Math.max(0, totalRh - guestsRh - mntRh);
  const roomHours: RoomHoursData = {
    guests: round2(guestsRh),
    mnt: round2(mntRh),
    free: round2(freeRh),
    total: round2(totalRh),
    totalRooms: maxRooms,
    windowHours: round2(windowMs / 3600000),
    windowLabel: WINDOW_LABEL[range],
  };

  // stay mix (90-day window)
  const mixBuckets = [
    { label: "UNDER 6 H", test: (h: number) => h < 6 },
    { label: "6 – 12 H", test: (h: number) => h >= 6 && h < 12 },
    { label: "12 – 24 H", test: (h: number) => h >= 12 && h < 24 },
    { label: "24 H +", test: (h: number) => h >= 24 },
  ];
  const mixTotal = stayRows.length || 1;
  const stayMix = mixBuckets.map((b) => ({
    label: b.label,
    share: Math.round((stayRows.filter((s) => b.test(s.hours)).length / mixTotal) * 100),
  }));

  const occCount = rooms.filter((r) => r.status === "occ").length;

  // revenue by level — powers the LODGE scope donut
  const tierRows = await db.lodgeBill.groupBy({
    by: ["tier"],
    where: { createdAt: { gte: start } },
    _sum: { total: true },
  });
  const tierSum = tierRows.reduce((s, t) => s + (t._sum.total ?? 0), 0);
  const tierMix = tierRows
    .map((t) => ({
      tier: t.tier,
      revenue: round2(t._sum.total ?? 0),
      share: tierSum ? Math.round(((t._sum.total ?? 0) / tierSum) * 100) : 0,
    }))
    .sort((a, b) => b.revenue - a.revenue);

  return {
    revenue,
    stays,
    avgStay,
    deltaPct,
    discounts,
    discountRows,
    buckets,
    peakLabel: peakBucket.revenue > 0 ? peakBucket.label : null,
    dayCurve,
    dayPeak,
    inHouse: occCount,
    pctFull: Math.round((occCount / 100) * 100),
    mnt: mntCount,
    tonight,
    stayMix,
    tierMix,
    roomHours,
    recent: recent.map((b) => ({
      number: b.number,
      room: b.room,
      guestName: b.guestName,
      total: b.total,
      createdAt: b.createdAt.toISOString(),
      hours: b.hours,
    })),
  };
}
