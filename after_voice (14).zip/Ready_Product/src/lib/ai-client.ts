import ZAI from "z-ai-web-dev-sdk";

type ChatMsg = { role: "system" | "user" | "assistant"; content: string };

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
// Default engine: OpenAI gpt-oss-120b served by Groq — override with GROQ_MODEL in .env
const GROQ_MODEL = process.env.GROQ_MODEL?.trim() || "openai/gpt-oss-120b";
const IS_GPT_OSS = GROQ_MODEL.includes("gpt-oss");

// Shown as a normal assistant reply when no provider is reachable — the panel
// renders Markdown, so this walks the owner through the one-line fix.
const AI_SETUP_HINT = [
  "**The AI copilot is not configured on this device yet.**",
  "",
  "1. Open the **.env** file in the project folder",
  "2. Find the line `# GROQ_API_KEY=gsk_your_key_here`, remove the `#` and paste your own key:",
  "   `GROQ_API_KEY=gsk_...`  (free key: console.groq.com/keys)",
  "3. Save and restart the server (Ctrl+C, then `npm run dev:w`)",
  "",
  "Only the `GROQ_API_KEY` line needs uncommenting — the engine (gpt-oss-120b) is already the default.",
].join("\n");

/**
 * One AI chat completion for the copilot. Provider order:
 *   1. Groq (OpenAI-compatible endpoint) when GROQ_API_KEY is set in .env
 *   2. Z.ai SDK fallback (sandbox / .z-ai-config auth)
 */
export async function aiChat(
  messages: ChatMsg[],
  opts: { temperature?: number; maxTokens?: number } = {}
): Promise<string> {
  const key = process.env.GROQ_API_KEY?.trim();
  if (key) {
    const res = await fetch(GROQ_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages,
        temperature: opts.temperature ?? 0.3,
        max_tokens: opts.maxTokens ?? (IS_GPT_OSS ? 4096 : 2048),
        // gpt-oss reasons before answering — keep it brief; the reasoning
        // arrives out-of-band and never reaches the chat panel.
        ...(IS_GPT_OSS ? { reasoning_effort: "low" } : {}),
      }),
      signal: AbortSignal.timeout(50_000),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Groq ${res.status}: ${text.slice(0, 300)}`);
    }
    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = data.choices?.[0]?.message?.content;
    if (!content) throw new Error("Groq returned an empty response");
    // Defensive: if a reasoning model ever inlines its thoughts, strip them
    return content
      .replace(/<think>[\s\S]*?<\/think>/g, "")
      .trim();
  }

  // Z.ai fallback (sandbox — needs .z-ai-config). On the owner's machine the
  // Groq key in .env is the intended path, so a missing config becomes the
  // friendly setup hint instead of a raw 500.
  try {
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });
    const reply = completion.choices[0]?.message?.content;
    if (!reply) throw new Error("AI returned an empty response");
    return reply.trim();
  } catch (err) {
    const msg = String((err as Error)?.message ?? err);
    if (msg.includes("Configuration file not found") || msg.includes(".z-ai-config")) {
      return AI_SETUP_HINT;
    }
    throw err;
  }
}
