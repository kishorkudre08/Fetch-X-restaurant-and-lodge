import type { Metadata, Viewport } from "next";
import { Inter, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Fetch-X — Restaurant OS",
  description:
    "Zero-entry business intelligence for restaurants — the cashier bills, the software collects. {dish, quantity, time} flows in automatically. Many hotels, one platform.",
  icons: {
    /* t137 — the tab icon is the pre-login page's CHEF CAP (lucide ChefHat
       geometry: puffy toque + band), white on the Fetch-X blue tile. The cap
       is scaled to 0.82 about the centre so nothing touches the rounded
       outline — sleek, no overflow (the old graduate-hat diamond is gone). */
    icon:
      "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Crect width='24' height='24' rx='6' fill='%235b4fe9'/%3E%3Cg fill='none' stroke='white' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round' transform='translate(12 12) scale(0.82) translate(-12 -12)'%3E%3Cpath d='M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z'/%3E%3Cpath d='M6 17h12'/%3E%3C/g%3E%3C/svg%3E",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  /* t140 — plain 1:1 device viewport. The forced-landscape stage (boot script
     below + the t140 block in globals.css) scales a fixed 1280px desktop
     canvas by itself, so the meta viewport must NOT pre-zoom: t134's
     initialScale 0.5 made the phone layout width device-dependent (never the
     desktop's ratio) and its zoomed visual viewport fought touch scrolling
     (user: "scroll is not working in mobile view"). */
  initialScale: 1,
};

/* t140 — forced-landscape stage boot (inline, runs BEFORE first paint).
   t154 — THE STAGE IS BACK TO ALWAYS-ON MOBILE (owner: "make the mobile
   phone view landscape only, no matter browser runs in portrait or
   landscape, I want the website to be in landscape only"): on touch devices
   whose long side is below the 1280px desktop reference it tags
   <html data-fx-stage="1"> (+ data-fx-portrait) and publishes the stage
   geometry as CSS vars:
     --fx-dw  1280px desktop reference width
     --fx-sw/--fx-sh  the screen's long/short side in CSS px
     --fx-fit  long/1280 — the scale factor globals.css applies to the body
   The SIGNED-IN app and the PRE-LOGIN landing both run the stage now, so
   the whole site presents the desktop replica in landscape on any phone.
   The landing scrolls inside the stage the exact way the dashboard shell
   demonstrably does on this phone: a constrained inner scroller with NO
   position:fixed descendants (t154 block in globals.css + the
   fx-landing-scroll wrapper in landing-view.tsx).
   Desktops and ≥1280px touch devices never get tagged — site untouched.
   ?fxstage=1 forces the stage on (testing on a desktop browser),
   ?fxstage=0 forces it off (escape hatch on a phone).
   window.__fxApplyStage re-runs fit() after in-session auth changes
   (no-op for the geometry now that the stage no longer depends on auth). */
const fxStageBoot = `(function(){
  var DW=1280;
  function fit(){
    try{
      var de=document.documentElement;
      var force=/[?&]fxstage=1/.test(location.search);
      var off=/[?&]fxstage=0/.test(location.search);
      var touch=false;
      try{touch=(navigator.maxTouchPoints>0)||("ontouchstart" in window)||(window.matchMedia&&window.matchMedia("(pointer: coarse)").matches);}catch(e){}
      var w=window.innerWidth||0,h=window.innerHeight||0;
      var lo=Math.max(w,h),sh=Math.min(w,h);
      /* t154 — no auth clause: the stage covers the landing too, so the whole
         site is landscape-only on mobile, signed in or not. */
      var on=!off&&lo>0&&(force||(touch&&lo<DW));
      if(!on){
        delete de.dataset.fxStage;delete de.dataset.fxPortrait;
        de.style.removeProperty("--fx-dw");de.style.removeProperty("--fx-sw");
        de.style.removeProperty("--fx-sh");de.style.removeProperty("--fx-fit");
        return;
      }
      de.dataset.fxStage="1";
      de.dataset.fxPortrait=h>w?"1":"0";
      de.style.setProperty("--fx-dw",DW+"px");
      de.style.setProperty("--fx-sw",lo+"px");
      de.style.setProperty("--fx-sh",sh+"px");
      de.style.setProperty("--fx-fit",String(lo/DW));
    }catch(e){}
  }
  fit();
  window.__fxApplyStage=fit;
  window.addEventListener("resize",fit);
  window.addEventListener("orientationchange",fit);
  if(window.visualViewport)window.visualViewport.addEventListener("resize",fit);
})();`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  /* t76 — apply the signed-in account's saved theme BEFORE first paint
     (same lookup order as readStoredTheme(): account → guest → legacy). */
  const themeBoot = `try{
    var a=null;try{a=JSON.parse(localStorage.getItem("fx-auth")||"null")}catch(e){}
    var who=((a&&(a.email||a.name))||"guest").toString().trim().toLowerCase();
    var t=localStorage.getItem("fx-theme:"+who)||localStorage.getItem("fx-theme:guest")||localStorage.getItem("fx-theme")||"classic";
    if(t&&t!=="classic")document.documentElement.dataset.fxTheme=t;
  }catch(e){}`;
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBoot }} />
        <script dangerouslySetInnerHTML={{ __html: fxStageBoot }} />
      </head>
      <body className={`${inter.variable} ${geistMono.variable} antialiased bg-background text-foreground font-sans`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          {/* t140 — in stage mode (touch devices < 1280px, see fxStageBoot +
              globals.css t140) this wrapper is the plain, UNtransformed
              scroller inside the scaled/rotated body stage — gestures hit a
              normal overflow-y box, which is what fixes "scroll is not
              working in mobile view". Radix portals are body children so they
              scale/rotate with the stage. On desktops it stays a passthrough
              div with zero styling. */}
          <div id="fx-scroll">
            {children}
            <Toaster />
          </div>
        </ThemeProvider>
        {/* t105 — phones ran Fetch-X in LANDSCAPE only: a pure-CSS gate covered
            narrow portrait screens with a rotate prompt. t139 — SUPERSEDED by
            the forced-landscape rotation: the site rotates itself now, so the
            gate stays in the DOM but never displays (display:none above). */}
        <div className="fx-rotate-gate" role="dialog" aria-modal="true" aria-label="Rotate your phone to landscape">
          <div className="fx-rotate-card">
            <div className="fx-rotate-phone" aria-hidden="true" />
            <h2 className="fx-rotate-title">Rotate your phone</h2>
            <p className="fx-rotate-sub">
              Fetch-X runs in landscape on mobile — turn your device sideways to continue.
            </p>
            <span className="fx-rotate-chip">LANDSCAPE MODE</span>
          </div>
        </div>
      </body>
    </html>
  );
}
