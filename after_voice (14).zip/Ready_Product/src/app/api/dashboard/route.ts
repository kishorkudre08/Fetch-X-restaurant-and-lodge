import { NextRequest, NextResponse } from "next/server";
import { getDashboardData, parseRange } from "@/lib/analytics";

export const dynamic = "force-dynamic";

// GET /api/dashboard?range=today|7d|1m|3m|1y
export async function GET(req: NextRequest) {
  const range = parseRange(req.nextUrl.searchParams.get("range"));
  const data = await getDashboardData(range);
  return NextResponse.json(data);
}
