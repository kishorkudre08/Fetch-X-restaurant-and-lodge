// Settle salaries for ALL active employees from 2025-01 to the latest over month.
// Run: bun scripts/seed-salary-pay-all.mjs
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const PAID_HOLIDAY_LIMIT_DEFAULT = 3;
const PAID_HOLIDAY_LIMIT_KEY = "paidHolidayLimit";
const MIN_MONTH = "2025-01";

async function getPaidHolidayLimit() {
  const row = await db.setting.findUnique({ where: { key: PAID_HOLIDAY_LIMIT_KEY } });
  const n = Math.floor(Number(row?.value));
  return Number.isFinite(n) && n >= 0 ? Math.min(n, 31) : PAID_HOLIDAY_LIMIT_DEFAULT;
}
function daysInMonthOf(month) {
  const [y, m] = month.split("-").map(Number);
  return new Date(y, m, 0).getDate();
}
function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

function monthsFromStart() {
  const out = [];
  const now = new Date();
  const [minY, minM] = MIN_MONTH.split("-").map(Number);
  let y = minY, m = minM;
  while (true) {
    out.push(`${y}-${String(m).padStart(2, "0")}`);
    m += 1;
    if (m > 12) { m = 1; y += 1; }
    if (y > now.getFullYear() || (y === now.getFullYear() && m >= now.getMonth() + 1)) break;
  }
  return out;
}

async function main() {
  const employees = await db.employee.findMany({ where: { active: true } });
  console.log(`active employees: ${employees.length}`);
  const wiped = await db.salaryPayment.deleteMany({});
  console.log(`wiped ${wiped.count} stale settlements`);
  const limit = await getPaidHolidayLimit();
  console.log(`paid holiday limit: ${limit} days/month`);
  const months = monthsFromStart();
  console.log(`months to settle (from ${MIN_MONTH} → latest over): ${months.length} months`);
  console.log(`first: ${months[0]} · last: ${months[months.length - 1]}`);
  let created = 0;
  let totalNet = 0;
  for (const month of months) {
    const days = daysInMonthOf(month);
    const from = `${month}-01`;
    const to = `${month}-${String(days).padStart(2, "0")}`;
    for (const e of employees) {
      const [present, absent] = await Promise.all([
        db.attendance.count({ where: { employeeId: e.id, date: { gte: from, lte: to }, status: "present" } }),
        db.attendance.count({ where: { employeeId: e.id, date: { gte: from, lte: to }, status: "absent" } }),
      ]);
      const paidHolidays = Math.max(0, Math.min(limit, absent));
      const cutDays = Math.max(0, absent - paidHolidays);
      const deduction = round2(cutDays * (e.salary / days));
      const netPaid = round2(e.salary - deduction);
      totalNet += netPaid;
      const [y, m] = month.split("-").map(Number);
      const nextMonth = new Date(Date.UTC(y, m, 1, 5, 0, 0));
      await db.salaryPayment.create({
        data: { employeeId: e.id, month, base: e.salary, presentDays: present,
          absentDays: absent, paidHolidays, deduction, netPaid, status: "paid",
          paidAt: nextMonth, paidBy: "OWNER" },
      });
      created++;
    }
  }
  console.log(`created ${created} fresh settlements · total paid ₹${totalNet.toLocaleString("en-IN")}`);
  await db.$disconnect();
}
main().catch((e) => { console.error(e); process.exit(1); });
