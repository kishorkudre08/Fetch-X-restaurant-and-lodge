/* t102 — fill the LAST FEW DAYS with real activity: the year-seeds stopped
 * on 2026-09-22, so TODAY / 7D windows showed ₹0. This tops the history up:
 *   · restaurant bills (real dish snapshots) — meal-hour shaped, incl. today
 *   · lodge checkouts (tier rate × hours ÷ 24, ₹1,000 floor, 5% GST)
 *   · a sprinkle of station expenses (raw / upgrade / maintenance, both books)
 *   · one done + one open owner task
 * Run: node scripts/seed-recent-days.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const IST = 330 * 60000;
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.round(rnd(a, b));
const r2 = (n) => Math.round(n * 100) / 100;

const GUESTS = [
  "Ramesh Kulkarni", "Priya Deshpande", "Arjun Mehta", "Sneha Patil", "Vikram Joshi",
  "Anita Desai", "Rahul Verma", "Kavita Rao", "Suresh Babu", "Meena Nair",
  "Prakash Gowda", "Shobha Kamath", "Mohan Pai", "Lata Hegde", "Girish Prabhu",
];

/* IST hour → order weight (breakfast, lunch, evening peaks) */
const HOUR_W = [
  2, 1, 0.5, 0.5, 0.5, 1, 3, 8, 10, 8, 8, 14, 16, 12, 8, 8, 10, 12, 14, 15, 12, 8, 5, 3,
];

const DEFAULT_LEVELS = [
  { from: 1, to: 40, rate: 2499, name: "BASIC" },
  { from: 41, to: 80, rate: 2999, name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, name: "LUXURY" },
];

function stayHours() {
  const tot = [[rnd(6, 12), 20], [rnd(20, 30), 32], [rnd(44, 54), 26], [rnd(68, 100), 22]];
  const w = tot.reduce((s, [, x]) => s + x, 0);
  let r = Math.random() * w;
  for (const [v, x] of tot) { r -= x; if (r <= 0) return v; }
  return tot[tot.length - 1][0];
}

async function main() {
  console.log("── seed-recent-days start ──");
  const now = Date.now();
  const istDayStart = new Date(new Date(now + IST).setUTCHours(0, 0, 0, 0)).getTime() - IST;
  const DAYS = 7;

  const dishes = await db.dish.findMany({ where: { active: true }, select: { id: true, name: true, price: true, category: true } });
  if (dishes.length < 5) throw new Error("menu too small to seed from");
  const lvlRow = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  let levels = DEFAULT_LEVELS;
  try {
    const parsed = JSON.parse(lvlRow?.value ?? "null");
    if (Array.isArray(parsed) && parsed.length) levels = parsed;
  } catch { /* defaults */ }

  const lastBill = await db.bill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let billNo = (lastBill?.number ?? 1000) + 1;
  const lastLodge = await db.lodgeBill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let lodgeNo = (lastLodge?.number ?? 5000) + 1;

  /* ── 1 · restaurant bills, day by day ── */
  let billCount = 0, itemCount = 0;
  for (let d = DAYS; d >= 0; d--) {
    const dayStart = istDayStart - d * DAY;
    const dayEnd = d === 0 ? now : dayStart + DAY;
    const dow = new Date(dayStart).getUTCDay();
    const weekend = dow === 5 || dow === 6 || dow === 0 ? 1.18 : 1;
    const target = Math.max(14, Math.round(30 * weekend + rnd(-5, 5)));
    // hour buckets for this day (IST hours), capped at "now"
    const buckets = [];
    for (let h = 0; h < 24; h++) {
      const slot = dayStart + h * 3_600_000;
      if (slot >= dayEnd) break;
      buckets.push({ slot, w: HOUR_W[h] * (d === 0 ? Math.max(0.25, (dayEnd - slot) / 3_600_000) : 1) });
    }
    const wTot = buckets.reduce((s, b) => s + b.w, 0);
    for (let k = 0; k < target; k++) {
      let r = Math.random() * wTot, at = buckets[buckets.length - 1].slot;
      for (const b of buckets) { r -= b.w; if (r <= 0) { at = b.slot; break; } }
      at = Math.min(at + Math.random() * 3_600_000, dayEnd - 60_000);

      const lines = irnd(1, 4);
      const picks = [];
      for (let i = 0; i < lines; i++) {
        const dish = dishes[irnd(0, dishes.length - 1)];
        const qty = Math.random() < 0.72 ? 1 : 2;
        picks.push({ dish, qty });
      }
      const subtotal = r2(picks.reduce((s, p) => s + p.dish.price * p.qty, 0));
      const discount = Math.random() < 0.12 ? r2(subtotal * 0.05) : 0;
      const tax = r2((subtotal - discount) * 0.05);
      const total = r2(subtotal - discount + tax);
      const units = picks.reduce((s, p) => s + p.qty, 0);
      const created = new Date(at);
      const bill = await db.bill.create({
        data: {
          number: billNo++, subtotal, discount, tax, total, itemCount: units, createdAt: created,
          items: {
            create: picks.map((p) => ({
              dishId: p.dish.id, name: p.dish.name, category: p.dish.category, qty: p.qty, price: p.dish.price,
            })),
          },
        },
      });
      void bill; billCount++; itemCount += units;
    }
  }
  console.log("restaurant bills:", billCount, `(${itemCount} items)`);

  /* ── 2 · lodge checkouts ── */
  const rows = [];
  for (let d = DAYS; d >= 0; d--) {
    const dayStart = istDayStart - d * DAY;
    const dayEnd = d === 0 ? now : dayStart + DAY;
    const dow = new Date(dayStart).getUTCDay();
    const weekend = dow === 5 || dow === 6 || dow === 0 ? 1.18 : 1;
    const count = Math.max(20, Math.round(40 * weekend + rnd(-4, 4)));
    for (let k = 0; k < count; k++) {
      const room = 1 + Math.floor(Math.random() * 100);
      const lv = levels.find((l) => room >= l.from && room <= l.to) ?? levels[0];
      const hours = stayHours();
      const checkOut = new Date(dayStart + Math.random() * (dayEnd - dayStart));
      const checkIn = new Date(checkOut.getTime() - hours * 3_600_000);
      if (checkIn.getTime() > now) continue;
      const raw = Math.round((lv.rate * hours) / 24);
      const min = raw < 1000;
      const stay = min ? 1000 : raw;
      const tax = Math.round(stay * 5) / 100;
      rows.push({
        number: lodgeNo++, room,
        guestName: GUESTS[irnd(0, GUESTS.length - 1)],
        guestPhone: "97" + irnd(10000000, 99999999),
        tier: lv.name, rate: lv.rate, checkInAt: checkIn, checkOutAt: checkOut,
        hours: r2(hours), stay, minApplied: min, discount: 0, tax, total: r2(stay + tax),
        createdAt: checkOut,
      });
    }
  }
  for (let i = 0; i < rows.length; i += 500) await db.lodgeBill.createMany({ data: rows.slice(i, i + 500) });
  console.log("lodge bills:", rows.length);

  /* ── 3 · station expenses ── */
  const EXP = [
    ["raw_material", "rest", "Vegetables + dairy top-up"],
    ["raw_material", "rest", "Spices and oil refill"],
    ["maintenance", "lodge", "Plumber — leaking tap, room wing 2"],
    ["upgrade", "rest", "New counter LED sign"],
    ["raw_material", "lodge", "Toiletries + linen restock"],
    ["maintenance", "rest", "Chimney deep-clean service"],
  ];
  let expCount = 0;
  for (let d = DAYS - 1; d >= 0; d--) {
    if (Math.random() < 0.25) continue;
    const e = EXP[irnd(0, EXP.length - 1)];
    await db.expense.create({
      data: {
        kind: e[0], book: e[1], label: e[2],
        amount: r2(rnd(800, 6000)),
        spentOn: new Date(istDayStart - d * DAY + 6 * 3_600_000),
      },
    });
    expCount++;
  }
  console.log("expenses:", expCount);

  /* ── 4 · one done + one open owner task ── */
  await db.task.create({
    data: {
      title: "Repaint the reception notice board",
      book: "lodge", kind: "upgrade", maxBudget: 2500,
      description: "Fresh coat on the notice board beside the front desk — guest rates board.",
      deadline: new Date(now + 2 * DAY), status: "done",
      createdBy: "Owner", createdAt: new Date(now - 2 * DAY),
      doneAt: new Date(now - DAY), doneBy: "Lodge reception",
      actualCost: 1800,
      updates: {
        create: [
          { author: "Lodge reception", role: "reception_lodge", message: "Board sanded and primed.", createdAt: new Date(now - 1.5 * DAY) },
          { author: "Lodge reception", role: "reception_lodge", message: "Second coat drying — done tomorrow morning.", createdAt: new Date(now - 0.8 * DAY) },
        ],
      },
    },
  });
  await db.task.create({
    data: {
      title: "Print this week's specials cards",
      book: "rest", maxBudget: null,
      description: "Table cards for the 3 new starters — need 40 prints.",
      deadline: new Date(now + DAY), status: "open",
      createdBy: "Owner", createdAt: new Date(now - 0.4 * DAY),
    },
  });
  console.log("tasks: 2 (1 done · 1 open)");
  console.log("── seed-recent-days done ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
