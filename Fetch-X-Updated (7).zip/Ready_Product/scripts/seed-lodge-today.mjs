/* t124 fixture top-up — the t118 suite reads the LODGE cost book in the TODAY
 * window; seed-lodge-live spreads its expenses over ~120 days and skips when
 * the 7-day window already has entries, so TODAY itself can end up empty.
 * This drops a few lodge expenses dated TODAY (idempotent: skips when the
 * lodge book already has entries spent today). */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const today = (() => {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  return d;
})();

const guard = new Date();
guard.setHours(0, 0, 0, 0);
/* the t118 suite itself adds maintenance entries via the UI each run — only
   the RAW MATERIAL / UPGRADE heads are ever the gap, so guard on those */
const existing = await db.expense.count({ where: { book: "lodge", kind: { in: ["raw_material", "upgrade"] }, spentOn: { gte: guard } } });
if (existing > 0) {
  console.log("lodge expenses already exist for today — skipping");
} else {
  await db.expense.createMany({
    data: [
      { kind: "raw_material", book: "lodge", label: "Fresh linens & toiletries restock", amount: 4820, spentOn: today },
      { kind: "raw_material", book: "lodge", label: "Breakfast kitchen supplies", amount: 3140, spentOn: today },
      { kind: "maintenance", book: "lodge", label: "Room 104 geyser repair", amount: 2200, spentOn: today },
      { kind: "upgrade", book: "lodge", label: "Lobby LED signboard fitting", amount: 6500, spentOn: today },
    ],
  });
  console.log("seeded 4 lodge expenses for TODAY (raw ×2, maintenance, upgrade)");
}
await db.$disconnect();
