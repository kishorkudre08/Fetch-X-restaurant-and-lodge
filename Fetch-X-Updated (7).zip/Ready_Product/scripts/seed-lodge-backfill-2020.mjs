// t194 — Generate lodge stays for 2020-2024 to fix the revenue split.
// Currently restaurant is 57.6% and lodge is 42.4% — the owner wants
// lodge ~60-70% and restaurant ~30-40%. This script backfills lodge
// stays across 2020-2024 so lodge revenue reaches ~₹2.3 crore (65%).
//
// Run: bun scripts/seed-lodge-backfill-2020.mjs
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const IST_OFFSET_MS = 330 * 60_000;
const round2 = (n) => Math.round(n * 100) / 100;

let _seed = 42;
const rand = () => { _seed = (_seed * 9301 + 49297) % 233280; return _seed / 233280; };
const randInt = (min, max) => min + Math.floor(rand() * (max - min + 1));

const TIERS = [
  { name: "BASIC", min: 1, max: 40, rate: 2499 },
  { name: "STANDARD", min: 41, max: 80, rate: 2999 },
  { name: "LUXURY", min: 81, max: 100, rate: 3999 },
];

const GUEST_NAMES = [
  "R. Patel", "S. Gupta", "M. Khan", "A. Reddy", "K. Nair", "P. Sharma",
  "V. Iyer", "D. Joshi", "N. Mehta", "L. Verma", "T. Singh", "C. Bose",
  "B. Kumar", "G. Menon", "J. Pillai", "F. Ansari", "H. Gowda", "R. Desai",
];

async function main() {
  // Get the current lodge bill number (to continue numbering)
  const lastBill = await db.lodgeBill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let billNumber = (lastBill?.number ?? 5000) + 1;

  // Date range: 2020-01-01 → 2025-09-30 (the historical backfill period)
  const startDate = new Date("2020-01-01T00:00:00Z");
  const endDate = new Date("2025-09-30T23:59:59Z");
  const daysBack = Math.ceil((endDate.getTime() - startDate.getTime()) / 86_400_000);
  console.log(`backfilling lodge stays for ${daysBack} days (2020-01-01 → 2025-09-30)`);
  console.log(`starting bill number: ${billNumber}`);

  let created = 0;
  let totalRevenue = 0;

  for (let i = 0; i < daysBack; i++) {
    const day = new Date(startDate.getTime() + i * 86_400_000);
    const dow = day.getDay();

    // Generate 1-2 stays per day (calibrated to hit the 65/35 split target).
    // Restaurant is ₹1.22 crore (35%) → lodge target = ₹2.27 crore (65%).
    // Existing lodge: ₹89 lakh. Need ~₹1.38 crore more.
    // At ~₹7,800/stay avg (2-3 nights × ₹2,999) → ~1,770 stays needed.
    // 2,100 days × ~0.84 stays/day = ~1,770 stays.
    const stayCount = (dow === 5 || dow === 6) ? 1 : (rand() < 0.5 ? 1 : 0);

    for (let s = 0; s < stayCount; s++) {
      const tier = TIERS[randInt(0, 2)];
      const roomNumber = randInt(tier.min, tier.max);
      const nights = randInt(2, 4); // longer stays for higher revenue
      const rate = tier.rate;

      // Calculate stay charge (with ₹1,000 floor)
      const rawStay = rate * nights;
      const stay = Math.max(1000, rawStay); // ₹1,000 minimum
      const minApplied = rawStay < 1000;

      // Small discount sometimes (~15% of stays)
      const discount = rand() < 0.15 ? Math.round(stay * 0.05) : 0;
      const taxable = stay - discount;
      const tax = round2(taxable * 0.05);
      const total = round2(taxable + tax);

      // Check-in: random hour during the day
      const checkInHour = randInt(10, 20);
      const checkIn = new Date(day.getTime() + IST_OFFSET_MS);
      checkIn.setUTCHours(checkInHour, randInt(0, 59), 0, 0);
      const checkOut = new Date(checkIn.getTime() + nights * 86_400_000);

      const guestName = GUEST_NAMES[randInt(0, GUEST_NAMES.length - 1)];
      const guestPhone = `+91 ${randInt(70, 99)}${randInt(100, 999)}${randInt(10000, 99999)}`;
      const hours = nights * 24;

      await db.lodgeBill.create({
        data: {
          number: billNumber++,
          room: roomNumber,
          guestName,
          guestPhone,
          tier: tier.name,
          rate,
          checkInAt: new Date(checkIn.getTime() - IST_OFFSET_MS),
          checkOutAt: new Date(checkOut.getTime() - IST_OFFSET_MS),
          hours,
          stay,
          minApplied,
          discount,
          tax,
          total,
          createdAt: new Date(checkOut.getTime() - IST_OFFSET_MS),
        },
      });
      created++;
      totalRevenue += total;
    }
  }

  console.log(`\n=== DONE ===`);
  console.log(`lodge stays created: ${created}`);
  console.log(`revenue generated: ₹${totalRevenue.toLocaleString("en-IN")}`);

  // Verify the new split
  const bills = await db.bill.aggregate({ _sum: { total: true }, _count: true });
  const stays = await db.lodgeBill.aggregate({ _sum: { total: true }, _count: true });
  const restRev = bills._sum.total || 0;
  const lodgeRev = stays._sum.total || 0;
  const total = restRev + lodgeRev;
  console.log(`\n=== REVENUE SPLIT ===`);
  console.log(`restaurant: ${bills._count} bills · ₹${restRev.toLocaleString("en-IN")} · ${(restRev/total*100).toFixed(1)}%`);
  console.log(`lodge:      ${stays._count} stays · ₹${lodgeRev.toLocaleString("en-IN")} · ${(lodgeRev/total*100).toFixed(1)}%`);
  console.log(`total: ₹${total.toLocaleString("en-IN")}`);

  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
