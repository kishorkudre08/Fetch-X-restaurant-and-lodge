// Seeds the 100 lodge rooms (1–100) as available. Idempotent — running it
// never touches rooms that already have a state (occupied / maintenance).
// Usage: bun scripts/seed-rooms.ts
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  await db.$transaction(
    Array.from({ length: 100 }, (_, i) =>
      db.room.upsert({
        where: { number: i + 1 },
        update: {}, // keep any live state (occupied / maintenance)
        create: { number: i + 1 },
      }),
    ),
  );
  const count = await db.room.count();
  const occ = await db.room.count({ where: { status: "occ" } });
  const mnt = await db.room.count({ where: { status: "mnt" } });
  console.log(`Lodge ready: ${count} rooms · ${occ} occupied · ${mnt} under maintenance · ${count - occ - mnt} free`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
