/* t168 — SEED DISCOUNT HISTORY + TODAY'S ATTENDANCE
 *
 * 1. Goes through existing bills from the last 365 days and adds
 *    random 5-10% discounts to ~20% of them (so the dashboard's
 *    discount analytics have data to show across the year).
 *    Recalculates tax + total to keep the books honest.
 *
 * 2. Creates today's attendance marks for every employee (most present,
 *    1-2 absent — the realistic daily mix).
 *
 * Usage: DATABASE_URL=file:...db node scripts/seed-discounts-attendance.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const r2 = (n) => Math.round(n * 100) / 100;
const irnd = (a, b) => Math.round(a + Math.random() * (b - a));

async function main() {
  console.log("── seed-discounts-attendance start ──");

  /* ── 1 · DISCOUNT HISTORY ─────────────────────────────────────────── */
  const since = new Date(Date.now() - 365 * 86_400_000);
  const bills = await db.bill.findMany({
    where: { createdAt: { gte: since }, discount: 0 },
    select: { id: true, subtotal: true, tax: true, total: true, createdAt: true },
  });
  console.log(`bills without discount (last 365d): ${bills.length}`);

  // Pick ~20% of them to receive a discount
  const toUpdate = bills.filter(() => Math.random() < 0.20);
  let discountCount = 0;
  let totalDiscountGiven = 0;

  for (const b of toUpdate) {
    // Random 5% or 10% discount
    const pct = Math.random() < 0.7 ? 0.05 : 0.10;
    const discount = r2(b.subtotal * pct);
    const newSubtotalAfterDiscount = b.subtotal - discount;
    const newTax = r2(newSubtotalAfterDiscount * 0.05);
    const newTotal = r2(newSubtotalAfterDiscount + newTax);
    await db.bill.update({
      where: { id: b.id },
      data: { discount, tax: newTax, total: newTotal },
    });
    discountCount++;
    totalDiscountGiven += discount;
  }
  console.log(`bills updated with discount: ${discountCount}`);
  console.log(`total discount given: ₹${r2(totalDiscountGiven).toLocaleString("en-IN")}`);

  /* ── 2 · TODAY'S ATTENDANCE ────────────────────────────────────────── */
  const today = new Date().toLocaleDateString("sv-SE", { timeZone: "Asia/Kolkata" });
  const employees = await db.employee.findMany({ select: { id: true, name: true, role: true, book: true } });
  console.log(`employees: ${employees.length}`);

  // Check if today's attendance already exists
  const existingToday = await db.attendance.count({
    where: { date: today },
  });
  if (existingToday > 0) {
    console.log(`today's attendance already exists (${existingToday} marks) — skipping`);
  } else {
    let present = 0, absent = 0;
    for (const emp of employees) {
      // ~90% present, ~10% absent (realistic daily mix)
      const status = Math.random() < 0.9 ? "present" : "absent";
      await db.attendance.create({
        data: { employeeId: emp.id, date: today, status },
      });
      if (status === "present") present++;
      else absent++;
    }
    console.log(`attendance marks created: ${present} present · ${absent} absent`);
  }

  console.log("── seed-discounts-attendance done ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
