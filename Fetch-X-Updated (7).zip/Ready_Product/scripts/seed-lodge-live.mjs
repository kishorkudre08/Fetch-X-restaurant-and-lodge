/* t118 — bring the LODGE back to life (user: "also add some lodge data, idk
 * why it looks fully empty"). The t116 fixture reset had left the whole
 * 100-room wall FREE and the lodge cost book thin, so the front desk and the
 * dashboard's lodge band read like a ghost building. This tops the live db up:
 *   · ~58 rooms checked in NOW (guest name + phone + entry time within the
 *     last ~54h, tier-aware rates) + 4 rooms under maintenance
 *   · lodge expenses (raw materials / upgrades / maintenance) spread over the
 *     last ~120 days so the LODGE revenue breakdown + REVENUE SPLIT donut,
 *     the cost-split cards and the ledger all carry real weight
 * Guards make it idempotent: rooms already occ/mnt are never touched, and the
 * expense seeding skips when the recent window already has entries.
 * Run: node scripts/seed-lodge-live.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const HOUR = 3_600_000;
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.round(rnd(a, b));
const r2 = (n) => Math.round(n * 100) / 100;
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const GUESTS = [
  "Ramesh Kulkarni", "Priya Deshpande", "Arjun Mehta", "Sneha Patil", "Vikram Joshi",
  "Anita Desai", "Rahul Verma", "Kavita Rao", "Suresh Babu", "Meena Nair",
  "Prakash Gowda", "Shobha Kamath", "Mohan Pai", "Lata Hegde", "Girish Prabhu",
  "Deepak Shenoy", "Rohit Chandra", "Nalini Iyer", "Farhan Qureshi", "Geeta Shetty",
  "Harish Bhat", "Lakshmi Menon", "Naveen Kumar", "Rekha Pillai", "Sameer Shaikh",
  "Vasanth Rao", "Divya Prasad", "Manoj Gupta", "Sarita Yadav", "Kiran Naik",
];

const tierRate = (n) => (n <= 40 ? 2499 : n <= 80 ? 2999 : 3999);

/* label pool — [kind, label, min₹, max₹] */
const EXPENSE_POOL = [
  ["raw_material", "Toiletries & amenity restock · all floors", 1200, 9500],
  ["raw_material", "Linen & towel restock · housekeeping", 2400, 14000],
  ["raw_material", "Housekeeping supplies · corridors & lobby", 800, 6200],
  ["raw_material", "Guest tea/coffee replenishment kits", 900, 5400],
  ["raw_material", "Laundry detergent & cleaning agents", 1100, 7800],
  ["raw_material", "Bottled water stock · front desk", 700, 4800],
  ["upgrade", "Smart TV upgrade · BASIC wing", 18000, 74000],
  ["upgrade", "Door-lock upgrade · LUXURY floor", 14000, 58000],
  ["upgrade", "Room signage & numbering refresh", 4200, 21000],
  ["upgrade", "Geyser replacement batch · rooms 61–65", 16000, 46000],
  ["upgrade", "LED lighting retrofit · stairwells", 8000, 32000],
  ["upgrade", "Lobby seating refurbish", 12000, 52000],
  ["maintenance", "Plumbing repair · third floor", 1500, 12500],
  ["maintenance", "AC servicing · seasonal round", 2600, 18500],
  ["maintenance", "Pest control · whole building", 3400, 15500],
  ["maintenance", "Carpet deep-clean · STANDARD rooms", 2800, 16800],
  ["maintenance", "Water purifier service · pantries", 900, 5600],
  ["maintenance", "Electrical fix · corridor flicker", 1200, 9200],
  ["maintenance", "Paint touch-up · wear & tear", 2200, 14200],
  ["maintenance", "Drain descaling · bathrooms", 1600, 10400],
];

const day = (ms) => new Date(ms);

async function main() {
  /* ── 1 · OCCUPANCY — only if the wall is (near) empty ──────────────────── */
  const rooms = await db.room.findMany({ orderBy: { number: "asc" } });
  const occ = rooms.filter((r) => r.status === "occ").length;
  const mnt = rooms.filter((r) => r.status === "mnt").length;

  if (occ >= 20) {
    console.log(`occupancy: ${occ} rooms already in-house — skipping the check-in seed`);
  } else {
    const free = rooms.filter((r) => r.status === "avl");
    const takeOcc = Math.min(free.length, 58 - occ);
    const takeMnt = Math.max(0, Math.min(free.length - takeOcc, 4 - mnt));
    const shuffled = [...free].sort(() => Math.random() - 0.5);
    const occSet = shuffled.slice(0, takeOcc);
    const mntSet = shuffled.slice(takeOcc, takeOcc + takeMnt);

    for (const r of occSet) {
      await db.room.update({
        where: { number: r.number },
        data: {
          status: "occ",
          guestName: pick(GUESTS),
          guestPhone: `9${irnd(100000000, 999999999)}`,
          checkInAt: day(Date.now() - irnd(2, 54) * HOUR - irnd(0, 59) * 60000),
        },
      });
    }
    for (const r of mntSet) {
      await db.room.update({
        where: { number: r.number },
        data: { status: "mnt", guestName: null, guestPhone: null, checkInAt: null },
      });
    }
    console.log(`occupancy: checked ${takeOcc} guests in + put ${takeMnt} rooms under maintenance`);
  }

  /* ── 2 · LODGE EXPENSES — only if the recent window is thin ────────────── */
  const recent = await db.expense.count({
    where: { book: "lodge", spentOn: { gte: day(Date.now() - 7 * DAY) } },
  });
  if (recent >= 12) {
    console.log(`lodge expenses: ${recent} entries in the last 7 days — skipping the expense seed`);
  } else {
    const since = Date.now() - 120 * DAY;
    let added = 0;
    /* walk the window day by day: 0–2 entries a day, weighted toward the now */
    for (let d = 120; d >= 0; d--) {
      const n = d < 7 ? irnd(2, 3) : Math.random() < 0.65 ? irnd(0, 2) : 0;
      for (let i = 0; i < n; i++) {
        const [kind, label, min, max] = pick(EXPENSE_POOL);
        const amount = r2(rnd(min, max));
        const spentOn = day(Date.now() - d * DAY - irnd(0, 23) * HOUR - irnd(0, 59) * 60000);
        if (spentOn.getTime() > Date.now()) continue;
        await db.expense.create({
          data: { kind, book: "lodge", label, amount, spentOn },
        });
        added++;
      }
    }
    console.log(`lodge expenses: seeded ${added} entries across the last 120 days`);
  }

  const [occNow, mntNow, lodgeExp7d] = await Promise.all([
    db.room.count({ where: { status: "occ" } }),
    db.room.count({ where: { status: "mnt" } }),
    db.expense.count({ where: { book: "lodge", spentOn: { gte: day(Date.now() - 7 * DAY) } } }),
  ]);
  console.log(`wall now: ${occNow} in-house · ${mntNow} maintenance · ${100 - occNow - mntNow} free`);
  console.log(`lodge expenses last 7d: ${lodgeExp7d}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
