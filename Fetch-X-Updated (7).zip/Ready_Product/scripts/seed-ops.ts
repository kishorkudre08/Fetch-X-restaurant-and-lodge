// seed-ops.ts — Seeds the operational side of Jaya's Kitchen:
//   · Categories (the 6 default dish sections)
//   · Employees (5 staff with monthly salaries)
//   · Historical expenses sized off REAL bill history:
//       - raw materials: one weekly purchase ≈ 30% of that week's revenue
//       - maintenance: one entry per month (repairs, gas, upkeep)
//
// Idempotent: skips anything already present.
// Run: bun scripts/seed-ops.ts

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const IST_OFFSET_MS = 330 * 60_000;
const round2 = (n: number) => Math.round(n * 100) / 100;

// Deterministic PRNG
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(19092026);

const CATEGORIES = ["Starters", "Main Course", "Breads", "Rice & Biryani", "Desserts", "Beverages"];

const EMPLOYEES: Array<[name: string, role: string, salary: number]> = [
  ["Suresh Nair", "Head Chef", 28000],
  ["Lakshmi Iyer", "South Indian Station", 20000],
  ["Ravi Kumar", "Cashier · Counter 01", 18000],
  ["Kumar Swamy", "Server", 14000],
  ["Devi shetty", "Kitchen Helper & Cleaning", 9000],
];

const MAINTENANCE_LABELS = [
  "Repairs & upkeep",
  "Gas cylinder refill",
  "Pest control service",
  "Chimney & exhaust cleaning",
  "Electrical & plumbing fixes",
  "Machinery service",
];

async function main() {
  // ── Categories ──────────────────────────────────────────────────────────
  for (const name of CATEGORIES) {
    await db.category.upsert({ where: { name }, update: {}, create: { name } });
  }
  console.log(`Categories: ${await db.category.count()} ensured.`);

  // ── Employees ───────────────────────────────────────────────────────────
  if ((await db.employee.count()) === 0) {
    await db.employee.createMany({
      data: EMPLOYEES.map(([name, role, salary]) => ({ name, role, salary })),
    });
  }
  const emps = await db.employee.findMany({ where: { active: true } });
  const monthlySalary = emps.reduce((s, e) => s + e.salary, 0);
  console.log(
    `Employees: ${emps.length} active, ₹${monthlySalary.toLocaleString("en-IN")}/month total.`,
  );

  // ── Expenses (raw materials weekly ≈ 30% of that week's real revenue) ──
  if ((await db.expense.count()) === 0) {
    const bills = await db.bill.findMany({
      select: { total: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    });

    // bucket bills into IST weeks (Sunday-start, same as dashboard)
    const weekRev = new Map<number, number>();
    for (const b of bills) {
      const shifted = new Date(b.createdAt.getTime() + IST_OFFSET_MS);
      const day = Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate());
      const weekStart = day - shifted.getUTCDay() * 86_400_000;
      weekRev.set(weekStart, (weekRev.get(weekStart) ?? 0) + b.total);
    }

    const expenseRows: Array<{
      kind: string;
      label: string;
      amount: number;
      spentOn: Date;
    }> = [];

    for (const [weekStart, revenue] of [...weekRev.entries()].sort((a, b) => a[0] - b[0])) {
      if (revenue <= 0) continue;
      // purchase on a random weekday mid-week; food cost 26–34% of revenue
      const ratio = 0.26 + rand() * 0.08;
      const dayOffset = 2 + Math.floor(rand() * 4); // Tue–Fri
      const spentOn = new Date(weekStart + dayOffset * 86_400_000 + 10 * 3_600_000 - IST_OFFSET_MS);
      if (spentOn.getTime() > Date.now()) continue; // don't book purchases in the future
      expenseRows.push({
        kind: "raw_material",
        label: rand() < 0.5 ? "Vegetables, dairy & groceries" : "Weekly market purchase",
        amount: round2(revenue * ratio),
        spentOn,
      });
    }

    // maintenance: monthly, ₹1,200–₹6,000
    const months = new Set<string>();
    for (const b of bills) {
      months.add(new Date(b.createdAt.getTime() + IST_OFFSET_MS).toISOString().slice(0, 7));
    }
    for (const mk of [...months].sort()) {
      const [y, m] = mk.split("-").map(Number);
      const spentOn = new Date(Date.UTC(y, m - 1, 5 + Math.floor(rand() * 20), 12) - IST_OFFSET_MS);
      if (spentOn.getTime() > Date.now()) continue;
      expenseRows.push({
        kind: "maintenance",
        label: MAINTENANCE_LABELS[Math.floor(rand() * MAINTENANCE_LABELS.length)],
        amount: round2(1200 + rand() * 4800),
        spentOn,
      });
    }

    for (let i = 0; i < expenseRows.length; i += 300) {
      await db.expense.createMany({ data: expenseRows.slice(i, i + 300) });
    }

    const raw = expenseRows.filter((e) => e.kind === "raw_material");
    const maint = expenseRows.filter((e) => e.kind === "maintenance");
    console.log(
      `Expenses: ${raw.length} raw-material entries (₹${round2(raw.reduce((s, e) => s + e.amount, 0)).toLocaleString("en-IN")}) + ` +
        `${maint.length} maintenance entries (₹${round2(maint.reduce((s, e) => s + e.amount, 0)).toLocaleString("en-IN")}).`,
    );
  } else {
    console.log(`Expenses: already present (${await db.expense.count()}), skipped.`);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
