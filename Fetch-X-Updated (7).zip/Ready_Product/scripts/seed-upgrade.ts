/**
 * Seed upgrade — brings the DB to the approved demo state (Tasks 26–37):
 *  - Two-book team: 5 restaurant + 6 lodge employees (₹89,000 + ₹94,000 / MO)
 *  - Lodge-book expenses (supplies + maintenance) spread over 12 months
 *  - Live lodge wall: 55 in-house guests, 3 rooms under maintenance
 *  - A year of lodge stay history (LodgeBill 5001+, hourly billing, ₹1,000 floor, 5% GST)
 *  - Editable lodge level config (default 3 tiers) in Setting.lodgeLevels
 * Run: bunx tsx scripts/seed-upgrade.ts   (or bun run scripts/seed-upgrade.ts)
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const LEVELS = [
  { from: 1, to: 40, rate: 2499, name: "BASIC" },
  { from: 41, to: 80, rate: 2999, name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, name: "LUXURY" },
];

const REST_EMPLOYEES = [
  { name: "Suresh Nair", role: "Head Chef", salary: 28000 },
  { name: "Lakshmi Iyer", role: "South Indian Station", salary: 20000 },
  { name: "Ravi Kumar", role: "Cashier · Counter 01", salary: 18000 },
  { name: "Kumar Swamy", role: "Server", salary: 14000 },
  { name: "Devi Shetty", role: "Kitchen Helper & Cleaning", salary: 9000 },
];
const LODGE_EMPLOYEES = [
  { name: "Anil Fernandes", role: "Lodge Manager · Front Desk", salary: 26000 },
  { name: "Rekha Nambiar", role: "Receptionist · Day", salary: 16000 },
  { name: "Imran Khan", role: "Receptionist · Night", salary: 15000 },
  { name: "Sarala Devi", role: "Housekeeping Supervisor", salary: 14000 },
  { name: "Pushpa Mestri", role: "Housekeeping", salary: 11000 },
  { name: "Vittal Poojary", role: "Security · Night Watch", salary: 12000 },
];

const GUEST_NAMES = [
  "Ramesh Kulkarni", "Priya Deshpande", "Arjun Mehta", "Sneha Patil", "Vikram Joshi",
  "Anita Desai", "Rahul Verma", "Kavita Rao", "Suresh Babu", "Meena Nair",
  "Prakash Gowda", "Shobha Kamath", "Mohan Pai", "Lata Hegde", "Girish Prabhu",
  "Vidya Shetty", "Nagesh Rao", "Sudha Murthy", "Harish Pai", "Roopa Iyer",
  "Ganesh Bhat", "Usha Kamat", "Dinesh Shenoy", "Rekha Balan", "Satish Poojari",
  "Nirmala Nayak", "Ravi Shastri", "Geetha Kulkarni", "Amit Chavan", "Sunita Jadhav",
  "Rajesh Kumbhar", "Manisha Gaikwad", "Sagar Patil", "Asha Bhosale", "Vivek Sawant",
  "Pooja Salvi", "Nitin Rane", "Sadhana Kale", "Prasad Dalvi", "Vaishali More",
];

function istNow(): Date {
  return new Date();
}

function tierOf(n: number): { name: string; rate: number } {
  if (n <= 40) return { name: "BASIC", rate: 2499 };
  if (n <= 80) return { name: "STANDARD", rate: 2999 };
  return { name: "LUXURY", rate: 3999 };
}

async function main() {
  console.log("── seed upgrade start ──");

  /* 1. Team — exact demo roster, split across the two books */
  await db.employee.deleteMany({});
  for (const e of REST_EMPLOYEES) await db.employee.create({ data: { ...e, book: "rest" } });
  for (const e of LODGE_EMPLOYEES) await db.employee.create({ data: { ...e, book: "lodge" } });
  console.log("employees: 5 rest + 6 lodge");

  /* 2. Lodge-book expenses — supplies + maintenance across 12 months */
  const existingLodge = await db.expense.count({ where: { book: "lodge" } });
  if (existingLodge === 0) {
    const rows: Array<{ kind: string; book: string; label: string; amount: number; spentOn: Date }> = [];
    const now = istNow();
    for (let mo = 0; mo < 12; mo++) {
      const base = new Date(now.getTime() - mo * 30 * 86400000);
      // monthly lodge supplies (toiletries, linen wash, cleaning)
      rows.push({ kind: "raw_material", book: "lodge", label: "Toiletries & amenities", amount: 900 + Math.round(Math.random() * 500), spentOn: new Date(base.getTime() - Math.random() * 20 * 86400000) });
      rows.push({ kind: "raw_material", book: "lodge", label: "Linen & laundry", amount: 600 + Math.round(Math.random() * 400), spentOn: new Date(base.getTime() - Math.random() * 25 * 86400000) });
      // occasional lodge maintenance
      if (mo % 2 === 0) rows.push({ kind: "maintenance", book: "lodge", label: "Plumbing / electrical fixes", amount: 300 + Math.round(Math.random() * 700), spentOn: new Date(base.getTime() - Math.random() * 28 * 86400000) });
      if (mo % 5 === 0) rows.push({ kind: "maintenance", book: "lodge", label: "Pest control · floors 1-4", amount: 800 + Math.round(Math.random() * 600), spentOn: new Date(base.getTime() - Math.random() * 28 * 86400000) });
    }
    await db.expense.createMany({ data: rows });
    console.log("lodge expenses created:", rows.length);
  }

  /* 3. Lodge wall — 55 in-house, 3 under maintenance, rest free */
  await db.room.updateMany({ data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null } });
  const roomNums = Array.from({ length: 100 }, (_, i) => i + 1);
  // shuffle
  for (let i = roomNums.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [roomNums[i], roomNums[j]] = [roomNums[j], roomNums[i]];
  }
  const now = istNow();
  const istDayStartMs = new Date(new Date(now.getTime() + 330 * 60000).setUTCHours(0, 0, 0, 0)).getTime() - 330 * 60000;
  const occ = roomNums.slice(0, 55);
  const mnt = roomNums.slice(55, 58);
  for (let i = 0; i < occ.length; i++) {
    const n = occ[i];
    const hoursIn = 2 + Math.random() * 30; // arrived between 30 h ago and 2 h ago
    await db.room.update({
      where: { number: n },
      data: {
        status: "occ",
        guestName: GUEST_NAMES[i % GUEST_NAMES.length],
        guestPhone: "98" + String(40000000 + Math.floor(Math.random() * 9999999)),
        checkInAt: new Date(now.getTime() - hoursIn * 3600000),
      },
    });
  }
  for (const n of mnt) {
    await db.room.update({ where: { number: n }, data: { status: "mnt", guestName: null, guestPhone: null, checkInAt: null } });
  }
  console.log("rooms: 55 occ · 3 mnt · 42 avl");

  /* 4. Lodge stay history — a year of checkouts (L-5001 +) */
  const have = await db.lodgeBill.count();
  {
    await db.lodgeBill.deleteMany({});
    let num = 5001;
    const yearAgo = new Date(now.getTime() - 365 * 86400000);
    const rows: Array<{
      number: number; room: number; guestName: string; guestPhone: string; tier: string; rate: number;
      checkInAt: Date; checkOutAt: Date; hours: number; stay: number; minApplied: boolean;
      discount: number; tax: number; total: number; createdAt: Date;
    }> = [];
    // ~18 checkouts/day keeps the wall believable: 100 rooms, hourly billing
    for (let day = 365; day >= 0; day--) {
      const dayStart = new Date(now.getTime() - day * 86400000);
      const count = 14 + Math.floor(Math.random() * 10); // 14–23 per day
      for (let k = 0; k < count; k++) {
        const room = 1 + Math.floor(Math.random() * 100);
        const t = tierOf(room);
        const hours = Math.max(3, Math.min(40, 3 + Math.exp(Math.random() * 2.2) * 1.6)); // short stays dominate
        let checkIn: Date;
        if (day === 0) {
          // today — spread check-ins across the hours already lived, so the
          // TODAY range shows a living business instead of an empty morning
          checkIn = new Date(istDayStartMs + Math.random() * Math.max(1, now.getTime() - istDayStartMs - 2 * 3600000));
        } else {
          checkIn = new Date(dayStart.getTime() - Math.random() * 86400000);
        }
        const checkOut = new Date(checkIn.getTime() + hours * 3600000);
        if (checkOut > now) continue;
        const raw = Math.round((t.rate * hours) / 24);
        const min = raw < 1000;
        const stay = min ? 1000 : raw;
        const tax = Math.round(stay * 5) / 100;
        const total = Math.round((stay + tax) * 100) / 100;
        rows.push({
          number: num++, room, guestName: GUEST_NAMES[Math.floor(Math.random() * GUEST_NAMES.length)],
          guestPhone: "97" + String(10000000 + Math.floor(Math.random() * 8999999)),
          tier: t.name, rate: t.rate, checkInAt: checkIn, checkOutAt: checkOut,
          hours: Math.round(hours * 100) / 100, stay, minApplied: min,
          discount: 0, tax, total, createdAt: checkOut,
        });
      }
    }
    // chunked createMany
    for (let i = 0; i < rows.length; i += 500) {
      await db.lodgeBill.createMany({ data: rows.slice(i, i + 500) });
    }
    console.log("lodge bills created:", rows.length);
  }

  /* 4b. Restaurant — a living TODAY (bills 7 AM → now, 5% GST) */
  const todayCount = await db.bill.count({
    where: { createdAt: { gte: new Date(istDayStartMs) } },
  });
  if (todayCount < 25) {
    const dishes = await db.dish.findMany({ where: { active: true } });
    const last = await db.bill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
    let bn = (last?.number ?? 1000) + 1;
    const made: Array<{
      number: number; subtotal: number; discount: number; tax: number; total: number;
      itemCount: number; createdAt: Date;
      items: Array<{ name: string; category: string; qty: number; price: number; dishId: string }>;
    }> = [];
    const target = 30 + Math.floor(Math.random() * 10);
    for (let k = 0; k < target; k++) {
      const createdAt = new Date(istDayStartMs + 7 * 3600000 + Math.random() * Math.max(1, now.getTime() - istDayStartMs - 7.5 * 3600000));
      if (createdAt > now) continue;
      const lines = 1 + Math.floor(Math.random() * 3);
      const items: Array<{ name: string; category: string; qty: number; price: number; dishId: string }> = [];
      for (let li = 0; li < lines; li++) {
        const dsh = dishes[Math.floor(Math.random() * dishes.length)];
        const qty = 1 + Math.floor(Math.random() * 2);
        items.push({ name: dsh.name, category: dsh.category, qty, price: dsh.price, dishId: dsh.id });
      }
      const subtotal = items.reduce((s2, it) => s2 + it.qty * it.price, 0);
      const tax = Math.round(subtotal * 5) / 100;
      made.push({
        number: bn++, subtotal, discount: 0, tax, total: Math.round((subtotal + tax) * 100) / 100,
        itemCount: items.reduce((s2, it) => s2 + it.qty, 0), createdAt, items,
      });
    }
    for (const b of made) {
      await db.bill.create({
        data: {
          number: b.number, subtotal: b.subtotal, discount: 0, tax: b.tax, total: b.total,
          itemCount: b.itemCount, createdAt: b.createdAt,
          items: { create: b.items.map((it) => ({ name: it.name, category: it.category, qty: it.qty, price: it.price, dishId: it.dishId })) },
        },
      });
    }
    console.log("restaurant bills today created:", made.length);
  } else {
    console.log("restaurant bills today already:", todayCount);
  }

  /* 5. Settings — lodge level config */
  await db.setting.upsert({
    where: { key: "lodgeLevels" },
    create: { key: "lodgeLevels", value: JSON.stringify(LEVELS) },
    update: { value: JSON.stringify(LEVELS) },
  });
  const hn = await db.setting.findUnique({ where: { key: "hotelName" } });
  if (!hn || !hn.value) {
    await db.setting.upsert({
      where: { key: "hotelName" },
      create: { key: "hotelName", value: "Imperial Spice" },
      update: { value: "Imperial Spice" },
    });
  }
  console.log("settings: lodgeLevels + hotelName ready");
  console.log("── seed upgrade done ──");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
