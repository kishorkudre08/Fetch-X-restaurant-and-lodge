// t121 — add a few tasks timestamped TODAY so the board's TODAY window is alive
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const mk = async (title, book, kind, maxBudget, status, cost, updates) => {
  const t = await db.task.create({
    data: {
      title, book, kind, maxBudget,
      description: maxBudget ? `Owner-ordered ${kind.replace("_", " ")} job budgeted at ₹${maxBudget}.` : "Owner-ordered free job — nothing may be spent.",
      deadline: new Date(Date.now() + 2 * 86400000),
      createdBy: "OWNER",
      status,
      doneAt: status === "done" ? new Date() : null,
      doneBy: status === "done" ? "Ravi Kumar (REST desk)" : null,
      actualCost: status === "done" ? cost : null,
      updates: { create: updates },
    },
  });
  if (status === "done" && cost > 0 && kind) {
    await db.expense.create({
      data: {
        kind, book,
        label: `TASK · ${title}`.slice(0, 120),
        amount: cost, spentOn: new Date(), via: "task", taskId: t.id,
      },
    });
  }
  return t;
};

const today = (h, m) => new Date(new Date().setHours(h, m, 0, 0));

const t1 = await mk("Fix the leaking sink at the pantry counter", "rest", "maintenance", 1500, "done", 1120, [
  { author: "OWNER", role: "owner", message: "Task forwarded with a max budget of ₹1,500 · maintenance spend.", createdAt: today(9, 10) },
  { author: "Kumar Swamy", role: "reception", message: "Plumber came at noon, replaced the trap pipe.", createdAt: today(13, 40) },
  { author: "Kumar Swamy", role: "reception", message: "Marked DONE — ₹1,120 spent of the ₹1,500 budget. The spend is booked in the RESTAURANT ledger with the owner's crown.", createdAt: today(15, 5) },
]);
const t2 = await mk("Repaint the faded menu board frame", "rest", null, null, "done", 0, [
  { author: "OWNER", role: "owner", message: "Task forwarded as a FREE task — no budget attached.", createdAt: today(9, 25) },
  { author: "Ravi Kumar", role: "reception", message: "House paint from the store room was enough — marked DONE, nothing spent.", createdAt: today(16, 30) },
]);
const t3 = await mk("Replace the corridor tube-lights floor 1", "lodge", "maintenance", 900, "open", null, [
  { author: "OWNER", role: "owner", message: "Task forwarded with a max budget of ₹900 · maintenance spend.", createdAt: today(10, 0) },
  { author: "Rekha Nambiar", role: "reception", message: "Electrician scheduled for tomorrow morning.", createdAt: today(11, 20) },
]);
console.log("created:", [t1.id, t2.id, t3.id]);
await db.$disconnect();
