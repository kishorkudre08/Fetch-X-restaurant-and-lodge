// Generate attendance marks for current employees from 2025-01-01 to today.
// Run: bun scripts/seed-attendance-fresh.mjs
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const IST_OFFSET_MIN = 330;
const nowIst = new Date(Date.now() + IST_OFFSET_MIN * 60000);
const localISO = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

async function main() {
  const employees = await db.employee.findMany({ where: { active: true } });
  console.log(`active employees: ${employees.length}`);
  const wiped = await db.attendance.deleteMany({});
  console.log(`wiped ${wiped.count} stale marks`);
  const MIN_DATE = "2025-01-01";
  const minDate = new Date(MIN_DATE + "T00:00:00");
  const days = Math.ceil((nowIst.getTime() - minDate.getTime()) / 86_400_000);
  const created = [];
  const hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) | 0; } return Math.abs(h) % 100; };
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(nowIst.getTime() - i * 86_400_000);
    const iso = localISO(d);
    if (d.getDay() === 0) continue; // Sunday — off
    for (const e of employees) {
      const seed = hash(e.id + ":" + iso);
      const status = seed < 85 ? "present" : "absent";
      created.push({ employeeId: e.id, date: iso, status });
    }
  }
  console.log(`covering ${days} days from ${MIN_DATE} to today (${created.length} marks to create)`);
  let inserted = 0;
  for (let i = 0; i < created.length; i += 500) {
    const chunk = created.slice(i, i + 500);
    await db.attendance.createMany({ data: chunk });
    inserted += chunk.length;
  }
  console.log(`created ${inserted} fresh marks`);
  for (const e of employees) {
    const marks = await db.attendance.findMany({ where: { employeeId: e.id }, select: { status: true } });
    const present = marks.filter((m) => m.status === "present").length;
    const absent = marks.filter((m) => m.status === "absent").length;
    const rate = present + absent > 0 ? Math.round((present / (present + absent)) * 100) : 0;
    console.log(`  ${e.name.padEnd(25, " ")} · ${present}P / ${absent}A · ${rate}%`);
  }
  await db.$disconnect();
}
main().catch((e) => { console.error(e); process.exit(1); });
