import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(projectDir);

const nextBin = path.join(projectDir, "node_modules", "next", "dist", "bin", "next");
const port = process.env.PORT || "3000";
const logPath = path.join(projectDir, "dev.log");

const out = fs.openSync(logPath, "a");
const err = fs.openSync(logPath, "a");

function start() {
  const child = spawn(process.execPath, [nextBin, "dev", "-p", port], {
    cwd: projectDir,
    stdio: ["ignore", out, err],
    detached: true,
    env: { ...process.env, FX_PROJECT_DIR: projectDir, NODE_ENV: "development" },
  });
  child.unref();
  child.on("exit", (code, signal) => {
    fs.writeFileSync(logPath, `\n[relaunch] child exited code=${code} signal=${signal} — respawning in 3s\n`, { flag: "a" });
    setTimeout(start, 3000);
  });
}

start();
console.log("Detached launcher started, dev.log:", logPath);
