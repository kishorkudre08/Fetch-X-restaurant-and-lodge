/* t171 — SEED LATE-COMPLETED + NOT-COMPLETED TASKS so the donut has visible
 * slices in all 4 categories (completed, late completed, not completed,
 * late & open). Currently late-completed and not-completed are ~0.
 *
 * Creates tasks in BOTH books (rest + lodge):
 *   · LATE COMPLETED: status="done" with doneAt > deadline + 1 day
 *   · NOT COMPLETED: status="open" with deadline in the FUTURE (not overdue)
 *
 * Usage: DATABASE_URL=file:...db node scripts/seed-task-variety.mjs
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const DAY = 86_400_000;
const r2 = (n) => Math.round(n * 100) / 100;

const LATE_COMPLETED_TITLES = [
  { title: "Replace kitchen exhaust fan motor", book: "rest", kind: "maintenance", maxBudget: 4500, desc: "Old motor was seizing — replaced with a new 1HP unit." },
  { title: "Deep-clean the dining hall carpets", book: "rest", kind: "maintenance", maxBudget: 2000, desc: "Quarterly carpet shampoo — the high-traffic area near the entrance." },
  { title: "Install new LED menu board", book: "rest", kind: "upgrade", maxBudget: 3500, desc: "Wall-mounted digital menu board replacing the old printed one." },
  { title: "Service the lodge water heater (wing 2)", book: "lodge", kind: "maintenance", maxBudget: 6000, desc: "Scale buildup was reducing efficiency — flushed and descaled." },
  { title: "Repaint room 45 (water damage on ceiling)", book: "lodge", kind: "upgrade", maxBudget: 3000, desc: "Bathroom leak from upstairs left a stain — patched and painted." },
  { title: "Restock lodge toiletries — bulk order", book: "lodge", kind: "raw_material", maxBudget: 5000, desc: "Shampoo, soap, towels — 3-month supply for 100 rooms." },
];

const NOT_COMPLETED_TITLES = [
  { title: "Train new cashier on the POS system", book: "rest", kind: null, maxBudget: null, desc: "Walk the new hire through billing, discounts, and end-of-day reconciliation." },
  { title: "Update the restaurant's GST registration", book: "rest", kind: null, maxBudget: null, desc: "New GSTIN after the address amendment — needs to be updated in all bill templates." },
  { title: "Plan the Diwali special menu", book: "rest", kind: null, maxBudget: null, desc: "Festive thali + dessert — need costing and pricing by next week." },
  { title: "Install grab bars in lodge bathrooms (wing 1)", book: "lodge", kind: "upgrade", maxBudget: 8000, desc: "Safety upgrade for senior guests — 20 rooms in wing 1." },
  { title: "Replace worn corridor carpet (wing 3)", book: "lodge", kind: "upgrade", maxBudget: 15000, desc: "High-traffic area near rooms 61-80 — fraying at the edges." },
  { title: "Renew the lodge's fire safety certificate", book: "lodge", kind: "maintenance", maxBudget: 2500, desc: "Annual inspection due — schedule the fire officer visit." },
  { title: "Set up online booking integration", book: "lodge", kind: "upgrade", maxBudget: 12000, desc: "Connect the lodge to MakeMyTrip / Booking.com for direct online reservations." },
];

async function main() {
  console.log("── seed-task-variety start ──");
  const now = Date.now();

  // Get the last task number for sequencing
  const lastTask = await db.task.findFirst({ orderBy: { createdAt: "desc" }, select: { createdAt: true } });
  // We don't need a number for tasks (they use cuid IDs), but we need the dates

  let lateCount = 0, notCompletedCount = 0;

  /* ── LATE COMPLETED TASKS ──────────────────────────────────────────── */
  for (const t of LATE_COMPLETED_TITLES) {
    // Deadline was 10-20 days ago; task was completed 5-15 days ago (after deadline)
    const deadlineDaysAgo = 10 + Math.floor(Math.random() * 10);
    const completedDaysAgo = Math.max(1, deadlineDaysAgo - 5 + Math.floor(Math.random() * 5));
    // Ensure completed is AFTER deadline
    const completedAfter = Math.max(1, deadlineDaysAgo - completedDaysAgo + 1);

    const deadline = new Date(now - deadlineDaysAgo * DAY);
    const createdAt = new Date(now - (deadlineDaysAgo + 2) * DAY);
    const doneAt = new Date(now - completedAfter * DAY);

    const cost = t.maxBudget ? r2(t.maxBudget * (0.6 + Math.random() * 0.3)) : 0;
    const kind = t.kind ?? "raw_material";

    await db.task.create({
      data: {
        title: t.title,
        book: t.book,
        kind: t.kind,
        maxBudget: t.maxBudget,
        description: t.desc,
        deadline,
        status: "done",
        createdBy: "Owner",
        createdAt,
        doneAt,
        doneBy: t.book === "lodge" ? "Lodge reception" : "Restaurant counter",
        actualCost: cost,
        updates: {
          create: [
            { author: "Owner", role: "owner", message: "Forwarded with a deadline — close with the actual spend.", createdAt },
            { author: t.book === "lodge" ? "Lodge reception" : "Restaurant counter", role: t.book === "lodge" ? "reception_lodge" : "reception_rest", message: "Started working on it.", createdAt: new Date(createdAt.getTime() + DAY) },
            { author: t.book === "lodge" ? "Lodge reception" : "Restaurant counter", role: t.book === "lodge" ? "reception_lodge" : "reception_rest", message: `Marked DONE — ₹${cost.toLocaleString("en-IN")} spent (completed past deadline).`, createdAt: doneAt },
          ],
        },
      },
    });
    // If cost > 0 and kind, create an expense
    if (cost > 0) {
      await db.expense.create({
        data: {
          kind,
          book: t.book,
          label: `TASK · ${t.title}`.slice(0, 120),
          amount: cost,
          spentOn: doneAt,
          via: "task",
        },
      });
    }
    lateCount++;
  }
  console.log(`late-completed tasks created: ${lateCount}`);

  /* ── NOT COMPLETED (OPEN, ON TIME) TASKS ───────────────────────────── */
  for (const t of NOT_COMPLETED_TITLES) {
    // Deadline is 3-14 days in the FUTURE (not overdue, still open)
    const deadlineDaysAhead = 3 + Math.floor(Math.random() * 12);
    const createdAt = new Date(now - Math.floor(Math.random() * 3) * DAY - DAY);

    await db.task.create({
      data: {
        title: t.title,
        book: t.book,
        kind: t.kind,
        maxBudget: t.maxBudget,
        description: t.desc,
        deadline: new Date(now + deadlineDaysAhead * DAY),
        status: "open",
        createdBy: "Owner",
        createdAt,
        updates: {
          create: [
            { author: "Owner", role: "owner", message: "Forwarded — work on this before the deadline.", createdAt },
          ],
        },
      },
    });
    notCompletedCount++;
  }
  console.log(`not-completed (open, on time) tasks created: ${notCompletedCount}`);

  console.log("── seed-task-variety done ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
