/**
 * Validation harness for the Fetch-X AI Data Snapshot exporter.
 * Tests: structure, JSON validity, cross-checks vs direct DB aggregates,
 * relationship integrity, date-range mode, anonymization mode, error handling.
 */
const fs = require("fs");
const path = require("path");

process.env.DATABASE_URL = "file:" + path.join(__dirname, "..", "db", "custom.db");
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient({ datasourceUrl: "file:" + path.join(__dirname, "..", "db", "custom.db") });

const r2 = (n) => Math.round(n * 100) / 100;
let failures = 0;
const ok = (cond, label, extra = "") => {
  if (cond) console.log(`  ✓ ${label}${extra ? " — " + extra : ""}`);
  else {
    console.log(`  ✗ FAIL: ${label}${extra ? " — " + extra : ""}`);
    failures++;
  }
};
const close = (a, b, tol = 0.5) => Math.abs(a - b) <= tol;

async function main() {
  const raw = fs.readFileSync("/tmp/export_full.json", "utf8");
  const X = JSON.parse(raw); // throws if invalid JSON

  console.log("── 1 · ROOT STRUCTURE ──");
  const expectedRoot = ["fetchx_export", "business", "dashboard_summary", "sales", "receipts", "menu", "expenses", "tasks", "employees", "attendance", "salary", "rooms", "bookings", "raw_materials", "budgets", "restaurant", "lodge", "analytics", "relationships", "data_dictionary"];
  ok(expectedRoot.every((k) => k in X), "all 20 root sections present", expectedRoot.filter((k) => !(k in X)).join(",") || "complete");

  console.log("── 2 · METADATA ──");
  const M = X.fetchx_export;
  ok(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+05:30$/.test(M.exported_at), "exported_at ISO with IST offset", M.exported_at);
  ok(M.timezone === "Asia/Kolkata", "timezone IST");
  ok(M.export_mode === "full", "mode = full");
  ok(M.anonymized === false, "anonymized off");
  ok(M.data_period.from === "2020-01-01", "data period starts at first record", M.data_period.from + " → " + M.data_period.to);
  ok(M.record_counts.receipts === X.receipts.length, "record_counts.receipts matches array");

  console.log("── 3 · CROSS-CHECK vs DATABASE (the no-fake-data proof) ──");
  const agg = await db.bill.aggregate({ _count: true, _sum: { total: true, discount: true, tax: true, subtotal: true, itemCount: true } });
  ok(X.receipts.length === agg._count, `receipt count = DB bills (${agg._count})`);
  const jsonRevenue = r2(X.receipts.reduce((s, b) => s + b.total, 0));
  ok(close(jsonRevenue, r2(agg._sum.total)), `revenue sum matches DB (₹${jsonRevenue.toLocaleString("en-IN")})`);
  ok(close(X.sales.restaurant.total_revenue, r2(agg._sum.total)), "sales.restaurant.total_revenue matches");
  ok(close(X.sales.restaurant.discounts, r2(agg._sum.discount)), "discounts match");
  ok(close(X.sales.restaurant.tax, r2(agg._sum.tax)), "tax matches");
  ok(X.sales.restaurant.items_sold === agg._sum.itemCount, "items sold match", String(agg._sum.itemCount));

  const lAgg = await db.lodgeBill.aggregate({ _count: true, _sum: { total: true } });
  ok(X.bookings.records.length === lAgg._count, `lodge bookings = DB (${lAgg._count})`);
  ok(close(X.sales.lodge.total_revenue, r2(lAgg._sum.total)), "lodge revenue matches");

  const expAgg = await db.expense.aggregate({ _count: true, _sum: { amount: true } });
  ok(X.expenses.records.length === expAgg._count, `expenses = DB (${expAgg._count})`);
  ok(close(X.expenses.summary.total, r2(expAgg._sum.amount)), "expense total matches");

  const [attC, spC, taskC, empC, dishC, roomC] = await Promise.all([
    db.attendance.count(), db.salaryPayment.count(), db.task.count(), db.employee.count(), db.dish.count(), db.room.count(),
  ]);
  ok(X.attendance.records.length === attC, `attendance records = DB (${attC})`);
  ok(X.salary.payments.length === spC, `salary payments = DB (${spC})`);
  ok(X.tasks.records.length === taskC, `tasks = DB (${taskC})`);
  ok(X.employees.records.length === empC, `employees = DB (${empC})`);
  ok(X.menu.dishes.length === dishC, `menu dishes = DB (${dishC})`);
  ok(X.rooms.current_rooms.length === roomC, `rooms = DB (${roomC})`);

  console.log("── 4 · PER-RECEIPT MATH (subtotal ± discount + tax = total) ──");
  let badMath = 0, withDiscount = 0, itemsLinked = 0;
  for (const b of X.receipts) {
    if (b.discount > 0) withDiscount++;
    const calc = r2(b.subtotal - b.discount + b.tax);
    if (close(calc, b.total, 0.02) === false) badMath++;
    itemsLinked += b.items.length;
  }
  ok(badMath === 0, `bill arithmetic holds on all ${X.receipts.length} receipts`);
  ok(itemsLinked === (await db.billItem.count()), `all bill items exported (${itemsLinked})`);
  console.log(`    · ${withDiscount} receipts carry discounts`);

  console.log("── 5 · RELATIONSHIP INTEGRITY ──");
  const empIds = new Set(X.employees.records.map((e) => e.employee_id));
  const orphanAtt = X.attendance.records.filter((a) => !empIds.has(a.employee_id)).length;
  const orphanSal = X.salary.payments.filter((p) => !empIds.has(p.employee_id)).length;
  ok(orphanAtt === 0 && orphanSal === 0, "attendance + salary join 100% to employees");
  const roomNums = new Set(X.rooms.current_rooms.map((r) => r.room_number));
  const orphanBook = X.bookings.records.filter((b) => !roomNums.has(b.room_number)).length;
  ok(orphanBook === 0, "every booking joins to a room");
  const dishIds = new Set(X.menu.dishes.map((d) => d.dish_id));
  const billDishRefs = X.receipts.flatMap((r) => r.items).filter((i) => i.dish_id);
  const orphanDish = billDishRefs.filter((i) => !dishIds.has(i.dish_id)).length;
  ok(orphanDish === 0, `every dish_id in receipts joins to menu (${billDishRefs.length} refs)`);
  const taskIds = new Set(X.tasks.records.map((t) => t.task_id));
  const orphanExp = X.expenses.records.filter((e) => e.task_id && !taskIds.has(e.task_id)).length;
  ok(orphanExp === 0, "expense→task links resolve");

  console.log("── 6 · ROOMS LIVE SNAPSHOT ──");
  const dbStatus = { avl: 0, occ: 0, mnt: 0 };
  (await db.room.findMany({ select: { status: true } })).forEach((r) => dbStatus[r.status]++);
  ok(X.rooms.status_at_export.available === dbStatus.avl && X.rooms.status_at_export.occupied === dbStatus.occ && X.rooms.status_at_export.maintenance === dbStatus.mnt,
    `status_at_export mirrors Room table (avl ${dbStatus.avl} · occ ${dbStatus.occ} · mnt ${dbStatus.mnt})`);
  ok(X.rooms.total_rooms === 100, "100-room wall");
  ok(X.rooms.wall.levels.length >= 1 && X.rooms.wall.levels[0].rate_per_24h > 0, "level config exported", X.rooms.wall.levels.map((l) => l.name + " ₹" + l.rate_per_24h).join(", "));

  console.log("── 7 · ANALYTICS (verified, scope-tagged) ──");
  const VA = X.analytics;
  ok(VA.period && VA.period.from && VA.period.to && /combined/.test(VA.period.scope), "analytics.period present with combined scope", `${VA.period.from} → ${VA.period.to}`);
  ok(VA.restaurant.period.scope === "restaurant" && VA.lodge.period.scope === "lodge" && VA.combined.period.scope === "combined", "restaurant/lodge/combined blocks each declare their scope");
  ok(close(VA.restaurant.revenue, r2(agg._sum.total), 1), "analytics.restaurant.revenue matches raw receipts", "₹" + VA.restaurant.revenue.toLocaleString("en-IN"));
  ok(VA.combined.revenue === r2(VA.restaurant.revenue + VA.lodge.revenue) || close(VA.combined.revenue, VA.restaurant.revenue + VA.lodge.revenue, 0.5), "combined.revenue = restaurant + lodge (like-for-like sum)");
  // profit re-derivation from analytics' own components (settled-salary basis)
  for (const book of ["restaurant", "lodge"]) {
    const p = VA[book].profit;
    const expect = r2(p.revenue - p.discounts - p.raw_materials - p.upgrades - p.maintenance - p.salaries_settled);
    ok(close(p.profit, expect, 0.5), `analytics.${book}.profit = revenue − discounts − expenses − salaries (re-derivable)`, `₹${p.profit.toLocaleString("en-IN")}`);
    ok(p.scope === book, `analytics.${book}.profit carries scope label`);
    ok(p.margin_pct === null || close(p.margin_pct, r2((p.profit / p.revenue) * 100), 0.05), `analytics.${book}.margin_pct = profit ÷ revenue`);
  }
  ok(close(VA.combined.profit, r2(VA.restaurant.profit.profit + VA.lodge.profit.profit), 0.5), "combined.profit = restaurant + lodge profit");
  ok(close(VA.costs.expenses.combined.total, X.expenses.summary.total, 0.5), "costs.expenses.combined = expenses.summary.total");
  ok(close(VA.costs.expenses.restaurant.total + VA.costs.expenses.lodge.total, VA.costs.expenses.combined.total, 0.5), "per-book expenses sum to combined");
  ok(VA.costs.salaries.settled_in_period.value_kind === "settled_actual" && close(VA.costs.salaries.settled_in_period.combined, r2(X.salary.payments.reduce((s, p) => s + p.net_paid, 0)), 0.5), "settled salaries = Σ salary payments");
  ok(VA.attendance.marked_days === X.attendance.records.length, "analytics.attendance ties to attendance records", `${VA.attendance.marked_days} marked days`);
  ok(VA.task_completion.combined.total === X.tasks.records.length, "analytics.task_completion ties to task records");
  ok(VA.costs.budget_utilization && close(VA.costs.budget_utilization.allocated, X.budgets.totals.allocated, 0.5), "budget_utilization ties to budgets section");
  ok(VA.all_time.value_kind === "all_time_total" && VA.all_time.restaurant.bills >= X.receipts.length, "all_time labelled and ≥ window");
  ok(VA.lodge.occupancy.live.value_kind === "live_state_snapshot", "occupancy.live labelled as live snapshot");
  ok(VA.lodge.occupancy.historical === null || VA.lodge.occupancy.historical.occupancy_pct !== null, "historical occupancy present or explicitly null + note");

  console.log("── 7b · ANALYTICS INTEGRITY (self-audit) ──");
  const I = VA.analytics_integrity;
  ok(I && typeof I.checks_performed === "number" && I.checks_performed >= 40, `integrity ran ${I.checks_performed} checks`);
  ok(I.status === "passed", `integrity status = ${I.status}`);
  ok(I.checks_failed === 0, "zero failed checks");
  ok(Array.isArray(I.warnings), `integrity warnings documented (${I.warnings.length} labelled definitions)`);
  ok(/recomputed|re-verified|recomputed from the raw records/.test(I.method), "integrity method describes raw-record reconciliation");
  ok(Array.isArray(I.failed_check_names) && I.failed_check_names.length === 0, "no failed check names");

  console.log("── 7c · DASHBOARD MIRROR (labelled, moved charts) ──");
  ok(X.dashboard_summary.stats.scope === "restaurant", "dashboard stats labelled restaurant-only");
  ok(/restaurant bills ONLY/.test(X.dashboard_summary.all_time.scope), "dashboard all_time labelled restaurant-only (was ambiguous before)");
  ok(/MIXED/.test(X.dashboard_summary.costs.scope), "dashboard NET PROFIT card labelled MIXED scope (restaurant revenue − all-house costs)");
  ok(Array.isArray(X.dashboard_summary.charts.restaurant_revenue_buckets) && X.dashboard_summary.charts.restaurant_revenue_buckets.length > 0, "revenue buckets present (moved to dashboard_summary.charts)", `${X.dashboard_summary.charts.restaurant_revenue_buckets.length} buckets`);
  ok(X.dashboard_summary.charts.restaurant_hourly_rhythm.series.length === 17, "hourly rhythm series present (7AM–11PM)");
  ok(X.dashboard_summary.charts.lodge.room_hours.total > 0, "room-hours wall data present");
  ok(X.dashboard_summary.costs.salaries > 0, "salary accrual cost present", "₹" + X.dashboard_summary.costs.salaries.toLocaleString("en-IN"));
  ok(X.sales.items_definitions && typeof X.sales.restaurant.line_items === "number" && typeof X.sales.restaurant.units_sold === "number", "three items counters exported + definition map");

  console.log("── 8 · SECURITY — no secrets ──");
  ok(!raw.includes("gsk_") && !raw.includes("GROQ_API_KEY"), "no Groq API key in export");
  ok(!raw.includes("DATABASE_URL"), "no DB credentials in export");

  console.log("── 9 · DATE-RANGE MODE ──");
  const res = await fetch("http://localhost:3000/api/export?from=2026-09-01&to=2026-09-30");
  ok(res.status === 200, "range export HTTP 200");
  const R = await res.json();
  const sepAgg = await db.bill.aggregate({ where: { createdAt: { gte: new Date("2026-08-31T18:30:00.000Z"), lt: new Date("2026-09-30T18:30:00.000Z") } }, _count: true, _sum: { total: true } });
  ok(R.receipts.length === sepAgg._count, `Sept receipts = DB (${sepAgg._count})`, `got ${R.receipts.length}`);
  ok(close(R.receipts.reduce((s, b) => s + b.total, 0), r2(sepAgg._sum.total ?? 0)), "Sept revenue matches DB");
  ok(R.fetchx_export.export_mode === "date_range", "mode = date_range");
  ok(R.rooms.current_rooms.length === 100, "current-state tables ride along whole");
  const sepAtt = await db.attendance.count({ where: { date: { gte: "2026-09-01", lte: "2026-09-30" } } });
  ok(R.attendance.records.length === sepAtt, `Sept attendance = DB (${sepAtt})`);

  console.log("── 10 · ANONYMIZATION MODE ──");
  const resA = await fetch("http://localhost:3000/api/export?from=2026-09-01&to=2026-09-30&anonymize=1");
  const A = await resA.json();
  const realBook = R.bookings.records[0];
  const anonBook = A.bookings.records.find((b) => b.booking_id === realBook.booking_id);
  ok(anonBook.guest_name !== realBook.guest_name || realBook.guest_name === null, "guest names pseudonymized", `${realBook.guest_name} → ${anonBook.guest_name}`);
  ok(anonBook.guest_phone === null, "phones dropped");
  ok(A.employees.records.every((e) => /^Person-[0-9a-f]{6}$/.test(e.name)), "employee names pseudonymized");
  const pseudoSet = new Set(A.employees.records.map((e) => e.name));
  ok(pseudoSet.size === A.employees.records.length, "pseudonyms stable & unique per person");
  ok(A.bookings.records.every((b) => b.guest_phone === null), "all booking phones dropped");
  // stability: same original → same pseudonym across bookings
  const byName = new Map();
  let stable = true;
  for (const b of R.bookings.records) if (b.guest_name) byName.set(b.guest_name, null);
  for (const b of A.bookings.records) {
    const orig = R.bookings.records.find((x) => x.booking_id === b.booking_id)?.guest_name;
    if (orig && byName.get(orig) && byName.get(orig) !== b.guest_name) stable = false;
    if (orig) byName.set(orig, b.guest_name);
  }
  ok(stable, "same guest always maps to the same pseudonym");

  console.log("── 11 · ERROR HANDLING ──");
  const bad1 = await fetch("http://localhost:3000/api/export?from=2026-09-01");
  ok(bad1.status === 400, "missing 'to' → 400");
  const bad2 = await fetch("http://localhost:3000/api/export?from=2026-12-01&to=2026-01-01");
  ok(bad2.status === 400, "from > to → 400");
  const bad3 = await fetch("http://localhost:3000/api/export?from=garbage&to=2026-01-01");
  ok(bad3.status === 400, "malformed date → 400");

  console.log("── 12 · HONESTY (no invented fields) ──");
  ok(X.sales.payment_methods === null, "payment_methods explicitly null + noted");
  ok(X.sales.refunds_cancellations === null, "refunds explicitly null + noted");
  ok(X.menu.dishes.every((d) => d.cost_price === null), "cost_price null (not stored in app)");
  ok(X.business.unique_business_id === null, "business id null (not stored in app)");

  console.log(failures === 0 ? "\n═══ ALL CHECKS PASSED ═══" : `\n═══ ${failures} CHECK(S) FAILED ═══`);
  await db.$disconnect();
  process.exit(failures === 0 ? 0 : 1);
}
main().catch((e) => { console.error(e); process.exit(1); });
