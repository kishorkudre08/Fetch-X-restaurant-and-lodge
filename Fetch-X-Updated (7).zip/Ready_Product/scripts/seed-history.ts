// seed-history.ts — Generates a realistic 365-day operating history for
// JAYA'S KITCHEN so the dashboard ranges (today / 7d / 1m / 3m / 1y) show
// distinct, meaningful data instead of the same 3 demo bills everywhere.
//
// Modelled like a real mid-size pure-veg restaurant:
//   · IST-correct timestamps with breakfast / lunch / evening / dinner peaks
//   · Weekday vs weekend rhythm (Fri–Sun busier, Mon–Tue slow)
//   · Festive-season bump (mid-Oct → early Dec) + occasional slow days
//   · Gentle year-long growth trend (the business is getting busier)
//   · Bill math identical to POST /api/bills (5% GST, rounding)
//
// Wipes ALL bills first (history restarts numbering at 1001), keeps the menu.
// Run: bun scripts/seed-history.ts

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

// ── Deterministic PRNG (reproducible history) ───────────────────────────────
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(20260919);
const randInt = (min: number, max: number) => min + Math.floor(rand() * (max - min + 1));

function weightedPick<T>(entries: Array<[T, number]>): T {
  const total = entries.reduce((s, [, w]) => s + w, 0);
  let roll = rand() * total;
  for (const [value, w] of entries) {
    roll -= w;
    if (roll <= 0) return value;
  }
  return entries[entries.length - 1][0];
}

// ── IST helpers (business runs on UTC+5:30) ─────────────────────────────────
const IST_OFFSET_MS = 330 * 60_000;
const round2 = (n: number) => Math.round(n * 100) / 100;

// ── Meal windows (minutes from IST midnight, weight) ────────────────────────
type Window = { name: string; from: number; to: number; w: number };
const WINDOWS: Window[] = [
  { name: "breakfast", from: 8 * 60, to: 11 * 60 + 15, w: 13 },
  { name: "lunch", from: 11 * 60 + 45, to: 15 * 60 + 30, w: 42 },
  { name: "evening", from: 16 * 60, to: 18 * 60 + 15, w: 10 },
  { name: "dinner", from: 18 * 60 + 30, to: 22 * 60 + 30, w: 35 },
];

// Category bias per meal window — how likely a category is ordered then.
const CAT_BIAS: Record<string, Record<string, number>> = {
  breakfast: {
    Beverages: 2.4,
    Desserts: 0.55, // kesari bath crowd
    Starters: 0.35,
    "Main Course": 0.5,
    Breads: 0.4,
    "Rice & Biryani": 0.5,
  },
  lunch: {
    "Rice & Biryani": 1.7,
    "Main Course": 1.15,
    Beverages: 1.05,
    Starters: 0.75,
    Breads: 0.55,
    Desserts: 0.55,
  },
  evening: {
    Beverages: 1.9,
    Starters: 1.3,
    Desserts: 0.9,
    Breads: 0.4,
    "Main Course": 0.5,
    "Rice & Biryani": 0.4,
  },
  dinner: {
    Breads: 1.8,
    "Main Course": 1.5,
    Starters: 1.05,
    "Rice & Biryani": 0.85,
    Desserts: 1.15,
    Beverages: 0.8,
  },
};

// Crowd-favourite dishes get ordered noticeably more.
const STAR_DISHES = new Set([
  "Paneer Butter Masala",
  "Veg Biryani",
  "Veg Dum Biryani",
  "Butter Naan",
  "Masala Chai",
  "Filter Coffee",
  "Gulab Jamun (2 pc)",
  "Dal Tadka",
]);

// Weekday rhythm (IST weekday index Sun=0 … Sat=6)
const DOW_FACTOR = [1.35, 0.7, 0.75, 0.8, 0.9, 1.2, 1.35];

const BASE_BILLS_PER_DAY = 34;
const HISTORY_DAYS = 365; // includes today (partial, up to "now")
const START_NUMBER = 1001;

type NewBill = {
  id: string;
  number: number;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  itemCount: number;
  createdAt: Date;
};
type NewItem = {
  id: string;
  billId: string;
  dishId: string;
  name: string;
  category: string;
  qty: number;
  price: number;
};

async function main() {
  const now = new Date();
  const nowIstShifted = new Date(now.getTime() + IST_OFFSET_MS);
  const nowIstMin = nowIstShifted.getUTCHours() * 60 + nowIstShifted.getUTCMinutes();

  // IST midnight of "today" expressed in shifted-UTC ms
  const todayIstMidnight =
    Date.UTC(
      nowIstShifted.getUTCFullYear(),
      nowIstShifted.getUTCMonth(),
      nowIstShifted.getUTCDate(),
    ) - 0;

  // ── Load menu & assign popularity ─────────────────────────────────────────
  const dishes = await db.dish.findMany({ where: { active: true } });
  if (dishes.length === 0) throw new Error("Menu is empty — run scripts/reset-data.ts first");

  const pool = dishes.map((d) => ({
    id: d.id,
    name: d.name,
    price: d.price,
    category: d.category,
    pop: (0.55 + 1.15 * rand()) * (STAR_DISHES.has(d.name) ? 1.6 : 1),
  }));
  const catCount = new Map<string, number>();
  for (const p of pool) catCount.set(p.category, (catCount.get(p.category) ?? 0) + 1);
  console.log(
    `Menu: ${pool.length} dishes across ${catCount.size} categories ` +
      `[${[...catCount.entries()].map(([c, n]) => `${c}:${n}`).join(", ")}]`,
  );

  // ── Wipe existing bills (cascade clears BillItem) ─────────────────────────
  const wiped = await db.bill.deleteMany({});
  console.log(`Wiped ${wiped.count} existing bills. Generating ${HISTORY_DAYS} days of history…`);

  const bills: NewBill[] = [];
  const items: NewItem[] = [];
  let number = START_NUMBER;

  // Line-count mix for a 2–4 person veg restaurant table
  const LINE_COUNT: Array<[number, number]> = [
    [1, 0.18],
    [2, 0.34],
    [3, 0.28],
    [4, 0.13],
    [5, 0.07],
  ];
  const QTY: Array<[number, number]> = [
    [1, 0.72],
    [2, 0.22],
    [3, 0.06],
  ];

  for (let i = HISTORY_DAYS - 1; i >= 0; i--) {
    const istMidnight = todayIstMidnight - i * 86_400_000;
    const dayDate = new Date(istMidnight); // shifted space → IST calendar day
    const isToday = i === 0;
    if (isToday && nowIstMin < WINDOWS[0].from) continue; // kitchen not open yet

    const month = dayDate.getUTCMonth();
    const dateOfMonth = dayDate.getUTCDate();
    const dow = dayDate.getUTCDay();

    // Growth: oldest day ≈ 55% of today's volume, easing upward
    const progress = 1 - i / (HISTORY_DAYS - 1);
    const growth = 0.55 + 0.45 * Math.pow(progress, 0.85);

    // Festive season: Oct 15 – Dec 10 (Diwali & wedding season)
    let festive = 1;
    if ((month === 9 && dateOfMonth >= 15) || month === 10 || (month === 11 && dateOfMonth <= 10))
      festive = 1.22;
    if (month === 11 && dateOfMonth >= 24) festive = 1.3; // year-end crowd
    if (rand() < 0.02) festive *= 1.4; // random local festival
    if (rand() < 0.015) festive *= 0.25; // rains / half-closed day

    const noise = 0.88 + rand() * 0.24;
    const count = Math.max(
      5,
      Math.min(95, Math.round(BASE_BILLS_PER_DAY * DOW_FACTOR[dow] * growth * festive * noise)),
    );

    for (let b = 0; b < count; b++) {
      const win = weightedPick(WINDOWS.map((w) => [w, w.w] as [Window, number]));
      const minute = randInt(win.from, win.to);
      if (isToday && minute > nowIstMin) continue; // future of today hasn't happened

      const billId = crypto.randomUUID();
      const createdAt = new Date(istMidnight + minute * 60_000 - IST_OFFSET_MS);

      // 1–5 distinct dishes, biased by meal window × dish popularity
      const nLines = weightedPick(LINE_COUNT);
      const chosen = new Set<string>();
      const lines: Array<{ dish: (typeof pool)[number]; qty: number }> = [];
      for (let l = 0; l < nLines; l++) {
        const bias = CAT_BIAS[win.name];
        const candidates = pool
          .filter((p) => !chosen.has(p.id))
          .map((p) => [p, (bias[p.category] ?? 1) * p.pop] as [typeof p, number]);
        if (candidates.length === 0) break;
        const dish = weightedPick(candidates);
        chosen.add(dish.id);
        lines.push({ dish, qty: weightedPick(QTY) });
      }
      if (lines.length === 0) continue;

      const subtotal = round2(lines.reduce((s, l) => s + l.qty * l.dish.price, 0));
      // ~88% of bills have no discount; cashier gives flat amounts otherwise
      const discount =
        rand() < 0.88 ? 0 : Math.min(subtotal * 0.3, [10, 20, 25, 30, 40, 50][randInt(0, 5)]);
      const taxable = Math.max(0, subtotal - discount);
      const tax = round2(taxable * 0.05);
      const total = round2(taxable + tax);
      const itemCount = lines.reduce((s, l) => s + l.qty, 0);

      bills.push({ id: billId, number: number++, subtotal, discount, tax, total, itemCount, createdAt });
      for (const l of lines) {
        items.push({
          id: crypto.randomUUID(),
          billId,
          dishId: l.dish.id,
          name: l.dish.name,
          category: l.dish.category,
          qty: l.qty,
          price: l.dish.price,
        });
      }
    }
  }

  // Bills were generated day-by-day in order; numbers follow createdAt.
  bills.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  bills.forEach((b, idx) => (b.number = START_NUMBER + idx));

  // ── Insert in chunks ──────────────────────────────────────────────────────
  console.log(`Inserting ${bills.length} bills + ${items.length} line items…`);
  for (let i = 0; i < bills.length; i += 400) {
    await db.bill.createMany({ data: bills.slice(i, i + 400) });
    if (i % 4000 === 0) console.log(`  bills ${(i + 400).toLocaleString("en-IN")} / ${bills.length}`);
  }
  for (let i = 0; i < items.length; i += 1500) {
    await db.billItem.createMany({ data: items.slice(i, i + 1500) });
  }

  // ── Summary ───────────────────────────────────────────────────────────────
  const revenue = round2(bills.reduce((s, b) => s + b.total, 0));
  const byMonth = new Map<string, { bills: number; revenue: number }>();
  const byDay = new Map<string, { bills: number; revenue: number }>();
  for (const b of bills) {
    const mk = new Date(b.createdAt.getTime() + IST_OFFSET_MS).toISOString().slice(0, 7);
    const dk = new Date(b.createdAt.getTime() + IST_OFFSET_MS).toISOString().slice(0, 10);
    const m = byMonth.get(mk) ?? { bills: 0, revenue: 0 };
    m.bills++; m.revenue += b.total; byMonth.set(mk, m);
    const d = byDay.get(dk) ?? { bills: 0, revenue: 0 };
    d.bills++; d.revenue += b.total; byDay.set(dk, d);
  }
  const busiest = [...byDay.entries()].sort((a, b) => b[1].revenue - a[1].revenue)[0];
  const first = bills[0];
  const last = bills[bills.length - 1];
  const fmt = (iso: string) =>
    new Date(iso + "T00:00:00Z").toLocaleDateString("en-IN", { month: "short", year: "2-digit", timeZone: "UTC" });

  console.log("\n──── HISTORY SEEDED ────");
  console.log(`Bills:        ${bills.length.toLocaleString("en-IN")}  (#${first.number} → #${last.number})`);
  console.log(`Line items:   ${items.length.toLocaleString("en-IN")}`);
  console.log(`Revenue:      ₹${revenue.toLocaleString("en-IN")}`);
  console.log(`Span (IST):   ${first.createdAt.toISOString()} → ${last.createdAt.toISOString()}`);
  console.log(`Busiest day:  ${busiest[0]}  (${busiest[1].bills} bills, ₹${round2(busiest[1].revenue).toLocaleString("en-IN")})`);
  console.log("\nMonthly revenue:");
  for (const [mk, v] of [...byMonth.entries()].sort())
    console.log(`  ${fmt(mk)}  ${String(v.bills).padStart(5)} bills   ₹${Math.round(v.revenue).toLocaleString("en-IN")}`);
  const todayKey = new Date(nowIstShifted).toISOString().slice(0, 10);
  const t = byDay.get(todayKey);
  console.log(`\nToday so far: ${t ? `${t.bills} bills, ₹${Math.round(t.revenue).toLocaleString("en-IN")}` : "0 bills (opens soon)"}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
