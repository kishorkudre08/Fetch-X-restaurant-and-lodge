// t193 — One-shot: rebuild ALL the seeded data with two new requirements:
//   (1) Data spans from 1 January 2020 → today (was Jan 2025 only).
//   (2) Employee history — some employees JOIN LATER (createdAt in 2021/2022),
//       some LEAVE EARLIER (active=false with a "left on" date). The dashboard
//       attendance wall shows only CURRENT active employees; the AI still
//       sees historical employee data for past queries.
//
// This script:
//   1. Wipes Attendance + SalaryPayment + Bill + LodgeBill + Expense + Task tables
//   2. Re-creates the 11 current employees with `createdAt=2020-01-01`
//   3. Adds 4 PAST employees (active=false, left in 2022/2023) so the AI can
//      answer "who used to work here?"
//   4. Generates attendance marks for every active employee from 2020-01-01
//      until the day they left (for past employees) or today (for current)
//   5. Settles salaries for every month from 2020-01 to 2026-09 (latest over)
//      — only for months when the employee was active
//
// Run: bun scripts/seed-rebuild-2020.mjs
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const IST_OFFSET_MIN = 330;
const PAID_HOLIDAY_LIMIT = 3;
const MIN_DATE = "2020-01-01";

const localISO = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const hash = (s) => { let h = 0; for (let i=0;i<s.length;i++){ h = (h*31 + s.charCodeAt(i))|0; } return Math.abs(h) % 100; };
const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
const daysInMonth = (m) => { const [y,mm] = m.split("-").map(Number); return new Date(y, mm, 0).getDate(); };
const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;

// All full months from MIN_DATE to (current month − 1).
function allMonths() {
  const out = [];
  const now = new Date();
  let y = 2020, m = 1;
  while (true) {
    out.push(`${y}-${String(m).padStart(2,"0")}`);
    m += 1;
    if (m > 12) { m = 1; y += 1; }
    if (y > now.getFullYear() || (y === now.getFullYear() && m >= now.getMonth()+1)) break;
  }
  return out;
}

// Employee roster. The CURRENT 11 stay; 4 are added as PAST employees who left.
const CURRENT_EMPLOYEES = [
  { name: "Suresh Nair", role: "Head Chef", book: "rest", salary: 28000, joined: "2020-01-01" },
  { name: "Lakshmi Iyer", role: "South Indian Station", book: "rest", salary: 20000, joined: "2020-01-01" },
  { name: "Ravi Kumar", role: "Cashier · Counter 01", book: "rest", salary: 18000, joined: "2020-01-01" },
  { name: "Kumar Swamy", role: "Server", book: "rest", salary: 14000, joined: "2020-03-15" },
  { name: "Devi Shetty", role: "Kitchen Helper & Cleaning", book: "rest", salary: 9000, joined: "2021-06-01" },
  { name: "Anil Fernandes", role: "Lodge Manager · Front Desk", book: "lodge", salary: 26000, joined: "2020-01-01" },
  { name: "Rekha Nambiar", role: "Receptionist · Day", book: "lodge", salary: 16000, joined: "2020-01-01" },
  { name: "Imran Khan", role: "Receptionist · Night", book: "lodge", salary: 15000, joined: "2020-02-01" },
  { name: "Sarala Devi", role: "Housekeeping Supervisor", book: "lodge", salary: 14000, joined: "2020-01-01" },
  { name: "Pushpa Mestri", role: "Housekeeping", book: "lodge", salary: 11000, joined: "2021-09-01" },
  { name: "Vittal Poojary", role: "Security · Night Watch", book: "lodge", salary: 12000, joined: "2020-04-01" },
];

// Past employees — left the company at some point. active=false.
// Used by the AI for "who used to work here?" queries.
const PAST_EMPLOYEES = [
  { name: "Ramesh Shetty", role: "Old Cashier", book: "rest", salary: 16000, joined: "2020-01-01", left: "2022-08-31" },
  { name: "Geeta Rao", role: "Old Housekeeping", book: "lodge", salary: 9000, joined: "2020-01-01", left: "2023-03-31" },
  { name: "Mohan Das", role: "Old Server", book: "rest", salary: 12000, joined: "2020-06-01", left: "2024-01-15" },
  { name: "Fatima Sheikh", role: "Old Receptionist", book: "lodge", salary: 14000, joined: "2021-03-01", left: "2024-06-30" },
];

async function main() {
  console.log("=== wiping data ===");
  await db.attendance.deleteMany({});
  await db.salaryPayment.deleteMany({});
  // Keep Bills + LodgeBills + Expenses + Tasks from the other seed scripts
  // — we only own attendance + salaries here.

  console.log("=== upserting current employees (set createdAt) ===");
  // Find existing employees by name (the seed-ops script created them).
  // Update their `createdAt` to match the joined date.
  const allCurrent = await db.employee.findMany({ where: { active: true } });
  console.log(`found ${allCurrent.length} current employees; updating createdAt...`);
  for (const e of allCurrent) {
    const match = CURRENT_EMPLOYEES.find((x) => x.name === e.name);
    if (match) {
      await db.employee.update({ where: { id: e.id }, data: { createdAt: new Date(match.joined + "T00:00:00Z") } });
    }
  }

  console.log("=== creating PAST employees (active=false) ===");
  // Only create if not already there (idempotent).
  for (const p of PAST_EMPLOYEES) {
    const existing = await db.employee.findFirst({ where: { name: p.name } });
    if (existing) {
      // Update to active=false + correct createdAt if needed
      await db.employee.update({ where: { id: existing.id }, data: { active: false, createdAt: new Date(p.joined + "T00:00:00Z") } });
      console.log(`  updated (active=false): ${p.name} · left ${p.left}`);
    } else {
      await db.employee.create({ data: { name: p.name, role: p.role, book: p.book, salary: p.salary, active: false, createdAt: new Date(p.joined + "T00:00:00Z") } });
      console.log(`  created (active=false): ${p.name} · left ${p.left}`);
    }
  }

  // === Generate attendance marks ===
  // For each employee (current AND past), generate marks from their joined
  // date until today (current) or until their `left` date (past).
  console.log("=== generating attendance marks from 2020-01-01 ===");
  const allEmps = await db.employee.findMany(); // include inactive
  const empJoinedMap = new Map();
  for (const e of allEmps) {
    const cur = CURRENT_EMPLOYEES.find((x) => x.name === e.name);
    const past = PAST_EMPLOYEES.find((x) => x.name === e.name);
    empJoinedMap.set(e.id, {
      joined: cur?.joined ?? past?.joined ?? "2020-01-01",
      left: past?.left,
    });
  }

  const nowIst = new Date(Date.now() + IST_OFFSET_MIN * 60000);
  const created = [];
  for (const e of allEmps) {
    const { joined, left } = empJoinedMap.get(e.id);
    const joinedDate = new Date(joined + "T00:00:00");
    const endDate = left ? new Date(left + "T23:59:59") : nowIst;
    let d = new Date(joinedDate);
    while (d <= endDate) {
      if (d.getDay() === 0) { d = new Date(d.getTime() + 86_400_000); continue; } // skip Sundays
      const iso = localISO(d);
      const seed = hash(e.id + ":" + iso);
      const status = seed < 85 ? "present" : "absent";
      created.push({ employeeId: e.id, date: iso, status });
      d = new Date(d.getTime() + 86_400_000);
    }
  }
  console.log(`  generating ${created.length} attendance marks...`);
  for (let i = 0; i < created.length; i += 500) {
    await db.attendance.createMany({ data: created.slice(i, i + 500) });
  }
  console.log(`  ✓ created ${created.length} attendance marks`);

  // === Settle salaries ===
  // For each month from 2020-01 to latest-over, settle every employee who
  // was active DURING that month (joined ≤ month-end AND not left before
  // month-start). Past employees only get settlements for months they were
  // active.
  console.log("=== settling salaries from 2020-01 to latest over ===");
  const months = allMonths();
  console.log(`  ${months.length} months to settle (${months[0]} → ${months[months.length-1]})`);

  let createdSal = 0;
  let totalNet = 0;
  for (const month of months) {
    const days = daysInMonth(month);
    const monthStart = new Date(month + "-01T00:00:00");
    const monthEnd = new Date(month + "-" + String(days).padStart(2,"0") + "T23:59:59");
    for (const e of allEmps) {
      const meta = empJoinedMap.get(e.id);
      const joinedDate = new Date(meta.joined + "T00:00:00");
      const leftDate = meta.left ? new Date(meta.left + "T23:59:59") : null;
      // Skip if employee joined AFTER this month ended, or left BEFORE month started
      if (joinedDate > monthEnd) continue;
      if (leftDate && leftDate < monthStart) continue;

      // Count attendance in this month (only for the days they were active)
      const from = `${month}-01`;
      const to = `${month}-${String(days).padStart(2,"0")}`;
      const [present, absent] = await Promise.all([
        db.attendance.count({ where: { employeeId: e.id, date: { gte: from, lte: to }, status: "present" } }),
        db.attendance.count({ where: { employeeId: e.id, date: { gte: from, lte: to }, status: "absent" } }),
      ]);
      const paidHolidays = Math.max(0, Math.min(PAID_HOLIDAY_LIMIT, absent));
      const cutDays = Math.max(0, absent - paidHolidays);
      const deduction = round2(cutDays * (e.salary / days));
      const netPaid = round2(e.salary - deduction);
      totalNet += netPaid;
      const [y, m] = month.split("-").map(Number);
      const nextMonth = new Date(Date.UTC(y, m, 1, 5, 0, 0));
      await db.salaryPayment.create({
        data: {
          employeeId: e.id, month, base: e.salary,
          presentDays: present, absentDays: absent,
          paidHolidays, deduction, netPaid,
          status: "paid", paidAt: nextMonth, paidBy: "OWNER",
        },
      });
      createdSal++;
    }
  }
  console.log(`  ✓ created ${createdSal} salary settlements · total ₹${totalNet.toLocaleString("en-IN")}`);

  // Final summary
  console.log("\n=== FINAL SUMMARY ===");
  console.log(`active employees: ${await db.employee.count({ where: { active: true } })}`);
  console.log(`past employees (active=false): ${await db.employee.count({ where: { active: false } })}`);
  console.log(`attendance marks: ${await db.attendance.count()}`);
  console.log(`salary settlements: ${await db.salaryPayment.count()}`);

  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
