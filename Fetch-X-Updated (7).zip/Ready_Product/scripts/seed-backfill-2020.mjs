// t193 — Backfill SPARSE bills + expenses + tasks + lodge stays for the
// historical period 2020-01-01 → 2025-09-30. The existing seed-history.ts
// covers the last 365 days densely (~30 bills/day). This script fills in
// the OLDER years sparsely (~3 bills/day, 1 expense/week, 1 task/week,
// 5 stays/week) so the LIFETIME and CUSTOM ranges show meaningful data.
//
// Run: bun scripts/seed-backfill-2020.mjs
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const IST_OFFSET_MS = 330 * 60_000;
const localISO = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const round2 = (n) => Math.round(n * 100) / 100;

// Simple deterministic PRNG
let _seed = 42;
const rand = () => { _seed = (_seed * 9301 + 49297) % 233280; return _seed / 233280; };
const randInt = (min, max) => min + Math.floor(rand() * (max - min + 1));

async function main() {
  const dishes = await db.dish.findMany();
  console.log(`menu: ${dishes.length} dishes`);

  // Get the current bill number (to continue numbering from there)
  const lastBill = await db.bill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let billNumber = (lastBill?.number ?? 1000) + 1;

  // Date range: 2020-01-01 → 2025-09-30 (just before the dense recent year)
  const startDate = new Date("2020-01-01T00:00:00Z");
  const endDate = new Date("2025-09-30T23:59:59Z");
  const daysBack = Math.ceil((endDate.getTime() - startDate.getTime()) / 86_400_000);
  console.log(`backfilling ${daysBack} days from 2020-01-01 to 2025-09-30`);

  let billsCreated = 0;
  let expensesCreated = 0;
  let tasksCreated = 0;
  let staysCreated = 0;

  for (let i = 0; i < daysBack; i++) {
    const day = new Date(startDate.getTime() + i * 86_400_000);
    const iso = localISO(day);
    const dow = day.getDay();
    const isWeekend = dow === 5 || dow === 6; // Fri/Sat busier

    // 3-5 bills/day (sparse — the dense recent year has ~30/day)
    const billCount = isWeekend ? randInt(4, 7) : randInt(2, 5);
    for (let b = 0; b < billCount; b++) {
      const itemCount = randInt(1, 4);
      const items = [];
      let subtotal = 0;
      for (let it = 0; it < itemCount; it++) {
        const dish = dishes[randInt(0, dishes.length - 1)];
        const qty = randInt(1, 3);
        items.push({ name: dish.name, category: dish.category, qty, price: dish.price, dishId: dish.id });
        subtotal += dish.price * qty;
      }
      const discount = rand() < 0.15 ? Math.round(subtotal * 0.05) : 0;
      const taxable = subtotal - discount;
      const tax = round2(taxable * 0.05);
      const total = round2(taxable + tax);
      // Random time during business hours (IST)
      const hour = randInt(8, 21);
      const minute = randInt(0, 59);
      const istTime = new Date(day.getTime() + IST_OFFSET_MS);
      istTime.setUTCHours(hour, minute, 0, 0);
      const createdAt = new Date(istTime.getTime() - IST_OFFSET_MS);

      const bill = await db.bill.create({
        data: {
          number: billNumber++,
          subtotal: round2(subtotal),
          discount,
          tax,
          total,
          itemCount,
          createdAt,
          items: { create: items },
        },
      });
      billsCreated++;
    }

    // 1 expense every ~5 days (raw_material / upgrade / maintenance)
    if (i % 5 === 0) {
      const kinds = ["raw_material", "upgrade", "maintenance"];
      const books = ["rest", "lodge"];
      const kind = kinds[randInt(0, 2)];
      const book = books[randInt(0, 1)];
      const amount = kind === "raw_material" ? randInt(500, 3000)
        : kind === "upgrade" ? randInt(2000, 15000)
        : randInt(300, 2000);
      await db.expense.create({
        data: {
          kind,
          book,
          amount,
          label: `${kind === "raw_material" ? "Groceries" : kind === "upgrade" ? "Upgrade" : "Repair"} · ${iso}`,
          spentOn: new Date(iso + "T12:00:00Z"),
          createdAt: new Date(day.getTime() + IST_OFFSET_MS),
        },
      });
      expensesCreated++;
    }

    // 1 task every ~7 days
    if (i % 7 === 0) {
      const titles = [
        "Weekly inventory check",
        "Clean the kitchen exhaust",
        "Restock dry goods",
        "Lodge room maintenance round",
        "Staff schedule review",
        "Equipment servicing",
        "Deep clean dining area",
      ];
      const books = ["rest", "lodge"];
      const kinds = ["raw_material", "upgrade", "maintenance"];
      const title = titles[randInt(0, titles.length - 1)];
      const book = books[randInt(0, 1)];
      const kind = kinds[randInt(0, 2)];
      const maxBudget = kind === "raw_material" ? randInt(500, 2000) : kind === "upgrade" ? randInt(2000, 10000) : randInt(300, 1500);
      const deadline = new Date(day.getTime() + 7 * 86_400_000);
      const isDone = i < daysBack - 14; // most old tasks are done
      await db.task.create({
        data: {
          title,
          description: `${title} — routine maintenance for ${book} book.`,
          book,
          kind,
          maxBudget,
          deadline,
          status: isDone ? "done" : "open",
          createdAt: new Date(day.getTime()),
          doneAt: isDone ? new Date(day.getTime() + 3 * 86_400_000) : null,
          createdBy: "OWNER",
          actualCost: isDone ? Math.round(maxBudget * (0.8 + rand() * 0.3)) : null,
        },
      });
      tasksCreated++;
    }

    // Lodge stays: skip — the existing seed-stays-year.mjs already generated
    // 6,832 stays for the last year. Adding sparse historical stays would
    // require all the LodgeBill required fields (number, room, guestName,
    // guestPhone, tier, rate, checkInAt, checkOutAt, hours, stay, minApplied,
    // discount, tax, total) — too complex for a sparse backfill. The LIFETIME
    // range shows the existing stays + the new bills + expenses.
  }

  console.log(`\n=== BACKFILL DONE ===`);
  console.log(`bills created: ${billsCreated}`);
  console.log(`expenses created: ${expensesCreated}`);
  console.log(`tasks created: ${tasksCreated}`);
  console.log(`lodge stays created: ${staysCreated}`);

  // Final aggregate
  const billAgg = await db.bill.aggregate({ _min: { createdAt: true }, _max: { createdAt: true }, _count: true, _sum: { total: true } });
  console.log(`\ntotal bills: ${billAgg._count} · range: ${billAgg._min.createdAt?.toISOString().slice(0,10)} → ${billAgg._max.createdAt?.toISOString().slice(0,10)} · revenue ₹${billAgg._sum.total?.toLocaleString("en-IN")}`);
  const expAgg = await db.expense.aggregate({ _count: true });
  console.log(`total expenses: ${expAgg._count}`);

  await db.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
