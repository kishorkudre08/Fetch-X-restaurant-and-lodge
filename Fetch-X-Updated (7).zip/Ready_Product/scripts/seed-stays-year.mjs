// ── t99 — generalise the year of lodge stays ────────────────────────────────
// The complaint: "why are only 8 rooms filled in yearly view?? please
// generalise the data". The old generator wrote ~18 short stays/day, which
// time-weighs to a nearly empty wall (~7 of 100 rooms) across 1Y.
//
// This rebuilds the whole year of LodgeBill history with REALISTIC occupancy:
//   · ~38-46 checkouts/day (weekend bump + a gentle seasonal wave)
//   · a duration mix of day-uses, 1-nighters, 2-nighters and long weekends
//     → the wall settles at ~55-70 rooms filled for every window
//   · the live wall (rooms table, 55 in-house / 3 mnt) is NOT touched
//   · restaurant bills, tasks, expenses — untouched
// Rates/floor/GST follow the same rules: tier rate × hours ÷ 24, ₹1,000
// floor, 5% GST. Run: node scripts/seed-stays-year.mjs
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const rnd = (a, b) => a + Math.random() * (b - a);
const pickW = (pairs) => {
  // [[value, weight], …]
  const tot = pairs.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * tot;
  for (const [v, w] of pairs) {
    r -= w;
    if (r <= 0) return v;
  }
  return pairs[pairs.length - 1][0];
};
const r2 = (n) => Math.round(n * 100) / 100;

const GUEST_NAMES = [
  "Ramesh Kulkarni", "Priya Deshpande", "Arjun Mehta", "Sneha Patil", "Vikram Joshi",
  "Anita Desai", "Rahul Verma", "Kavita Rao", "Suresh Babu", "Meena Nair",
  "Prakash Gowda", "Shobha Kamath", "Mohan Pai", "Lata Hegde", "Girish Prabhu",
  "Vidya Shetty", "Nagesh Rao", "Sudha Murthy", "Harish Pai", "Roopa Iyer",
  "Ganesh Bhat", "Usha Kamat", "Dinesh Shenoy", "Rekha Balan", "Satish Poojari",
  "Nirmala Nayak", "Ravi Shastri", "Geetha Kulkarni", "Amit Chavan", "Sunita Jadhav",
  "Rajesh Kumbhar", "Manisha Gaikwad", "Sagar Patil", "Asha Bhosale", "Vivek Sawant",
  "Pooja Salvi", "Nitin Rane", "Sadhana Kale", "Prasad Dalvi", "Vaishali More",
];

const DEFAULT_LEVELS = [
  { from: 1, to: 40, rate: 2499, name: "BASIC" },
  { from: 41, to: 80, rate: 2999, name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, name: "LUXURY" },
];

const istDayStartMs = (() => {
  const now = Date.now();
  return new Date(new Date(now + 330 * 60000).setUTCHours(0, 0, 0, 0)).getTime() - 330 * 60000;
})();

function tierOf(n, levels) {
  const lv = levels.find((l) => n >= l.from && n <= l.to) ?? levels[0];
  return { name: lv.name, rate: lv.rate };
}

/* stay duration in hours — day-uses, 1-nighters, 2-nighters, long weekends */
function stayHours() {
  return pickW([
    [rnd(6, 12), 20], // day use / few hours
    [rnd(20, 30), 32], // the classic one-night stay
    [rnd(44, 54), 26], // two nights
    [rnd(68, 100), 22], // the long weekend
  ]);
}

async function main() {
  console.log("── seed-stays-year start ──");

  const lvlRow = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  let levels = DEFAULT_LEVELS;
  try {
    if (lvlRow?.value) {
      const parsed = JSON.parse(lvlRow.value);
      if (Array.isArray(parsed) && parsed.length) levels = parsed;
    }
  } catch {
    /* keep defaults */
  }

  const now = Date.now();
  const yearAgo = now - 365 * DAY;

  console.log("wiping the old stay history…");
  await db.lodgeBill.deleteMany({});

  const rows = [];
  let numBill = 5001;

  for (let day = 365; day >= 0; day--) {
    const dayStart = now - day * DAY;
    const isToday = day === 0;
    const dayEnd = isToday ? now : Math.min(dayStart + DAY, now);
    if (dayEnd <= dayStart) continue;

    const dow = new Date(dayStart).getUTCDay();
    const weekend = dow === 5 || dow === 6 || dow === 0 ? 1.18 : 1; // Fri-Sun busier
    const season = 1 + 0.12 * Math.sin((day / 365) * Math.PI * 2); // a gentle yearly wave
    const base = 40 * weekend * season; // → ~63% of the 100-room wall
    const count = Math.max(24, Math.round(base + rnd(-5, 5)));

    for (let k = 0; k < count; k++) {
      const room = 1 + Math.floor(Math.random() * 100);
      const t = tierOf(room, levels);
      const hours = stayHours();
      // checkout lands inside this day; checkIn reaches back by the duration
      const checkOut = new Date(dayStart + Math.random() * (dayEnd - dayStart));
      const checkIn = new Date(checkOut.getTime() - hours * 3_600_000);
      if (checkIn.getTime() > now || checkOut.getTime() > now) continue;

      const raw = Math.round((t.rate * hours) / 24);
      const min = raw < 1000;
      const stay = min ? 1000 : raw;
      const tax = Math.round(stay * 5) / 100;
      const total = Math.round((stay + tax) * 100) / 100;
      rows.push({
        number: numBill++,
        room,
        guestName: GUEST_NAMES[Math.floor(Math.random() * GUEST_NAMES.length)],
        guestPhone: "97" + String(10000000 + Math.floor(Math.random() * 8999999)),
        tier: t.name,
        rate: t.rate,
        checkInAt: checkIn,
        checkOutAt: checkOut,
        hours: r2(hours),
        stay,
        minApplied: min,
        discount: 0,
        tax,
        total,
        createdAt: checkOut,
      });
    }
  }

  for (let i = 0; i < rows.length; i += 500) {
    await db.lodgeBill.createMany({ data: rows.slice(i, i + 500) });
  }
  console.log("lodge bills created:", rows.length);

  /* sanity report — the room-equivalents each window should now show */
  const spans = await db.lodgeBill.findMany({
    where: { checkOutAt: { gte: new Date(yearAgo) } },
    select: { checkInAt: true, checkOutAt: true },
  });
  const report = (label, days) => {
    const start = now - days * DAY;
    const totalRh = 100 * ((now - start) / 3_600_000);
    let g = 0;
    for (const s of spans) {
      const from = Math.max(+s.checkInAt, start);
      const to = Math.min(+s.checkOutAt, now);
      if (to > from) g += (to - from) / 3_600_000;
    }
    // open stays of today's in-house guests
    console.log(
      `${label.padEnd(8)} guests ≈ ${String(Math.round(g / 24)).padStart(3)} rooms of 100 (${Math.round((g / totalRh) * 100)}% of the wall)`,
    );
  };
  report("TODAY", 1);
  report("7D", 7);
  report("1M", 30);
  report("3M", 91);
  report("1Y", 365);

  console.log("── seed-stays-year done ──");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
