/* Inspect what days are missing data — query bills, lodgeBills, expenses,
 * and tasks for the last 14 days of activity.
 *
 * Usage:  node scripts/inspect-recent.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const IST = 330 * 60000;

function istDay(ts) {
  return new Date((ts + IST)).toISOString().slice(0, 10);
}

async function main() {
  const now = Date.now();
  const since = now - 14 * DAY;

  const [bills, lodge, exp, tasks] = await Promise.all([
    db.bill.findMany({ where: { createdAt: { gte: new Date(since) } }, select: { createdAt: true } }),
    db.lodgeBill.findMany({ where: { createdAt: { gte: new Date(since) } }, select: { createdAt: true } }),
    db.expense.findMany({ where: { spentOn: { gte: new Date(since) } }, select: { spentOn: true } }),
    db.task.findMany({ where: { createdAt: { gte: new Date(since) } }, select: { createdAt: true, status: true } }),
  ]);

  const byDay = {};
  for (const b of bills) {
    const k = istDay(b.createdAt.getTime());
    byDay[k] = byDay[k] ?? { rest: 0, lodge: 0, exp: 0, tasksOpen: 0, tasksDone: 0 };
    byDay[k].rest++;
  }
  for (const l of lodge) {
    const k = istDay(l.createdAt.getTime());
    byDay[k] = byDay[k] ?? { rest: 0, lodge: 0, exp: 0, tasksOpen: 0, tasksDone: 0 };
    byDay[k].lodge++;
  }
  for (const e of exp) {
    const k = istDay(e.spentOn.getTime());
    byDay[k] = byDay[k] ?? { rest: 0, lodge: 0, exp: 0, tasksOpen: 0, tasksDone: 0 };
    byDay[k].exp++;
  }
  for (const t of tasks) {
    const k = istDay(t.createdAt.getTime());
    byDay[k] = byDay[k] ?? { rest: 0, lodge: 0, exp: 0, tasksOpen: 0, tasksDone: 0 };
    if (t.status === "done") byDay[k].tasksDone++;
    else byDay[k].tasksOpen++;
  }

  // Build a 14-day window
  const istDayStart = new Date(new Date(now + IST).setUTCHours(0, 0, 0, 0)).getTime() - IST;
  const rows = [];
  for (let d = 13; d >= 0; d--) {
    const ts = istDayStart - d * DAY;
    const k = new Date(ts + IST).toISOString().slice(0, 10);
    const c = byDay[k] ?? { rest: 0, lodge: 0, exp: 0, tasksOpen: 0, tasksDone: 0 };
    const dow = new Date(ts).toLocaleDateString("en-IN", { weekday: "short", timeZone: "Asia/Kolkata" });
    rows.push(`${k} ${dow.padEnd(4)}  rest=${String(c.rest).padStart(3)}  lodge=${String(c.lodge).padStart(3)}  exp=${String(c.exp).padStart(2)}  tasks(open/done)=${c.tasksOpen}/${c.tasksDone}`);
  }

  console.log("── last 14 days of activity ──");
  console.log(rows.join("\n"));
  console.log("── end ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
