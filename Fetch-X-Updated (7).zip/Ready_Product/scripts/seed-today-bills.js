/* t205 — seed TODAY's (IST) billing data into db/custom.db.
 *
 * Why: the demo books stopped at yesterday (2026-10-05), so the app opened
 * on the default TODAY view with ₹0 revenue and the AI panel's money
 * template hit its "no billing" guard. This script adds a realistic day of
 * business — restaurant bills, the morning raw-material buys, today's
 * attendance (which drives the salary accrual), one lodge checkout and a
 * few owner tasks — so every template answer is alive on TODAY.
 *
 * Mirror of the app's own flows:
 *   • Bill  → POS print (subtotal → optional discount → 5% GST → total)
 *   • Lodge → /api/lodge checkout (lgStay: round(rate*h/24), ₹1,000 floor,
 *             5% GST, room goes "mnt", L-series number)
 *   • Attendance → one row per employee per IST date (present/absent)
 * Run: node scripts/seed-today-bills.js   (idempotent-ish: skips if bills
 * already exist for today)
 */
const { PrismaClient } = require("@prisma/client");
const p = new PrismaClient();

const IST_MIN = 330; // UTC+5:30
const LG_MIN = 1000; // ₹1,000 stay floor (src/lib/lodge.ts)
const round2 = (n) => Math.round(n * 100) / 100;

const istDayStartUtc = (d = new Date()) => {
  const s = new Date(d.getTime() + IST_MIN * 60000);
  s.setUTCHours(0, 0, 0, 0);
  return new Date(s.getTime() - IST_MIN * 60000);
};
const istDateKey = (d = new Date()) =>
  new Date(d.getTime() + IST_MIN * 60000).toISOString().slice(0, 10);

(async () => {
  const now = new Date();
  const dayStart = istDayStartUtc(now);
  const dateKey = istDateKey(now);
  // wall-clock slot in IST → UTC instant (clamped to a few minutes ago)
  const at = (h, m) => {
    const t = new Date(dayStart.getTime() + (h * 60 + m) * 60000);
    return t.getTime() < now.getTime() - 2 * 60000 ? t : new Date(now.getTime() - 2 * 60000);
  };

  const existingToday = await p.bill.count({ where: { createdAt: { gte: dayStart, lt: new Date(dayStart.getTime() + 86400000) } } });
  if (existingToday > 0) {
    console.log(`Today (${dateKey} IST) already has ${existingToday} restaurant bills — nothing to seed.`);
    await p.$disconnect();
    return;
  }

  /* ── 1. Restaurant bills: 9:05 → 20:10 IST, lunch + evening weighted ── */
  const dishes = await p.dish.findMany({ where: { active: true }, orderBy: { id: "asc" } });
  if (dishes.length < 8) throw new Error("Need at least 8 active dishes");
  const cat = (name) => dishes.find((d) => d.category === name) ?? dishes[0];
  const pick = (name, qty) => ({ dish: cat(name), qty });

  // [IST h, m, items[], discount%]
  const plan = [
    [9, 5,  [["Beverages", 2], ["Breads", 2]], 0],
    [10, 20, [["Beverages", 1], ["Desserts", 1]], 0],
    [11, 45, [["Starters", 1], ["Main Course", 2], ["Breads", 2]], 0],
    [12, 30, [["Starters", 2], ["Main Course", 2], ["Rice & Biryani", 1], ["Beverages", 2]], 5],
    [12, 55, [["Main Course", 1], ["Breads", 3]], 0],
    [13, 35, [["Rice & Biryani", 2], ["Starters", 1], ["Desserts", 2]], 0],
    [14, 15, [["Main Course", 2], ["Rice & Biryani", 1]], 10],
    [15, 10, [["Beverages", 2], ["Starters", 1]], 0],
    [16, 25, [["Desserts", 2], ["Beverages", 1]], 0],
    [18, 5,  [["Starters", 2], ["Main Course", 1], ["Breads", 2]], 0],
    [18, 50, [["Rice & Biryani", 1], ["Starters", 1], ["Beverages", 2]], 0],
    [19, 25, [["Starters", 2], ["Main Course", 2], ["Breads", 2], ["Desserts", 1]], 5],
    [19, 55, [["Main Course", 1], ["Rice & Biryani", 1]], 0],
    [20, 10, [["Starters", 1], ["Main Course", 2], ["Beverages", 2]], 0],
  ];

  const maxB = await p.bill.aggregate({ _max: { number: true } });
  let num = (maxB._max.number ?? 1000) + 1;
  let restRevenue = 0;
  for (const [h, m, items, discPct] of plan) {
    const rows = items.map(([name, qty]) => pick(name, qty));
    const subtotal = round2(rows.reduce((s, r) => s + r.dish.price * r.qty, 0));
    const discount = round2((subtotal * discPct) / 100);
    const taxable = round2(subtotal - discount);
    const tax = round2(taxable * 0.05);
    const total = round2(taxable + tax);
    const createdAt = at(h, m);
    await p.bill.create({
      data: {
        number: num++,
        subtotal,
        discount,
        tax,
        total,
        itemCount: rows.reduce((s, r) => s + r.qty, 0),
        createdAt,
        items: {
          create: rows.map((r) => ({
            dishId: r.dish.id,
            name: r.dish.name,
            category: r.dish.category,
            qty: r.qty,
            price: r.dish.price,
          })),
        },
      },
    });
    restRevenue += total;
  }
  console.log(`Restaurant: ${plan.length} bills created (₹${round2(restRevenue)} revenue today)`);

  /* ── 2. Attendance today → drives the salary accrual (10 present, 1 absent) ── */
  const emps = await p.employee.findMany({ where: { active: true }, orderBy: { name: "asc" } });
  let attCount = 0;
  for (let i = 0; i < emps.length; i++) {
    const status = i === emps.length - 1 ? "absent" : "present"; // one planned absence
    await p.attendance.upsert({
      where: { employeeId_date: { employeeId: emps[i].id, date: dateKey } },
      update: { status },
      create: { employeeId: emps[i].id, date: dateKey, status },
    });
    attCount++;
  }
  console.log(`Attendance: ${attCount} rows for ${dateKey} (IST)`);

  /* ── 3. Today's raw-material buys (the only manual cost entries) ── */
  await p.expense.create({ data: { kind: "raw_material", book: "rest", label: "Morning vegetable market run", amount: 2850, spentOn: at(8, 45) } });
  await p.expense.create({ data: { kind: "raw_material", book: "rest", label: "Dairy and ghee restock", amount: 1140, spentOn: at(9, 30) } });
  console.log("Expenses: 2 raw-material entries (₹3,990)");

  /* ── 4. One lodge checkout today (mirrors /api/lodge checkout exactly) ── */
  const room = await p.room.findFirst({ where: { status: "occ", checkInAt: { not: null } }, orderBy: { number: "asc" } });
  if (room) {
    let tier = { name: "STANDARD", rate: 2999 };
    const levelsRaw = await p.setting.findUnique({ where: { key: "lodgeLevels" } });
    if (levelsRaw?.value) {
      try {
        const levels = JSON.parse(levelsRaw.value);
        const t = (Array.isArray(levels) ? levels : []).find((l) => room.number >= l.from && room.number <= l.to);
        if (t) tier = { name: String(t.name).toUpperCase(), rate: Number(t.rate) };
      } catch { /* default tier */ }
    }
    const checkOutAt = at(11, 0);
    const hours = (checkOutAt.getTime() - room.checkInAt.getTime()) / 3600000;
    const raw = Math.round((tier.rate * hours) / 24);
    const min = raw < LG_MIN;
    const stay = min ? LG_MIN : raw;
    const tax = Math.round(stay * 5) / 100;
    const total = round2(stay + tax);
    const maxL = await p.lodgeBill.aggregate({ _max: { number: true } });
    await p.$transaction([
      p.lodgeBill.create({
        data: {
          number: (maxL._max.number ?? 5000) + 1,
          room: room.number,
          guestName: room.guestName ?? "Walk-in guest",
          guestPhone: room.guestPhone ?? "",
          tier: tier.name,
          rate: tier.rate,
          checkInAt: room.checkInAt,
          checkOutAt,
          hours: round2(hours),
          stay,
          minApplied: min,
          discount: 0,
          tax,
          total,
          createdAt: checkOutAt,
        },
      }),
      p.room.update({
        where: { number: room.number },
        data: { status: "mnt", guestName: null, guestPhone: null, checkInAt: null },
      }),
    ]);
    console.log(`Lodge: room ${room.number} (${tier.name} ₹${tier.rate}) checked out — ${round2(hours)} h, stay ₹${stay}, total ₹${total} (L-series)`);
  }

  /* ── 5. A few owner tasks today (feeds task completion + budget %) ── */
  const tomorrow = new Date(dayStart.getTime() + 36 * 3600000);
  await p.task.create({
    data: { title: "Fix the wobbly table by the window", book: "rest", kind: "maintenance", maxBudget: 800, description: "Corner table keeps rocking — get the leg bracket replaced.", deadline: tomorrow, status: "done", createdBy: "Owner", createdAt: at(10, 20), doneAt: at(13, 5), doneBy: "Reception", actualCost: 650 },
  });
  await p.task.create({
    data: { title: "Refill the paneer stock for dinner service", book: "rest", kind: "raw_material", maxBudget: 1500, description: "Dinner prep needs 8 kg more paneer from the dairy.", deadline: tomorrow, status: "open", createdBy: "Owner", createdAt: at(16, 40) },
  });
  await p.task.create({
    data: { title: "Service the AC unit in room 7", book: "lodge", kind: "maintenance", maxBudget: 2000, description: "Guest complained the AC is not cooling after noon.", deadline: tomorrow, status: "done", createdBy: "Owner", createdAt: at(9, 40), doneAt: at(12, 30), doneBy: "Reception", actualCost: 1750 },
  });
  console.log("Tasks: 3 created (2 rest — 1 done, 1 open; 1 lodge — done)");

  await p.$disconnect();
  console.log("DONE — today's billing data seeded for", dateKey, "(IST)");
})().catch((e) => {
  console.error("SEED FAILED:", e.message);
  process.exit(1);
});
