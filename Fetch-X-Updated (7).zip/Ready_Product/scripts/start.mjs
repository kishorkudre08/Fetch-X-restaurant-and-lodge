#!/usr/bin/env node
/* Fetch-X launcher — the single command that does everything (SETUP.md contract):
   1) dependencies missing?            → install them (first run only)
   2) Prisma client missing?           → generate it
   3) print a health report (Node version, database file found, AI key set or not)
   4) start the Next.js dev server on port 3000

   Works with whatever starts it: `bun run dev`, `npm run dev`, `npm run dev:w`.
   The server is spawned as a direct child; Ctrl+C stops it cleanly. */

import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const tag = "[fetchx]";

/* The folder that physically contains this script's parent = project root.
   Never trust cwd — the launcher pins FX_PROJECT_DIR so db.ts and
   instrumentation.ts both resolve the database and client correctly. */
const projectDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.env.FX_PROJECT_DIR = process.env.FX_PROJECT_DIR || projectDir;
process.chdir(projectDir);

const isWindows = process.platform === "win32";
const nodeModulesDir = path.join(projectDir, "node_modules");
const prismaClientDir = path.join(nodeModulesDir, ".prisma", "client");

function run(cmd, args, label) {
  console.log(`${tag} ${label}…`);
  const res = spawnSync(cmd, args, { stdio: "inherit", cwd: projectDir, shell: isWindows });
  if (res.status !== 0) {
    console.error(`${tag} ${label} FAILED (exit ${res.status}). Fix the error above and run again.`);
    process.exit(res.status ?? 1);
  }
}

/* 1) dependencies */
if (!fs.existsSync(path.join(nodeModulesDir, "next", "package.json"))) {
  const hasBun = !isWindows && spawnSync("bun", ["--version"], { shell: isWindows }).status === 0;
  if (hasBun) run("bun", ["install"], "Dependencies missing — installing with bun (first run, a few minutes)");
  else run(isWindows ? "npm.cmd" : "npm", ["install"], "Dependencies missing — installing with npm (first run, a few minutes)");
} else {
  console.log(`${tag} dependencies OK`);
}

/* 2) Prisma client */
const prismaReady =
  fs.existsSync(path.join(prismaClientDir, "index.js")) &&
  fs.existsSync(path.join(prismaClientDir, "schema.prisma"));
if (!prismaReady) {
  run(
    isWindows ? "npx.cmd" : "npx",
    ["prisma", "generate"],
    "Prisma client not generated yet — generating now (one time, ~10s)",
  );
} else {
  console.log(`${tag} Prisma client OK`);
}

/* 3) health report */
console.log(`${tag} Node ${process.version}`);
const envDb = (process.env.DATABASE_URL || "").replace(/^file:/, "");
const dbCandidates = [
  envDb && path.isAbsolute(envDb) ? envDb : path.join(projectDir, "db", "custom.db"),
  path.join(projectDir, "db", "custom.db"),
];
const dbFile = dbCandidates.find((c) => c && fs.existsSync(c));
console.log(dbFile ? `${tag} database OK → ${dbFile}` : `${tag} DATABASE NOT FOUND — run: npm run doctor`);
console.log(
  process.env.GROQ_API_KEY
    ? `${tag} AI copilot → Groq key ${process.env.GROQ_API_KEY.slice(0, 6)}…${process.env.GROQ_API_KEY.slice(-4)}`
    : `${tag} AI copilot → no Groq key set (the panel shows setup steps; app works fine without it)`,
);

/* 4) start the dev server on port 3000 */
const nextBin = path.join(nodeModulesDir, "next", "dist", "bin", "next");
const port = process.env.PORT || "3000";
console.log(`${tag} starting Next.js dev server on http://localhost:${port} …`);

const child = spawn(process.execPath, [nextBin, "dev", "-p", port], {
  cwd: projectDir,
  stdio: "inherit",
  env: { ...process.env, FX_PROJECT_DIR: projectDir, NODE_ENV: "development" },
});

const stop = (sig) => {
  if (child.pid && !child.killed) child.kill(sig);
};
process.on("SIGINT", () => stop("SIGINT"));
process.on("SIGTERM", () => stop("SIGTERM"));
child.on("exit", (code) => process.exit(code ?? 0));
