#!/usr/bin/env node
// Fetch-X · database doctor — run inside the project folder:  npm run doctor
// Read-only diagnosis: finds the SQLite file, then really opens it with Prisma
// in both URL formats and reports which one works on THIS machine.
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const cwd = process.cwd();
const line = "-".repeat(60);
console.log(`\nFetch-X · database doctor`);
console.log(`node ${process.version} · ${process.platform} · cwd: ${cwd}\n${line}`);

// npm does not auto-load .env for arbitrary scripts — read it directly.
let envUrl = process.env.DATABASE_URL?.trim().replace(/^["']|["']$/g, "");
try {
  const txt = fs.readFileSync(path.join(cwd, ".env"), "utf8");
  const m = txt.split(/\r?\n/).find((l) => /^\s*DATABASE_URL\s*=/.test(l));
  if (m) envUrl = m.slice(m.indexOf("=") + 1).trim().replace(/^["']|["']$/g, "");
} catch {}
console.log("DATABASE_URL:", envUrl || "(not set)");

const candidates = [];
if (envUrl && envUrl.startsWith("file:")) {
  let p = envUrl.slice(5);
  const isAbs = p.startsWith("/") || /^[A-Za-z]:[\\/]/.test(p);
  if (!isAbs) p = path.resolve(cwd, "prisma", p); // schema-relative
  else p = p.replace(/^\/+(?=[A-Za-z]:)/, ""); // file:/C:/x → C:/x
  candidates.push(path.normalize(p));
}
for (const rel of ["db/custom.db", "prisma/dev.db", "custom.db", "dev.db"])
  candidates.push(path.resolve(cwd, rel));
const spots = [...new Set(candidates)];

console.log("\nLooking for the database file:");
for (const c of spots) console.log(`  ${fs.existsSync(c) ? "[FOUND]" : "[     ]"} ${c}`);

const found = spots.find((c) => fs.existsSync(c));
if (!found) {
  console.log(`\n${line}\nNO DATABASE FILE in any spot above.`);
  console.log("Fix: re-extract the project zip (it ships db/custom.db), or create an empty one:\n  npx prisma db push\n");
  process.exit(1);
}

console.log(`\nTrying to open: ${found}`);
const { PrismaClient } = await import("@prisma/client");
const formats = [
  ["portable  file:<path>", "file:" + found.replace(/\\/g, "/")],
  ["encoded   file:// URL", pathToFileURL(found).href],
];
let working = null;
for (const [label, url] of formats) {
  const pc = new PrismaClient({ datasourceUrl: url });
  try {
    await pc.$connect();
    const bills = await pc.bill.count();
    console.log(`  [OK]   ${label}  → connected, bills in db: ${bills}`);
    working = url;
    await pc.$disconnect();
    break;
  } catch (e) {
    const msg = String(e?.message ?? e);
    const codeLine = msg.split("\n").find((l) => l.includes("Error code")) ?? msg.split("\n")[0];
    console.log(`  [FAIL] ${label}\n         ${codeLine}`);
    try { await pc.$disconnect(); } catch {}
  }
}

console.log(`\n${line}`);
if (working) {
  console.log("ALL GOOD — the app will run. Start it with:  npm run dev");
  if (working !== formats[0][1])
    console.log(`Your machine prefers the encoded form — put this line in .env and restart:\nDATABASE_URL="${working}"`);
  else console.log(`If the app still complains, put this line in .env and restart:\nDATABASE_URL="${working}"`);
} else {
  console.log("Every format failed. Copy this entire output and send it back.");
}

// AI copilot check (needs GROQ_API_KEY in .env on the user's machine)
let groq = null;
try {
  const txt2 = fs.readFileSync(path.join(cwd, ".env"), "utf8");
  const m2 = txt2.split(/\r?\n/).find((l) => /^\s*GROQ_API_KEY\s*=/.test(l));
  if (m2) {
    const v = m2.slice(m2.indexOf("=") + 1).trim().replace(/^["']|["']$/g, "");
    if (v && !v.startsWith("gsk_your_key")) groq = v;
  }
} catch {}
console.log(`\nAI copilot: ${groq ? `GROQ_API_KEY is set (${groq.slice(0, 6)}...${groq.slice(-4)})` : "GROQ_API_KEY not set — paste your key in .env (free: console.groq.com/keys), then restart"}`);
console.log("");
