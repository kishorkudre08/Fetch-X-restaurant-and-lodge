// Seed script: JAYA'S KITCHEN — 100% pure vegetarian menu.
// Run directly: bun scripts/seed.ts   (seeds only if menu is empty)
// Or import MENU from here. Reset data: bun scripts/reset-data.ts
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

export type Row = [name: string, price: number, cat: string];

// Every dish is vegetarian — Jaya's Kitchen is a pure-veg restaurant.
export const MENU: Row[] = [
  // Starters
  ["Paneer Tikka", 220, "Starters"],
  ["Hara Bhara Kebab", 190, "Starters"],
  ["Crispy Corn", 150, "Starters"],
  ["Veg Manchurian", 160, "Starters"],
  ["Gobi 65", 130, "Starters"],
  ["Paneer Chilli Dry", 240, "Starters"],
  ["Mushroom Pepper Fry", 190, "Starters"],
  ["Cheese Balls", 180, "Starters"],
  ["Veg Spring Rolls", 150, "Starters"],
  ["Corn Cheese Balls", 170, "Starters"],
  // Main Course
  ["Paneer Butter Masala", 260, "Main Course"],
  ["Kadai Paneer", 250, "Main Course"],
  ["Palak Paneer", 240, "Main Course"],
  ["Malai Kofta", 240, "Main Course"],
  ["Navratan Kurma", 240, "Main Course"],
  ["Methi Malai Mutter", 230, "Main Course"],
  ["Mushroom Do Pyaza", 230, "Main Course"],
  ["Veg Jalfrezi", 210, "Main Course"],
  ["Veg Kolhapuri", 220, "Main Course"],
  ["Chana Masala", 190, "Main Course"],
  ["Dal Tadka", 170, "Main Course"],
  ["Dal Fry", 150, "Main Course"],
  // Breads
  ["Tandoori Roti", 25, "Breads"],
  ["Butter Naan", 55, "Breads"],
  ["Garlic Naan", 70, "Breads"],
  ["Lachha Paratha", 60, "Breads"],
  ["Kulcha", 50, "Breads"],
  // Rice & Biryani
  ["Veg Biryani", 200, "Rice & Biryani"],
  ["Paneer Biryani", 240, "Rice & Biryani"],
  ["Veg Dum Biryani", 230, "Rice & Biryani"],
  ["Veg Fried Rice", 160, "Rice & Biryani"],
  ["Schezwan Fried Rice", 180, "Rice & Biryani"],
  ["Jeera Rice", 120, "Rice & Biryani"],
  ["Curd Rice", 90, "Rice & Biryani"],
  // Desserts
  ["Gulab Jamun (2 pc)", 80, "Desserts"],
  ["Rasmalai (2 pc)", 110, "Desserts"],
  ["Gajar Halwa", 100, "Desserts"],
  ["Brownie with Ice Cream", 150, "Desserts"],
  ["Kesari Bath", 60, "Desserts"],
  // Beverages
  ["Masala Chai", 30, "Beverages"],
  ["Filter Coffee", 45, "Beverages"],
  ["Sweet Lassi", 70, "Beverages"],
  ["Salt Lassi", 65, "Beverages"],
  ["Fresh Lime Soda", 60, "Beverages"],
  ["Masala Buttermilk", 55, "Beverages"],
];

export async function seedMenu() {
  const existing = await db.dish.count();
  if (existing > 0) {
    console.log(`Menu already seeded (${existing} dishes). Skipping.`);
    return;
  }
  await db.dish.createMany({
    data: MENU.map(([name, price, category]) => ({ name, price, category, veg: true })),
  });
  console.log(`Seeded ${MENU.length} pure-veg dishes.`);
}

async function main() {
  await seedMenu();
}

if (import.meta.main) {
  main()
    .catch((e) => {
      console.error(e);
      process.exit(1);
    })
    .finally(() => db.$disconnect());
}
