#!/usr/bin/env node
/* Detached launcher for Fetch-X dev server. Stays alive after the spawning
   shell exits by re-spawning if the child dies. */
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(projectDir);

const nextBin = path.join(projectDir, "node_modules", "next", "dist", "bin", "next");
const port = process.env.PORT || "3000";

function start() {
  const child = spawn(process.execPath, [nextBin, "dev", "-p", port], {
    cwd: projectDir,
    stdio: "inherit",
    env: { ...process.env, FX_PROJECT_DIR: projectDir, NODE_ENV: "development" },
  });
  child.on("exit", (code, signal) => {
    console.log(`[fetchx-relaunch] child exited code=${code} signal=${signal} — respawning in 2s`);
    setTimeout(start, 2000);
  });
  process.on("SIGTERM", () => child.kill("SIGTERM"));
  process.on("SIGINT", () => child.kill("SIGINT"));
}

start();
