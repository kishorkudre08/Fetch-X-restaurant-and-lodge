/* t144 — backfill MISSING days only. The owner left the project idle for a
 * few days so the dashboard's TODAY / 7D windows were showing ₹0.
 *
 * This script inspects the last N days and, for any day that has NO
 * restaurant bills AND NO lodge bills (truly empty), generates a realistic
 * day of activity:
 *   · restaurant bills (~30 / day, weekend boost, meal-hour shaped)
 *   · lodge checkouts (~40 / day, weekend boost, tier-rate × hours ÷ 24)
 *   · one station expense (raw / upgrade / maintenance, alternating book)
 *   · one owner task (open or done) on a few of the days
 *
 * Days that already have data are LEFT ALONE — running twice is safe.
 *
 * Usage:  DATABASE_URL=file:...db node scripts/seed-backfill.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const IST = 330 * 60000;
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.round(rnd(a, b));
const r2 = (n) => Math.round(n * 100) / 100;

const GUESTS = [
  "Ramesh Kulkarni", "Priya Deshpande", "Arjun Mehta", "Sneha Patil", "Vikram Joshi",
  "Anita Desai", "Rahul Verma", "Kavita Rao", "Suresh Babu", "Meena Nair",
  "Prakash Gowda", "Shobha Kamath", "Mohan Pai", "Lata Hegde", "Girish Prabhu",
  "Deepak Iyer", "Farida Sheikh", "Bhaskar Reddy", "Nisha Pillai", "Anand Subramaniam",
];

/* IST hour → order weight (breakfast, lunch, evening peaks) */
const HOUR_W = [
  2, 1, 0.5, 0.5, 0.5, 1, 3, 8, 10, 8, 8, 14, 16, 12, 8, 8, 10, 12, 14, 15, 12, 8, 5, 3,
];

const DEFAULT_LEVELS = [
  { from: 1, to: 40, rate: 2499, name: "BASIC" },
  { from: 41, to: 80, rate: 2999, name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, name: "LUXURY" },
];

function stayHours() {
  const tot = [[rnd(6, 12), 20], [rnd(20, 30), 32], [rnd(44, 54), 26], [rnd(68, 100), 22]];
  const w = tot.reduce((s, [, x]) => s + x, 0);
  let r = Math.random() * w;
  for (const [v, x] of tot) { r -= x; if (r <= 0) return v; }
  return tot[tot.length - 1][0];
}

function istDayKey(ts) {
  return new Date(ts + IST).toISOString().slice(0, 10);
}

/* IST day start (UTC midnight of the IST day) */
function istDayStart(ts) {
  const d = new Date(ts + IST);
  d.setUTCHours(0, 0, 0, 0);
  return d.getTime() - IST;
}

async function main() {
  console.log("── seed-backfill start ──");
  const now = Date.now();
  const DAYS = 7; // look back 7 IST days (today + 6 prior)
  const todayStart = istDayStart(now);

  const dishes = await db.dish.findMany({ where: { active: true }, select: { id: true, name: true, price: true, category: true } });
  if (dishes.length < 5) throw new Error("menu too small to seed from — run seed scripts first");

  const lvlRow = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  let levels = DEFAULT_LEVELS;
  try {
    const parsed = JSON.parse(lvlRow?.value ?? "null");
    if (Array.isArray(parsed) && parsed.length) levels = parsed;
  } catch { /* defaults */ }

  // Anchors for bill numbers
  const lastBill = await db.bill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let billNo = (lastBill?.number ?? 1000) + 1;
  const lastLodge = await db.lodgeBill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let lodgeNo = (lastLodge?.number ?? 5000) + 1;

  // Snapshot existing activity per day in the window (so we skip days that
  // already have data — leaves real/seeded history untouched).
  const since = todayStart - (DAYS - 1) * DAY;
  const [existingBills, existingLodge] = await Promise.all([
    db.bill.findMany({ where: { createdAt: { gte: new Date(since) } }, select: { createdAt: true } }),
    db.lodgeBill.findMany({ where: { createdAt: { gte: new Date(since) } }, select: { createdAt: true } }),
  ]);
  // Count by IST day — only treat a day as "already has data" if it has
  // >= 5 restaurant bills AND >= 5 lodge bills. A leftover 1-2 bills from
  // API tests doesn't count as a real day.
  const restByDay = new Map();
  for (const b of existingBills) {
    const k = istDayKey(b.createdAt.getTime());
    restByDay.set(k, (restByDay.get(k) ?? 0) + 1);
  }
  const lodgeByDay = new Map();
  for (const b of existingLodge) {
    const k = istDayKey(b.createdAt.getTime());
    lodgeByDay.set(k, (lodgeByDay.get(k) ?? 0) + 1);
  }
  const haveRest = new Set([...restByDay.entries()].filter(([, n]) => n >= 5).map(([k]) => k));
  const haveLodge = new Set([...lodgeByDay.entries()].filter(([, n]) => n >= 5).map(([k]) => k));

  const EXP_BANK = [
    ["raw_material", "rest", "Vegetables + dairy top-up"],
    ["raw_material", "rest", "Spices and oil refill"],
    ["maintenance", "lodge", "Plumber — leaking tap, room wing 2"],
    ["upgrade", "rest", "New counter LED sign"],
    ["raw_material", "lodge", "Toiletries + linen restock"],
    ["maintenance", "rest", "Chimney deep-clean service"],
    ["upgrade", "lodge", "Replace corridor carpet — wing 1"],
    ["maintenance", "lodge", "AC service — room 207"],
  ];

  const OPEN_TASK_BANK = [
    { title: "Restock the reception stationery drawer", book: "lodge", kind: "raw_material", maxBudget: 1500, desc: "Printed forms, pens, key tags — needs ~150 prints." },
    { title: "Print this week's specials cards", book: "rest", kind: null, maxBudget: null, desc: "Table cards for the 3 new starters — 40 prints." },
    { title: "Service the kitchen mixer", book: "rest", kind: "maintenance", maxBudget: 2000, desc: "Planetary mixer — bearing noise, needs lubrication." },
    { title: "Refill lobby drinking-water dispenser", book: "lodge", kind: null, maxBudget: null, desc: "Stock the dispenser + spare bottles at reception." },
    { title: "Replace blown corridor bulb (wing 2)", book: "lodge", kind: "maintenance", maxBudget: 600, desc: "Bulb above room 207 — flickered out overnight." },
    { title: "Polish the brass bell at the entrance", book: "lodge", kind: "upgrade", maxBudget: 800, desc: "Tarnished — needs brass polish + soft cloth." },
  ];
  const DONE_TASK_BANK = [
    { title: "Repaint the reception notice board", book: "lodge", kind: "upgrade", maxBudget: 2500, desc: "Fresh coat on the notice board beside the front desk.", cost: 1800 },
    { title: "Restock menu printouts for the counter", book: "rest", kind: "raw_material", maxBudget: 1000, desc: "200 menu sheets — counter ran out yesterday.", cost: 740 },
    { title: "Replace the lodge front-desk chair caster", book: "lodge", kind: "maintenance", maxBudget: 500, desc: "One wheel snapped off — replace the caster set.", cost: 320 },
    { title: "Refill cooking-gas cylinder (restaurant)", book: "rest", kind: "raw_material", maxBudget: 2200, desc: "Swap the empty cylinder before lunch service.", cost: 2050 },
  ];

  let totalBills = 0, totalItems = 0, totalLodge = 0, totalExp = 0, totalTasks = 0;
  const filled = [];
  const skipped = [];

  for (let d = DAYS - 1; d >= 0; d--) {
    const dayStart = todayStart - d * DAY;
    const dayEnd = d === 0 ? now : dayStart + DAY;
    const key = istDayKey(dayStart);
    if (haveRest.has(key) || haveLodge.has(key)) {
      skipped.push(key);
      continue;
    }

    filled.push(key);
    const dow = new Date(dayStart).getUTCDay();
    const weekend = dow === 5 || dow === 6 || dow === 0 ? 1.18 : 1;

    /* ── restaurant bills ─────────────────────────────────────────── */
    const target = Math.max(14, Math.round(30 * weekend + rnd(-5, 5)));
    const buckets = [];
    for (let h = 0; h < 24; h++) {
      const slot = dayStart + h * 3_600_000;
      if (slot >= dayEnd) break;
      buckets.push({ slot, w: HOUR_W[h] * (d === 0 ? Math.max(0.25, (dayEnd - slot) / 3_600_000) : 1) });
    }
    const wTot = buckets.reduce((s, b) => s + b.w, 0);
    for (let k = 0; k < target; k++) {
      let r = Math.random() * wTot, at = buckets[buckets.length - 1].slot;
      for (const b of buckets) { r -= b.w; if (r <= 0) { at = b.slot; break; } }
      at = Math.min(at + Math.random() * 3_600_000, dayEnd - 60_000);

      const lines = irnd(1, 4);
      const picks = [];
      for (let i = 0; i < lines; i++) {
        const dish = dishes[irnd(0, dishes.length - 1)];
        const qty = Math.random() < 0.72 ? 1 : 2;
        picks.push({ dish, qty });
      }
      const subtotal = r2(picks.reduce((s, p) => s + p.dish.price * p.qty, 0));
      const discount = Math.random() < 0.12 ? r2(subtotal * 0.05) : 0;
      const tax = r2((subtotal - discount) * 0.05);
      const total = r2(subtotal - discount + tax);
      const units = picks.reduce((s, p) => s + p.qty, 0);
      const created = new Date(at);
      const bill = await db.bill.create({
        data: {
          number: billNo++, subtotal, discount, tax, total, itemCount: units, createdAt: created,
          items: {
            create: picks.map((p) => ({
              dishId: p.dish.id, name: p.dish.name, category: p.dish.category, qty: p.qty, price: p.dish.price,
            })),
          },
        },
      });
      void bill; totalBills++; totalItems += units;
    }

    /* ── lodge checkouts ───────────────────────────────────────────── */
    const lodgeCount = Math.max(20, Math.round(40 * weekend + rnd(-4, 4)));
    const rows = [];
    for (let k = 0; k < lodgeCount; k++) {
      const room = 1 + Math.floor(Math.random() * 100);
      const lv = levels.find((l) => room >= l.from && room <= l.to) ?? levels[0];
      const hours = stayHours();
      const checkOut = new Date(dayStart + Math.random() * (dayEnd - dayStart));
      const checkIn = new Date(checkOut.getTime() - hours * 3_600_000);
      if (checkIn.getTime() > now) continue;
      const raw = Math.round((lv.rate * hours) / 24);
      const min = raw < 1000;
      const stay = min ? 1000 : raw;
      const tax = Math.round(stay * 5) / 100;
      rows.push({
        number: lodgeNo++, room,
        guestName: GUESTS[irnd(0, GUESTS.length - 1)],
        guestPhone: "97" + irnd(10000000, 99999999),
        tier: lv.name, rate: lv.rate, checkInAt: checkIn, checkOutAt: checkOut,
        hours: r2(hours), stay, minApplied: min, discount: 0, tax, total: r2(stay + tax),
        createdAt: checkOut,
      });
    }
    if (rows.length) {
      for (let i = 0; i < rows.length; i += 500) await db.lodgeBill.createMany({ data: rows.slice(i, i + 500) });
      totalLodge += rows.length;
    }

    /* ── one station expense ──────────────────────────────────────── */
    if (Math.random() > 0.18) {
      const e = EXP_BANK[irnd(0, EXP_BANK.length - 1)];
      await db.expense.create({
        data: {
          kind: e[0], book: e[1], label: e[2],
          amount: r2(rnd(800, 6000)),
          spentOn: new Date(dayStart + 6 * 3_600_000),
        },
      });
      totalExp++;
    }

    /* ── a task — alternately open or done ────────────────────────── */
    if (Math.random() > 0.4) {
      if (Math.random() < 0.55) {
        // open task — deadline 1-3 days from this day
        const t = OPEN_TASK_BANK[irnd(0, OPEN_TASK_BANK.length - 1)];
        await db.task.create({
          data: {
            title: t.title, book: t.book, kind: t.kind, maxBudget: t.maxBudget,
            description: t.desc, deadline: new Date(dayEnd + irnd(1, 3) * DAY),
            status: "open", createdBy: "Owner",
            createdAt: new Date(dayStart + 9 * 3_600_000),
            updates: {
              create: [
                { author: "Owner", role: "owner", message: `Forwarded from the back office — deadline ${new Date(dayEnd + 2 * DAY).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata" })}.`, createdAt: new Date(dayStart + 9 * 3_600_000) },
              ],
            },
          },
        });
      } else {
        // done task — closed with cost within budget
        const t = DONE_TASK_BANK[irnd(0, DONE_TASK_BANK.length - 1)];
        const cost = t.cost ?? r2(rnd(400, Math.min(t.maxBudget ?? 2000, 2000)));
        const kind = t.kind ?? "raw_material";
        const createdAt = new Date(dayStart + 9 * 3_600_000);
        const doneAt = new Date(dayStart + 16 * 3_600_000);
        await db.task.create({
          data: {
            title: t.title, book: t.book, kind, maxBudget: t.maxBudget,
            description: t.desc, deadline: new Date(dayEnd + DAY),
            status: "done", createdBy: "Owner", createdAt,
            doneAt, doneBy: t.book === "lodge" ? "Lodge reception" : "Restaurant counter",
            actualCost: cost,
            updates: {
              create: [
                { author: "Owner", role: "owner", message: "Forwarded with a max budget — close with the actual spend.", createdAt },
                { author: t.book === "lodge" ? "Lodge reception" : "Restaurant counter", role: t.book === "lodge" ? "reception_lodge" : "reception_rest", message: `Marked DONE — ₹${cost.toLocaleString("en-IN")} spent.`, createdAt: doneAt },
              ],
            },
          },
        });
      }
      totalTasks++;
    }
  }

  console.log(`filled days:    ${filled.length}  [${filled.join(", ")}]`);
  console.log(`skipped days:   ${skipped.length}  [${skipped.join(", ")}]`);
  console.log(`restaurant bills: ${totalBills}  (${totalItems} items)`);
  console.log(`lodge bills:     ${totalLodge}`);
  console.log(`station expenses: ${totalExp}`);
  console.log(`tasks:           ${totalTasks}`);
  console.log("── seed-backfill done ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
