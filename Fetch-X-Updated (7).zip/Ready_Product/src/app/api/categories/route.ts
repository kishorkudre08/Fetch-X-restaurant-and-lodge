import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/categories — every dish section (user-extensible)
export async function GET() {
  const categories = await db.category.findMany({ orderBy: { createdAt: "asc" } });
  return NextResponse.json(categories);
}

// POST /api/categories — { name } — creates a new section (idempotent)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim().slice(0, 40);
    if (!name) return NextResponse.json({ error: "Section name is required" }, { status: 400 });

    const existing = await db.category.findUnique({ where: { name } });
    if (existing) return NextResponse.json(existing); // already there — fine
    const category = await db.category.create({ data: { name } });
    return NextResponse.json(category, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not add section" }, { status: 500 });
  }
}

// DELETE /api/categories?id=… — a section can only be removed when no LIVE
// dish still uses it (dishes on the menu lock it to protect the menu). Any
// already-removed (inactive) dishes under it are purged — past bills keep
// their frozen name/price snapshots, so history is untouched. The last
// remaining section can never be deleted.
export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  try {
    const category = await db.category.findUnique({ where: { id } });
    if (!category) return NextResponse.json({ error: "Section not found" }, { status: 404 });

    const live = await db.dish.count({ where: { category: category.name, active: true } });
    if (live > 0)
      return NextResponse.json(
        {
          error: `“${category.name}” still has ${live} dish${live === 1 ? "" : "es"} on the menu — remove or move them first`,
        },
        { status: 409 },
      );

    const sections = await db.category.count();
    if (sections <= 1)
      return NextResponse.json(
        { error: "Keep at least one section — the menu needs a section for new dishes" },
        { status: 409 },
      );

    const purged = await db.$transaction(async (tx) => {
      const gone = await tx.dish.deleteMany({ where: { category: category.name, active: false } });
      await tx.category.delete({ where: { id } });
      return gone.count;
    });
    return NextResponse.json({ ok: true, purged });
  } catch {
    return NextResponse.json({ error: "Could not delete section" }, { status: 500 });
  }
}
