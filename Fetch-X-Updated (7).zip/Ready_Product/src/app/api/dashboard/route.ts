import { NextRequest, NextResponse } from "next/server";
import { getDashboardData, parseRange } from "@/lib/analytics";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const range = parseRange(sp.get("range"));
  const customStart = sp.get("start") ?? undefined;
  const customEnd = sp.get("end") ?? undefined;
  console.log("[dashboard] range:", range, "customStart:", customStart, "customEnd:", customEnd);
  const data = await getDashboardData(range, { customStart, customEnd });
  console.log("[dashboard] buckets:", data.buckets?.length, "first:", data.buckets?.[0]?.label);
  return NextResponse.json(data);
}
