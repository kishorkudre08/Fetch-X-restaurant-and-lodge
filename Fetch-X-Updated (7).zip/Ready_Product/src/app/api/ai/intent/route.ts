import { NextRequest, NextResponse } from "next/server";
import { aiIntentDetect } from "@/lib/ai-client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* t187 — AI-DRIVEN INTENT DETECTION ROUTE
 *
 * The AI panel calls this BEFORE the regular /api/ai chat endpoint. A fast
 * LLM reads the user's message + current screen context and returns a
 * structured JSON action. The panel then EXECUTES that action
 * deterministically (navigate to a section, apply toggles, expand the
 * panel, etc.) — no regex guessing.
 *
 * Provider order (mirrors the main /api/ai route):
 *   1. Groq (llama-3.1-8b-instant, JSON mode) when GROQ_API_KEY is set
 *   2. Z.ai SDK fallback (sandbox / .z-ai-config)
 *
 * Returns:
 *   200 — { intent, view?, toggles?, panelAction?, sidebarAction?, reply }
 *   503 — no provider configured (the panel falls back to regex)
 *   500 — provider error (the panel falls back to regex)
 *
 * The panel ALWAYS falls back to the regex detector if this route returns
 * non-200, so the app keeps working even when the network is flaky.
 */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      message?: string;
      screenContext?: { sectionId: string | null; viewState: Record<string, unknown> | null };
    };
    const message = (body.message ?? "").trim();
    if (!message) {
      return NextResponse.json({ error: "Missing message" }, { status: 400 });
    }
    const screenContext = body.screenContext ?? { sectionId: null, viewState: null };

    const intent = await aiIntentDetect(message, screenContext);
    if (!intent) {
      // No provider configured at all — tell the panel to fall back to regex
      return NextResponse.json(
        { error: "Intent detection unavailable — set GROQ_API_KEY in .env or configure .z-ai-config" },
        { status: 503 },
      );
    }
    return NextResponse.json(intent);
  } catch (err) {
    const msg = String((err as Error)?.message ?? err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
