import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";

export const dynamic = "force-dynamic";

// GET /api/employees — full team (including removed, so they can be restored)
export async function GET() {
  const employees = await db.employee.findMany({
    orderBy: [{ active: "desc" }, { salary: "desc" }],
  });
  return NextResponse.json(employees);
}

// POST /api/employees — { name, role, salary(monthly) }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const role = String(body.role ?? "").trim() || "Staff";
    const salary = Number(body.salary);
    if (!name || !Number.isFinite(salary) || salary < 0)
      return NextResponse.json({ error: "Name and a valid salary are required" }, { status: 400 });

    const book = body.book === "lodge" ? "lodge" : "rest";
    const employee = await db.employee.create({ data: { name, role, salary, book } });
    invalidateDashboardCache();
    return NextResponse.json(employee, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not add employee" }, { status: 500 });
  }
}

// PATCH /api/employees — { id, name?, role?, salary?, active? }
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const id = String(body.id ?? "");
    if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

    const data: Record<string, unknown> = {};
    if (typeof body.name === "string" && body.name.trim()) data.name = body.name.trim();
    if (typeof body.role === "string" && body.role.trim()) data.role = body.role.trim();
    if (body.salary !== undefined) {
      const salary = Number(body.salary);
      if (!Number.isFinite(salary) || salary < 0)
        return NextResponse.json({ error: "Invalid salary" }, { status: 400 });
      data.salary = salary;
    }
    if (typeof body.active === "boolean") data.active = body.active;
    if (body.book === "rest" || body.book === "lodge") data.book = body.book;
    if (Object.keys(data).length === 0)
      return NextResponse.json({ error: "Nothing to update" }, { status: 400 });

    const employee = await db.employee.update({ where: { id }, data });
    invalidateDashboardCache();
    return NextResponse.json(employee);
  } catch {
    return NextResponse.json({ error: "Could not update employee" }, { status: 500 });
  }
}

// DELETE /api/employees?id=… — soft delete (keeps past salary history intact)
export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  try {
    await db.employee.update({ where: { id }, data: { active: false } });
    invalidateDashboardCache();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Could not remove employee" }, { status: 500 });
  }
}
