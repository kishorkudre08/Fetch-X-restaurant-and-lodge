import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

// PATCH /api/menu/[id] — edit name / price / category / veg / active
export async function PATCH(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  try {
    const body = await req.json();
    const data: {
      name?: string;
      price?: number;
      category?: string;
      veg?: boolean;
      active?: boolean;
    } = {};
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return NextResponse.json({ error: "Name cannot be empty" }, { status: 400 });
      data.name = name;
    }
    if (body.price !== undefined) {
      const price = Number(body.price);
      if (!Number.isFinite(price) || price <= 0)
        return NextResponse.json({ error: "Price must be positive" }, { status: 400 });
      data.price = price;
    }
    if (body.category !== undefined) data.category = String(body.category).trim();
    if (body.veg !== undefined) data.veg = Boolean(body.veg);
    if (body.active !== undefined) data.active = Boolean(body.active);

    const dish = await db.dish.update({ where: { id }, data });
    return NextResponse.json(dish);
  } catch {
    return NextResponse.json({ error: "Update failed" }, { status: 400 });
  }
}

// DELETE /api/menu/[id] — soft delete: bills keep their snapshot,
// so we deactivate instead of destroying history.
export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  try {
    const dish = await db.dish.update({ where: { id }, data: { active: false } });
    return NextResponse.json(dish);
  } catch {
    return NextResponse.json({ error: "Dish not found" }, { status: 404 });
  }
}
