import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";

export const dynamic = "force-dynamic";

// DELETE /api/bills/[id] — undo a restaurant bill from the dashboard feed.
// Removes the bill and every line item (cascade), so totals, trends and the
// top-dishes board recompute without it — exactly like tearing a wrong bill.
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const existing = await db.bill.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: "Bill not found" }, { status: 404 });
    await db.bill.delete({ where: { id } }); // BillItem rows cascade
    invalidateDashboardCache();
    return NextResponse.json({ ok: true, number: existing.number });
  } catch (e) {
    console.error("Bill undo failed:", e);
    return NextResponse.json({ error: "Could not undo the bill" }, { status: 500 });
  }
}
