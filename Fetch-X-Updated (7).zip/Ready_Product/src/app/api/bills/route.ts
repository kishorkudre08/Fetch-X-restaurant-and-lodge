import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";
import { getDiscountLimit } from "@/lib/settings";

export const dynamic = "force-dynamic";

const GST_RATE = 0.05;

// GET /api/bills?limit=20 — most recent bills with their items
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 20) || 20, 100);
  const bills = await db.bill.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { items: true },
  });
  return NextResponse.json(bills);
}

// POST /api/bills — THE ZERO-ENTRY DATA PIPELINE.
// The cashier only taps dishes + quantities. Prices are pulled from the menu,
// the timestamp is stamped here, and every line is written automatically.
// body: { items: [{ dishId, qty }], discount? }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const rawItems: Array<{ dishId?: unknown; qty?: unknown }> = Array.isArray(body.items)
      ? body.items
      : [];
    const discount = Math.max(0, Number(body.discount) || 0);

    // Merge duplicate dishes, validate quantities
    const qtyByDish = new Map<string, number>();
    for (const it of rawItems) {
      const dishId = String(it.dishId ?? "");
      const qty = Math.floor(Number(it.qty));
      if (!dishId || !Number.isFinite(qty) || qty <= 0) continue;
      qtyByDish.set(dishId, (qtyByDish.get(dishId) ?? 0) + qty);
    }
    if (qtyByDish.size === 0)
      return NextResponse.json({ error: "Bill has no items" }, { status: 400 });

    const dishIds = [...qtyByDish.keys()];
    const dishes = await db.dish.findMany({ where: { id: { in: dishIds }, active: true } });
    if (dishes.length !== dishIds.length)
      return NextResponse.json({ error: "One or more dishes are unavailable" }, { status: 400 });

    const lines = dishes.map((d) => {
      const qty = qtyByDish.get(d.id)!;
      return { dishId: d.id, name: d.name, category: d.category, qty, price: d.price };
    });

    const subtotal = lines.reduce((s, l) => s + l.qty * l.price, 0);
    // t143 — the owner's discount rule is re-checked SERVER-SIDE: whatever the
    // client sends, a reception can never write a discount above the limit %
    // of the bill's value (paise-exact, rounded down).
    const discLimit = await getDiscountLimit();
    const discCap = Math.floor(subtotal * discLimit) / 100;
    const safeDiscount = Math.min(discount, discCap);
    const taxable = Math.max(0, subtotal - safeDiscount);
    const tax = Math.round(taxable * GST_RATE * 100) / 100;
    const total = Math.round((taxable + tax) * 100) / 100;
    const itemCount = lines.reduce((s, l) => s + l.qty, 0);

    const bill = await db.$transaction(async (tx) => {
      // Successive numbering: normally count upward, but when an UNDO tore a
      // hole out of the series (e.g. #11268 was torn, #11269 exists), the next
      // bill reuses the first free number so the sequence never skips.
      const maxAgg = await tx.bill.aggregate({ _max: { number: true } });
      const count = await tx.bill.count();
      const max = maxAgg._max.number ?? 1000;
      let number: number;
      if (count === max - 1000) {
        number = max + 1; // dense series 1001…max — keep counting up
      } else {
        const nums = await tx.bill.findMany({ select: { number: true }, orderBy: { number: "asc" } });
        number = 1001;
        for (const n of nums) {
          if (n.number === number) number += 1;
          else break;
        }
      }
      return tx.bill.create({
        data: {
          number,
          subtotal: Math.round(subtotal * 100) / 100,
          discount: Math.round(safeDiscount * 100) / 100,
          tax,
          total,
          itemCount,
          items: {
            create: lines.map((l) => ({
              dishId: l.dishId,
              name: l.name,
              category: l.category,
              qty: l.qty,
              price: l.price,
            })),
          },
        },
        include: { items: true },
      });
    });

    // The instant a bill lands, the dashboard must reflect it on next fetch.
    invalidateDashboardCache();

    return NextResponse.json(bill, { status: 201 });
  } catch (e) {
    console.error("Bill creation failed:", e);
    return NextResponse.json({ error: "Bill generation failed" }, { status: 500 });
  }
}
