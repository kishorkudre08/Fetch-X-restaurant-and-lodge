import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { db } from "@/lib/db";
import { getDashboardData } from "@/lib/analytics";
import {
  parseLevels,
  parseMaxRooms,
  tierOfRoom,
  DEFAULT_LEVELS,
  MAX_ROOMS_KEY,
  lgStay,
} from "@/lib/lodge";
import { HOTEL_DEFAULT, PLATFORM } from "@/lib/brand";
import {
  getHotelName,
  getPaidHolidayLimit,
  getDiscountLimit,
  HOTEL_NAME_KEY,
  PAID_HOLIDAY_LIMIT_KEY,
  DISCOUNT_LIMIT_KEY,
} from "@/lib/settings";

export const dynamic = "force-dynamic";

// ═══════════════════════════════════════════════════════════════════════════
// FETCH-X AI DATA SNAPSHOT — /api/export
//
// Builds a complete, dynamically generated JSON snapshot of EVERYTHING the
// Fetch-X business system knows, at the exact moment the export runs, so an
// external AI can interpret the business without touching the app.
//
// Rules baked into this exporter:
//   · NO fake data, NO hardcoded values — every record comes from the live DB.
//   · The DB schema is the source of truth; fields that do not exist in the
//     app are exported as null WITH an honest note, never invented.
//   · Raw records AND calculated summaries ride together (raw = foundation,
//     analytics = precalculated context from the app's own dashboard engine).
//   · Relationships survive: employee_id, dish_id, room number, task_id all
//     stay consistent across sections.
//   · NO secrets: API keys, .env values and credentials are never read here.
//   · PRIVATE DATA tick box: UNTICKED (hide) swaps guest/employee/person
//     names for stable pseudonyms and drops phone numbers, so analysis
//     still works on IDs; TICKED (show) exports them exactly as stored.
// ═══════════════════════════════════════════════════════════════════════════

const round2 = (n: number) => Math.round(n * 100) / 100;

// ── IST (UTC+5:30) helpers — the whole Fetch-X analytics engine runs on IST ─
const IST_OFFSET_MIN = 330;
const istShift = (d: Date) => new Date(d.getTime() + IST_OFFSET_MIN * 60000);
const istDateKey = (d: Date) => istShift(d).toISOString().slice(0, 10); // YYYY-MM-DD
const istMonthKey = (d: Date) => istDateKey(d).slice(0, 7); // YYYY-MM
const istTime = (d: Date) => istShift(d).toISOString().slice(11, 19); // HH:mm:ss
/** Full ISO timestamp with the IST offset, e.g. "2026-10-06T20:15:42+05:30". */
const istIso = (d: Date) => istShift(d).toISOString().slice(0, 19) + "+05:30";
function istDayStart(d: Date): Date {
  const s = istShift(d);
  s.setUTCHours(0, 0, 0, 0);
  return new Date(s.getTime() - IST_OFFSET_MIN * 60000);
}
const DATE_KEY = /^\d{4}-\d{2}-\d{2}$/;

// ── Stable pseudonyms (djb2 → same input always maps to the same alias) ────
function pseudoOf(map: Map<string, string>, raw: string | null | undefined): string | null {
  if (raw == null) return null;
  const key = String(raw).trim();
  if (!key) return null;
  let hit = map.get(key);
  if (!hit) {
    let h = 5381;
    for (let i = 0; i < key.length; i++) h = ((h << 5) + h + key.charCodeAt(i)) >>> 0;
    hit = "Person-" + h.toString(16).padStart(8, "0").slice(0, 6);
    map.set(key, hit);
  }
  return hit;
}

function appVersion(): string | null {
  try {
    const base = process.env.FX_PROJECT_DIR?.trim() || process.cwd();
    const pkg = JSON.parse(fs.readFileSync(path.join(base, "package.json"), "utf8"));
    return typeof pkg?.version === "string" ? pkg.version : null;
  } catch {
    return null;
  }
}

// ── Generic aggregators (IST day / month buckets) ───────────────────────────
function byDay<T>(rows: T[], at: (r: T) => Date, value: (r: T) => number) {
  const m = new Map<string, { date: string; value: number; count: number }>();
  for (const r of rows) {
    const k = istDateKey(at(r));
    const e = m.get(k) ?? { date: k, value: 0, count: 0 };
    e.value += value(r);
    e.count += 1;
    m.set(k, e);
  }
  return [...m.values()]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((e) => ({ date: e.date, value: round2(e.value), count: e.count }));
}
function byMonth<T>(rows: T[], at: (r: T) => Date, value: (r: T) => number) {
  const m = new Map<string, { month: string; value: number; count: number }>();
  for (const r of rows) {
    const k = istMonthKey(at(r));
    const e = m.get(k) ?? { month: k, value: 0, count: 0 };
    e.value += value(r);
    e.count += 1;
    m.set(k, e);
  }
  return [...m.values()]
    .sort((a, b) => a.month.localeCompare(b.month))
    .map((e) => ({ month: e.month, value: round2(e.value), count: e.count }));
}
function byHour(rows: { createdAt: Date; total: number }[]) {
  const hours = Array.from({ length: 24 }, (_, h) => ({ hour: h, revenue: 0, bills: 0 }));
  for (const b of rows) {
    const h = istShift(b.createdAt).getUTCHours();
    hours[h].revenue += b.total;
    hours[h].bills += 1;
  }
  return hours.filter((x) => x.bills > 0).map((x) => ({ hour: x.hour, revenue: round2(x.revenue), bills: x.bills }));
}

// ── ANALYTICS INTEGRITY HARNESS ─────────────────────────────────────────────
// Every aggregate written to the analytics section is recomputed from the raw
// records included in this same export and compared to the value written.
// Money is compared with a ±0.5 ₹ tolerance (2-decimal rounding); counts must
// match exactly. Definitions that CANNOT be reconciled are never silently
// merged — they are labelled on the field and listed as warnings.
type IntegrityCheck = { name: string; ok: boolean; detail: string };
const I_TOL = 0.5; // rupee tolerance for 2-decimal rounding
const nearR = (a: number, b: number, tol = I_TOL) => Math.abs(a - b) <= tol;
const vSum = <T,>(rows: T[], f: (r: T) => number) => rows.reduce((s, r) => s + f(r), 0);
const marginPctOf = (profit: number, revenue: number) => (revenue > 0 ? round2((profit / revenue) * 100) : null);
/** Per-request harness factory — checks/warnings MUST NOT live at module level
 * or one export's audit would bleed into the next file. */
const makeIntegrity = () => {
  const checks: IntegrityCheck[] = [];
  const warnings: string[] = [];
  return {
    checks,
    warnings,
    check: (name: string, ok: boolean, detail: string) => checks.push({ name, ok, detail }),
    warn: (msg: string) => warnings.push(msg),
  };
};

export async function GET(req: NextRequest) {
  try {
    // per-request audit harness (never carry checks between exports)
    const { checks: integrityChecks, warnings: integrityWarnings, check: iCheck, warn: iWarn } = makeIntegrity();
    const sp = req.nextUrl.searchParams;

    // ── Mode: FULL (default) or a custom date range (from + to, YYYY-MM-DD) ──
    const fromRaw = sp.get("from");
    const toRaw = sp.get("to");
    const anonymize = sp.get("anonymize") === "1";
    const isRange = !!(fromRaw || toRaw);
    if (isRange && (!fromRaw || !toRaw || !DATE_KEY.test(fromRaw) || !DATE_KEY.test(toRaw) || fromRaw > toRaw)) {
      return NextResponse.json(
        { error: "Date-range export needs both from=YYYY-MM-DD and to=YYYY-MM-DD (from ≤ to)." },
        { status: 400 },
      );
    }
    const fromKey = isRange ? fromRaw! : null;
    const toKey = isRange ? toRaw! : null;
    // Datetime window for Bill / LodgeBill / Expense.spentOn / Task.createdAt —
    // the same IST day-bounding the dashboard's custom range uses.
    const dtStart = isRange ? istDayStart(new Date(fromKey! + "T00:00:00")) : null;
    const dtEnd = isRange ? new Date(istDayStart(new Date(toKey! + "T00:00:00")).getTime() + 86_400_000) : null;

    const now = new Date();

    // ── Wave 1 · current-state tables + config (never range-filtered) ───────
    const [dishes, categories, employees, rooms, settingsRows, holidayLimit, discountLimit, hotelName, counts] =
      await Promise.all([
        db.dish.findMany({ orderBy: [{ category: "asc" }, { name: "asc" }] }),
        db.category.findMany({ orderBy: { name: "asc" } }),
        db.employee.findMany({ orderBy: [{ book: "asc" }, { salary: "desc" }] }),
        db.room.findMany({ orderBy: { number: "asc" } }),
        db.setting.findMany({ orderBy: { key: "asc" } }),
        getPaidHolidayLimit(),
        getDiscountLimit(),
        getHotelName(),
        Promise.all([
          db.dish.count(),
          db.bill.count(),
          db.billItem.count(),
          db.employee.count(),
          db.attendance.count(),
          db.expense.count(),
          db.task.count(),
          db.taskUpdate.count(),
          db.category.count(),
          db.room.count(),
          db.lodgeBill.count(),
          db.salaryPayment.count(),
        ]),
      ]);
    const settingMap = new Map(settingsRows.map((s) => [s.key, s.value]));
    const [dishC, billC, billItemC, empC, attC, expC, taskC, taskUpC, catC, roomC, lodgeC, salC] = counts;

    // ── Wave 2 · historical business records (+ the app's own analytics) ────
    const billWhere = isRange ? { createdAt: { gte: dtStart!, lt: dtEnd! } } : {};
    const lodgeWhere = isRange ? { createdAt: { gte: dtStart!, lt: dtEnd! } } : {};
    const expenseWhere = isRange ? { spentOn: { gte: dtStart!, lt: dtEnd! } } : {};
    const taskWhere = isRange ? { createdAt: { gte: dtStart!, lt: dtEnd! } } : {};
    const attWhere = isRange ? { date: { gte: fromKey!, lte: toKey! } } : {};
    // Salary payments settle whole months — overlap with the picked months.
    const salaryWhere = isRange
      ? { month: { gte: fromKey!.slice(0, 7), lte: toKey!.slice(0, 7) } }
      : {};

    const [bills, lodgeBills, expenses, tasks, attendance, salaryPayments, dash] = await Promise.all([
      db.bill.findMany({ where: billWhere, include: { items: true }, orderBy: { createdAt: "asc" } }),
      db.lodgeBill.findMany({ where: lodgeWhere, orderBy: { createdAt: "asc" } }),
      db.expense.findMany({ where: expenseWhere, orderBy: { spentOn: "asc" } }),
      db.task.findMany({ where: taskWhere, include: { updates: { orderBy: { createdAt: "asc" } } }, orderBy: { createdAt: "asc" } }),
      db.attendance.findMany({ where: attWhere, orderBy: [{ date: "asc" }, { employeeId: "asc" }] }),
      db.salaryPayment.findMany({ where: salaryWhere, orderBy: [{ month: "asc" }, { employeeId: "asc" }] }),
      getDashboardData(
        isRange ? "custom" : "lifetime",
        isRange ? { customStart: fromKey!, customEnd: toKey! } : {},
      ),
    ]);

    // ── Anonymization maps (stable pseudonyms; phones are dropped entirely) ──
    const pseudo = new Map<string, string>();
    const an = (v: string | null | undefined) => (anonymize ? pseudoOf(pseudo, v) : v ?? null);
    const anReq = (v: string) => (anonymize ? pseudoOf(pseudo, v)! : v);

    // ════════ VERIFIED AGGREGATES — scope-clean, recomputed from the raw rows ══
    // Every figure here is derived ONLY from the records this export carries,
    // so an external AI can re-derive each one from the file itself. Scopes:
    //   restaurant = Bill receipts · lodge = LodgeBill bookings ·
    //   combined = same-window sums of both books (identical definitions).
    const isLodgeBook = (book: string) => book === "lodge";
    const bookOfEmp = new Map<string, "rest" | "lodge">(employees.map((e) => [e.id, isLodgeBook(e.book) ? "lodge" : "rest"] as const));
    const empById = new Map(employees.map((e) => [e.id, e]));

    // — restaurant scope —
    const vRest = {
      bills: bills.length,
      revenue: round2(vSum(bills, (b) => b.total)),
      subtotal: round2(vSum(bills, (b) => b.subtotal)),
      discounts: round2(vSum(bills, (b) => b.discount)),
      tax: round2(vSum(bills, (b) => b.tax)),
      items_counter: vSum(bills, (b) => b.itemCount), // the POS counter frozen on each bill
      line_items: vSum(bills, (b) => b.items.length), // receipt line rows
      units_sold: vSum(bills, (b) => vSum(b.items, (it) => it.qty)), // actual units
      avg_transaction: 0,
    };
    vRest.avg_transaction = vRest.bills ? round2(vRest.revenue / vRest.bills) : 0;

    // — lodge scope —
    const vLodge = {
      bookings: lodgeBills.length,
      revenue: round2(vSum(lodgeBills, (b) => b.total)),
      stay_charges: round2(vSum(lodgeBills, (b) => b.stay)),
      discounts: round2(vSum(lodgeBills, (b) => b.discount)),
      tax: round2(vSum(lodgeBills, (b) => b.tax)),
      stay_hours: round2(vSum(lodgeBills, (b) => b.hours)),
      avg_bill: 0,
      avg_stay_hours: 0,
    };
    vLodge.avg_bill = vLodge.bookings ? round2(vLodge.revenue / vLodge.bookings) : 0;
    vLodge.avg_stay_hours = vLodge.bookings ? round2(vLodge.stay_hours / vLodge.bookings) : 0;

    // — expenses by kind × book —
    const KINDS = ["raw_material", "upgrade", "maintenance"] as const;
    const expOf = (book: "rest" | "lodge" | null, kind: string | null) =>
      round2(
        vSum(
          expenses.filter((e) => (book === null || (book === "lodge" ? isLodgeBook(e.book) : !isLodgeBook(e.book))) && (kind === null || e.kind === kind)),
          (e) => e.amount,
        ),
      );
    const vExp = {
      rest: Object.fromEntries(KINDS.map((k) => [k, expOf("rest", k)])) as Record<string, number>,
      lodge: Object.fromEntries(KINDS.map((k) => [k, expOf("lodge", k)])) as Record<string, number>,
      total_rest: expOf("rest", null),
      total_lodge: expOf("lodge", null),
      total_combined: 0,
    };
    vExp.total_combined = round2(vExp.total_rest + vExp.total_lodge);

    // — salaries: SETTLED money (exact SalaryPayment rows), split by employee book —
    const vSal = { rest: 0, lodge: 0, combined: 0, rows: salaryPayments.length, paid_rows: 0, unattributable_rows: 0 };
    for (const p of salaryPayments) {
      const book = bookOfEmp.get(p.employeeId);
      if (!book) {
        vSal.unattributable_rows += 1;
        continue;
      }
      vSal[book] += p.netPaid;
      if (p.status === "paid") vSal.paid_rows += 1;
    }
    vSal.rest = round2(vSal.rest);
    vSal.lodge = round2(vSal.lodge);
    vSal.combined = round2(vSal.rest + vSal.lodge);
    const rosterMonthly = {
      rest: round2(vSum(employees.filter((e) => e.active && !isLodgeBook(e.book)), (e) => e.salary)),
      lodge: round2(vSum(employees.filter((e) => e.active && isLodgeBook(e.book)), (e) => e.salary)),
      combined: 0,
    };
    rosterMonthly.combined = round2(rosterMonthly.rest + rosterMonthly.lodge);

    // — tasks + budgets —
    const bookTasksOf = (book: "rest" | "lodge") => {
      const rows = tasks.filter((t) => (book === "lodge" ? isLodgeBook(t.book) : !isLodgeBook(t.book)));
      return { total: rows.length, done: rows.filter((t) => t.status !== "open").length, open: rows.filter((t) => t.status === "open").length };
    };
    const vTasks = { total: tasks.length, rest: bookTasksOf("rest"), lodge: bookTasksOf("lodge") };
    const budgeted = tasks.filter((t) => t.maxBudget != null);
    const budgetedTaskIds = new Set(budgeted.map((t) => t.id));
    const doneBudgeted = budgeted.filter((t) => t.status !== "open" && t.actualCost != null);
    const tiedExpenseRows = expenses.filter((e) => e.taskId && budgetedTaskIds.has(e.taskId));
    const vBudget = {
      allocated: round2(vSum(budgeted, (t) => t.maxBudget ?? 0)),
      used: round2(vSum(budgeted, (t) => t.actualCost ?? 0)),
      budgeted_tasks: budgeted.length,
      done_budgeted_tasks: doneBudgeted.length,
      over_budget_tasks: budgeted.filter((t) => t.actualCost != null && t.actualCost > (t.maxBudget ?? 0) + I_TOL).length,
      expense_rows_tied: tiedExpenseRows.length,
      expense_rupees_tied: round2(vSum(tiedExpenseRows, (e) => e.amount)),
      remaining: 0,
      utilization_pct: null as number | null,
    };
    vBudget.remaining = round2(vBudget.allocated - vBudget.used);
    vBudget.utilization_pct = vBudget.allocated ? round2((vBudget.used / vBudget.allocated) * 100) : null;

    // — attendance (register is not book-tagged; split via the employee roster) —
    const vAtt = {
      rows: attendance.length,
      present: 0,
      absent: 0,
      rest: { present: 0, absent: 0 },
      lodge: { present: 0, absent: 0 },
      inactive_roster_rows: 0,
      unattributable_rows: 0,
      marked_days: 0,
      attendance_pct: null as number | null,
    };
    for (const a of attendance) {
      if (a.status === "present") vAtt.present += 1;
      else vAtt.absent += 1;
      const book = bookOfEmp.get(a.employeeId);
      if (!book) {
        vAtt.unattributable_rows += 1;
        continue;
      }
      if (!empById.get(a.employeeId)?.active) vAtt.inactive_roster_rows += 1;
      if (a.status === "present") vAtt[book].present += 1;
      else vAtt[book].absent += 1;
    }
    vAtt.marked_days = vAtt.present + vAtt.absent;
    vAtt.attendance_pct = vAtt.marked_days ? round2((vAtt.present / vAtt.marked_days) * 100) : null;

    // — historical lodge occupancy from booking spans ∩ window —
    // FULL export: every completed stay is in the file → true span coverage.
    // DATE RANGE: only stays BILLED inside the window are carried, so spans
    // clip at the window edge (method note explains this).
    const occWinStart = isRange ? dtStart!.getTime() : lodgeBills.length ? Math.min(...lodgeBills.map((b) => b.checkInAt.getTime())) : null;
    const occWinEnd = isRange ? dtEnd!.getTime() : now.getTime();
    let vOccupancy: { room_hours_occupied: number; capacity_room_hours: number; occupancy_pct: number | null; window: { from: string; to: string } } | null = null;
    if (occWinStart && occWinEnd > occWinStart && rooms.length) {
      let rh = 0;
      for (const b of lodgeBills) {
        const from = Math.max(b.checkInAt.getTime(), occWinStart);
        const to = Math.min(b.checkOutAt.getTime(), occWinEnd);
        if (to > from) rh += (to - from) / 3600000;
      }
      rh = round2(rh);
      const capacity = round2((rooms.length * (occWinEnd - occWinStart)) / 3600000);
      vOccupancy = {
        room_hours_occupied: rh,
        capacity_room_hours: capacity,
        occupancy_pct: capacity > 0 ? round2((rh / capacity) * 100) : null,
        window: { from: istDateKey(new Date(occWinStart)), to: istDateKey(new Date(occWinEnd)) },
      };
    }

    // — scope + period anchors (used by every section below) —
    const periodFrom = isRange
      ? fromKey!
      : [
          ...bills.map((b) => b.createdAt),
          ...lodgeBills.map((b) => b.createdAt),
          ...expenses.map((e) => e.spentOn),
          ...tasks.map((t) => t.createdAt),
          ...employees.map((e) => e.createdAt),
        ].reduce<string | null>((min, d) => {
          const k = istDateKey(d);
          return !min || k < min ? k : min;
        }, null) ?? istDateKey(now);
    const periodTo = isRange ? toKey! : istDateKey(now);
    // The dashboard engine's own accrual start: the custom range's first day,
    // or (lifetime) the first restaurant bill's IST day.
    const dashStartKey = isRange ? fromKey! : bills.length ? istDateKey(bills[0].createdAt) : istDateKey(now);

    // — window-bounded salary accrual replica (verifies the dashboard's own
    // accrual in FULL exports; offered as a labelled estimate otherwise) —
    // Eligible only when the window starts at a month boundary: the accrual
    // rule counts each month's paid-holiday allowance from the 1st, so a
    // mid-month start would need attendance rows OUTSIDE this export.
    const accrualEligible = !isRange || fromKey!.slice(8, 10) === "01";
    const accrualBetween = (startKey: string, endKey: string): { rest: number; lodge: number; total: number } => {
      const active = employees.filter((e) => e.active);
      if (!active.length) return { rest: 0, lodge: 0, total: 0 };
      const marks = new Map<string, Map<string, string>>();
      for (const a of attendance) {
        let m = marks.get(a.employeeId);
        if (!m) marks.set(a.employeeId, (m = new Map()));
        m.set(a.date, a.status);
      }
      const nextKey = (k: string) => istDateKey(new Date(istDayStart(new Date(k + "T00:00:00")).getTime() + 86_400_000));
      const daysInMonthOf = (k: string) => {
        const [y, m] = k.split("-").map(Number);
        return new Date(y, m, 0).getDate();
      };
      const out = { rest: 0, lodge: 0, total: 0 };
      for (const e of active) {
        const m = marks.get(e.id);
        if (!m || m.size === 0) continue;
        const book = isLodgeBook(e.book) ? "lodge" : "rest";
        let cursor = startKey;
        let monthCursor = cursor.slice(0, 7);
        let monthAbsences = 0;
        for (const [date, st] of m) if (st === "absent" && date.slice(0, 7) === monthCursor && date < startKey) monthAbsences += 1;
        let perDay = e.salary / daysInMonthOf(cursor);
        while (cursor <= endKey) {
          const mk = cursor.slice(0, 7);
          if (mk !== monthCursor) {
            monthCursor = mk;
            monthAbsences = 0;
            perDay = e.salary / daysInMonthOf(cursor);
          }
          const st = m.get(cursor);
          if (st === "present") out[book] += perDay;
          else if (st === "absent") {
            monthAbsences += 1;
            if (monthAbsences <= holidayLimit) out[book] += perDay;
          }
          cursor = nextKey(cursor);
        }
      }
      out.rest = round2(out.rest);
      out.lodge = round2(out.lodge);
      out.total = round2(out.rest + out.lodge);
      return out;
    };
    // Dashboard-definition replica: same start AND end the live dashboard uses
    // (window start → export moment). Exact verification target in FULL mode.
    const dashAccrualReplica = accrualEligible ? accrualBetween(dashStartKey, istDateKey(now)) : null;
    // Window-bounded replica: salary money the attendance register says the
    // window itself cost (end bounded by the export's own period).
    const windowAccrualReplica = accrualEligible ? accrualBetween(dashStartKey, periodTo) : null;

    // — scope-clean profit (settled-salary basis, same window for every term) —
    const vProfit = {
      rest: round2(vRest.revenue - vRest.discounts - vExp.total_rest - vSal.rest),
      lodge: round2(vLodge.revenue - vLodge.discounts - vExp.total_lodge - vSal.lodge),
      combined: 0,
    };
    vProfit.combined = round2(vProfit.rest + vProfit.lodge);

    // — all-time figures (labelled separately from the window) —
    // FULL export: the file already carries every record, so all-time = the
    // verified window sums. DATE RANGE: queried from the live database —
    // intentionally broader than this file's records (stated on the field).
    const allTimeFigures = isRange
      ? await Promise.all([
          db.bill.aggregate({ _count: true, _sum: { total: true } }),
          db.lodgeBill.aggregate({ _count: true, _sum: { total: true } }),
        ])
      : null;
    const vAllTime: {
      restaurant: { bills: number; revenue: number };
      lodge: { bookings: number; revenue: number };
      combined: { revenue: number; transactions: number };
    } = isRange
      ? {
          restaurant: { bills: allTimeFigures![0]._count, revenue: round2(allTimeFigures![0]._sum.total ?? 0) },
          lodge: { bookings: allTimeFigures![1]._count, revenue: round2(allTimeFigures![1]._sum.total ?? 0) },
          combined: { revenue: 0, transactions: 0 },
        }
      : {
          restaurant: { bills: vRest.bills, revenue: vRest.revenue },
          lodge: { bookings: vLodge.bookings, revenue: vLodge.revenue },
          combined: { revenue: 0, transactions: 0 },
        };
    vAllTime.combined = { revenue: round2(vAllTime.restaurant.revenue + vAllTime.lodge.revenue), transactions: vAllTime.restaurant.bills + vAllTime.lodge.bookings };

    // ══════════════════════════ METADATA ══════════════════════════
    const fileStamp = istShift(now).toISOString().slice(0, 19).replace("T", "_").replace(/:/g, "-");

    const fetchx_export = {
      schema_version: "1.0",
      generator: `${PLATFORM.name} AI Data Snapshot exporter`,
      exported_at: istIso(now),
      exported_at_iso_utc: now.toISOString(),
      file_timestamp: fileStamp,
      timezone: "Asia/Kolkata",
      timezone_note: "Every timestamp in this export is IST (UTC+05:30) — the timezone the whole application runs on. Datetimes are also given as ISO strings.",
      application: {
        name: PLATFORM.name,
        tagline: PLATFORM.tagline,
        version: appVersion(),
        modules: ["restaurant POS", "menu", "lodge front desk", "attendance", "salary", "expenses", "tasks", "dashboard", "AI copilot"],
      },
      database: {
        engine: "SQLite (single file)",
        orm: "Prisma",
        lifetime_row_counts: {
          dishes: dishC,
          restaurant_bills: billC,
          restaurant_bill_items: billItemC,
          employees: empC,
          attendance_records: attC,
          expenses: expC,
          tasks: taskC,
          task_updates: taskUpC,
          menu_categories: catC,
          rooms: roomC,
          lodge_bills: lodgeC,
          salary_payments: salC,
        },
      },
      export_mode: isRange ? "date_range" : "full",
      data_period: {
        from: periodFrom,
        to: periodTo,
        scope: "combined — every business record the filters cover (restaurant + lodge + shared books)",
        covered_by_filters: isRange
          ? `Only records dated ${fromKey} → ${toKey} (IST calendar days) are included; current-state tables (menu, rooms, employees, settings) are always exported whole.`
          : "Full history — every record the database holds.",
      },
      anonymized: anonymize,
      anonymization_note: anonymize
        ? "ON — private data is hidden: every guest/employee/person name is replaced by a stable pseudonym (the same original name always maps to the same pseudonym, so relationships survive); phone numbers are removed."
        : "OFF — private data is shown: names and phone numbers are exported as stored.",
      currency: "INR",
      record_counts: {
        receipts: bills.length,
        lodge_bookings: lodgeBills.length,
        expenses: expenses.length,
        tasks: tasks.length,
        employees: employees.length,
        attendance_records: attendance.length,
        salary_payments: salaryPayments.length,
        menu_dishes: dishes.length,
        rooms: rooms.length,
      },
    };

    // ══════════════════════════ BUSINESS ══════════════════════════
    const business = {
      name: hotelName,
      type: "restaurant + lodge (both operated under one roof, separate cost books)",
      unique_business_id: null as string | null,
      currency: "INR",
      currency_symbol: "₹",
      timezone: "Asia/Kolkata",
      receipt_identity: {
        note: "Fixed header printed on every bill (platform receipt identity).",
        tagline: HOTEL_DEFAULT.tagline,
        address: HOTEL_DEFAULT.address,
        phone: HOTEL_DEFAULT.phone,
        gstin: HOTEL_DEFAULT.gstin,
        fssai: HOTEL_DEFAULT.fssai,
        cashier_line: HOTEL_DEFAULT.cashier,
      },
      tenant_config: {
        note: "Operating rules the owner set inside Fetch-X (the Setting table).",
        hotel_name: settingMap.get(HOTEL_NAME_KEY) ?? hotelName,
        paid_holiday_limit_per_month: holidayLimit,
        discount_limit_percent_per_bill: discountLimit,
        lodge_max_rooms: parseMaxRooms(settingMap.get(MAX_ROOMS_KEY) ?? null),
        lodge_levels: parseLevels(settingMap.get("lodgeLevels") ?? null, parseMaxRooms(settingMap.get(MAX_ROOMS_KEY) ?? null)) ?? DEFAULT_LEVELS,
        raw_settings: settingsRows.map((s) => ({ key: s.key, value: s.value, updated_at: istIso(s.updatedAt) })),
      },
      tax_rule: "5% GST on both restaurant and lodge bills (printed as CGST 2.5% + SGST 2.5%).",
      lodge_billing_rule: "Lodge stays bill to the hour: tier rate × hours ÷ 24, never below the ₹1,000 floor (minApplied marks bills where the floor kicked in).",
      salary_rule: "Salaries are monthly INR. Absences beyond the paid-holiday limit cut per-day wages (monthly salary ÷ days in that month). SalaryPayment freezes what was actually paid.",
      expense_kinds: "raw_material (groceries & consumables) | upgrade (furniture, signage, equipment) | maintenance (repairs, gas, pest control). Each row also carries a book: rest (restaurant) or lodge.",
    };

    // ══════════════════════════ RECEIPTS (raw restaurant bills) ══════════════════════════
    const receipts = bills.map((b) => ({
      receipt_id: b.id,
      number: b.number,
      printed_as: `#${b.number}`,
      date: istDateKey(b.createdAt),
      time: istTime(b.createdAt),
      created_at: istIso(b.createdAt),
      item_count: b.itemCount,
      items: b.items.map((it) => ({
        item_id: it.id,
        dish_id: it.dishId, // joins to menu.dishes — null if the dish was later deleted from the menu
        name: it.name,
        category: it.category,
        quantity: it.qty,
        unit_price: round2(it.price), // price snapshot frozen at sale time
        line_total: round2(it.qty * it.price),
      })),
      subtotal: round2(b.subtotal),
      discount: round2(b.discount),
      tax: round2(b.tax),
      total: round2(b.total),
    }));

    // ══════════════════════════ MENU (complete, current) ══════════════════════════
    const dishSales = new Map<string, { qty: number; revenue: number; bills: Set<string>; last: string | null }>();
    for (const b of bills) {
      const d = istDateKey(b.createdAt);
      for (const it of b.items) {
        if (!it.dishId) continue;
        const e = dishSales.get(it.dishId) ?? { qty: 0, revenue: 0, bills: new Set<string>(), last: null };
        e.qty += it.qty;
        e.revenue += it.qty * it.price;
        e.bills.add(b.id);
        if (!e.last || d > e.last) e.last = d;
        dishSales.set(it.dishId, e);
      }
    }
    const menu = {
      note: "The complete CURRENT menu. Receipts snapshot name+price at sale time, so later menu edits never corrupt history — dish_id joins receipts to this menu.",
      total_dishes: dishes.length,
      active_dishes: dishes.filter((d) => d.active).length,
      inactive_dishes: dishes.filter((d) => !d.active).length,
      categories: categories.map((c) => ({ category_id: c.id, name: c.name, created_at: istIso(c.createdAt) })),
      dishes: dishes.map((d) => {
        const s = dishSales.get(d.id);
        return {
          dish_id: d.id,
          name: d.name,
          category: d.category,
          selling_price: round2(d.price),
          cost_price: null as number | null, // Fetch-X does not store per-dish cost — expenses are booked by kind instead
          veg: d.veg,
          availability: d.active ? "available" : "removed_from_menu",
          created_at: istIso(d.createdAt),
          sales_in_period: s
            ? { units_sold: s.qty, revenue: round2(s.revenue), bills_appeared_on: s.bills.size, last_sold_on: s.last }
            : { units_sold: 0, revenue: 0, bills_appeared_on: 0, last_sold_on: null },
        };
      }),
    };

    // ══════════════════════════ SALES (raw-derived summaries) ══════════════════════════
    const restRevenue = round2(bills.reduce((s, b) => s + b.total, 0));
    const restDiscounts = round2(bills.reduce((s, b) => s + b.discount, 0));
    const restTax = round2(bills.reduce((s, b) => s + b.tax, 0));
    const lodgeRevenue = round2(lodgeBills.reduce((s, b) => s + b.total, 0));
    const lodgeDiscounts = round2(lodgeBills.reduce((s, b) => s + b.discount, 0));
    const lodgeTax = round2(lodgeBills.reduce((s, b) => s + b.tax, 0));

    const catAgg = new Map<string, { category: string; revenue: number; units: number }>();
    for (const b of bills)
      for (const it of b.items) {
        const e = catAgg.get(it.category) ?? { category: it.category, revenue: 0, units: 0 };
        e.revenue += it.qty * it.price;
        e.units += it.qty;
        catAgg.set(it.category, e);
      }

    const tierAgg = new Map<string, { tier: string; revenue: number; stays: number }>();
    for (const b of lodgeBills) {
      const e = tierAgg.get(b.tier) ?? { tier: b.tier, revenue: 0, stays: 0 };
      e.revenue += b.total;
      e.stays += 1;
      tierAgg.set(b.tier, e);
    }

    const sales = {
      note: "Calculated FROM the raw receipts/bookings above inside this same export — the AI can re-derive every number here. Every sub-block states its scope; 'combined' blocks add restaurant + lodge ONLY because both figures share the same window, tax treatment (5% GST) and inclusion rules.",
      payment_methods: null as string | null,
      payment_methods_note: "Fetch-X bills do not record a payment method — all sales are counter-settled.",
      refunds_cancellations: null as string | null,
      refunds_note: "No refund/cancellation flow exists in this version; every generated bill is a completed sale.",
      items_definitions: {
        items_sold: "Σ of the itemCount counter frozen on each restaurant bill at POS time (the dashboard's 'items' figure).",
        line_items: "Σ of receipt line rows in this export (one row per bill line).",
        units_sold: "Σ of quantity across receipt lines (true units served).",
        reconciliation_note: "These three counters can legitimately disagree on older bills (the POS counter was not always rewritten when a bill's lines changed). The disagreement is counted in analytics.analytics_integrity rather than hidden.",
      },
      restaurant: {
        period: { from: periodFrom, to: periodTo, scope: "restaurant" as const },
        transactions: bills.length,
        items_sold: vRest.items_counter,
        line_items: vRest.line_items,
        units_sold: vRest.units_sold,
        total_revenue: restRevenue,
        subtotal: round2(bills.reduce((s, b) => s + b.subtotal, 0)),
        discounts: restDiscounts,
        tax: restTax,
        average_transaction_value: bills.length ? round2(restRevenue / bills.length) : 0,
        revenue_by_day: byDay(bills, (b) => b.createdAt, (b) => b.total),
        revenue_by_month: byMonth(bills, (b) => b.createdAt, (b) => b.total),
        revenue_by_hour: byHour(bills),
        revenue_by_category: [...catAgg.values()]
          .map((e) => ({ category: e.category, revenue: round2(e.revenue), units: e.units }))
          .sort((a, b) => b.revenue - a.revenue),
        busiest_hours: dash.hourly.peak ? { peak: dash.hourly.peak, quiet: dash.hourly.quiet } : null,
      },
      lodge: {
        period: { from: periodFrom, to: periodTo, scope: "lodge" as const },
        bookings: lodgeBills.length,
        total_revenue: lodgeRevenue,
        stay_charges: vLodge.stay_charges,
        discounts: lodgeDiscounts,
        tax: lodgeTax,
        average_bill: lodgeBills.length ? round2(lodgeRevenue / lodgeBills.length) : 0,
        stay_hours_total: vLodge.stay_hours,
        revenue_by_day: byDay(lodgeBills, (b) => b.createdAt, (b) => b.total),
        revenue_by_month: byMonth(lodgeBills, (b) => b.createdAt, (b) => b.total),
        revenue_by_tier: [...tierAgg.values()].map((e) => ({ tier: e.tier, revenue: round2(e.revenue), stays: e.stays })).sort((a, b) => b.revenue - a.revenue),
      },
      combined: {
        period: { from: periodFrom, to: periodTo, scope: "combined" as const },
        comparability: "restaurant + lodge only — both series share the same window, GST treatment and completed-sale rule, so their sums are like-for-like.",
        total_revenue: round2(restRevenue + lodgeRevenue),
        total_transactions: bills.length + lodgeBills.length,
        total_discounts: round2(restDiscounts + lodgeDiscounts),
        total_tax: round2(restTax + lodgeTax),
      },
    };

    // ══════════════════════════ EXPENSES (every row) ══════════════════════════
    const expenseSummary = {
      by_kind: {} as Record<string, number>,
      by_book: {} as Record<string, number>,
      by_month: byMonth(expenses, (e) => e.spentOn, (e) => e.amount),
      total: round2(expenses.reduce((s, e) => s + e.amount, 0)),
    };
    for (const e of expenses) {
      expenseSummary.by_kind[e.kind] = round2((expenseSummary.by_kind[e.kind] ?? 0) + e.amount);
      expenseSummary.by_book[e.book === "lodge" ? "lodge" : "rest"] = round2(
        (expenseSummary.by_book[e.book === "lodge" ? "lodge" : "rest"] ?? 0) + e.amount,
      );
    }
    const expensesExport = {
      note: "Every expense the owner/receptions entered, individually. kind = raw_material | upgrade | maintenance; book = rest | lodge; via='task' rows were auto-registered when a reception closed a budgeted owner task.",
      summary: expenseSummary,
      records: expenses.map((e) => ({
        expense_id: e.id,
        kind: e.kind,
        book: e.book === "lodge" ? "lodge" : "rest",
        name: e.label,
        amount: round2(e.amount),
        date: istDateKey(e.spentOn),
        created_at: istIso(e.createdAt),
        registered_from_task: e.via === "task" ? e.taskId : null,
        task_id: e.taskId, // joins to tasks.task_id when this expense came from a closed task
      })),
    };

    // ══════════════════════════ TASKS (+ budget mechanism) ══════════════════════════
    const tasksExport = {
      note: "Owner-created tasks forwarded to a reception (book = rest | lodge). maxBudget = null → free task; when set, kind + description were mandatory and the reception closed it with actualCost ≤ maxBudget. Task updates are the receptions' progress notes.",
      summary: {
        total: tasks.length,
        open: tasks.filter((t) => t.status === "open").length,
        done: tasks.filter((t) => t.status !== "open").length,
        by_book: {
          rest: { total: tasks.filter((t) => t.book !== "lodge").length, done: tasks.filter((t) => t.book !== "lodge" && t.status !== "open").length },
          lodge: { total: tasks.filter((t) => t.book === "lodge").length, done: tasks.filter((t) => t.book === "lodge" && t.status !== "open").length },
        },
      },
      records: tasks.map((t) => ({
        task_id: t.id,
        title: t.title,
        book: t.book === "lodge" ? "lodge" : "rest",
        expense_kind: t.kind, // required when budgeted — the ledger the spend registers into
        max_budget: t.maxBudget, // null = free task
        description: t.description,
        deadline: istIso(t.deadline),
        status: t.status, // open | done
        created_by: anReq(t.createdBy || "OWNER"),
        created_at: istIso(t.createdAt),
        completed_at: t.doneAt ? istIso(t.doneAt) : null,
        completed_by: t.doneBy ? anReq(t.doneBy) : null,
        actual_cost: t.actualCost != null ? round2(t.actualCost) : null,
        updates: t.updates.map((u) => ({
          update_id: u.id,
          author: anReq(u.author || "OWNER"),
          role: u.role,
          message: u.message,
          created_at: istIso(u.createdAt),
        })),
      })),
    };

    // ══════════════════════════ EMPLOYEES ══════════════════════════
    const attByEmp = new Map<string, { present: number; absent: number }>();
    for (const a of attendance) {
      const e = attByEmp.get(a.employeeId) ?? { present: 0, absent: 0 };
      if (a.status === "present") e.present += 1;
      else e.absent += 1;
      attByEmp.set(a.employeeId, e);
    }
    const payByEmp = new Map<string, { count: number; total: number }>();
    for (const p of salaryPayments) {
      const e = payByEmp.get(p.employeeId) ?? { count: 0, total: 0 };
      e.count += 1;
      e.total += p.netPaid;
      payByEmp.set(p.employeeId, e);
    }
    const employeesExport = {
      note: "The staff roster (current state). book = which business's cost book carries the salary. Attendance/salary/task sections join on employee_id.",
      count: employees.length,
      active_count: employees.filter((e) => e.active).length,
      monthly_salary_total: round2(employees.filter((e) => e.active).reduce((s, e) => s + e.salary, 0)),
      records: employees.map((e) => {
        const att = attByEmp.get(e.id);
        const pay = payByEmp.get(e.id);
        return {
          employee_id: e.id,
          name: anReq(e.name),
          role: e.role,
          book: e.book === "lodge" ? "lodge" : "rest",
          monthly_salary: round2(e.salary),
          status: e.active ? "active" : "inactive",
          joined_at: istIso(e.createdAt),
          attendance_in_period: att ? { present_days: att.present, absent_days: att.absent, attendance_pct: att.present + att.absent ? round2((att.present / (att.present + att.absent)) * 100) : null } : { present_days: 0, absent_days: 0, attendance_pct: null },
          salary_in_period: pay ? { settlements: pay.count, total_paid: round2(pay.total) } : { settlements: 0, total_paid: 0 },
        };
      }),
    };

    // ══════════════════════════ ATTENDANCE (records + summaries) ══════════════════════════
    const attMonth = new Map<string, { employee_id: string; month: string; present: number; absent: number }>();
    for (const a of attendance) {
      const m = a.date.slice(0, 7);
      const k = a.employeeId + "|" + m;
      const e = attMonth.get(k) ?? { employee_id: a.employeeId, month: m, present: 0, absent: 0 };
      if (a.status === "present") e.present += 1;
      else e.absent += 1;
      attMonth.set(k, e);
    }
    const attendanceExport = {
      note: "Daily register marked by the receptions — one row per employee per date. Unmarked days are simply absent from the records (not automatically absences). status is present | absent only (no late mechanism by design).",
      rule: { paid_holiday_limit_per_month: holidayLimit, cut_rule: "(absent days − paid_holiday_limit) × (monthly salary ÷ days in that month)" },
      summaries: [...attMonth.values()]
        .map((e) => ({
          employee_id: e.employee_id,
          month: e.month,
          present_days: e.present,
          absent_days: e.absent,
          marked_days: e.present + e.absent,
          attendance_pct: e.present + e.absent ? round2((e.present / (e.present + e.absent)) * 100) : null,
        }))
        .sort((a, b) => a.month.localeCompare(b.month) || a.employee_id.localeCompare(b.employee_id)),
      records: attendance.map((a) => ({ employee_id: a.employeeId, date: a.date, status: a.status })),
    };

    // ══════════════════════════ SALARY ══════════════════════════
    const salMonth = new Map<string, { month: string; base: number; deduction: number; net: number; paid: number; unpaid: number }>();
    for (const p of salaryPayments) {
      const e = salMonth.get(p.month) ?? { month: p.month, base: 0, deduction: 0, net: 0, paid: 0, unpaid: 0 };
      e.base += p.base;
      e.deduction += p.deduction;
      e.net += p.netPaid;
      if (p.status === "paid") e.paid += 1;
      else e.unpaid += 1;
      salMonth.set(p.month, e);
    }
    const salaryExport = {
      note: "What the owner ACTUALLY settled per employee per month — frozen at settlement time (base = roster salary that month; deduction = attendance cut; netPaid = money that went home). status unpaid rows exist when a settlement was undone.",
      rule: { paid_holiday_limit_per_month: holidayLimit, note: "A month can only be settled after it fully ends; settlements freeze base/present/absent/paidHolidays/deduction/netPaid." },
      monthly_summaries: [...salMonth.values()]
        .map((e) => ({
          month: e.month,
          base_total: round2(e.base),
          deduction_total: round2(e.deduction),
          net_paid_total: round2(e.net),
          employees_paid: e.paid,
          employees_unpaid: e.unpaid,
        }))
        .sort((a, b) => a.month.localeCompare(b.month)),
      payments: salaryPayments.map((p) => ({
        payment_id: p.id,
        employee_id: p.employeeId, // joins to employees
        month: p.month,
        base: round2(p.base),
        present_days: p.presentDays,
        absent_days: p.absentDays,
        paid_holidays: p.paidHolidays,
        deduction: round2(p.deduction),
        net_paid: round2(p.netPaid),
        status: p.status,
        paid_at: p.paidAt ? istIso(p.paidAt) : null,
        paid_by: p.paidBy ? anReq(p.paidBy) : null,
      })),
    };

    // ══════════════════════════ ROOMS (live state at export moment) ══════════════════════════
    const maxRooms = parseMaxRooms(settingMap.get(MAX_ROOMS_KEY) ?? null);
    const levels = parseLevels(settingMap.get("lodgeLevels") ?? null, maxRooms) ?? DEFAULT_LEVELS;
    const statusAt = { available: 0, occupied: 0, maintenance: 0 };
    for (const r of rooms) {
      if (r.status === "occ") statusAt.occupied += 1;
      else if (r.status === "mnt") statusAt.maintenance += 1;
      else statusAt.available += 1;
    }
    const roomsExport = {
      note: "Live lodge state read at the exact export moment (NOT derived from history). status: avl = available · occ = guest in house · mnt = vacated, waiting for housekeeping.",
      wall: { max_rooms: maxRooms, levels: levels.map((l) => ({ name: l.name, rooms: `Rooms ${l.from} – ${l.to}`, from: l.from, to: l.to, rate_per_24h: l.rate })) },
      total_rooms: rooms.length,
      status_at_export: {
        available: statusAt.available,
        occupied: statusAt.occupied,
        maintenance: statusAt.maintenance,
        occupancy_pct: rooms.length ? round2((statusAt.occupied / rooms.length) * 100) : 0,
        exported_at: istIso(now),
      },
      in_house_guests: rooms.filter((r) => r.status === "occ").length,
      current_rooms: rooms.map((r) => {
        const tier = tierOfRoom(r.number, levels);
        const hoursIn = r.status === "occ" && r.checkInAt ? round2((now.getTime() - r.checkInAt.getTime()) / 3600000) : null;
        return {
          room_number: r.number, // the room's identity everywhere (bookings, lodge revenue)
          level: tier.name,
          rate_per_24h: tier.rate,
          status: r.status === "occ" ? "occupied" : r.status === "mnt" ? "maintenance" : "available",
          guest_name: r.status === "occ" ? an(r.guestName) : null,
          guest_phone: anonymize ? null : r.status === "occ" ? r.guestPhone : null,
          check_in_at: r.checkInAt ? istIso(r.checkInAt) : null,
          hours_in_house: hoursIn,
          estimated_charge_so_far: hoursIn != null ? round2(lgStay(tier.rate, hoursIn).stay) : null,
          state_changed_at: istIso(r.updatedAt),
        };
      }),
    };

    // ══════════════════════════ BOOKINGS (lodge stays) ══════════════════════════
    const bookingsExport = {
      note: "LodgeBill rows = COMPLETED stays (generated at checkout; the bill series prints as L-5001+). Guests currently in house appear under rooms.current_rooms with status 'occupied' — their bill does not exist yet.",
      count: lodgeBills.length,
      records: lodgeBills.map((b) => ({
        booking_id: b.id,
        bill_number: b.number,
        printed_as: `L-${b.number}`,
        room_number: b.room, // joins to rooms.current_rooms.room_number
        guest_name: an(b.guestName),
        guest_phone: anonymize ? null : b.guestPhone,
        tier: b.tier,
        rate_per_24h: round2(b.rate),
        check_in_at: istIso(b.checkInAt),
        check_out_at: istIso(b.checkOutAt),
        stay_hours: round2(b.hours),
        stay_charge: round2(b.stay), // after the ₹1,000 floor
        min_charge_applied: b.minApplied,
        discount: round2(b.discount),
        tax: round2(b.tax),
        total: round2(b.total),
        billed_at: istIso(b.createdAt),
      })),
    };

    // ══════════════════════════ RAW MATERIALS (purchase view) ══════════════════════════
    const rawPurchases = expenses.filter((e) => e.kind === "raw_material");
    const rawMaterialsExport = {
      note: "Fetch-X has no inventory/stock module — raw materials are booked as Expense rows with kind='raw_material' (groceries, dairy, vegetables…). Exported here as purchases so an AI can analyse input costs; there is no stock quantity/supplier data.",
      total_in_period: round2(rawPurchases.reduce((s, e) => s + e.amount, 0)),
      by_month: byMonth(rawPurchases, (e) => e.spentOn, (e) => e.amount),
      by_book: {
        rest: round2(rawPurchases.filter((e) => e.book !== "lodge").reduce((s, e) => s + e.amount, 0)),
        lodge: round2(rawPurchases.filter((e) => e.book === "lodge").reduce((s, e) => s + e.amount, 0)),
      },
      purchases: rawPurchases.map((e) => ({
        expense_id: e.id,
        item: e.label,
        amount: round2(e.amount),
        date: istDateKey(e.spentOn),
        book: e.book === "lodge" ? "lodge" : "rest",
      })),
    };

    // ══════════════════════════ BUDGETS (task-budget mechanism) ══════════════════════════
    const budgetsExport = {
      note: "Fetch-X has no standalone budget module — BUDGETED OWNER TASKS are the budget mechanism: the owner sets maxBudget (allocated) on a task and the reception closes it with actualCost (used). The rule of thumb is to close at or under the cap, but history contains closes ABOVE the cap — the over_budget_tasks count below states how many, rather than hiding them. Spending is authoritative from task.actual_cost; expenses auto-registered from tasks (via='task') exist only for the closes that registered ledger rows.",
      period: { from: periodFrom, to: periodTo, scope: "combined (owner tasks of both books); task_budgets rows carry each task's book" },
      value_kind: "period_aggregate",
      totals: {
        allocated: vBudget.allocated,
        used: vBudget.used,
        remaining: vBudget.remaining,
        utilization_pct: vBudget.utilization_pct,
        utilization_definition: "used ÷ allocated × 100 (null when no task carried a budget)",
        budgeted_tasks: vBudget.budgeted_tasks,
        done_budgeted_tasks: vBudget.done_budgeted_tasks,
        over_budget_tasks: vBudget.over_budget_tasks,
        expense_rows_registered: vBudget.expense_rows_tied,
        expense_rupees_registered: vBudget.expense_rupees_tied,
        expense_tie_note:
          "done budgeted tasks whose auto-registered expense rows sum exactly to actual_cost: verified in analytics_integrity. Tasks closed without ledger rows are normal in this data — trust actual_cost as the spend figure.",
      },
      by_book: {
        rest: {
          allocated: round2(vSum(budgeted.filter((t) => !isLodgeBook(t.book)), (t) => t.maxBudget ?? 0)),
          used: round2(vSum(budgeted.filter((t) => !isLodgeBook(t.book)), (t) => t.actualCost ?? 0)),
        },
        lodge: {
          allocated: round2(vSum(budgeted.filter((t) => isLodgeBook(t.book)), (t) => t.maxBudget ?? 0)),
          used: round2(vSum(budgeted.filter((t) => isLodgeBook(t.book)), (t) => t.actualCost ?? 0)),
        },
      },
      task_budgets: budgeted.map((t) => ({
        task_id: t.id,
        name: t.title,
        category: t.kind, // the expense kind this budget spends into
        book: t.book === "lodge" ? "lodge" : "rest",
        allocated: round2(t.maxBudget ?? 0),
        used: round2(t.actualCost ?? 0),
        remaining: round2((t.maxBudget ?? 0) - (t.actualCost ?? 0)),
        status: t.status,
        period: `${istDateKey(t.createdAt)} → ${t.doneAt ? istDateKey(t.doneAt) : "open"}`,
      })),
    };

    // ══════════════════════════ RESTAURANT / LODGE ROLLUPS ══════════════════════════
    // Scope-clean one-page summaries — every figure verified against the raw
    // records in this export (see analytics.analytics_integrity).
    const restaurantRollup = {
      period: { from: periodFrom, to: periodTo, scope: "restaurant" as const },
      value_kind: "period_aggregate (employees/menu are live-state counts)",
      revenue: restRevenue,
      bills: bills.length,
      items_sold: vRest.items_counter,
      units_sold: vRest.units_sold,
      discounts_given: restDiscounts,
      tax_collected: restTax,
      expenses: {
        raw_materials: vExp.rest.raw_material,
        upgrades: vExp.rest.upgrade,
        maintenance: vExp.rest.maintenance,
        total: vExp.total_rest,
        note: "Expense rows whose book = rest, window-bounded by spentOn.",
      },
      salaries_settled: vSal.rest,
      salaries_settled_note: "Σ netPaid of SalaryPayment rows joined to rest-book employees (months overlapping the window).",
      profit: vProfit.rest,
      profit_definition: "revenue − discounts − expenses(total) − salaries_settled — every term restaurant-book, same window.",
      margin_pct: marginPctOf(vProfit.rest, restRevenue),
      tasks: { total: vTasks.rest.total, done: vTasks.rest.done, open: vTasks.rest.open, completion_pct: vTasks.rest.total ? round2((vTasks.rest.done / vTasks.rest.total) * 100) : null },
      employees: employees.filter((e) => e.book !== "lodge" && e.active).length,
      menu: { dishes: dishes.length, categories: categories.length, note: "current menu (live state)" },
    };
    const lodgeRollup = {
      period: { from: periodFrom, to: periodTo, scope: "lodge" as const },
      value_kind: "period_aggregate (rooms/occupancy are live-state snapshots)",
      revenue: lodgeRevenue,
      bookings: lodgeBills.length,
      discounts_given: lodgeDiscounts,
      tax_collected: lodgeTax,
      expenses: {
        raw_materials: vExp.lodge.raw_material,
        upgrades: vExp.lodge.upgrade,
        maintenance: vExp.lodge.maintenance,
        total: vExp.total_lodge,
        note: "Expense rows whose book = lodge, window-bounded by spentOn.",
      },
      salaries_settled: vSal.lodge,
      salaries_settled_note: "Σ netPaid of SalaryPayment rows joined to lodge-book employees (months overlapping the window).",
      profit: vProfit.lodge,
      profit_definition: "revenue − discounts − expenses(total) − salaries_settled — every term lodge-book, same window.",
      margin_pct: marginPctOf(vProfit.lodge, lodgeRevenue),
      tasks: { total: vTasks.lodge.total, done: vTasks.lodge.done, open: vTasks.lodge.open, completion_pct: vTasks.lodge.total ? round2((vTasks.lodge.done / vTasks.lodge.total) * 100) : null },
      employees: employees.filter((e) => e.book === "lodge" && e.active).length,
      rooms: roomsExport.status_at_export,
      occupancy_snapshot: {
        value_kind: "live_state_snapshot",
        in_house: statusAt.occupied,
        pct_full: rooms.length ? round2((statusAt.occupied / rooms.length) * 100) : 0,
        pct_basis: "occupied ÷ room rows in database × 100 (the dashboard's own pct_full card divides by the configured wall size instead — see dashboard_summary.lodge_snapshot)",
      },
      occupancy_period: vOccupancy
        ? { value_kind: "period_aggregate", ...vOccupancy, method: "Σ overlap of completed booking spans (check_in → check_out) with the window ÷ (rooms × window hours) × 100" }
        : null,
    };

    // ══════════════════════════ DASHBOARD SUMMARY (app's own math, labelled) ══════════════════════════
    // This mirrors the live dashboard card-for-card. Where a card's window or
    // definition differs from the export's records, the difference is stated
    // ON the field AND listed in analytics.analytics_integrity.warnings.
    const dashboard_summary = {
      note: "Exactly what the Fetch-X live dashboard computes and displays, card for card, with every figure's scope and definition labelled. The analytics section is the reconciliation layer: it recomputes aggregates from the raw records in this file. Do not mix figures across cards without reading their definitions — the dashboard's own NET PROFIT card is intentionally a mixed-scope figure (restaurant revenue minus all-house costs) and is labelled as such.",
      period: {
        from: periodFrom,
        to: periodTo,
        scope: "combined (each card below restates its own scope)",
        dashboard_range_key: dash.range,
        note: "The dashboard window is [from 00:00 IST, to 23:59:59 IST]; 'lifetime' means first record → export moment.",
      },
      stats: {
        scope: "restaurant",
        value_kind: "period_aggregate",
        definition: "Restaurant receipts in the window: revenue (GST-inclusive bill totals), bills, items (the POS item counter), avgTicket, discounts — plus delta vs the previous equal-length window (null when the previous window had no revenue).",
        ...dash.stats,
      },
      all_time: {
        scope: "restaurant bills ONLY — the dashboard's all-time card never includes lodge. Lodge + combined all-time: analytics.all_time.",
        value_kind: "all_time_total",
        ...dash.allTime,
      },
      costs: {
        scope: "MIXED — restaurant revenue minus ALL-house costs (labelled, not silently merged)",
        value_kind: "period_aggregate",
        definition: "The dashboard's NET PROFIT card: restaurant window revenue − both books' salary accrual − both books' expenses (raw_material + upgrade + maintenance) − restaurant discounts. Lodge revenue is NOT added. For scope-clean profit use analytics.restaurant.profit / analytics.lodge.profit / analytics.combined.profit.",
        ...dash.costs,
      },
      books: {
        note: "Per-book cost cards. Salaries = attendance-recalculated accrual per Employee.book (accrual_estimate). Expenses + discounts = Expense/Bill aggregates. WINDOW DEFINITION: the dashboard computes these over the trailing window-length of days ENDING at the export moment — in FULL exports that equals all history, but in DATE RANGE exports it can differ from this file's [from → to]; the analytics_integrity section flags it. Scope-clean per-book figures: analytics.costs.expenses + analytics.salary.settled.",
        window_definition: isRange
          ? `trailing ${dash.hourly.days} day(s) ending at the export moment, with no end-date bound (dashboard definition — NOT this export's date filter)`
          : "all history (full export)",
        rest: { scope: "restaurant book", ...dash.books.rest },
        lodge: { scope: "lodge book", ...dash.books.lodge },
      },
      team: {
        scope: "both books (all staff)",
        value_kind: "mixed — see per-field definitions",
        monthly_salary_total: dash.team.monthlyTotal,
        monthly_salary_total_definition: "live_state_snapshot — current active roster × monthly salary, both books.",
        salary_cost_in_period: dash.team.periodCost,
        salary_cost_in_period_definition: "accrual_estimate — attendance-recalculated salary from the window's first day to the EXPORT MOMENT (not bounded by a range export's end date). Verified against an independent re-derivation in FULL exports (analytics_integrity).",
        projected_salary_cost: dash.team.projectedCost,
        projected_salary_cost_definition: "projection — roster proration (Σ monthly salary ÷ 30 × window days); the dashboard's comparison figure, NOT actual money.",
        settlements_paid_in_period: dash.team.paidCount,
        settlements_paid_definition: "settled_actual — SalaryPayment rows with status=paid and paidAt ≥ window start (months can straddle the window edges).",
      },
      lodge_snapshot: {
        scope: "lodge",
        value_kind: "mixed — window revenue/stays + live state + one projection",
        revenue: dash.lodge.revenue,
        revenue_definition: "completed lodge bills in the window (bills are generated at checkout).",
        stays: dash.lodge.stays,
        in_house: dash.lodge.inHouse,
        in_house_definition: "live_state_snapshot — Room.status = occ at the export moment.",
        pct_full: dash.lodge.pctFull,
        pct_full_definition: "occupied ÷ configured wall size (maxRooms, default 100) — rooms.status_at_export.occupancy_pct uses the actual room rows instead; same number when the wall matches the room count.",
        maintenance: dash.lodge.mnt,
        maintenance_definition: "live_state_snapshot — Room.status = mnt at the export moment.",
        tonight_potential: dash.lodge.tonight,
        tonight_potential_definition: "projection — Σ tier rate of rooms currently occupied, as if every in-house guest paid a full 24h at the tier rate.",
      },
      charts: {
        scope: "restaurant charts + lodge sub-block",
        value_kind: "period_aggregate",
        restaurant_revenue_buckets: dash.buckets,
        restaurant_revenue_buckets_note: "Revenue-per-bucket series on the dashboard's chosen axis (hour/day/week/month). Scope: restaurant.",
        restaurant_hourly_rhythm: dash.hourly,
        restaurant_hourly_rhythm_note: "Average-day revenue per hour (7 AM – 11 PM IST) across the window; 'days' = window length used as the divisor.",
        restaurant_peak_label: dash.peakLabel,
        lodge: {
          scope: "lodge",
          revenue_buckets: dash.lodge.buckets,
          peak_label: dash.lodge.peakLabel,
          delta_pct: dash.lodge.deltaPct,
          delta_pct_definition: "revenue vs the previous equal-length window (null when the previous window had no revenue).",
          avg_charge_per_stay: dash.lodge.avgStay,
          avg_charge_per_stay_definition: "window revenue ÷ completed stays (the dashboard card named it 'avgStay'; it is a charge average, not hours).",
          day_curve: dash.lodge.dayCurve,
          day_curve_definition: "average-day occupancy curve: rooms in house per hour of day (from real stay spans incl. open stays) ÷ wall size — hourly percentages, peak in day_peak.",
          stay_mix: dash.lodge.stayMix,
          stay_mix_definition: "share of completed stays by duration bucket over the trailing 90 days (NOT window-bounded — fixed 90-day lookback by design).",
          tier_mix: dash.lodge.tierMix,
          tier_mix_definition: "window revenue share by room tier (lodge scope).",
          room_hours: dash.lodge.roomHours,
          room_hours_definition: "room-hours wall split for the window: guests (occupied spans) + mnt (rooms sitting in maintenance) + free = total. totalRooms = the configured wall.",
        },
      },
      discount_log: {
        scope: "rest = restaurant bills · lodge = lodge checkouts (two separate discount ledgers)",
        value_kind: "period_aggregate (most recent discounted bills, capped at 12 per book)",
        rest: dash.discountLog.rest.map((r) => ({ ...r })),
        lodge: dash.discountLog.lodge.map((r) => ({ ...r, guestName: an(r.guestName) })),
      },
    };

    // ════════════════ ANALYTICS — verified, scope-tagged, reconciled ════════════════
    // Every figure in this section was calculated from the raw records in THIS
    // file and re-verified against them before the file was written. Where the
    // dashboard's own cards use a different window or definition, that is a
    // LABELLED difference (field note + integrity warning) — never a silent mix.

    // — item ranking straight from receipt lines (name snapshots) —
    const itemRank = new Map<string, { name: string; qty: number; revenue: number }>();
    for (const b of bills)
      for (const it of b.items) {
        const e = itemRank.get(it.name) ?? { name: it.name, qty: 0, revenue: 0 };
        e.qty += it.qty;
        e.revenue += it.qty * it.price;
        itemRank.set(it.name, e);
      }

    // ════════════════ RECONCILIATION — recompute every aggregate from the
    // exported raw records and compare to the values written above ════════════════
    {
      // — restaurant vs receipts —
      const rxRev = round2(vSum(receipts, (r) => r.total));
      iCheck("restaurant.revenue = Σ receipts.total", nearR(sales.restaurant.total_revenue, rxRev), `₹${rxRev.toLocaleString("en-IN")}`);
      iCheck("restaurant.subtotal = Σ receipts.subtotal", nearR(sales.restaurant.subtotal, round2(vSum(receipts, (r) => r.subtotal))), "Σ receipts.subtotal");
      iCheck("restaurant.discounts = Σ receipts.discount", nearR(sales.restaurant.discounts, round2(vSum(receipts, (r) => r.discount))), "Σ receipts.discount");
      iCheck("restaurant.tax = Σ receipts.tax", nearR(sales.restaurant.tax, round2(vSum(receipts, (r) => r.tax))), "Σ receipts.tax");
      iCheck("restaurant.transactions = receipts.length", sales.restaurant.transactions === receipts.length, `${receipts.length} receipts`);
      iCheck("restaurant.line_items = Σ receipt lines", sales.restaurant.line_items === vSum(receipts, (r) => r.items.length), "line rows in receipts");
      iCheck("restaurant.units_sold = Σ line qty", sales.restaurant.units_sold === vSum(receipts, (r) => vSum(r.items, (i) => i.quantity)), "units across lines");
      iCheck("restaurant.items_sold = Σ receipt item_count", sales.restaurant.items_sold === vSum(receipts, (r) => r.item_count), "POS counter");
      iCheck("restaurant.average_transaction_value = revenue ÷ bills", nearR(sales.restaurant.average_transaction_value, sales.restaurant.transactions ? round2(sales.restaurant.total_revenue / sales.restaurant.transactions) : 0), "revenue/transactions");
      iCheck("restaurant.revenue_by_day sums to revenue", nearR(vSum(sales.restaurant.revenue_by_day, (d) => d.value), sales.restaurant.total_revenue), "by_day series");
      iCheck("restaurant.revenue_by_month sums to revenue", nearR(vSum(sales.restaurant.revenue_by_month, (d) => d.value), sales.restaurant.total_revenue), "by_month series");
      iCheck("restaurant.revenue_by_category sums to subtotal", nearR(vSum(sales.restaurant.revenue_by_category, (c) => c.revenue), sales.restaurant.subtotal), "category revenue is pre-tax line value");
      const rxBadMath = receipts.filter((r) => !nearR(round2(r.subtotal - r.discount + r.tax), r.total, 0.02));
      iCheck("per-receipt math: subtotal − discount + tax = total", rxBadMath.length === 0, rxBadMath.length ? `offenders: ${rxBadMath.slice(0, 3).map((r) => "#" + r.number).join(", ")}` : `all ${receipts.length} receipts hold`);

      // — lodge vs bookings —
      iCheck("lodge.revenue = Σ bookings.total", nearR(sales.lodge.total_revenue, round2(vSum(bookingsExport.records, (b) => b.total))), "Σ bookings.total");
      iCheck("lodge.discounts = Σ bookings.discount", nearR(sales.lodge.discounts, round2(vSum(bookingsExport.records, (b) => b.discount))), "Σ bookings.discount");
      iCheck("lodge.tax = Σ bookings.tax", nearR(sales.lodge.tax, round2(vSum(bookingsExport.records, (b) => b.tax))), "Σ bookings.tax");
      iCheck("lodge.bookings = bookings.count", sales.lodge.bookings === bookingsExport.count, `${bookingsExport.count} bookings`);
      iCheck("lodge.average_bill = revenue ÷ bookings", nearR(sales.lodge.average_bill, sales.lodge.bookings ? round2(sales.lodge.total_revenue / sales.lodge.bookings) : 0), "revenue/bookings");
      iCheck("lodge.revenue_by_tier sums to revenue", nearR(vSum(sales.lodge.revenue_by_tier, (t) => t.revenue), sales.lodge.total_revenue), "tier series");
      iCheck("lodge.revenue_by_day sums to revenue", nearR(vSum(sales.lodge.revenue_by_day, (d) => d.value), sales.lodge.total_revenue), "by_day series");
      const bkBadMath = bookingsExport.records.filter((b) => !nearR(round2(b.stay_charge - b.discount + b.tax), b.total, 0.02));
      iCheck("per-booking math: stay_charge − discount + tax = total", bkBadMath.length === 0, bkBadMath.length ? `offenders: ${bkBadMath.slice(0, 3).map((b) => "L-" + b.bill_number).join(", ")}` : `all ${bookingsExport.records.length} bookings hold`);

      // — combined (only same-window sums) —
      iCheck("combined.revenue = restaurant + lodge", nearR(sales.combined.total_revenue, round2(sales.restaurant.total_revenue + sales.lodge.total_revenue)), "same-window sum");
      iCheck("combined.transactions = restaurant + lodge", sales.combined.total_transactions === sales.restaurant.transactions + sales.lodge.bookings, "same-window sum");
      iCheck("combined.discounts = restaurant + lodge", nearR(sales.combined.total_discounts, round2(sales.restaurant.discounts + sales.lodge.discounts)), "same-window sum");
      iCheck("combined.tax = restaurant + lodge", nearR(sales.combined.total_tax, round2(sales.restaurant.tax + sales.lodge.tax)), "same-window sum");

      // — expenses —
      iCheck("expenses.summary.total = Σ records.amount", nearR(expensesExport.summary.total, round2(vSum(expensesExport.records, (e) => e.amount))), "Σ expense records");
      iCheck("expenses by_kind sums to total", nearR(vSum(Object.values(expensesExport.summary.by_kind), (v) => v), expensesExport.summary.total), "kind split");
      iCheck("expenses by_book sums to total", nearR(vSum(Object.values(expensesExport.summary.by_book), (v) => v), expensesExport.summary.total), "book split");
      iCheck("expenses by_month sums to total", nearR(vSum(expensesExport.summary.by_month, (m) => m.value), expensesExport.summary.total), "month series");
      iCheck("costs.expenses.restaurant.total = Σ rest-book records", nearR(vExp.total_rest, round2(vSum(expensesExport.records.filter((e) => e.book === "rest"), (e) => e.amount))), "Σ rest rows");
      iCheck("costs.expenses.lodge.total = Σ lodge-book records", nearR(vExp.total_lodge, round2(vSum(expensesExport.records.filter((e) => e.book === "lodge"), (e) => e.amount))), "Σ lodge rows");
      iCheck("costs.expenses.combined = restaurant + lodge", nearR(vExp.total_combined, round2(vExp.total_rest + vExp.total_lodge)), "sum of books");
      for (const k of KINDS) {
        iCheck(`costs.expenses per kind×book (${k})`, nearR(vExp.rest[k] + vExp.lodge[k], round2(vSum(expensesExport.records.filter((e) => e.kind === k), (e) => e.amount))), `rest ${vExp.rest[k]} + lodge ${vExp.lodge[k]}`);
      }
      iCheck("raw_materials.total_in_period = raw_material expenses", nearR(rawMaterialsExport.total_in_period, round2(vExp.rest.raw_material + vExp.lodge.raw_material)), "kind = raw_material");

      // — salaries (settled = exact records) —
      iCheck("salary.settled.combined = Σ payments.net_paid", nearR(vSal.combined, round2(vSum(salaryExport.payments, (p) => p.net_paid))), "Σ net_paid");
      iCheck("salary.settled rest + lodge = combined", nearR(vSal.rest + vSal.lodge, vSal.combined), "book split via employee.book");
      iCheck("salary monthly_summaries net = Σ payments.net_paid", nearR(vSum(salaryExport.monthly_summaries, (m) => m.net_paid_total), round2(vSum(salaryExport.payments, (p) => p.net_paid))), "monthly roll-up");
      iCheck("employees salary_in_period total = Σ payments.net_paid", nearR(vSum(employeesExport.records, (e) => e.salary_in_period.total_paid), round2(vSum(salaryExport.payments, (p) => p.net_paid))), "per-employee roll-up");
      const salBadMath = salaryExport.payments.filter((p) => !nearR(round2(p.base - p.deduction), p.net_paid, 0.02));
      iCheck("per-settlement math: base − deduction = net_paid", salBadMath.length === 0, salBadMath.length ? `${salBadMath.length} offenders` : `all ${salaryExport.payments.length} settlements hold`);
      iCheck("roster monthly total = Σ active salaries", nearR(employeesExport.monthly_salary_total, rosterMonthly.combined), "live roster");

      // — attendance —
      iCheck("attendance.marked_days = records.length", vAtt.marked_days === attendanceExport.records.length, `${attendanceExport.records.length} rows`);
      iCheck("attendance present + absent = marked_days", vAtt.present + vAtt.absent === vAtt.marked_days, `${vAtt.present} present / ${vAtt.absent} absent`);
      iCheck("attendance per-book split + unattributable = marked_days", vAtt.rest.present + vAtt.rest.absent + vAtt.lodge.present + vAtt.lodge.absent + vAtt.unattributable_rows === vAtt.marked_days, "roster attribution");
      iCheck("attendance summaries Σ marked = records", vSum(attendanceExport.summaries, (s) => s.marked_days) === attendanceExport.records.length, "month×employee summaries");
      iCheck("employees attendance_in_period = Σ records", vSum(employeesExport.records, (e) => e.attendance_in_period.present_days + e.attendance_in_period.absent_days) === vAtt.marked_days - vAtt.unattributable_rows, "per-employee roll-up");

      // — tasks + budgets —
      iCheck("tasks.summary.total = records.length", tasksExport.summary.total === tasksExport.records.length, `${tasksExport.records.length} tasks`);
      iCheck("tasks done + open = total", tasksExport.summary.done + tasksExport.summary.open === tasksExport.summary.total, "status split");
      iCheck("tasks by_book sums to total", tasksExport.summary.by_book.rest.total + tasksExport.summary.by_book.lodge.total === tasksExport.summary.total, "book split");
      iCheck("budgets.allocated = Σ task_budgets.allocated", nearR(budgetsExport.totals.allocated, round2(vSum(budgetsExport.task_budgets, (t) => t.allocated))), "Σ allocated");
      iCheck("budgets.used = Σ task_budgets.used", nearR(budgetsExport.totals.used, round2(vSum(budgetsExport.task_budgets, (t) => t.used))), "Σ used");
      iCheck("budgets.remaining = allocated − used", nearR(budgetsExport.totals.remaining, round2(budgetsExport.totals.allocated - budgetsExport.totals.used)), "arithmetic");
      iCheck(
        "budgets.utilization_pct = used ÷ allocated",
        budgetsExport.totals.utilization_pct === null
          ? budgetsExport.totals.allocated === 0
          : nearR(budgetsExport.totals.utilization_pct, round2((budgetsExport.totals.used / budgetsExport.totals.allocated) * 100), 0.05),
        budgetsExport.totals.utilization_pct === null ? "no budgeted tasks" : `${budgetsExport.totals.utilization_pct}%`,
      );
      iCheck("budgets.by_book sums to totals", nearR(budgetsExport.by_book.rest.allocated + budgetsExport.by_book.lodge.allocated, budgetsExport.totals.allocated) && nearR(budgetsExport.by_book.rest.used + budgetsExport.by_book.lodge.used, budgetsExport.totals.used), "book split");
      // tasks whose closes DID register expense rows must tie to the rupee
      let tieOk = 0, tieBad = 0;
      const expByTask = new Map<string, number>();
      for (const e of expensesExport.records) if (e.task_id) expByTask.set(e.task_id, (expByTask.get(e.task_id) ?? 0) + e.amount);
      for (const t of tasksExport.records) {
        if (t.max_budget == null || t.status === "open" || t.actual_cost == null || !expByTask.has(t.task_id)) continue;
        if (nearR(round2(expByTask.get(t.task_id)!), t.actual_cost, 0.05)) tieOk += 1;
        else tieBad += 1;
      }
      iCheck("budgeted tasks WITH expense rows tie to actual_cost", tieBad === 0, `${tieOk} tie exactly, ${tieBad} mismatched`);

      // — rooms / occupancy —
      iCheck("rooms status counts sum to total_rooms", roomsExport.status_at_export.available + roomsExport.status_at_export.occupied + roomsExport.status_at_export.maintenance === roomsExport.total_rooms, "live wall");
      iCheck("rooms.occupancy_pct = occupied ÷ total_rooms", nearR(roomsExport.status_at_export.occupancy_pct, roomsExport.total_rooms ? round2((roomsExport.status_at_export.occupied / roomsExport.total_rooms) * 100) : 0), "live snapshot");
      iCheck("rooms.in_house_guests = occupied", roomsExport.in_house_guests === roomsExport.status_at_export.occupied, "live snapshot");
      if (vOccupancy) {
        iCheck("occupancy.room_hours_occupied ≤ capacity", vOccupancy.room_hours_occupied <= vOccupancy.capacity_room_hours + I_TOL, `${vOccupancy.room_hours_occupied} / ${vOccupancy.capacity_room_hours} room-hours`);
        iCheck(
          "occupancy.occupancy_pct = room_hours ÷ capacity",
          vOccupancy.occupancy_pct === null || nearR(vOccupancy.occupancy_pct, round2((vOccupancy.room_hours_occupied / vOccupancy.capacity_room_hours) * 100), 0.05),
          vOccupancy.occupancy_pct === null ? "no capacity" : `${vOccupancy.occupancy_pct}%`,
        );
      }
      iCheck("dashboard lodge revenue = verified lodge revenue", nearR(dashboard_summary.lodge_snapshot.revenue, sales.lodge.total_revenue), "window match");
      iCheck("dashboard lodge stays = verified bookings", dashboard_summary.lodge_snapshot.stays === sales.lodge.bookings, "window match");
      iCheck("dashboard stats.revenue = verified restaurant revenue", nearR(dashboard_summary.stats.revenue, sales.restaurant.total_revenue, 1), "window match");
      iCheck("dashboard stats.bills = verified bills", dashboard_summary.stats.bills === sales.restaurant.transactions, "window match");
      iCheck("dashboard stats.discounts = verified discounts", nearR(dashboard_summary.stats.discounts, sales.restaurant.discounts, 1), "window match");
      iCheck("dashboard all_time ≥ window (restaurant)", dashboard_summary.all_time.bills >= sales.restaurant.transactions && nearR(dashboard_summary.all_time.revenue, Math.max(dashboard_summary.all_time.revenue, sales.restaurant.total_revenue), 1), "all-time is never smaller than the window");
      iCheck("all_time.combined = restaurant + lodge", nearR(vAllTime.combined.revenue, round2(vAllTime.restaurant.revenue + vAllTime.lodge.revenue)), "sum");

      // — task completion splits (non-tautological: status split per book) —
      iCheck(
        "task_completion status splits hold (done + open = total, per book)",
        vTasks.rest.done + vTasks.rest.open === vTasks.rest.total && vTasks.lodge.done + vTasks.lodge.open === vTasks.lodge.total && vTasks.rest.total + vTasks.lodge.total === vTasks.total,
        `rest ${vTasks.rest.done}+${vTasks.rest.open}/${vTasks.rest.total} · lodge ${vTasks.lodge.done}+${vTasks.lodge.open}/${vTasks.lodge.total}`,
      );

      // — dashboard salary accrual vs independent re-derivation (FULL exact; RANGE labelled) —
      if (dashAccrualReplica) {
        const okAccrual = nearR(dashAccrualReplica.total, dash.team.periodCost, 1);
        if (isRange) {
          iWarn(
            `dashboard team.salary_cost_in_period (₹${dash.team.periodCost.toLocaleString("en-IN")}) is the attendance accrual from ${dashStartKey} to the EXPORT MOMENT — not bounded by this range's end (${periodTo}). An independent re-derivation of the dashboard definition returned ₹${dashAccrualReplica.total.toLocaleString("en-IN")}; use analytics.salary figures for window-exact money.`,
          );
        } else {
          iCheck("dashboard salary accrual = re-derived from attendance records", okAccrual, `dashboard ₹${dash.team.periodCost.toLocaleString("en-IN")} vs replica ₹${dashAccrualReplica.total.toLocaleString("en-IN")}`);
        }
        if (!isRange) {
          iCheck("dashboard books.rest.salaries = re-derived accrual (rest)", nearR(dash.books.rest.salaries, dashAccrualReplica.rest, 1), `₹${dash.books.rest.salaries.toLocaleString("en-IN")}`);
          iCheck("dashboard books.lodge.salaries = re-derived accrual (lodge)", nearR(dash.books.lodge.salaries, dashAccrualReplica.lodge, 1), `₹${dash.books.lodge.salaries.toLocaleString("en-IN")}`);
        }
      }

      // — dashboard books expenses/discounts vs their own trailing-window definition —
      const booksStartMs = istDayStart(new Date(now.getTime() - (dash.hourly.days - 1) * 86_400_000)).getTime();
      if (!isRange) {
        // FULL export: the file carries every expense/bill → recompute exactly.
        const expAfter = (kind: string, book: "rest" | "lodge") =>
          round2(vSum(expenses.filter((e) => e.spentOn.getTime() >= booksStartMs && e.kind === kind && (book === "lodge" ? isLodgeBook(e.book) : !isLodgeBook(e.book))), (e) => e.amount));
        iCheck("dashboard books.rest expenses = re-derived from expense records", nearR(dash.books.rest.rawMaterials, expAfter("raw_material", "rest")) && nearR(dash.books.rest.upgrades, expAfter("upgrade", "rest")) && nearR(dash.books.rest.maintenance, expAfter("maintenance", "rest")), "trailing-window definition");
        iCheck("dashboard books.lodge expenses = re-derived from expense records", nearR(dash.books.lodge.rawMaterials, expAfter("raw_material", "lodge")) && nearR(dash.books.lodge.upgrades, expAfter("upgrade", "lodge")) && nearR(dash.books.lodge.maintenance, expAfter("maintenance", "lodge")), "trailing-window definition");
        const restDiscWin = round2(vSum(bills.filter((b) => b.createdAt.getTime() >= booksStartMs), (b) => b.discount));
        const lodgeDiscWin = round2(vSum(lodgeBills.filter((b) => b.createdAt.getTime() >= booksStartMs), (b) => b.discount));
        iCheck("dashboard books discounts = re-derived from bills", nearR(dash.books.rest.discounts, restDiscWin) && nearR(dash.books.lodge.discounts, lodgeDiscWin), "trailing-window definition");
      } else {
        iWarn(
          `dashboard books.rest/books.lodge expenses + discounts use the dashboard's trailing ${dash.hourly.days}-day window ending at the export moment (no end bound) — they do NOT match this file's ${periodFrom} → ${periodTo} filter and cannot be re-derived from a range export. Scope-clean per-book figures are in analytics.costs.expenses and analytics.salary.settled.`,
        );
      }

      // — definitional differences → labelled warnings (never silently merged) —
      if (vRest.items_counter !== vRest.units_sold || vRest.items_counter !== vRest.line_items) {
        iWarn(
          `restaurant "items sold" has three definitions that disagree on this data: POS counter = ${vRest.items_counter.toLocaleString("en-IN")}, receipt line rows = ${vRest.line_items.toLocaleString("en-IN")}, units (Σ qty) = ${vRest.units_sold.toLocaleString("en-IN")}. sales.restaurant carries all three (items_sold / line_items / units_sold); the dashboard's stats.items uses the POS counter.`,
        );
      }
      iWarn(
        `dashboard_summary.costs.profit is a MIXED-scope figure by the dashboard's own definition: restaurant revenue minus BOTH books' costs. Scope-clean profit: analytics.restaurant.profit (₹${vProfit.rest.toLocaleString("en-IN")}), analytics.lodge.profit (₹${vProfit.lodge.toLocaleString("en-IN")}), analytics.combined.profit (₹${vProfit.combined.toLocaleString("en-IN")}).`,
      );
      if (vBudget.over_budget_tasks > 0) {
        iWarn(`${vBudget.over_budget_tasks} budgeted task(s) closed ABOVE their maxBudget cap (rule-of-thumb breach recorded as-is; see budgets.totals.over_budget_tasks).`);
      }
      if (vBudget.done_budgeted_tasks > vBudget.expense_rows_tied || vBudget.expense_rows_tied > 0) {
        iWarn(
          `only ${vBudget.expense_rows_tied} of ${vBudget.done_budgeted_tasks} done budgeted task(s) registered auto-expense rows (₹${vBudget.expense_rupees_tied.toLocaleString("en-IN")}). Task.actual_cost is the authoritative spend; the expense ledger is partial by history.`,
        );
      }
      if (vAtt.unattributable_rows > 0) {
        iWarn(`${vAtt.unattributable_rows} attendance row(s) join to employees missing from the roster — counted in totals, excluded from the per-book split.`);
      }
      if (vAtt.inactive_roster_rows > 0) {
        iWarn(`${vAtt.inactive_roster_rows} attendance row(s) belong to now-inactive employees — kept in totals and the per-book split (the register records them).`);
      }
      if (vSal.unattributable_rows > 0) {
        iWarn(`${vSal.unattributable_rows} salary payment(s) join to employees missing from the roster — excluded from the per-book settled split (counted in analytics_integrity only).`);
      }
      if (maxRooms !== rooms.length) {
        iWarn(`dashboard lodge pct_full divides by the configured wall (${maxRooms} rooms) while rooms.status_at_export.occupancy_pct divides by the ${rooms.length} room rows in the database — two bases, both labelled.`);
      }
      if (!accrualEligible) {
        iWarn(`salary accrual figures could not be re-derived for this window: it starts mid-month (${fromKey}) and the paid-holiday allowance needs attendance from the month's 1st, which this export does not carry. Settled salary money (analytics.salary.settled) remains exact.`);
      }
      if (!vOccupancy) {
        iWarn("historical occupancy is null: there are no completed lodge stays in this export to derive room-hours from. Live occupancy (rooms.status_at_export) is unaffected.");
      }
    }

    const failedChecks = integrityChecks.filter((c) => !c.ok);
    const analyticsExport = {
      note: "VERIFIED analytics — every figure here is calculated from the raw records included in this same export (receipts, bookings, expenses, tasks, attendance, salary payments, rooms) and was re-verified against them before this file was written (see analytics_integrity). Scopes are explicit and never mixed: restaurant = restaurant receipts only; lodge = lodge bookings only; combined = same-window sums of both books whose definitions match (window, 5% GST treatment, completed-sale rule). Profit uses SETTLED salary money and window-bounded expenses on both sides so every term is like-for-like.",
      generated_at: istIso(now),
      period: {
        from: periodFrom,
        to: periodTo,
        scope: "combined — restaurant + lodge; every sub-block restates its own scope",
        basis: "IST calendar days; datetime windows are [day 00:00, next-day 00:00) IST; salary months overlap the window by month",
      },
      value_kind_legend: {
        period_aggregate: "computed over this export's window from the records in this file",
        all_time_total: "the database's entire history — equals the window in FULL exports; broader in DATE RANGE exports (stated per field)",
        live_state_snapshot: "a reading of current tables (rooms, roster, settings) at the export moment — not a window figure",
        projection: "a forward-looking estimate (labelled on the field; never actual money)",
        settled_actual: "exact money from SalaryPayment/Expense records",
        accrual_estimate: "attendance-derived salary estimate (the dashboard's running-cost definition)",
      },
      restaurant: {
        period: { from: periodFrom, to: periodTo, scope: "restaurant" as const },
        value_kind: "period_aggregate",
        revenue: vRest.revenue,
        revenue_note: "GST-inclusive bill totals (each receipt's total; 5% GST inside).",
        subtotal: vRest.subtotal,
        discounts: vRest.discounts,
        tax: vRest.tax,
        bills: vRest.bills,
        items_sold: vRest.items_counter,
        line_items: vRest.line_items,
        units_sold: vRest.units_sold,
        items_definitions: "three counters are kept separate on purpose — see sales.items_definitions and analytics_integrity.warnings.",
        average_transaction_value: vRest.avg_transaction,
        items_ranking: [...itemRank.values()].sort((a, b) => b.qty - a.qty).map((d) => ({ name: d.name, qty: d.qty, revenue: round2(d.revenue) })),
        profit: {
          scope: "restaurant" as const,
          method: "revenue − discounts − restaurant-book expenses (raw_material + upgrade + maintenance) − restaurant-book salaries (settled, months overlapping the window)",
          revenue: vRest.revenue,
          discounts: vRest.discounts,
          raw_materials: vExp.rest.raw_material,
          upgrades: vExp.rest.upgrade,
          maintenance: vExp.rest.maintenance,
          salaries_settled: vSal.rest,
          profit: vProfit.rest,
          margin_pct: marginPctOf(vProfit.rest, vRest.revenue),
          margin_definition: "profit ÷ revenue × 100 (null when revenue is 0)",
          tax_note: "revenue is GST-inclusive; profit follows the dashboard's convention of subtracting costs from GST-inclusive revenue.",
        },
      },
      lodge: {
        period: { from: periodFrom, to: periodTo, scope: "lodge" as const },
        value_kind: "period_aggregate (occupancy.live is a snapshot)",
        revenue: vLodge.revenue,
        revenue_note: "GST-inclusive checkout totals; stay charges bill to the hour with a ₹1,000 floor.",
        stay_charges: vLodge.stay_charges,
        discounts: vLodge.discounts,
        tax: vLodge.tax,
        bookings: vLodge.bookings,
        average_bill: vLodge.avg_bill,
        stay_hours_total: vLodge.stay_hours,
        average_stay_hours: vLodge.avg_stay_hours,
        profit: {
          scope: "lodge" as const,
          method: "revenue − discounts − lodge-book expenses (all kinds) − lodge-book salaries (settled, months overlapping the window)",
          revenue: vLodge.revenue,
          discounts: vLodge.discounts,
          raw_materials: vExp.lodge.raw_material,
          upgrades: vExp.lodge.upgrade,
          maintenance: vExp.lodge.maintenance,
          salaries_settled: vSal.lodge,
          profit: vProfit.lodge,
          margin_pct: marginPctOf(vProfit.lodge, vLodge.revenue),
        },
        occupancy: {
          live: {
            value_kind: "live_state_snapshot",
            at: istIso(now),
            occupied: statusAt.occupied,
            available: statusAt.available,
            maintenance: statusAt.maintenance,
            total_rooms: rooms.length,
            occupancy_pct: rooms.length ? round2((statusAt.occupied / rooms.length) * 100) : null,
            basis: "occupied ÷ room rows in the database",
          },
          historical:
            vOccupancy && vOccupancy.occupancy_pct !== null
              ? {
                  value_kind: "period_aggregate",
                  scope: "lodge",
                  room_hours_occupied: vOccupancy.room_hours_occupied,
                  capacity_room_hours: vOccupancy.capacity_room_hours,
                  occupancy_pct: vOccupancy.occupancy_pct,
                  window: vOccupancy.window,
                  method: isRange
                    ? "Σ overlap of COMPLETED booking spans (check_in → check_out) with the window ÷ (rooms × window hours). Stays billed outside the window are not in this file, so spans clip at the window edge; guests currently in house are not in completed bookings."
                    : "Σ overlap of COMPLETED booking spans (check_in → check_out) with [first stay → export moment] ÷ (rooms × window hours). Guests currently in house are not in completed bookings — see occupancy.live.",
                  capacity_note: "capacity uses the CURRENT room count; Fetch-X does not track historical wall-size changes.",
                }
              : null,
          historical_null_note: vOccupancy ? null : "Cannot be calculated: no completed lodge stays are included in this export, so no room-hours can be derived. Live occupancy above remains valid.",
        },
      },
      combined: {
        period: { from: periodFrom, to: periodTo, scope: "combined" as const },
        value_kind: "period_aggregate",
        comparability: "Every combined figure sums restaurant + lodge terms that share the same window, the same 5% GST treatment and the same completed-record rule. Nothing else is combined.",
        revenue: round2(vRest.revenue + vLodge.revenue),
        discounts: round2(vRest.discounts + vLodge.discounts),
        tax: round2(vRest.tax + vLodge.tax),
        transactions: vRest.bills + vLodge.bookings,
        expenses_total: vExp.total_combined,
        salaries_settled: vSal.combined,
        profit: vProfit.combined,
        profit_method: "restaurant.profit + lodge.profit (each book already nets its own revenue, discounts, expenses and settled salaries) — identical windows on both sides.",
        margin_pct: marginPctOf(vProfit.combined, round2(vRest.revenue + vLodge.revenue)),
      },
      costs: {
        period: { from: periodFrom, to: periodTo, scope: "rest/lodge splits by Expense.book and Employee.book; combined sums both books" },
        value_kind: "period_aggregate",
        expenses: {
          restaurant: { scope: "restaurant book", raw_materials: vExp.rest.raw_material, upgrades: vExp.rest.upgrade, maintenance: vExp.rest.maintenance, total: vExp.total_rest },
          lodge: { scope: "lodge book", raw_materials: vExp.lodge.raw_material, upgrades: vExp.lodge.upgrade, maintenance: vExp.lodge.maintenance, total: vExp.total_lodge },
          combined: { scope: "combined", raw_materials: round2(vExp.rest.raw_material + vExp.lodge.raw_material), upgrades: round2(vExp.rest.upgrade + vExp.lodge.upgrade), maintenance: round2(vExp.rest.maintenance + vExp.lodge.maintenance), total: vExp.total_combined },
          method: "Expense.amount summed by kind × book, window-bounded by spentOn (IST day).",
        },
        salaries: {
          settled_in_period: {
            value_kind: "settled_actual",
            scope: "per-book split via Employee.book",
            restaurant: vSal.rest,
            lodge: vSal.lodge,
            combined: vSal.combined,
            method: "Σ SalaryPayment.net_paid for settlement months overlapping the window; base − deduction = netPaid verified per row.",
          },
          roster_monthly_total: {
            value_kind: "live_state_snapshot",
            scope: "per-book split via Employee.book",
            restaurant: rosterMonthly.rest,
            lodge: rosterMonthly.lodge,
            combined: rosterMonthly.combined,
            method: "Σ monthly salary of the CURRENT active roster — a run-rate, not window money.",
          },
          accrued_dashboard_definition: dash.team.periodCost,
          accrued_dashboard_note: "accrual_estimate — the dashboard's running salary cost (window start → export moment, both books). Not window-bounded in range exports; see dashboard_summary.team and analytics_integrity.warnings.",
          accrued_window_estimate: windowAccrualReplica
            ? { value_kind: "accrual_estimate", restaurant: windowAccrualReplica.rest, lodge: windowAccrualReplica.lodge, combined: windowAccrualReplica.total, method: `attendance-rule salary accrual over ${dashStartKey} → ${periodTo} (present days + paid-holiday absences × per-day wage), re-derived from this export's attendance records` }
            : null,
          accrued_window_estimate_note: windowAccrualReplica ? null : `null — this window starts mid-month (${fromKey}); the paid-holiday allowance needs attendance from the month's 1st, which a month-start-bounded export cannot provide. Use settled_in_period instead.`,
        },
        budget_utilization: {
          value_kind: "period_aggregate",
          scope: "combined (owner tasks of both books) — per-book split in budgets.by_book",
          allocated: vBudget.allocated,
          used: vBudget.used,
          remaining: vBudget.remaining,
          utilization_pct: vBudget.utilization_pct,
          method: "Σ maxBudget and Σ actualCost across budgeted owner tasks in the window; utilization = used ÷ allocated × 100 (null when nothing was budgeted).",
          over_budget_tasks: vBudget.over_budget_tasks,
        },
      },
      task_completion: {
        period: { from: periodFrom, to: periodTo, scope: "restaurant / lodge by Task.book; combined sums both" },
        value_kind: "period_aggregate",
        restaurant: { scope: "restaurant" as const, total: vTasks.rest.total, done: vTasks.rest.done, open: vTasks.rest.open, completion_pct: vTasks.rest.total ? round2((vTasks.rest.done / vTasks.rest.total) * 100) : null },
        lodge: { scope: "lodge" as const, total: vTasks.lodge.total, done: vTasks.lodge.done, open: vTasks.lodge.open, completion_pct: vTasks.lodge.total ? round2((vTasks.lodge.done / vTasks.lodge.total) * 100) : null },
        combined: { scope: "combined" as const, total: vTasks.total, done: vTasks.rest.done + vTasks.lodge.done, open: vTasks.rest.open + vTasks.lodge.open, completion_pct: vTasks.total ? round2(((vTasks.rest.done + vTasks.lodge.done) / vTasks.total) * 100) : null },
        method: "status = open | done; completion_pct = done ÷ total × 100 (null when the scope has no tasks).",
      },
      attendance: {
        period: { from: periodFrom, to: periodTo, scope: "all staff — the register is not book-tagged; the per-book split joins Employee.book" },
        value_kind: "period_aggregate",
        marked_days: vAtt.marked_days,
        present_days: vAtt.present,
        absent_days: vAtt.absent,
        attendance_pct: vAtt.attendance_pct,
        attendance_pct_definition: "present ÷ marked days × 100. Unmarked days have no row and are NOT absences.",
        by_book: {
          restaurant: { present: vAtt.rest.present, absent: vAtt.rest.absent },
          lodge: { present: vAtt.lodge.present, absent: vAtt.lodge.absent },
          unattributable: { rows: vAtt.unattributable_rows, note: "rows whose employee_id is missing from the roster" },
        },
        rows_from_inactive_employees: vAtt.inactive_roster_rows,
      },
      salary: {
        period: { from: periodFrom, to: periodTo, scope: "per-book split via Employee.book; settlement months overlap the window" },
        value_kind: "settled_actual",
        settled: {
          combined: vSal.combined,
          restaurant_book: vSal.rest,
          lodge_book: vSal.lodge,
          settlements: vSal.rows,
          paid_settlements: vSal.paid_rows,
          method: "Σ SalaryPayment.net_paid (base − deduction, verified per row). Unattributable rows (employee missing from roster): " + vSal.unattributable_rows,
        },
        months: salaryExport.monthly_summaries.length,
        note: "For per-month and per-employee detail see the salary and employees sections — those rows are the same records these totals verify against.",
      },
      all_time: {
        value_kind: "all_time_total",
        derivation_note: isRange
          ? "DATE RANGE export: queried live from the database at the export moment — deliberately broader than this file's records, so these figures CANNOT be re-derived from the filtered records above (they are still true database values, not estimates)."
          : "FULL export: this file carries every record, so all-time equals the verified window figures above (checked in analytics_integrity).",
        restaurant: { scope: "restaurant" as const, bills: vAllTime.restaurant.bills, revenue: vAllTime.restaurant.revenue },
        lodge: { scope: "lodge" as const, bookings: vAllTime.lodge.bookings, revenue: vAllTime.lodge.revenue },
        combined: { scope: "combined" as const, revenue: vAllTime.combined.revenue, transactions: vAllTime.combined.transactions },
      },
      analytics_integrity: {
        status: failedChecks.length === 0 ? "passed" : "failed",
        checks_performed: integrityChecks.length,
        checks_failed: failedChecks.length,
        failed_check_names: failedChecks.map((c) => c.name),
        warnings: integrityWarnings,
        tolerance: "money compared within ±0.5 ₹ (2-decimal rounding; per-record arithmetic ±0.02 ₹); counts and percentages must match exactly",
        checked_at: istIso(now),
        method: "Each aggregate was recomputed from the raw records included in this file and compared to the value written here, before the file was assembled. Definitions that cannot be reconciled are labelled on their fields and listed in warnings — conflicting numbers are never silently merged. Failed checks mean the exporter found arithmetic it could not reproduce; raw records are never altered to make numbers match.",
      },
    };

    // ══════════════════════════ RELATIONSHIPS + DATA DICTIONARY ══════════════════════════
    const relationships = {
      employee_id: "employees.records.employee_id → attendance.records.employee_id → salary.payments.employee_id. Tasks do not carry employee ids (they are forwarded to a reception 'book', not a person).",
      dish_id: "menu.dishes.dish_id → receipts[].items[].dish_id (null when the dish was later deleted from the menu; receipt items snapshot name+price, so history stays accurate either way).",
      room_number: "rooms.current_rooms.room_number → bookings.records.room_number → lodge revenue analytics.",
      task_id: "tasks.records.task_id → expenses.records.task_id (expenses auto-registered from closed budgeted tasks) and tasks.records.updates (progress notes).",
      receipt_id: "receipts[].receipt_id → restaurant analytics; bill numbers print as #1001+ (restaurant) and L-5001+ (lodge) — two independent series.",
      book: "employees.book / expenses.book / tasks.book — 'rest' = restaurant cost book, 'lodge' = lodge cost book. The two books share one roof and one dashboard.",
    };
    const data_dictionary = {
      book: "Which business's cost book a record belongs to: rest | lodge.",
      scope: "Which business a FIGURE describes: restaurant (Bill receipts / rest-book rows only) · lodge (LodgeBill bookings / lodge-book rows only) · combined (same-window sum of both, only where definitions match) · labelled otherwise (e.g. 'all staff', 'MIXED').",
      value_kind: "What kind of figure a field holds: period_aggregate (this export's window) | all_time_total (whole database history) | live_state_snapshot (current tables at export moment) | projection (forward-looking estimate) | settled_actual (exact money from records) | accrual_estimate (attendance-derived salary estimate).",
      period: "Every analytics sub-block carries { from, to, scope } in IST calendar days so no figure can be read without its time window.",
      kind: "Expense/task expense type: raw_material | upgrade | maintenance.",
      status_room: "avl = available · occ = occupied (guest in house) · mnt = maintenance/housekeeping wait.",
      IST: "All dates/times are Asia/Kolkata (UTC+05:30); date is the IST calendar day of the record.",
      money: "All money fields are INR, rounded to 2 decimals; totals include 5% GST; discounts are absolute rupees taken off the bill.",
      minApplied: "True when the lodge stay was below the ₹1,000 minimum charge and the floor was applied.",
      attendance_pct: "present ÷ marked days × 100. Unmarked days simply have no row — they are not auto-absences.",
      netPaid: "base − deduction, where deduction = (absent days − paid holidays) × per-day wage (monthly salary ÷ days in that month).",
      profit_convention: "Profit = revenue − discounts − expenses − salaries. Revenue is GST-INCLUSIVE (the dashboard's long-standing convention); per-book profit uses SETTLED salary money and window-bounded expenses so every term shares one window. The dashboard's own NET PROFIT card is different (mixed scope) and labelled as such in dashboard_summary.costs.",
      analytics_integrity: "Self-audit block: every analytics aggregate is recomputed from this file's raw records and compared before writing. status = passed only when every check holds; warnings list labelled definitional differences that are NOT errors.",
    };

    // ══════════════════════════ FINAL PAYLOAD ══════════════════════════
    const payload = {
      fetchx_export,
      business,
      dashboard_summary,
      sales,
      receipts,
      menu,
      expenses: expensesExport,
      tasks: tasksExport,
      employees: employeesExport,
      attendance: attendanceExport,
      salary: salaryExport,
      rooms: roomsExport,
      bookings: bookingsExport,
      raw_materials: rawMaterialsExport,
      budgets: budgetsExport,
      restaurant: restaurantRollup,
      lodge: lodgeRollup,
      analytics: analyticsExport,
      relationships,
      data_dictionary,
    };

    // Serialize (guaranteed-valid JSON by construction; stringify also acts as
    // the validation pass — a failure here returns a 500 instead of a bad file).
    const json = JSON.stringify(payload);

    return new NextResponse(json, {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="FetchX_AI_Snapshot_${fileStamp}.json"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    console.error("[export] failed:", e);
    return NextResponse.json({ error: "Export failed", detail: String((e as Error)?.message ?? e) }, { status: 500 });
  }
}
