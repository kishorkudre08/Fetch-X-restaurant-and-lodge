import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// t113 — daily staff attendance. One row per employee per date, status is
// "present" | "absent" only (no late mechanism by design).

// GET /api/attendance?date=YYYY-MM-DD — every marked row for that day
export async function GET(req: NextRequest) {
  const date = req.nextUrl.searchParams.get("date") ?? "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
    return NextResponse.json({ error: "date=YYYY-MM-DD is required" }, { status: 400 });
  const rows = await db.attendance.findMany({
    where: { date },
    select: { employeeId: true, status: true },
  });
  return NextResponse.json(rows);
}

// POST /api/attendance — upsert one mark or a whole day at once:
//   { date, employeeId, status }                       → single mark
//   { date, entries: [{ employeeId, status }, …] }     → bulk (all present / all absent)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const date = String(body.date ?? "");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
      return NextResponse.json({ error: "date=YYYY-MM-DD is required" }, { status: 400 });

    const entries: Array<{ employeeId: string; status: string }> = Array.isArray(body.entries)
      ? body.entries
      : [{ employeeId: String(body.employeeId ?? ""), status: String(body.status ?? "") }];

    const clean = entries
      .filter((e) => e && typeof e.employeeId === "string" && e.employeeId && (e.status === "present" || e.status === "absent"))
      .map((e) => ({ employeeId: e.employeeId, status: e.status }));
    if (!clean.length)
      return NextResponse.json({ error: "status must be present | absent" }, { status: 400 });

    await db.$transaction(
      clean.map((e) =>
        db.attendance.upsert({
          where: { employeeId_date: { employeeId: e.employeeId, date } },
          create: { employeeId: e.employeeId, date, status: e.status },
          update: { status: e.status },
        }),
      ),
    );
    return NextResponse.json({ saved: clean.length, date });
  } catch {
    return NextResponse.json({ error: "Could not save attendance" }, { status: 500 });
  }
}
