import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const daysRaw = Number(sp.get("days") ?? "30");
  const days = Number.isFinite(daysRaw) && daysRaw >= 1 && daysRaw <= 365
    ? Math.floor(daysRaw)
    : 30;
  const bookFilter = sp.get("book");
  const book = bookFilter === "rest" || bookFilter === "lodge" ? bookFilter : undefined;

  const IST_OFFSET_MIN = 330;
  const nowIst = new Date(Date.now() + IST_OFFSET_MIN * 60000);
  const dates: string[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(nowIst.getTime() - i * 86_400_000);
    dates.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
  }
  const from = dates[0];
  const to = dates[dates.length - 1];

  const [employees, marks] = await Promise.all([
    db.employee.findMany({
      where: { active: true, ...(book ? { book } : {}) },
      orderBy: [{ book: "asc" }, { salary: "desc" }],
      select: { id: true, name: true, role: true, book: true, salary: true },
    }),
    db.attendance.findMany({
      where: { date: { gte: from, lte: to } },
      select: { employeeId: true, date: true, status: true },
    }),
  ]);

  const inBookIds = new Set(employees.map((e) => e.id));
  const filteredMarks = book
    ? marks.filter((m) => inBookIds.has(m.employeeId))
    : marks;

  const byEmp = new Map<string, Record<string, string>>();
  for (const m of filteredMarks) {
    const map = byEmp.get(m.employeeId) ?? {};
    map[m.date] = m.status;
    byEmp.set(m.employeeId, map);
  }

  const employeesOut = employees.map((e) => {
    const m = byEmp.get(e.id) ?? {};
    let present = 0;
    let absent = 0;
    for (const d of dates) {
      const s = m[d];
      if (s === "present") present++;
      else if (s === "absent") absent++;
    }
    const marked = present + absent;
    const unmarked = dates.length - marked;
    const rate = marked > 0 ? Math.round((present / marked) * 100) : 0;
    return {
      id: e.id, name: e.name, role: e.role, book: e.book as "rest" | "lodge",
      marks: m, present, absent, unmarked, rate,
    };
  });

  return NextResponse.json({ dates, employees: employeesOut, days, from, to });
}
