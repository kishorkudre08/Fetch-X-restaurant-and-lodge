import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { RANGE_META, parseRange } from "@/lib/analytics";

export const dynamic = "force-dynamic";

// ── t120 · ATTENDANCE GRAPH — consistent per-employee day math ─────────────
// The dashboard's attendance bars must show the SAME total days for every
// employee — the length of the selected window — no matter how many rows
// exist in the attendance table:
//   today = 1 · 7 days = 7 · 1 month = 30 · 3 months = 91 · 1 year = 365
// present  = attendance rows marked present inside the window
// absent   = totalDays − present (unmarked days count as absent)
export async function GET(req: NextRequest) {
  const range = parseRange(req.nextUrl.searchParams.get("range"));
  const days = RANGE_META[range].days;

  // IST date keys covering the window (same convention as the attendance UI).
  const keys: string[] = [];
  const IST_OFFSET_MIN = 330;
  const nowIst = new Date(Date.now() + IST_OFFSET_MIN * 60000);
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(nowIst.getTime() - i * 86_400_000);
    keys.push(d.toISOString().slice(0, 10));
  }
  const from = keys[0];
  const to = keys[keys.length - 1];

  const [employees, marks] = await Promise.all([
    db.employee.findMany({ where: { active: true }, orderBy: [{ book: "asc" }, { salary: "desc" }] }),
    db.attendance.groupBy({
      by: ["employeeId", "status"],
      where: { date: { gte: from, lte: to } },
      _count: true,
    }),
  ]);

  const presentOf = new Map<string, number>();
  for (const m of marks)
    if (m.status === "present") presentOf.set(m.employeeId, m._count);

  const employeesOut = employees.map((e) => {
    const present = Math.min(presentOf.get(e.id) ?? 0, days);
    return {
      id: e.id,
      name: e.name,
      role: e.role,
      book: e.book as "rest" | "lodge",
      present,
      absent: days - present,
      total: days,
    };
  });

  return NextResponse.json({ range, days, from, to, employees: employeesOut });
}
