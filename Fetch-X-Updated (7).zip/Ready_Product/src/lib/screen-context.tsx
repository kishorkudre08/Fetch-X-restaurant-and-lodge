"use client";

/* t151 · SCREEN CONTEXT — gives the AI copilot eyes on what the owner is
 * looking at. Every page/section registers itself via useRegisterScreen()
 * with:
 *   · sectionId  — a stable slug ("dashboard", "pos", "lodge", "tasks",
 *                  "settings", "theme-gallery", "attendance", "expenses",
 *                  "menu", "management" …). This is the "address" the AI
 *                  uses to know which page the user is on.
 *   · sectionLabel — a human-readable label ("Live Dashboard", "POS
 *                  Billing", "Lodge Front Desk"). The AI sees this in its
 *                  system prompt.
 *   · viewState  — optional object with page-specific state (e.g. for
 *                  the dashboard: which range tab is selected; for the
 *                  lodge: which filter; for POS: which bill is open). The
 *                  AI sees a JSON dump of this so it can answer "what am
 *                  I looking at right now?" with the same context the
 *                  user has.
 *
 * The context also tracks viewport info — innerWidth, innerHeight,
 * devicePixelRatio (a proxy for browser zoom), and the document's scroll
 * offset — so the AI can reason about "how much of the page is visible"
 * if asked ("I can only see the top half of the dashboard"). The viewport
 * refreshes on resize/scroll but is throttled.
 *
 * Architecture for the future (per the owner's brief: "make subpages or
 * addresses for each page/section, for future not current"):
 *   · every section registers a stable sectionId on mount
 *   · the AI request includes the screen context in the body
 *   · /api/ai injects it into the system prompt as a [SCREEN CONTEXT]
 *     block, so the AI knows where the user is and what they're seeing
 *   · the viewState is free-form per section, so future sections can
 *     attach whatever context they want without changing the contract
 */

import * as React from "react";

export type ScreenContextValue = {
  /** Stable slug for the section the user is on (e.g. "dashboard"). */
  sectionId: string | null;
  /** Human-readable label (e.g. "Live Dashboard"). */
  sectionLabel: string | null;
  /** Page-specific state — range tab, filter, open bill, etc. The AI
   *  sees this as JSON, so it can be any serialisable shape. */
  viewState: Record<string, unknown> | null;
  /** Current URL pathname — the global "address" of the page. */
  route: string | null;
  /** Viewport info — for "how much of the page am I seeing" queries. */
  viewport: {
    innerWidth: number;
    innerHeight: number;
    devicePixelRatio: number; // proxy for browser zoom (1 = 100%, 1.5 = 150%)
    scrollY: number;
  } | null;
};

const ScreenContext = React.createContext<ScreenContextValue>({
  sectionId: null,
  sectionLabel: null,
  viewState: null,
  route: null,
  viewport: null,
});

/** Provider that wraps the app — tracks viewport + route changes. */
export function ScreenContextProvider({ children }: { children: React.ReactNode }) {
  const [section, setSection] = React.useState<{ id: string; label: string; viewState: Record<string, unknown> | null } | null>(null);
  const [viewport, setViewport] = React.useState<ScreenContextValue["viewport"]>(null);

  // Track viewport (resize + scroll). Throttle to once per 200ms.
  React.useEffect(() => {
    let raf = 0;
    let last = 0;
    const read = () => {
      const now = Date.now();
      if (now - last < 200) return;
      last = now;
      setViewport({
        innerWidth: window.innerWidth,
        innerHeight: window.innerHeight,
        devicePixelRatio: window.devicePixelRatio || 1,
        scrollY: window.scrollY || 0,
      });
    };
    const onResize = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(read);
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(read);
    };
    read(); // initial
    window.addEventListener("resize", onResize);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  // Track route changes (Next.js App Router uses the path as the address).
  const [route, setRoute] = React.useState<string | null>(typeof window !== "undefined" ? window.location.pathname : null);
  React.useEffect(() => {
    const onPop = () => setRoute(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const value: ScreenContextValue = React.useMemo(
    () => ({
      sectionId: section?.id ?? null,
      sectionLabel: section?.label ?? null,
      viewState: section?.viewState ?? null,
      route,
      viewport,
    }),
    [section, route, viewport],
  );

  // The register function — stable across renders so child effects don't loop.
  const register = React.useCallback(
    (id: string, label: string, viewState: Record<string, unknown> | null = null) => {
      setSection((cur) => {
        // Skip if no change (deep equality would be safer but JSON stringify
        // is good enough for our shapes).
        const vsJson = viewState ? JSON.stringify(viewState) : null;
        const curVsJson = cur?.viewState ? JSON.stringify(cur.viewState) : null;
        if (cur?.id === id && cur?.label === label && curVsJson === vsJson) return cur;
        return { id, label, viewState };
      });
    },
    [],
  );

  // We expose `register` via a separate context so consumers can call it
  // without re-rendering everyone on every viewport change.
  return (
    <RegisterContext.Provider value={register}>
      <ScreenContext.Provider value={value}>{children}</ScreenContext.Provider>
    </RegisterContext.Provider>
  );
}

const RegisterContext = React.createContext<(id: string, label: string, viewState?: Record<string, unknown> | null) => void>(() => {});

/**
 * Register the current page/section with the screen context. Call this from
 * a section's top-level component:
 *
 *   useRegisterScreen("dashboard", "Live Dashboard", { range: "today" });
 *
 * The viewState can be any JSON-serialisable object — when the user asks
 * "what am I looking at?", the AI sees this JSON in its system prompt.
 */
export function useRegisterScreen(
  id: string,
  label: string,
  viewState?: Record<string, unknown> | null,
) {
  const register = React.useContext(RegisterContext);
  React.useEffect(() => {
    register(id, label, viewState ?? null);
  }, [register, id, label, viewState]);
}

/** Read the current screen context (for the AI panel to send with requests). */
export function useScreenContext(): ScreenContextValue {
  return React.useContext(ScreenContext);
}

/**
 * Serialise the current screen context into a compact string for the AI
 * system prompt. Returns null if no section is registered yet (so the AI
 * just doesn't get a [SCREEN CONTEXT] block — it doesn't break).
 */
export function screenContextToPromptString(ctx: ScreenContextValue): string | null {
  if (!ctx.sectionId && !ctx.route) return null;
  const lines: string[] = [];
  lines.push(`route: ${ctx.route ?? "/"}`);
  lines.push(`sectionId: ${ctx.sectionId ?? "(none)"}`);
  lines.push(`sectionLabel: ${ctx.sectionLabel ?? "(none)"}`);
  if (ctx.viewport) {
    const zoom = Math.round((ctx.viewport.devicePixelRatio || 1) * 100);
    lines.push(`viewport: ${ctx.viewport.innerWidth}×${ctx.viewport.innerHeight}px @ ${zoom}% zoom, scrollY=${Math.round(ctx.viewport.scrollY)}px`);
  }
  if (ctx.viewState && Object.keys(ctx.viewState).length > 0) {
    try {
      lines.push(`viewState: ${JSON.stringify(ctx.viewState)}`);
    } catch {
      // viewState not JSON-serialisable — skip
    }
  }
  return lines.join("\n");
}
