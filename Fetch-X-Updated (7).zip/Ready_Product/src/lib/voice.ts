"use client";

/* t147 — VOICE — Web Speech API plumbing + voice preference storage.
 *
 * The Fetch-X live-talk feature uses the browser's built-in:
 *   · SpeechRecognition (SpeechRecognition || webkitSpeechRecognition) for STT
 *   · speechSynthesis for TTS
 *
 * Voices are OS-dependent — Chrome surfaces OS voices (Microsoft David,
 * Microsoft Zira, Google US English, etc.). The picker enumerates whatever
 * the platform offers and lets the user pick one. Stored per-account so
 * each reception/owner keeps their own voice.
 */

const VOICE_KEY_PREFIX = "fx-ai-voice";

export function voiceStorageKey(account?: string | null): string {
  const who = (account ?? "").trim().toLowerCase();
  return `${VOICE_KEY_PREFIX}:${who || "guest"}`;
}

export function readStoredVoice(account?: string | null): string | null {
  try {
    return localStorage.getItem(voiceStorageKey(account));
  } catch {
    return null;
  }
}

export function writeStoredVoice(voiceURI: string, account?: string | null): void {
  try {
    localStorage.setItem(voiceStorageKey(account), voiceURI);
  } catch {
    /* private mode */
  }
}

export type FxVoice = {
  voiceURI: string;
  name: string;
  lang: string;
  /** heuristic: "male" | "female" | "neutral" — best-effort from name tokens */
  gender: "male" | "female" | "neutral";
  /** "Microsoft" / "Google" / "Apple" — vendor prefix where available */
  vendor: string;
};

/* Name tokens that hint at gender. Imperfect; the user can override by
 * picking any voice regardless of the label. */
const MALE_HINTS = ["david", "mark", "george", "james", "fred", "ravi", "mahesh", "hemanth", "alex", "daniel", "thomas", "arthur", "oliver"];
const FEMALE_HINTS = ["zira", "susan", "hazel", "catherine", "linda", "heather", "veena", "sangeeta", "rishi", "anjali", "priya", "aria", "jenny", "samantha", "tessa", "serena"];

function guessGender(name: string): "male" | "female" | "neutral" {
  const lc = name.toLowerCase();
  if (MALE_HINTS.some((h) => lc.includes(h))) return "male";
  if (FEMALE_HINTS.some((h) => lc.includes(h))) return "female";
  return "neutral";
}

function vendorOf(name: string): string {
  if (/^microsoft/i.test(name)) return "Microsoft";
  if (/^google/i.test(name)) return "Google";
  if (/^apple/i.test(name)) return "Apple";
  if (/^amazon/i.test(name)) return "Amazon";
  return "System";
}

/** Wait for speechSynthesis to populate voices (Chrome loads them async). */
export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve([]);
      return;
    }
    const cur = window.speechSynthesis.getVoices();
    if (cur.length) {
      resolve(cur);
      return;
    }
    let done = false;
    const finish = (v: SpeechSynthesisVoice[]) => {
      if (done) return;
      done = true;
      resolve(v);
    };
    window.speechSynthesis.onvoiceschanged = () => finish(window.speechSynthesis.getVoices());
    setTimeout(() => finish(window.speechSynthesis.getVoices()), 1200);
  });
}

/** Map platform voices to FxVoice objects. */
export function toFxVoices(voices: SpeechSynthesisVoice[]): FxVoice[] {
  return voices
    .filter((v) => v.lang.toLowerCase().startsWith("en") || /india|hindi/i.test(v.name))
    .map((v) => ({
      voiceURI: v.voiceURI,
      name: v.name,
      lang: v.lang,
      gender: guessGender(v.name),
      vendor: vendorOf(v.name),
    }));
}

/** Find a sensible default — prefer Microsoft David (deep male), else a
 *  Microsoft female voice, else any English voice, else the first one. */
export function pickDefaultVoice(voices: FxVoice[]): FxVoice | null {
  if (!voices.length) return null;
  const david = voices.find((v) => /microsoft david/i.test(v.name));
  if (david) return david;
  const msFemale = voices.find((v) => v.vendor === "Microsoft" && v.gender === "female");
  if (msFemale) return msFemale;
  const enUS = voices.find((v) => v.lang === "en-US");
  if (enUS) return enUS;
  return voices[0];
}

/** Resolve a stored voiceURI to a real SpeechSynthesisVoice (or null). */
export function findVoice(voices: SpeechSynthesisVoice[], voiceURI: string | null): SpeechSynthesisVoice | null {
  if (!voiceURI) return null;
  return voices.find((v) => v.voiceURI === voiceURI) ?? null;
}

/** Speak text using the chosen voice. Cancels any in-flight speech first.
 *  Returns a promise that resolves when speech finishes (or errors). */
export function speak(
  text: string,
  voice: SpeechSynthesisVoice | null,
  opts: { rate?: number; pitch?: number; volume?: number; onStart?: () => void; onEnd?: () => void; onError?: () => void } = {},
): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve();
      return;
    }
    const synth = window.speechSynthesis;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(stripForSpeech(text));
    if (voice) u.voice = voice;
    u.rate = opts.rate ?? 1.0;
    u.pitch = opts.pitch ?? 1.0;
    u.volume = opts.volume ?? 1.0;
    u.onstart = () => opts.onStart?.();
    u.onend = () => {
      opts.onEnd?.();
      resolve();
    };
    u.onerror = () => {
      opts.onError?.();
      resolve();
    };
    synth.speak(u);
  });
}

/** Strip markdown/code fences for speech — the live-talk reply is plain
 *  text already, but if a stray table leaks through, we don't want the
 *  TTS reading "pipe pipe pipe" out loud.
 *
 *  t155 — ALSO converts any ₹-prefixed numerals in the text to their
 *  SPOKEN Indian chain, so the displayed live bubble can show "₹2,64,812"
 *  (numerals) while the TTS reads "rupees two lakh sixty-four thousand
 *  eight hundred twelve" naturally.
 *
 *  t156 — ALSO respells "lakh", "lakhs", "paise", "paisa", "crore",
 *  "crores" so OS TTS engines pronounce them correctly. Without this,
 *  Chrome/Edge TTS reads "lakh" as "laak" (drops the 'k') and "paise"
 *  as "pace" (treats 'ai' as long-A). The respellings map to phonetic
 *  English that the engine pronounces closer to the Indian sound:
 *    lakh   → lak    (engine reads /læk/ ≈ Indian /lak/)
 *    paise  → piesay (engine reads /paɪseɪ/ ≈ Indian /paɪseɪ/)
 *    crore  → kror   (engine reads /krɔːr/ ≈ Indian /kroːr/)
 */
export function stripForSpeech(text: string): string {
  let out = text;
  // t155 — replace ₹-prefixed numerals with their spoken Indian form.
  // Matches: ₹2,64,812 · ₹1,50,00,000 · ₹500 · ₹501.24 · ₹2.4L · ₹1.2Cr
  // The ₹ symbol is left in the text → the TTS engine reads it as "rupees"
  // (most voices do). The number after is converted to the full chain.
  out = out.replace(/₹\s?(\d[\d,]*\.?\d*)(?:\s(lakh|lakhs|crore|crores)\b)?/gi, (full, numStr, unit) => {
    // Strip trailing comma if the regex captured it (e.g. "₹17,543," — the
    // , after the number was getting absorbed by [\d,]*). The number itself
    // uses Indian grouping internally, so we keep internal commas but drop
    // any trailing one.
    const cleaned = numStr.replace(/,$/, "");
    const clean = cleaned.replace(/,/g, "");
    const num = Number(clean);
    if (!Number.isFinite(num)) return full;
    const spoken = numberToIndianSpoken(num);
    const u = unit ? ` ${unit.toLowerCase()}` : "";
    // Trailing space ensures the next word doesn't get glued to the
    // converted number ("₹2,64,812 across" → "rupees two lakh ... twelve across",
    // not "twelveacross"). If we stripped a trailing comma, restore it.
    const tail = numStr.endsWith(",") ? ", " : " ";
    return `rupees ${spoken}${u}${tail}`;
  });
  // t156 — fix common TTS mispronunciations of Indian units.
  out = out
    .replace(/\blakhs\b/gi, "laks")
    .replace(/\blakh\b/gi, "lak")
    .replace(/\bpaise\b/gi, "piesay")
    .replace(/\bpaisa\b/gi, "piesa")
    .replace(/\bcrores\b/gi, "krores")
    .replace(/\bcrore\b/gi, "kror");
  // markdown stripping (kept for safety even though live mode is plain)
  out = out
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/!\[[^\]]*\]\([^)]+\)/g, " ")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/^\s*\|.*\|\s*$/gm, " ")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/[*_~#]/g, "")
    .replace(/\n{2,}/g, ". ")
    .replace(/\s+/g, " ")
    .trim();
  return out;
}

/* t155 — convert a number to its SPOKEN Indian form (full place-value
 * chain). Powers the live-talk TTS so the displayed bubble can show
 * numerals (₹2,64,812) while the speech says
 * "two lakh sixty-four thousand eight hundred twelve".
 *
 *   0           → "zero"
 *   500         → "five hundred"
 *   134000      → "one lakh thirty-four thousand"
 *   264812      → "two lakh sixty-four thousand eight hundred twelve"
 *   1234567     → "twelve lakh thirty-four thousand five hundred sixty-seven"
 *   15000000    → "one crore fifty lakh"
 *   10000000    → "one crore"
 *
 * The chain: crore (1,00,00,000) → lakh (1,00,000) → thousand (1,000) →
 * hundred (100) → tens+units. Paise (decimal part) appended as
 * "point one two three" digit-by-digit.
 */
const ONES = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
const TENS_WORDS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

function speakUnder100(n: number): string {
  if (n < 20) return ONES[n];
  const t = Math.floor(n / 10);
  const u = n % 10;
  return u === 0 ? TENS_WORDS[t] : `${TENS_WORDS[t]} ${ONES[u]}`;
}

function speakUnder1000(n: number): string {
  if (n < 100) return speakUnder100(n);
  const h = Math.floor(n / 100);
  const r = n % 100;
  return r === 0 ? `${ONES[h]} hundred` : `${ONES[h]} hundred ${speakUnder100(r)}`;
}

function speakUnderLakh(n: number): string {
  if (n < 1000) return speakUnder1000(n);
  const th = Math.floor(n / 1000);
  const r = n % 1000;
  return r === 0 ? `${speakUnder100(th)} thousand` : `${speakUnder100(th)} thousand ${speakUnder1000(r)}`;
}

function speakUnderCrore(n: number): string {
  if (n < 100000) return speakUnderLakh(n);
  const lh = Math.floor(n / 100000);
  const r = n % 100000;
  return r === 0 ? `${speakUnder100(lh)} lakh` : `${speakUnder100(lh)} lakh ${speakUnderLakh(r)}`;
}

function speakInteger(n: number): string {
  if (n === 0) return "zero";
  if (n < 10000000) return speakUnderCrore(n);
  const cr = Math.floor(n / 10000000);
  const r = n % 10000000;
  return r === 0 ? `${speakUnder100(cr)} crore` : `${speakUnder100(cr)} crore ${speakUnderCrore(r)}`;
}

/** Speak a decimal number — integer part via the Indian chain, decimal
 *  part as "point" followed by per-digit. */
export function numberToIndianSpoken(n: number): string {
  if (!Number.isFinite(n)) return String(n);
  const intPart = Math.floor(Math.abs(n));
  const sign = n < 0 ? "minus " : "";
  const intSpoken = speakInteger(intPart);
  const decStr = String(n).split(".")[1];
  if (!decStr) return `${sign}${intSpoken}`;
  const digits = decStr.split("").map((d) => ONES[Number(d)]).join(" ");
  return `${sign}${intSpoken} point ${digits}`;
}

/* ── SPEECH RECOGNITION (STT) ──────────────────────────────────────────────── */

type AnyRec = typeof SpeechRecognition;

export function newRecognition(): AnyRec | null {
  if (typeof window === "undefined") return null;
  const Ctor = (window as unknown as { SpeechRecognition?: AnyRec; webkitSpeechRecognition?: AnyRec }).SpeechRecognition
    ?? (window as unknown as { webkitSpeechRecognition?: AnyRec }).webkitSpeechRecognition;
  if (!Ctor) return null;
  const r = new Ctor();
  r.lang = "en-IN";
  r.continuous = true;
  r.interimResults = true;
  r.maxAlternatives = 1;
  return r;
}

export function isSttSupported(): boolean {
  if (typeof window === "undefined") return false;
  return !!(
    (window as unknown as { SpeechRecognition?: AnyRec }).SpeechRecognition
    ?? (window as unknown as { webkitSpeechRecognition?: AnyRec }).webkitSpeechRecognition
  );
}

export function isTtsSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}
