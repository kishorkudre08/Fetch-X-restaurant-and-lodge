"use client";

/* t184 · VIEW-STATE CACHE — every section's toggles (range tab, scope chip,
 * filter chip, salary month, attendance date …) survive a section switch.
 *
 * Why: the owner asked for "a cache of toggles, if I open a toggle switch the
 * section and come back, the same thing should show up". Without this, every
 * section's local useState resets when the user navigates away and back.
 *
 * The contract is intentionally tiny:
 *
 *   const [range, setRange] = useCachedToggle<RangeKey>("dashboard", "range", "today");
 *
 * The hook:
 *   1. Reads the initial value from localStorage on mount (so reload + cross-
 *      section navigation both restore the last-used state).
 *   2. Writes through to localStorage on every user-driven change.
 *   3. Subscribes to in-memory pub/sub so the SAME hook instance updates
 *      live when the AI (or another view) writes to the cache while the
 *      target view is already mounted. e.g. owner is on the dashboard and
 *      says "switch to yearly view" — the dashboard's `range` flips to "1y"
 *      without needing a remount.
 *
 * Two pure helpers (`readCachedToggle`, `writeCachedToggle`) are also exported
 * so the AI panel can prime the cache BEFORE it calls onNavigate(view) —
 * this is how "open live dashboard in yearly view" actually delivers the
 * yearly state to the dashboard the moment it mounts.
 */

import * as React from "react";

const PREFIX = "fx-vs:"; // namespace inside localStorage

/* in-memory pub/sub — one Set of listeners per (sectionId, toggleId) key.
   When the AI writes to a toggle that a live view is subscribed to, the
   listener fires and the view's useState updates without a remount. */
type Listener = (value: unknown) => void;
const listeners = new Map<string, Set<Listener>>();

function key(sectionId: string, toggleId: string) {
  return `${PREFIX}${sectionId}:${toggleId}`;
}

function listenersKey(sectionId: string, toggleId: string) {
  return `${sectionId}:${toggleId}`;
}

function notifyListeners(sectionId: string, toggleId: string, value: unknown) {
  const set = listeners.get(listenersKey(sectionId, toggleId));
  if (!set) return;
  // Clone to be safe against unsubscribe-during-iteration
  for (const fn of Array.from(set)) {
    try {
      fn(value);
    } catch {
      /* listener threw — keep notifying the rest */
    }
  }
}

export function readCachedToggle<T>(sectionId: string, toggleId: string, defaultValue: T): T {
  if (typeof window === "undefined") return defaultValue;
  try {
    const raw = window.localStorage.getItem(key(sectionId, toggleId));
    if (raw == null) return defaultValue;
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

export function writeCachedToggle<T>(sectionId: string, toggleId: string, value: T): void {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(key(sectionId, toggleId), JSON.stringify(value));
    } catch {
      /* private mode / quota — ignore */
    }
  }
  notifyListeners(sectionId, toggleId, value);
}

export function clearCachedToggle(sectionId: string, toggleId: string): void {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.removeItem(key(sectionId, toggleId));
    } catch {
      /* ignore */
    }
  }
  notifyListeners(sectionId, toggleId, undefined);
}

/** Subscribe to external writes (AI navigation, another view, etc.). Returns
 *  an unsubscribe function. */
export function subscribeToToggle(
  sectionId: string,
  toggleId: string,
  cb: Listener,
): () => void {
  const k = listenersKey(sectionId, toggleId);
  let set = listeners.get(k);
  if (!set) {
    set = new Set();
    listeners.set(k, set);
  }
  set.add(cb);
  return () => {
    const s = listeners.get(k);
    if (s) {
      s.delete(cb);
      if (s.size === 0) listeners.delete(k);
    }
  };
}

/**
 * Drop-in replacement for `useState` that persists the value across
 * section switches AND reactively updates when the cache is written
 * externally (e.g. by the AI panel navigating with a toggle payload).
 *
 *   const [range, setRange] = useCachedToggle<RangeKey>("dashboard", "range", "today");
 *
 * The setter accepts either a value or an updater function, just like
 * useState. Every set writes through to localStorage so a reload of the
 * page restores the same view.
 */
export function useCachedToggle<T>(
  sectionId: string,
  toggleId: string,
  defaultValue: T,
): [T, (next: T | ((prev: T) => T)) => void] {
  const [value, setValue] = React.useState<T>(() => readCachedToggle(sectionId, toggleId, defaultValue));

  // Track the latest value in a ref so the subscription callback can decide
  // whether to call setValue (avoiding redundant renders when the AI writes
  // the same value the user just set locally — a primitive-equality guard).
  const valueRef = React.useRef<T>(value);
  React.useEffect(() => {
    valueRef.current = value;
  }, [value]);

  // Subscribe to external writes (AI navigation, another tab, etc.)
  React.useEffect(() => {
    const unsubscribe = subscribeToToggle(sectionId, toggleId, (v: unknown) => {
      if (v === valueRef.current) return; // no-op — avoids loop when WE wrote
      // If undefined was published (cleared), fall back to default
      setValue((v === undefined ? defaultValue : (v as T)));
    });
    return unsubscribe;
  }, [sectionId, toggleId, defaultValue]);

  const set = React.useCallback(
    (next: T | ((prev: T) => T)) => {
      setValue((prev) => {
        const computed = typeof next === "function" ? (next as (p: T) => T)(prev) : next;
        if (computed === prev) return prev;
        // Write through to cache — this will trigger our own subscriber
        // callback, but the equality guard above makes it a no-op.
        writeCachedToggle(sectionId, toggleId, computed);
        return computed;
      });
    },
    [sectionId, toggleId],
  );

  return [value, set];
}
