"use client";

/* t166 — CUSTOM AI NAME — per-account storage of a user-chosen name for
 * the AI copilot. Stored in localStorage (same pattern as the voice pick).
 * Default is "Fetch-X" (the platform brand).
 *
 * The name is:
 *   · shown in the AI panel's greeting bubble on open
 *   · sent with every /api/ai request so the AI's system prompt can use it
 *   · used in the live-talk persona ("Hey, this is [name] — ...")
 */

const NAME_KEY_PREFIX = "fx-ai-name";

export function aiNameStorageKey(account?: string | null): string {
  const who = (account ?? "").trim().toLowerCase();
  return `${NAME_KEY_PREFIX}:${who || "guest"}`;
}

export function readStoredAiName(account?: string | null): string | null {
  try {
    return localStorage.getItem(aiNameStorageKey(account));
  } catch {
    return null;
  }
}

export function writeStoredAiName(name: string, account?: string | null): void {
  try {
    localStorage.setItem(aiNameStorageKey(account), name.trim().slice(0, 40));
  } catch {
    /* private mode */
  }
}

/** Returns the custom name if set, otherwise "Fetch-X" (the platform default). */
export function getAiNameOrDefault(account?: string | null): string {
  const stored = readStoredAiName(account);
  if (stored && stored.trim().length > 0) return stored.trim();
  return "Fetch-X";
}
