// Indian-rupee + IST formatting helpers (business runs in IST).

export function inr(n: number, decimals = false): string {
  return (
    "₹" +
    n.toLocaleString("en-IN", {
      minimumFractionDigits: decimals ? 2 : 0,
      maximumFractionDigits: decimals ? 2 : 0,
    })
  );
}

export function inr2(n: number): string {
  return inr(n, true);
}

/** Plain Indian-locale grouping WITHOUT the ₹ sign (bills/items counts). */
export function num(n: number): string {
  return n.toLocaleString("en-IN");
}

export function istTime(iso: string | Date): string {
  return new Date(iso).toLocaleTimeString("en-IN", {
    timeZone: "Asia/Calcutta",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

export function istDateTime(iso: string | Date): string {
  // t197 — DD/MM/YYYY format everywhere
  return new Date(iso).toLocaleString("en-GB", {
    timeZone: "Asia/Calcutta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

export function istDateLong(d: Date = new Date()): string {
  // t197 — DD/MM/YYYY format
  return d.toLocaleDateString("en-GB", {
    timeZone: "Asia/Calcutta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

export function hourLabel(h: number): string {
  const suffix = h >= 12 ? "PM" : "AM";
  const base = h % 12 === 0 ? 12 : h % 12;
  return `${base} ${suffix}`;
}

export function deltaChip(pct: number | null, vs = "yesterday"): { text: string; up: boolean } | null {
  if (pct === null) return null;
  const rounded = Math.round(pct);
  return { text: `${rounded >= 0 ? "+" : ""}${rounded}% vs ${vs}`, up: rounded >= 0 };
}


// t197 — DD/MM/YYYY date format helper
export function istDay(iso: string | Date): string {
  return new Date(iso).toLocaleDateString("en-GB", {
    timeZone: "Asia/Calcutta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}
