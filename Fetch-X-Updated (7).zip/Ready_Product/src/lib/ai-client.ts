import ZAI from "z-ai-web-dev-sdk";

type ChatMsg = { role: "system" | "user" | "assistant"; content: string };

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
// Default engine: OpenAI gpt-oss-120b served by Groq — override with GROQ_MODEL in .env
const GROQ_MODEL = process.env.GROQ_MODEL?.trim() || "openai/gpt-oss-120b";
const IS_GPT_OSS = GROQ_MODEL.includes("gpt-oss");

// Fast model for intent detection — gpt-oss-20b is the smaller sibling, ideal
// for the JSON-mode single-shot classification the AI panel needs. Override
// with INTENT_MODEL in .env. Falls back to the main GROQ_MODEL if unset.
const INTENT_MODEL = process.env.INTENT_MODEL?.trim() || "llama-3.1-8b-instant";

// Shown as a normal assistant reply when no provider is reachable — the panel
// renders Markdown, so this walks the owner through the one-line fix.
const AI_SETUP_HINT = [
  "**The AI copilot is not configured on this device yet.**",
  "",
  "1. Open the **.env** file in the project folder",
  "2. Find the line `# GROQ_API_KEY=gsk_your_key_here`, remove the `#` and paste your own key:",
  "   `GROQ_API_KEY=gsk_...`  (free key: console.groq.com/keys)",
  "3. Save and restart the server (Ctrl+C, then `npm run dev:w`)",
  "",
  "Only the `GROQ_API_KEY` line needs uncommenting — the engine (gpt-oss-120b) is already the default.",
].join("\n");

/**
 * One AI chat completion for the copilot. Provider order:
 *   1. Groq (OpenAI-compatible endpoint) when GROQ_API_KEY is set in .env
 *   2. Z.ai SDK fallback (sandbox / .z-ai-config auth)
 */
export async function aiChat(
  messages: ChatMsg[],
  opts: { temperature?: number; maxTokens?: number } = {}
): Promise<string> {
  const key = process.env.GROQ_API_KEY?.trim();
  if (key) {
    const res = await fetch(GROQ_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages,
        temperature: opts.temperature ?? 0.3,
        max_tokens: opts.maxTokens ?? (IS_GPT_OSS ? 4096 : 2048),
        // gpt-oss reasons before answering — keep it brief; the reasoning
        // arrives out-of-band and never reaches the chat panel.
        ...(IS_GPT_OSS ? { reasoning_effort: "low" } : {}),
      }),
      // t188 — the omniscient payload (full business history in context)
      // needs a roomier ceiling than 50s: big prompts are still fast on
      // Groq, but deep-dive answers over a year of raw bills can take a bit.
      signal: AbortSignal.timeout(90_000),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Groq ${res.status}: ${text.slice(0, 300)}`);
    }
    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = data.choices?.[0]?.message?.content;
    if (!content) throw new Error("Groq returned an empty response");
    // Defensive: if a reasoning model ever inlines its thoughts, strip them
    return content
      .replace(/<think>[\s\S]*?<\/think>/g, "")
      .trim();
  }

  // Z.ai fallback (sandbox — needs .z-ai-config). On the owner's machine the
  // Groq key in .env is the intended path, so a missing config becomes the
  // friendly setup hint instead of a raw 500.
  try {
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });
    const reply = completion.choices[0]?.message?.content;
    if (!reply) throw new Error("AI returned an empty response");
    return reply.trim();
  } catch (err) {
    const msg = String((err as Error)?.message ?? err);
    if (msg.includes("Configuration file not found") || msg.includes(".z-ai-config")) {
      return AI_SETUP_HINT;
    }
    throw err;
  }
}

/* ───────────────────────────────────────────────────────────────────────────
 * t187 — AI-DRIVEN INTENT DETECTION
 *
 * The owner explicitly asked: "why cant you just set-up a intent detection
 * mechanism with an AI involved in figuring out what function execute, dont
 * make it guess using low right action probability". The regex approach was
 * brittle — "7 days" / "one month" needed custom patterns, "open tasks"
 * false-positived as a status filter, and conflicting toggles were tricky.
 *
 * This function asks a fast LLM (llama-3.1-8b-instant by default — sub-200ms
 * latency on Groq) to read the user's message + the current screen context
 * and return a structured JSON action. The AI panel then EXECUTES that action
 * deterministically — no guessing, no second-pass interpretation.
 *
 * Returns null when no Groq key is configured (the panel falls back to the
 * regex detector in that case so the app still works in dev without a key).
 * ─────────────────────────────────────────────────────────────────────────── */

export type AiIntent =
  | "navigate" // open a section, optionally with toggles
  | "toggle-only" // apply toggles to the current section, no navigation
  | "panel-size" // expand/contract the AI panel
  | "sidebar" // collapse/expand the sidebar
  | "close" // close panel / clear conversation
  | "question"; // not a command — let the regular /api/ai handle it

export interface IntentResult {
  intent: AiIntent;
  /** Required when intent="navigate". One of: dashboard, menu, lodge, tasks,
   *  expenses, management, attendance, settings. */
  view?: string;
  /** Required when intent="navigate" or "toggle-only". Map of toggleId →
   *  value, e.g. { "range": "1y", "scope": "all" }. */
  toggles?: Record<string, string>;
  /** Required when intent="panel-size". */
  panelAction?: "fullscreen" | "contract";
  /** Required when intent="sidebar". */
  sidebarAction?: "collapse" | "expand";
  /** Short one-sentence acknowledgment the panel displays + speaks (TTS). */
  reply: string;
}

const INTENT_SYSTEM_PROMPT = `You are the intent-detection layer for the Fetch-X business dashboard. Read the user's message and decide what action to take. Reply with a SINGLE JSON object — no markdown, no prose, just JSON.

Available sections (use the slug EXACTLY as written as the "view" value):
- dashboard (Live Dashboard — owner's command center)
- menu (Menu Manager — dish + category editor)
- lodge (Rooms Overview — 100-room wall)
- tasks (Tasks board — forwarded work + budgets)
- expenses (Expenses ledger — both books)
- management (Employee — roster + salaries)
- attendance (Attendance — daily staff marks)
- settings (Settings — themes, voice, AI name, limits)

Available toggles per section — use the EXACT toggleId and the EXACT value (case-sensitive slugs, NEVER the human label). For range keys, the slug is "1m" not "monthly", "1y" not "yearly", "7d" not "weekly":
- dashboard: range ("today" | "7d" | "1m" | "3m" | "1y"), scope ("all" | "rest" | "lodge")
- menu: query (any search text), cat (a category name — only if the user explicitly names one)
- lodge: filter ("all" | "avl" | "occ")
- tasks: fRange ("today" | "7d" | "1m" | "3m" | "1y" | "late"), fBook ("all" | "rest" | "lodge"), fStatus ("open" | "done" | "all")
- expenses: range ("today" | "7d" | "1m" | "3m" | "1y" | "all"), feedBook ("all" | "rest" | "lodge"), feedKind ("all" | "raw_material" | "upgrade" | "maintenance")
- management: empBook ("all" | "rest" | "lodge")
- attendance: date (YYYY-MM-DD format, e.g. "2026-10-05")
- settings: (no toggles)

CRITICAL — SLUG VALUES: when the user says "yearly" / "monthly" / "weekly" / "quarterly", you MUST convert to the slug: "1y" / "1m" / "7d" / "3m". When they say "today", use "today". When they say "all time" / "all history" / "everything" / "all expenses", use "all" (only valid for the expenses range). When they say "restaurant only", use "rest" for the scope/feedBook/fBook/empBook. When they say "lodge only", use "lodge". When they say "both books" or "all books", use "all". When they say "raw materials", use "raw_material". When they say "available rooms" or "vacant", use "avl" for the lodge filter. When they say "occupied rooms", use "occ". When they say "open tasks only", use "open" for fStatus. NEVER use the human label as the value — always the slug.

Intent types:
- "navigate" — the user wants to open a section (with optional toggles). Examples: "open dashboard in yearly view", "go to tasks", "show me expenses in monthly view, raw materials only", "switch to lodge, available rooms".
- "toggle-only" — the user wants to change a toggle on the CURRENT section WITHOUT navigating. Examples: "switch to monthly view", "show open only", "filter to lodge", "set yearly view". Use this when the user is clearly NOT asking to open a different section — check the screenContext.sectionId and use it as the target if the message refers to "the current page" / "this view" / no section name.
- "panel-size" — adjust the AI panel width. Examples: "full screen", "maximize", "expand the panel", "contract the panel", "wider", "narrower", "stretch", "make it big".
- "sidebar" — collapse/expand the left sidebar. Examples: "collapse sidebar", "hide side panel", "expand nav".
- "close" — close/clear the conversation. Examples: "close", "clear", "refresh", "stop".
- "question" — anything else (asking for info, analysis, advice, comparison, summary, etc.). Examples: "how's business today", "what's selling", "who hasn't shown up", "is the lodge full", "what was my revenue this year".

CONFLICT RULE: if the user mentions TWO values for the SAME toggle in one message (e.g. "yearly, monthly"), use the LAST one mentioned. If they mention values for DIFFERENT toggles (e.g. "monthly view, lodge only"), apply both.

Reply shape (STRICT — every field except "reply" is conditionally required based on intent):
{
  "intent": "navigate" | "toggle-only" | "panel-size" | "sidebar" | "close" | "question",
  "view": "<section-slug>",            // only when intent="navigate"
  "toggles": { "<toggleId>": "<slug-value>" }, // when intent="navigate" or "toggle-only"
  "panelAction": "fullscreen" | "contract", // only when intent="panel-size"
  "sidebarAction": "collapse" | "expand",   // only when intent="sidebar"
  "reply": "<one short sentence the user sees + hears via TTS>"
}

The reply must be ONE short sentence. For "navigate": "Opening dashboard in yearly view." For "toggle-only": "Switched to monthly view." For "panel-size": "Full screen." or "Contracted." For "sidebar": "Side panel collapsed." For "close": "Conversation cleared." For "question": "Let me check that for you." (the panel will follow up with the actual answer from the main AI).

CRITICAL: if the message is a question (asks for info, advice, comparison, summary, etc.), return intent="question" with reply="Let me check that for you." — do NOT try to answer the question yourself. The main AI (/api/ai) handles the actual answer.

Current screen context:
- sectionId: __SECTION_ID__
- viewState: __VIEW_STATE__
`;

/**
 * Detect the user's intent for a single message using a fast LLM. Returns a
 * structured IntentResult the panel can execute deterministically. Returns
 * null when no AI provider is configured (panel falls back to regex).
 */
export async function aiIntentDetect(
  message: string,
  screenContext: { sectionId: string | null; viewState: Record<string, unknown> | null },
  opts: { signal?: AbortSignal } = {},
): Promise<IntentResult | null> {
  const systemPrompt = INTENT_SYSTEM_PROMPT
    .replace("__SECTION_ID__", screenContext.sectionId ?? "(none)")
    .replace("__VIEW_STATE__", JSON.stringify(screenContext.viewState ?? {}));

  let content: string | null = null;

  // Path 1: Groq (fast + supports JSON mode). Used when GROQ_API_KEY is set.
  const key = process.env.GROQ_API_KEY?.trim();
  if (key) {
    try {
      const res = await fetch(GROQ_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: INTENT_MODEL,
          // Groq's JSON mode — guarantees valid JSON output
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: message },
          ],
          temperature: 0.0, // deterministic — same message → same intent
          max_tokens: 256, // the JSON is small
        }),
        signal: opts.signal ?? AbortSignal.timeout(8_000), // 8s hard cap
      });
      if (res.ok) {
        const data = (await res.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        content = data.choices?.[0]?.message?.content ?? null;
      }
      // non-2xx → fall through to Z.ai
    } catch {
      // network / abort → fall through to Z.ai
    }
  }

  // Path 2: Z.ai SDK fallback (sandbox / .z-ai-config). No JSON mode, but the
  // system prompt demands JSON-only output and we parse defensively.
  if (!content) {
    try {
      const zai = await ZAI.create();
      const completion = await zai.chat.completions.create({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message },
        ],
        thinking: { type: "disabled" },
      });
      content = completion.choices[0]?.message?.content ?? null;
    } catch (err) {
      const msg = String((err as Error)?.message ?? err);
      if (msg.includes("Configuration file not found") || msg.includes(".z-ai-config")) {
        // No provider configured at all — let the panel fall back to regex
        return null;
      }
      throw err;
    }
  }

  if (!content) return null;

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    // Sometimes the model wraps JSON in ```json fences or adds prose around
    // it — strip everything outside the first { ... } block and retry.
    const match = content.match(/\{[\s\S]*\}/);
    if (!match) {
      // Can't recover — treat as a question and let the main AI handle it
      return { intent: "question", reply: "Let me check that for you." };
    }
    try {
      parsed = JSON.parse(match[0]);
    } catch {
      return { intent: "question", reply: "Let me check that for you." };
    }
  }

  const r = parsed as Partial<IntentResult>;
  // Validate the shape — default to "question" if anything's off
  if (!r.intent || !["navigate", "toggle-only", "panel-size", "sidebar", "close", "question"].includes(r.intent)) {
    return {
      intent: "question",
      reply: "Let me check that for you.",
    };
  }
  return {
    intent: r.intent,
    view: r.view,
    toggles: r.toggles,
    panelAction: r.panelAction,
    sidebarAction: r.sidebarAction,
    reply: r.reply?.trim() || "Done.",
  };
}
