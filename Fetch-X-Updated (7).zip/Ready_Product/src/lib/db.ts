import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
  fxDbSelfTest: boolean | undefined;
};

/** Project-local spots the database is looked for when .env doesn't name a real file. */
const DB_FALLBACKS = ["db/custom.db", "prisma/dev.db", "custom.db", "dev.db"];

/**
 * Locate the SQLite database FILE on disk, whatever the machine looks like.
 *
 * 0. The project directory anchor. `process.cwd()` cannot be trusted — some
 *    launch chains (workspace-root inference, workers spawned elsewhere) run
 *    with a different cwd. The launcher (scripts/start.mjs) and the boot hook
 *    (instrumentation.ts) both pin FX_PROJECT_DIR to the real project folder;
 *    only when neither ran do we fall back to cwd.
 * 1. DATABASE_URL from .env — honoured ONLY if the file it names really exists.
 *    A stale value copied from another computer (or an old zip) must never win.
 * 2. Otherwise the well-known project-local spots are tried in order.
 *
 * The URL handed to Prisma uses the one format every SQLite build accepts on
 * every OS: `file:<absolute path, forward slashes>`. No percent-encoding and no
 * `file:///C:/` triple slash — both have broken the engine on Windows
 * ("Error code 14: Unable to open the database file"), spaces included.
 */
function resolveDbFile(): string {
  const base = process.env.FX_PROJECT_DIR?.trim() || process.cwd();

  const rawEnv = process.env.DATABASE_URL?.trim().replace(/^["']|["']$/g, "");
  if (rawEnv && !rawEnv.startsWith("file:")) return rawEnv; // non-sqlite URL — pass through untouched

  const candidates: string[] = [];

  if (rawEnv) {
    let p = rawEnv.slice("file:".length);
    const isAbs = p.startsWith("/") || /^[A-Za-z]:[\\/]/.test(p);
    if (!isAbs) {
      p = path.resolve(base, "prisma", p); // schema-relative (schema lives in <project>/prisma)
    } else {
      p = p.replace(/^\/+(?=[A-Za-z]:)/, ""); // file:/C:/x → C:/x
    }
    candidates.push(path.normalize(p));
  }
  for (const rel of DB_FALLBACKS) candidates.push(path.resolve(base, rel));
  const spots = [...new Set(candidates)];

  for (const c of spots) {
    if (fs.existsSync(c)) return c;
    if (c === spots[0]) {
      console.warn(`[fetchx] DATABASE_URL points at a missing file, ignoring: ${c}`);
    }
  }

  throw new Error(
    `[Fetch-X] Database file not found. Looked in:\n` +
      spots.map((c) => `  - ${c}`).join("\n") +
      `\nRe-extract the project zip (it ships db/custom.db), or create an empty one with: npx prisma db push`,
  );
}

const dbFile = resolveDbFile();
// Golden format: "file:" + absolute path with forward slashes. Survives naive
// path slicing AND spec-compliant URL parsing, spaces and drive letters alike.
const dbUrl = "file:" + dbFile.replace(/\\/g, "/");

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: dbUrl,
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db;

// One-shot boot check: proves the engine really opened the file, and leaves a
// copy-pasteable fix in the terminal when it did not. The OK line doubles as a
// marker that this version of db.ts is actually the code that is running.
if (!globalForPrisma.fxDbSelfTest) {
  globalForPrisma.fxDbSelfTest = true;
  db.$connect()
    .then(() => {
      console.log(`[fetchx] database OK → ${dbFile}`);
    })
    .catch((e: unknown) => {
      console.error(`[fetchx] DATABASE OPEN FAILED → ${dbFile}`);
      console.error(String((e as Error)?.message ?? e).split("\n").slice(0, 10).join("\n"));
      console.error(
        `[fetchx] FIX — put this single line in .env, save, restart the server:\nDATABASE_URL="${dbUrl}"`,
      );
    });
}
