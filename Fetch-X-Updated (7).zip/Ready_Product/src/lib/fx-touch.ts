/* t149 — JS touch-scroll driver (the guaranteed path inside the rotated stage).
   Native panning of these inner scrollers is dead on the user's phone for every
   touch-action we tried (pan-y t144, auto t148) — Chrome claims the gesture and
   dead-ends it — while the same phone scrolls the dashboard shell fine. So the
   boxes the user actually scrolls on mobile carry this driver:

   • touches are tracked on the element; the scroll follows the finger 1:1 after
     a ~5px engage (taps stay taps; a click that follows a real drag is
     suppressed once so a swipe never "taps" a dish or a button);
   • release starts a fling with native-grade physics: velocity = the average
     over the last ~120ms (a finger that slows before lifting still carries
     momentum — the t145 "stuck" feel came from sampling only the final two
     points), then decays ~0.998 per ms (iOS-like glide) and stops hard at the
     edges;
   • touch-action is synced from the element's real overflow (mount, resize and
     a 500ms poll): "none" while it can scroll so the browser never fights the
     driver, "" when it can't so touches fall through natively (short filtered
     menus, non-stage touch devices like iPads).

   The dashboard shell is NOT bound — its native scrolling demonstrably works.

   t155 — ROTATION + SCALE AWARENESS (required by the t154 landscape-only
   landing). clientX/clientY are always VIEWPORT coordinates — CSS transforms
   do not touch them — so inside the portrait stage (body rotated 90°, the
   page's "down" lying along the screen's horizontal axis) the old clientY-only
   math moved the content SIDEWAYS: a vertical swipe scrolled the wrong axis.
   The driver now picks the gesture axis from the stage state at touchstart:
     landscape stage (or no stage) → vertical swipes, scrollTop −= dy
     portrait stage  (data-fx-portrait="1") → horizontal swipes, scrollTop += dx
   (rotate(90deg) maps local down to screen left, so a swipe toward screen
   right pushes the content up the page — the natural reading flick). Screen
   pixels are also divided by --fx-fit: the stage canvas is scaled by fit
   (long/1280), so dividing keeps the page tracking the finger 1:1 in REAL
   screen pixels instead of the t149 fit-ratio drift. Wheel/keyboard/native
   scrolling are untouched — the driver only ever owns touch pans. */

export function bindFxTouchScroll(el: HTMLElement): () => void {
  let active = false;
  let portrait = false;
  let fit = 1;
  let startCoord = 0;
  let startTop = 0;
  let moved = 0;
  let samples: { t: number; c: number }[] = [];
  let fling = 0;
  let suppressClick = false;
  let poll = 0;

  const maxTop = () => el.scrollHeight - el.clientHeight;
  const clamp = (n: number) => Math.min(Math.max(n, 0), maxTop());

  /* the browser must never start a competing pan while the box can scroll —
     but a box that can't scroll must let touches fall through to the page */
  const syncTouchAction = () => {
    el.style.touchAction = maxTop() > 0 ? "none" : "";
  };
  syncTouchAction();
  poll = window.setInterval(syncTouchAction, 500);
  window.addEventListener("resize", syncTouchAction);

  const stopFling = () => {
    if (fling) {
      cancelAnimationFrame(fling);
      fling = 0;
    }
  };

  const onClick = (e: MouseEvent) => {
    if (suppressClick) {
      e.stopPropagation();
      e.preventDefault();
    }
  };

  const onStart = (e: TouchEvent) => {
    if (e.touches.length !== 1) return;
    stopFling();
    /* stage state at gesture start — rotation mid-drag is not a thing */
    const de = document.documentElement;
    portrait = de.dataset.fxPortrait === "1";
    fit = parseFloat(de.style.getPropertyValue("--fx-fit") || "") || 1;
    active = true;
    suppressClick = false;
    startCoord = portrait ? e.touches[0].clientX : e.touches[0].clientY;
    startTop = el.scrollTop;
    moved = 0;
    samples = [{ t: e.timeStamp, c: startCoord }];
  };

  const onMove = (e: TouchEvent) => {
    if (!active || e.touches.length !== 1) return;
    const c = portrait ? e.touches[0].clientX : e.touches[0].clientY;
    const d = c - startCoord; // screen px along the gesture axis
    if (!moved && Math.abs(d) < 5) return; // taps stay taps
    e.preventDefault(); // the pan belongs to us (touch-action none backs us)
    moved = Math.abs(d);
    if (moved >= 5) suppressClick = true;
    samples.push({ t: e.timeStamp, c });
    while (samples.length > 2 && e.timeStamp - samples[0].t > 120) samples.shift();
    /* portrait: swipe right (d>0) pushes content up the page → scrollTop up.
       landscape: swipe up (d<0) → scrollTop up. Divide by fit so the page
       moves with the finger in real screen pixels. */
    const delta = portrait ? d : -d;
    el.scrollTop = clamp(startTop + delta / fit);
  };

  const onEnd = (e: TouchEvent) => {
    if (!active) return;
    active = false;
    const now = e.timeStamp;
    while (samples.length > 2 && now - samples[0].t > 120) samples.shift();
    const a = samples[0];
    const b = samples[samples.length - 1];
    const dt = b.t - a.t;
    /* px/ms along the axis, + = scrollTop increasing (content travelling up
       the page). portrait: + = finger moving right; landscape: + = finger
       moving up. */
    let v = dt >= 16 ? (portrait ? b.c - a.c : a.c - b.c) / dt : 0; // screen px/ms
    v = Math.max(-3, Math.min(3, v)) / fit; // → local (page) px/ms
    if (Math.abs(v) < 0.1 || maxTop() <= 0) return;
    let last = now;
    const step = (ts: number) => {
      const d = Math.min(64, Math.max(1, ts - last));
      last = ts;
      v *= Math.pow(0.998, d); // iOS-grade deceleration
      if (Math.abs(v) < 0.02) {
        fling = 0;
        return;
      }
      const before = el.scrollTop;
      el.scrollTop = clamp(before + v * d);
      if (el.scrollTop === before) {
        fling = 0; // hit an edge — stop dead like native
        return;
      }
      fling = requestAnimationFrame(step);
    };
    fling = requestAnimationFrame(step);
  };

  el.addEventListener("touchstart", onStart, { passive: true });
  el.addEventListener("touchmove", onMove, { passive: false });
  el.addEventListener("touchend", onEnd, { passive: true });
  el.addEventListener("touchcancel", onEnd, { passive: true });
  el.addEventListener("click", onClick, { capture: true });

  return () => {
    stopFling();
    window.clearInterval(poll);
    window.removeEventListener("resize", syncTouchAction);
    el.removeEventListener("touchstart", onStart);
    el.removeEventListener("touchmove", onMove);
    el.removeEventListener("touchend", onEnd);
    el.removeEventListener("touchcancel", onEnd);
    el.removeEventListener("click", onClick, { capture: true });
    el.style.touchAction = "";
  };
}
