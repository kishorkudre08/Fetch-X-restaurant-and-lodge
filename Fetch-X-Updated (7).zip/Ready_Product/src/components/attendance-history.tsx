"use client";

import * as React from "react";
import { Check, Loader2, Minus, X } from "lucide-react";
import { useCachedToggle } from "@/lib/view-state-cache";

type EmpRow = {
  id: string; name: string; role: string;
  book: "rest" | "lodge";
  marks: Record<string, string>;
  present: number; absent: number; unmarked: number; rate: number;
};

type HistoryResp = { dates: string[]; employees: EmpRow[]; days: number; from: string; to: string };

const RANGES: Array<{ key: "7d" | "30d" | "90d"; label: string; days: number }> = [
  { key: "7d", label: "7 DAYS", days: 7 },
  { key: "30d", label: "30 DAYS", days: 30 },
  { key: "90d", label: "90 DAYS", days: 90 },
];

const fmtDay = (iso: string) => iso.slice(8, 10);
const fmtMonth = (iso: string) => {
  const m = Number(iso.slice(5, 7));
  return ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"][m-1] ?? "";
};
const fmtDow = (iso: string) => {
  const d = new Date(iso + "T00:00:00");
  return ["SUN","MON","TUE","WED","THU","FRI","SAT"][d.getDay()];
};

export function AttendanceHistory({ book }: { book: "rest" | "lodge" }) {
  const [rangeKey, setRangeKey] = useCachedToggle<"7d" | "30d" | "90d">("attendance", "historyRange", "30d");
  const range = RANGES.find((r) => r.key === rangeKey) ?? RANGES[1];
  const [data, setData] = React.useState<HistoryResp | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [failed, setFailed] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true); setFailed(false);
    try {
      const res = await fetch(`/api/attendance/history?days=${range.days}&book=${book}`, { cache: "no-store" });
      if (!res.ok) throw new Error("bad status");
      setData(await res.json());
    } catch { setFailed(true); }
    finally { setLoading(false); }
  }, [range.days, book]);

  React.useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 60_000);
    return () => clearInterval(t);
  }, [load]);

  if (loading && !data) {
    return (
      <div className="fx-card flex items-center justify-center gap-2 rounded-2xl py-10 text-[13px] font-bold text-[var(--fx-muted)]">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading attendance history…
      </div>
    );
  }
  if (failed || !data) {
    return (
      <div className="fx-card rounded-2xl p-6 text-center text-[13px] font-semibold text-[var(--fx-rose)]">
        Couldn't load attendance history. Try again in a moment.
      </div>
    );
  }
  const { dates, employees } = data;
  const monthStartIdx = new Set<number>();
  for (let i = 0; i < dates.length; i++) {
    if (i === 0 || dates[i].slice(0, 7) !== dates[i - 1].slice(0, 7)) monthStartIdx.add(i);
  }

  return (
    <div className="fx-card overflow-hidden rounded-2xl" data-testid="attendance-history">
      <div className="flex flex-wrap items-center gap-3 border-b border-[var(--fx-line)] bg-[var(--fx-lav)]/40 px-5 py-3">
        <div className="min-w-0 flex-1">
          <div className="text-[14px] font-extrabold tracking-tight text-[var(--fx-ink)]">ATTENDANCE HISTORY</div>
          <div className="fx-label">
            {employees.length} STAFF · LAST {range.days} DAYS · {book === "lodge" ? "LODGE BOOK" : "RESTAURANT BOOK"} · {data.from} → {data.to}
          </div>
        </div>
        <div className="inline-flex gap-1 rounded-xl bg-[var(--fx-page)] p-1 shadow-[inset_0_0_0_1px_var(--fx-line)]">
          {RANGES.map((r) => (
            <button
              key={r.key}
              onClick={() => setRangeKey(r.key)}
              data-testid={`attendance-history-range-${r.key}`}
              aria-pressed={range.key === r.key}
              className={`rounded-lg px-3 py-1.5 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
                range.key === r.key
                  ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]"
                  : "text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>
      {employees.length === 0 ? (
        <p className="py-10 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
          No staff in this book yet — the owner adds the team in the Employee section.
        </p>
      ) : (
        <div className="fx-scroll overflow-x-auto">
          <table className="w-full border-collapse text-[11.5px]">
            <thead>
              <tr className="border-b border-[var(--fx-line)] bg-[var(--fx-surf)]">
                <th className="sticky left-0 z-10 bg-[var(--fx-surf)] px-3 py-2.5 text-left align-middle font-extrabold tracking-[0.06em] text-[var(--fx-ink)]">STAFF</th>
                {dates.map((d, i) => (
                  <th key={d} data-tip-pos="bottom" data-tip={`${fmtDow(d)} · ${d}`}
                    className={`px-1 py-2 text-center align-middle font-bold ${
                      monthStartIdx.has(i) ? "border-l-2 border-l-[var(--fx-purple)]/40" : "border-l border-l-[var(--fx-line)]"
                    }`}>
                    <div className="text-[9.5px] font-extrabold tracking-wider text-[var(--fx-muted)]">
                      {monthStartIdx.has(i) ? fmtMonth(d) : ""}
                    </div>
                    <div className={`text-[11px] font-black ${fmtDow(d) === "SUN" ? "text-[var(--fx-rose)]" : "text-[var(--fx-ink)]"}`}>
                      {fmtDay(d)}
                    </div>
                  </th>
                ))}
                <th className="sticky right-0 z-10 border-l-2 border-l-[var(--fx-line)] bg-[var(--fx-surf)] px-3 py-2 text-center align-middle font-extrabold tracking-[0.06em] text-[var(--fx-ink)]">RATE</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((emp, rowIdx) => (
                <tr key={emp.id} className={rowIdx % 2 === 0 ? "" : "bg-[var(--fx-lav)]/30"}>
                  <td className="sticky left-0 z-10 bg-inherit px-3 py-2 align-middle">
                    <div className="flex items-center gap-2">
                      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-[var(--fx-purple)] text-[10px] font-black text-[var(--fx-on-accent)]">
                        {emp.name.slice(0, 1).toUpperCase()}
                      </span>
                      <span className="min-w-0">
                        <span className="block truncate text-[12px] font-bold text-[var(--fx-ink)]">{emp.name}</span>
                        <span className="block truncate text-[9.5px] font-semibold text-[var(--fx-muted)]">
                          {emp.role} · {emp.present}P / {emp.absent}A{emp.unmarked > 0 ? ` / ${emp.unmarked}—` : ""}
                        </span>
                      </span>
                    </div>
                  </td>
                  {dates.map((d, i) => {
                    const m = emp.marks[d];
                    const present = m === "present";
                    const absent = m === "absent";
                    return (
                      <td key={d} data-tip={`${emp.name} · ${d} · ${present ? "Present" : absent ? "Absent" : "Not marked"}`}
                        className={`px-0.5 py-1 text-center align-middle ${
                          monthStartIdx.has(i) ? "border-l-2 border-l-[var(--fx-purple)]/30" : "border-l border-l-[var(--fx-line)]"
                        }`}>
                        {present ? (
                          <span className="grid h-5 w-5 place-items-center rounded-md bg-[var(--fx-green)]/15 text-[var(--fx-green)] shadow-[inset_0_0_0_1px_var(--fx-green)]">
                            <Check className="h-3 w-3" strokeWidth={3} />
                          </span>
                        ) : absent ? (
                          <span className="grid h-5 w-5 place-items-center rounded-md bg-[var(--fx-rose)]/15 text-[var(--fx-rose)] shadow-[inset_0_0_0_1px_var(--fx-rose)]">
                            <X className="h-3 w-3" strokeWidth={3} />
                          </span>
                        ) : (
                          <span className="grid h-5 w-5 place-items-center rounded-md text-[var(--fx-muted)]/50">
                            <Minus className="h-2.5 w-2.5" />
                          </span>
                        )}
                      </td>
                    );
                  })}
                  <td className="sticky right-0 z-10 border-l-2 border-l-[var(--fx-line)] bg-inherit px-3 py-2 text-center align-middle">
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-black ${
                      emp.rate >= 90 ? "bg-[var(--fx-green)]/15 text-[var(--fx-green)]"
                      : emp.rate >= 70 ? "bg-[var(--fx-amber)]/15 text-[var(--fx-amber)]"
                      : "bg-[var(--fx-rose)]/15 text-[var(--fx-rose)]"
                    }`}>
                      {emp.rate}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="border-t border-[var(--fx-line)] px-5 py-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
        <span className="inline-flex items-center gap-1"><Check className="h-3 w-3 text-[var(--fx-green)]" strokeWidth={3} /> Present</span>
        <span className="mx-2">·</span>
        <span className="inline-flex items-center gap-1"><X className="h-3 w-3 text-[var(--fx-rose)]" strokeWidth={3} /> Absent</span>
        <span className="mx-2">·</span>
        <span className="inline-flex items-center gap-1"><Minus className="h-2.5 w-2.5 text-[var(--fx-muted)]" /> Not marked (no entry that day)</span>
        <span className="mx-2">·</span>
        <span>Rate = present ÷ (present + absent). Unmarked days don't dilute it.</span>
      </p>
    </div>
  );
}
