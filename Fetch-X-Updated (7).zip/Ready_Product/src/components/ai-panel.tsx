"use client";

import * as React from "react";
import {
  AudioLines,
  Bot,
  Maximize2,
  Minimize2,
  Mic,
  Send,
  Sparkles,
  Volume2,
  X,
  Loader2,
  RotateCcw,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Button } from "@/components/ui/button";
import { LiveOrb } from "@/components/live-orb";
import { VoicePickerModal } from "@/components/voice-picker-modal";
import {
  findVoice,
  isSttSupported,
  isTtsSupported,
  loadVoices,
  newRecognition,
  readStoredVoice,
  speak,
  type FxVoice,
} from "@/lib/voice";
import { currentAccount } from "@/lib/fx-themes";
import { screenContextToPromptString, useScreenContext } from "@/lib/screen-context";
import { getAiNameOrDefault } from "@/lib/ai-name";
import { readCachedToggle, writeCachedToggle } from "@/lib/view-state-cache";
import { num } from "@/lib/format";
import type { IntentResult } from "@/lib/ai-client";
import type { RangeKey } from "@/lib/types";

type Msg =
  | { role: "user" | "assistant"; content: string; live?: boolean; formatted?: string | null }
  | { role: "user"; content: string; live: true; interim: true };

/* The four display questions. Clicking one — or typing/saying it — simply
   asks the AI: every question takes the same path, live data context in,
   analyst answer out. */
type QuickId = "money" | "sales" | "lodge" | "restaurant";
const QUICK: QuickId[] = ["money", "sales", "lodge", "restaurant"];

/* Fallback window lengths for the sales chip's label while the dashboard
 * window fetch is in flight (mirrors the dashboard's RANGE_DAYS map). */
const SALES_DAYS_FALLBACK: Record<string, number> = {
  today: 1,
  "7d": 7,
  "1m": 30,
  "3m": 91,
  "1y": 365,
  "3y": 1095,
  lifetime: 36500,
  custom: 30,
};

/* Chip labels — same four questions as always. The sales one embeds the REAL
 * window length (hourly.days from the dashboard payload) so "past 30 days"
 * always matches the window on screen. */
const quickLabel = (id: QuickId, range: string, salesDays: number | null): string => {
  switch (id) {
    case "money":
      return "Where is most of the money going?";
    case "sales": {
      const d = salesDays ?? SALES_DAYS_FALLBACK[range] ?? 30;
      if (range === "lifetime" || d >= 36500) return "How have sales been over the business's lifetime?";
      return d === 1 ? "How have sales been in the past day?" : `How have sales been in the past ${num(d)} days?`;
    }
    case "lodge":
      return "Is there any pattern you observe in the lodge business?";
    case "restaurant":
      return "Do you observe any pattern in the restaurant?";
  }
};

const WIDTH_KEY = "fx-ai-width";

/* t177 — AGENTIC NAVIGATION. When the user says "open [section]", "go to
   [section]", "show [section]" etc., the AI panel navigates immediately
   (client-side, no API round-trip) AND sends the message to the AI for a
   contextual response about the new page. */
const NAV_ALIASES: Array<{ view: string; aliases: string[] }> = [
  // t180 — owner-only: no "attendance" (receptions only), no "pos" (receptions only)
  // unless the owner specifically asks for billing/counter
  { view: "dashboard", aliases: ["dashboard", "live dashboard", "home"] },
  { view: "menu", aliases: ["menu", "menu manager", "menu page", "dishes"] },
  { view: "lodge", aliases: ["rooms overview", "rooms", "lodge", "lodge front desk", "front desk", "rooms front desk"] },
  { view: "tasks", aliases: ["tasks", "task board", "task tracker", "task section"] },
  { view: "expenses", aliases: ["expenses", "expense", "costs", "ledger"] },
  { view: "management", aliases: ["employee", "employees", "staff", "management", "manage", "team"] },
  { view: "settings", aliases: ["settings", "setting"] },
];

/* t184 — TOGGLE HINTS. Each row maps natural-language phrases to a (toggleId,
   value) pair keyed by the target view. When the user says "open dashboard in
   yearly view" or "change expenses to monthly view", these patterns extract
   the target view + the toggle value, and we write it to the cache BEFORE
   navigating — so the destination view mounts/updates with the right state.

   Conflict rule (per the owner's brief): "when there is a double toggle, make
   it only do what user said". We scan the message left-to-right and pick the
   LAST mentioned value per kind. So "open dashboard in yearly view, monthly
   view" results in range=1m (monthly is the last one). */
type ToggleHintEntry = { toggleId: string; value: string; pattern: RegExp };

const RANGE_HINTS: Array<ToggleHintEntry> = [
  { toggleId: "range", value: "today", pattern: /\b(today|today'?s view|daily|day view|intraday|this day|1 day|one day|today view)\b/i },
  { toggleId: "range", value: "7d", pattern: /\b(weekly|week view|this week|7\s?days?|seven days?|one week|1 week|week'?s view|last week|past week|previous week)\b/i },
  { toggleId: "range", value: "1m", pattern: /\b(monthly|month view|this month|one month|1 month|30 days|thirty days|month'?s view|last month|past month|previous month)\b/i },
  { toggleId: "range", value: "3m", pattern: /\b(quarterly|quarter view|this quarter|3 months?|90 days|three months?|one quarter|1 quarter|last quarter|past quarter|previous quarter)\b/i },
  { toggleId: "range", value: "1y", pattern: /\b(yearly|year view|annual|annually|this year|one year|1 year|365 days|year'?s view|last year|past year|previous year)\b/i },
];

const SCOPE_HINTS: Array<ToggleHintEntry> = [
  // The same scope knob is called different things per view (dashboard="scope",
  // expenses="feedBook", tasks="fBook", management="empBook"). We mirror the
  // hint into all of them so the right view picks up the right value.
  // Accept many phrasings: "restaurant only" / "restaurant book only" /
  // "restaurant books only" / "just restaurant" / "restaurant view".
  { toggleId: "scope", value: "all", pattern: /\b(both books?|all books?|everything|all view|combined view|all business|all of them|all of it)\b/i },
  { toggleId: "scope", value: "rest", pattern: /\b(restaurant only|restaurant book only|restaurant books? only|just restaurant|restaurant view|rest view|restaurant book|rest only|only restaurant|restaurant alone)\b/i },
  { toggleId: "scope", value: "lodge", pattern: /\b(lodge only|lodge book only|lodge books? only|just lodge|lodge view|hotel view|rooms book|hotel only|only lodge|lodge alone)\b/i },
  { toggleId: "feedBook", value: "all", pattern: /\b(both books?|all books?|everything|all view|combined view|all business|all of them|all of it)\b/i },
  { toggleId: "feedBook", value: "rest", pattern: /\b(restaurant only|restaurant book only|restaurant books? only|just restaurant|restaurant view|rest view|restaurant book|rest only|only restaurant|restaurant alone)\b/i },
  { toggleId: "feedBook", value: "lodge", pattern: /\b(lodge only|lodge book only|lodge books? only|just lodge|lodge view|hotel view|rooms book|hotel only|only lodge|lodge alone)\b/i },
  { toggleId: "fBook", value: "all", pattern: /\b(both books?|all books?|everything|all view|combined view|all business|all of them|all of it)\b/i },
  { toggleId: "fBook", value: "rest", pattern: /\b(restaurant only|restaurant book only|restaurant books? only|just restaurant|restaurant view|rest view|restaurant book|rest only|only restaurant|restaurant alone)\b/i },
  { toggleId: "fBook", value: "lodge", pattern: /\b(lodge only|lodge book only|lodge books? only|just lodge|lodge view|hotel view|rooms book|hotel only|only lodge|lodge alone)\b/i },
  { toggleId: "empBook", value: "all", pattern: /\b(both books?|all books?|everything|all view|combined view|all business|all of them|all of it)\b/i },
  { toggleId: "empBook", value: "rest", pattern: /\b(restaurant only|restaurant book only|restaurant books? only|just restaurant|restaurant view|rest view|restaurant book|rest only|only restaurant|restaurant alone)\b/i },
  { toggleId: "empBook", value: "lodge", pattern: /\b(lodge only|lodge book only|lodge books? only|just lodge|lodge view|hotel view|rooms book|hotel only|only lodge|lodge alone)\b/i },
];

const STATUS_HINTS: Array<ToggleHintEntry> = [
  // IMPORTANT: bare "open tasks" / "done tasks" is NAVIGATION, not a filter.
  // We only treat it as a status filter when the user explicitly says
  // "only", "just", "show me X", "filter to X", or uses "unfinished"/"pending"
  // (which can't be confused with the navigation verb).
  { toggleId: "fStatus", value: "open", pattern: /\b(open only|open tasks? only|show (?:me )?open|show (?:me )?open tasks?|filter (?:to )?open|just open|unfinished(?: tasks?)?|pending tasks?|in[\s-]?progress tasks?)\b/i },
  { toggleId: "fStatus", value: "done", pattern: /\b(done only|done tasks? only|completed tasks?|finished tasks?|show (?:me )?done|show (?:me )?done tasks?|filter (?:to )?done|just done|closed tasks?)\b/i },
  { toggleId: "fStatus", value: "all", pattern: /\b(all tasks?|every task|all status)\b/i },
];

const KIND_HINTS: Array<ToggleHintEntry> = [
  { toggleId: "feedKind", value: "raw_material", pattern: /\b(raw materials?|raw material|raw|groceries|ingredients?)\b/i },
  { toggleId: "feedKind", value: "upgrade", pattern: /\b(upgrades?|capital|capex|improvements?|renovations?|furniture|fixtures?)\b/i },
  { toggleId: "feedKind", value: "maintenance", pattern: /\b(maintenance|repairs?|fixes?|services?|upkeep)\b/i },
  { toggleId: "feedKind", value: "all", pattern: /\b(all kinds?|every kind|all expenses?)\b/i },
];

const FILTER_HINTS: Array<ToggleHintEntry> = [
  // Lodge room status filter — "all" / "avl" (available) / "occ" (occupied)
  { toggleId: "filter", value: "all", pattern: /\b(all rooms?|every room|all status)\b/i },
  { toggleId: "filter", value: "avl", pattern: /\b(available|vacant|empty|free rooms?|open rooms?)\b/i },
  { toggleId: "filter", value: "occ", pattern: /\b(occupied|filled|checked[\s-]?in rooms?|booked rooms?)\b/i },
];

const ALL_HINT_TABLES: Array<{ forViews: string[]; hints: ToggleHintEntry[] }> = [
  { forViews: ["dashboard", "expenses", "tasks", "attendance"], hints: RANGE_HINTS }, // tasks uses "fRange" but RangeKey-compatible
  { forViews: ["dashboard", "expenses", "tasks", "management"], hints: SCOPE_HINTS },
  { forViews: ["tasks"], hints: STATUS_HINTS },
  { forViews: ["expenses"], hints: KIND_HINTS },
  { forViews: ["lodge"], hints: FILTER_HINTS },
];

/* Map the "range" toggle id to whatever the destination view calls it.
   Dashboard calls it `range`, expenses calls it `range`, tasks calls it
   `fRange`. We rewrite the toggleId per destination view at write-time. */
const RANGE_TOGGLE_ID_PER_VIEW: Record<string, string> = {
  dashboard: "range",
  expenses: "range",
  tasks: "fRange",
};

/* t184 — Does this message look like a toggle command, or is it a question
   that happens to mention a hint word? We want to apply hints for
   "switch to monthly view" but NOT for "what was my revenue this year".
   The rule:
     1. Message must NOT start with a question word.
     2. EITHER:
        a) Message contains a section name AND a hint word (e.g.
           "Employee in restaurant only", "Dashboard in yearly view"), OR
        b) Message contains a strong command verb (switch to / change to /
           set to / filter to / show me only / pull up / bring up /
           take me to / navigate to / go to / goto) AND a hint word.
   This lets bare noun phrases ("employee in restaurant only") act as commands
   while still excluding questions. */
const QUESTION_STARTS = /^(what|what's|whats|why|how|when|who|where|tell me about|tell me the|summarize|summarise|explain|calculate|compare|analyze|analyse|give me|list|which|is|are|do|does|did|can|could|would|will|should|show me the|show me a|show the)\b/i;

function isToggleCommandMessage(message: string): boolean {
  const lc = message.toLowerCase().trim();
  if (QUESTION_STARTS.test(lc)) return false;
  const hasHintWord = ALL_HINT_TABLES.some((t) =>
    t.hints.some((h) => new RegExp(h.pattern.source, "i").test(lc)),
  );
  if (!hasHintWord) return false;
  // (a) section name + hint word — noun-phrase commands like
  // "employee in restaurant only" / "dashboard in yearly view"
  const hasSection = NAV_ALIASES.some((e) =>
    e.aliases.some((a) => lc.includes(a)),
  );
  if (hasSection) return true;
  // (b) strong command verb + hint word — "switch to monthly view" with
  // no section named (applies to the currently-active section).
  const strongCommand = /\b(switch to|change to|change the|set to|set the|filter to|filter by|show only|show me only|show just|view as|pull up|bring up|take me to|navigate to|go to|goto)\b/;
  return strongCommand.test(lc);
}

/* Scan the message and produce a per-view, per-toggleId { toggleId: value }
   map. Last-mentioned-wins per (view, toggleId) — this is the user's
   "double toggle → only the last applies" rule. */
function detectToggleHints(message: string, view: string): Record<string, string> {
  const lc = " " + message.toLowerCase() + " ";
  const out: Record<string, string> = {};

  // Collect all (toggleId, value, lastMatchIndex) candidates across all hint
  // tables that apply to this view.
  const candidates: Array<{ toggleId: string; value: string; idx: number }> = [];
  for (const table of ALL_HINT_TABLES) {
    if (!table.forViews.includes(view)) continue;
    for (const hint of table.hints) {
      const matches = [...lc.matchAll(new RegExp(hint.pattern.source, "gi"))];
      if (matches.length === 0) continue;
      const last = matches[matches.length - 1];
      let toggleId = hint.toggleId;
      if (toggleId === "range") {
        toggleId = RANGE_TOGGLE_ID_PER_VIEW[view] ?? "range";
      }
      candidates.push({ toggleId, value: hint.value, idx: last.index ?? 0 });
    }
  }
  // For each toggleId, keep the candidate whose match position is furthest
  // right in the message. "yearly view, monthly view" → monthly wins. This
  // is the "only do what user said" rule from the owner's brief.
  const best: Record<string, { value: string; idx: number }> = {};
  for (const c of candidates) {
    if (!best[c.toggleId] || c.idx > best[c.toggleId].idx) {
      best[c.toggleId] = { value: c.value, idx: c.idx };
    }
  }
  for (const [tid, info] of Object.entries(best)) {
    out[tid] = info.value;
  }
  return out;
}

function detectNavigation(message: string): string | null {
  const lc = message.toLowerCase().trim();
  const match = lc.match(/(?:open|go to|goto|show|show me|navigate to|switch to|take me to|i want to see|bring up|pull up|change|set|view|see)\s+(?:the\s+|a\s+|my\s+)?(.+)/i);
  if (!match) {
    // Fallback: maybe the user just said the section name alone ("yearly view
    // on dashboard", "tasks open only"). Try to find a section alias anywhere
    // in the message — only if the user is currently on a relevant view.
    for (const e of NAV_ALIASES) {
      for (const a of e.aliases) {
        const idx = lc.indexOf(a);
        if (idx >= 0) {
          // Verify there's also a verb-ish or "view" keyword nearby
          if (/\b(open|go to|goto|show|navigate|switch|take|bring|pull|change|set|view|see)\b/.test(lc)) {
            return e.view;
          }
        }
      }
    }
    return null;
  }
  const target = match[1].trim().toLowerCase();
  // Pass 1: exact, Pass 2: startsWith, Pass 3: includes
  for (const e of NAV_ALIASES) for (const a of e.aliases) if (target === a) return e.view;
  for (const e of NAV_ALIASES) for (const a of e.aliases) if (target.startsWith(a + " ")) return e.view;
  for (const e of NAV_ALIASES) for (const a of e.aliases) if (target.includes(a)) return e.view;
  return null;
}

/* t180 — AGENTIC COMMANDS (beyond navigation): full screen, close,
   collapse/expand sidebar, expand/contract panel. These are detected
   client-side like navigation. */
function detectCommand(message: string): "close" | "collapse-sidebar" | "expand-sidebar" | "toggle-panel-size" | null {
  const lc = message.toLowerCase().trim();
  // Check sidebar commands FIRST (before fullscreen / panel commands, since
  // "expand sidebar" contains "expand" which also matches panel commands)
  // Collapse side panel / sidebar
  if (/\b(?:collapse|hide|close)\s+(?:side\s*(?:panel|bar)|sidebar|nav|navigation)\b/.test(lc)) return "collapse-sidebar";
  // Open/expand side panel / sidebar
  if (/\b(?:open|expand|show|bring\s+up)\s+(?:side\s*(?:panel|bar)|sidebar|nav|navigation)\b/.test(lc)) return "expand-sidebar";
  // t185 — SINGLE fullscreen/contract toggle. The owner wanted ONE button.
  // The handler decides whether to jump to fullscreen or contract based on
  // the current panel width — same logic as the visible toggle button.
  // Match (a) explicit fullscreen phrases, (b) panel/ai/copilot/assistant/
  // chat targets, (c) bare whole-message commands like "expand" or "wider".
  // We DO NOT match "expand" alone in a longer message — that would false-
  // positive on "expand my menu" / "expand the dashboard's weekly view".
  if (/\b(?:full\s*screen|fullscreen|stretch|maximize|make it (?:full|big|wide)|go wide)\b/.test(lc)) return "toggle-panel-size";
  if (/\b(?:expand|widen|grow|narrow|shrink|contract)\s+(?:the\s+)?(?:panel|ai|copilot|assistant|chat)\b/.test(lc)) return "toggle-panel-size";
  if (/\bmake\s+(?:the\s+|it\s+)?(?:panel|ai|copilot|assistant|chat)\s+(?:wider|narrower|smaller|bigger)\b/.test(lc)) return "toggle-panel-size";
  if (/^(?:expand|contract|widen|narrow|wider|narrower|expand it|contract it|narrow it|shrink it|expand more|stretch|maximize)$/.test(lc)) return "toggle-panel-size";
  // Close / stop / refresh — kills live talk + clears conversation
  if (/^(?:close|stop|shut down|clear|reset|refresh)$/.test(lc) || /\b(?:close(?:\s+(?:it|this|the panel|the ai))?|stop(?:\s+(?:it|this|talking|speaking))?|clear(?:\s+(?:it|this|the conversation|chat))?|refresh(?:\s+(?:it|this|the conversation|chat))?)\b/.test(lc)) return "close";
  return null;
}

// Rich answer rendering — the copilot answers in Markdown (bold figures,
// bullet lists, GFM tables) and the panel draws them with Fetch-X styling.
const MD_COMPONENTS = {
  table: (p: React.ComponentPropsWithoutRef<"table">) => (
    <div className="ai-md-tblw">
      <table {...p} />
    </div>
  ),
  a: (p: React.ComponentPropsWithoutRef<"a">) => <a {...p} target="_blank" rel="noreferrer" />,
};

function AiMarkdown({ text }: { text: string }) {
  return (
    <div className="ai-md">
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={MD_COMPONENTS}>
        {text}
      </ReactMarkdown>
    </div>
  );
}

export function AiPanel({ range, hideFab = false, onWidthChange, onNavigate, onToggleSidebar }: { range: RangeKey; hideFab?: boolean; onWidthChange?: (w: number) => void; onNavigate?: (view: string) => void; onToggleSidebar?: (open: boolean) => void }) {
  const [open, setOpen] = React.useState(false);
  // t174 — default width is wide (70% of the CSS viewport), not the old 340px.
  // The user can drag the left edge to make it narrower. No more fullscreen snap.
  const [width, setWidth] = React.useState(900);
  const [msgs, setMsgs] = React.useState<Msg[]>([]);
  const [input, setInput] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);

  // ── LIVE TALK state (t147) ───────────────────────────────────────────────
  const [liveMode, setLiveMode] = React.useState(false);
  const [interim, setInterim] = React.useState("");
  const [speaking, setSpeaking] = React.useState(false);
  const [voicePickerOpen, setVoicePickerOpen] = React.useState(false);
  const [currentVoice, setCurrentVoice] = React.useState<FxVoice | null>(null);
  const [sttSupported, setSttSupported] = React.useState(false);
  const [ttsSupported, setTtsSupported] = React.useState(false);
  const [ttsVoices, setTtsVoices] = React.useState<SpeechSynthesisVoice[]>([]);

  const scrollRef = React.useRef<HTMLDivElement>(null);
  const dragging = React.useRef(false);
  const recRef = React.useRef<ReturnType<typeof newRecognition> | null>(null);
  // Live-mode refs (so callbacks inside the recognition handlers see the
  // latest values without re-creating the recognition instance):
  const liveRef = React.useRef(false);
  const busyRef = React.useRef(false);
  const speakingRef = React.useRef(false); // t149 — true while TTS is playing
  const lastFinalRef = React.useRef<string>("");
  // t178 — AbortController for the current fetch. When a new message arrives,
  // we abort the previous fetch + cancel TTS so the new message takes over
  // immediately — no waiting for the old reply to finish.
  const abortRef = React.useRef<AbortController | null>(null);
  // t151 — current screen context (route + section + viewState + viewport)
  const screen = useScreenContext();
  // t154 — keep a ref of the LATEST screen context so the SpeechRecognition
  // callbacks (set up once in startLive) always read the current page, not
  // the page the user was on when live talk started. Without this, navigating
  // to a different section mid-live-talk would send the stale screen context
  // with every spoken message.
  const screenRef = React.useRef(screen);
  React.useEffect(() => { screenRef.current = screen; }, [screen]);

  // t176 — notify the parent whenever the panel's width or open state changes
  // so the parent can set padding-right on <main> (squeeze the dashboard up to
  // a threshold, then let the panel overlay beyond it).
  React.useEffect(() => {
    onWidthChange?.(open ? width : 0);
  }, [open, width, onWidthChange]);

  // t175 — track desktop viewport for inline position:absolute (overlay)
  const [isDesktop, setIsDesktop] = React.useState(false);
  React.useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  // t166 — the AI's custom name (per-account, from Settings). Read fresh
  // whenever the panel opens so a name change in Settings takes effect.
  const [aiName, setAiName] = React.useState("Fetch-X");
  React.useEffect(() => {
    if (open) setAiName(getAiNameOrDefault(currentAccount()));
  }, [open]);

  // The sales chip's label follows the REAL dashboard window (hourly.days).
  // One light GET when the panel opens / the range changes — the dashboard
  // itself polls the same endpoint every 15s, so this is usually cache-hot.
  const [salesDays, setSalesDays] = React.useState<number | null>(null);
  React.useEffect(() => {
    if (!open) return;
    let dead = false;
    void (async () => {
      try {
        let url = `/api/dashboard?range=${encodeURIComponent(range)}`;
        if (range === "custom") {
          const cs = readCachedToggle<string>("global", "customStart", "");
          const ce = readCachedToggle<string>("global", "customEnd", "");
          if (cs && ce) url += `&start=${encodeURIComponent(cs)}&end=${encodeURIComponent(ce)}`;
        }
        const res = await fetch(url, { cache: "no-store" });
        if (!res.ok) return;
        const j = (await res.json()) as { hourly?: { days?: number } };
        const d = Math.max(1, Math.round(j?.hourly?.days ?? 0));
        if (!dead && d > 0) setSalesDays(d);
      } catch {
        /* label rides the fallback map until a fetch succeeds */
      }
    })();
    return () => { dead = true; };
  }, [open, range]);

  // t166 — dispatch a window event when the panel opens/closes so the task
  // tracker can hide itself while the AI panel is open (avoids overlap).
  React.useEffect(() => {
    window.dispatchEvent(new CustomEvent("fx-ai-panel-toggle", { detail: open }));
  }, [open]);

  // t174/t175 — restore saved width, or default to FULL width (fills the
  // parent container — from the sidebar's right edge to the viewport's right
  // edge). The panel overlays the dashboard (position: absolute on desktop).
  React.useEffect(() => {
    const zoomFactor = parseFloat(getComputedStyle(document.documentElement).zoom || "1") || 1;
    const cssViewport = window.innerWidth / zoomFactor;
    const saved = Number(localStorage.getItem(WIDTH_KEY));
    if (Number.isFinite(saved) && saved >= 280) {
      setWidth(Math.min(saved, cssViewport));
    } else {
      // t176 — default to the SQUEEZE THRESHOLD (55% of CSS viewport).
      // At this width: the dashboard is squeezed to ~45%, the panel is at ~55%,
      // they meet exactly with no overlay. Dragging wider overlays the dashboard;
      // dragging narrower un-squeezes the dashboard.
      setWidth(Math.floor(cssViewport * 0.55));
    }
  }, []);

  // t185 — FULLSCREEN / CONTRACT toggle (the owner asked for ONE button that
  // does both). When the panel is at its normal width, the button jumps it
  // to ~95% of the CSS viewport (fullscreen). When it's already fullscreen,
  // the same button contracts it back to the default squeeze threshold
  // (55% of viewport — the dashboard meets the panel edge-to-edge with no
  // overlay). The state is tracked by comparing the current width to the
  // fullscreen threshold; both endpoints are persisted to fx-ai-width.
  const cssViewportWidth = React.useMemo(() => {
    if (typeof window === "undefined") return 1408;
    const zoomFactor = parseFloat(getComputedStyle(document.documentElement).zoom || "1") || 1;
    return window.innerWidth / zoomFactor;
  }, []);
  const fullscreenW = Math.floor(cssViewportWidth * 0.95);
  const defaultW = Math.floor(cssViewportWidth * 0.55);
  const isFullscreen = width >= fullscreenW - 4; // 4px tolerance for float rounding
  const toggleFullscreen = React.useCallback(() => {
    setWidth((w) => {
      const next = w >= fullscreenW - 4 ? defaultW : fullscreenW;
      try { localStorage.setItem(WIDTH_KEY, String(next)); } catch { /* private mode */ }
      return next;
    });
  }, [defaultW, fullscreenW]);

  // Feature-detect STT + TTS, load TTS voices + current voice on mount
  React.useEffect(() => {
    setSttSupported(isSttSupported());
    setTtsSupported(isTtsSupported());
    if (isTtsSupported()) {
      loadVoices().then((vs) => {
        setTtsVoices(vs);
        const stored = readStoredVoice(currentAccount());
        if (stored) {
          const real = findVoice(vs, stored);
          if (real) {
            setCurrentVoice({
              voiceURI: real.voiceURI,
              name: real.name,
              lang: real.lang,
              gender: "neutral",
              vendor: "System",
            });
          }
        }
      });
      const handler = () => loadVoices().then(setTtsVoices);
      window.speechSynthesis.addEventListener?.("voiceschanged", handler);
      return () => window.speechSynthesis.removeEventListener?.("voiceschanged", handler);
    }
  }, []);

  // t174 — no more Escape/fullscreen handler (fullscreen removed).

  React.useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, busy, interim, speaking]);

  // t174 — drag-to-resize (left edge handle). Fixed zoom:0.75 bug:
  // window.innerWidth is in DEVICE px; the panel's width is in CSS px.
  // The drag X is in device px too. So: css_width = device_width / zoomFactor.
  // Without this fix, the panel would "shrink" when dragged because the
  // CSS width was being set to device-px values (too small by 1/zoomFactor).
  React.useEffect(() => {
    const zoomFactor = parseFloat(getComputedStyle(document.documentElement).zoom || "1") || 1;
    const move = (e: MouseEvent | TouchEvent) => {
      if (!dragging.current) return;
      const x = "touches" in e ? e.touches[0].clientX : e.clientX;
      // device px from the right edge to the cursor = how wide the panel should be in device px
      const deviceWidth = window.innerWidth - x;
      // convert to CSS px (the panel's width is in CSS px, rendered at zoomFactor)
      const cssWidth = deviceWidth / zoomFactor;
      // clamp: minimum 280 CSS px, maximum the CSS viewport
      const cssViewport = window.innerWidth / zoomFactor;
      setWidth(Math.max(280, Math.min(cssViewport, cssWidth)));
    };
    const up = () => {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.userSelect = "";
      localStorage.setItem(WIDTH_KEY, String(width));
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("touchmove", move, { passive: true });
    window.addEventListener("mouseup", up);
    window.addEventListener("touchend", up);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("touchend", up);
    };
  }, [width]);

  // Stop everything — only called from the mic button or unmount.
  // t150 — closing the panel NO LONGER kills live talk: the orb takes
  // over the FAB slot and keeps listening. Only the mic button (or
  // closing the panel via the X) ends the live-talk session.
  const stopLive = React.useCallback(() => {
    liveRef.current = false;
    speakingRef.current = false;
    setLiveMode(false);
    setInterim("");
    setSpeaking(false);
    try { recRef.current?.stop(); } catch { /* ignore */ }
    recRef.current = null;
    if (isTtsSupported()) window.speechSynthesis.cancel();
    // t178 — also abort any in-flight AI fetch
    abortRef.current?.abort();
    abortRef.current = null;
    busyRef.current = false;
    setBusy(false);
  }, []);

  // Unmount cleanup — stop live talk when the whole panel unmounts
  React.useEffect(() => {
    return () => stopLive();
  }, [stopLive]);

  const send = async (text: string, opts: { live?: boolean } = {}) => {
    const message = text.trim();
    if (!message) return;

    // t178 — ABORT the previous AI reply (fetch + TTS) so the new message
    // takes over immediately. No waiting for the old reply to finish.
    abortRef.current?.abort();
    if (isTtsSupported()) window.speechSynthesis.cancel();
    speakingRef.current = false;
    setSpeaking(false);

    setInput("");
    setErr(null);
    setMsgs((m) => [...m, { role: "user", content: message, ...(opts.live ? { live: true } : {}) }]);

    // t187 — AI-DRIVEN INTENT DETECTION (the owner's explicit ask: "set up an
    // intent detection mechanism with an AI involved in figuring out what
    // function execute, dont make it guess using low right action probability").
    // Before any regex guessing, ask the fast LLM (llama-3.1-8b-instant on
    // Groq, ~200ms latency) what the user wants. The LLM returns a structured
    // JSON action; we EXECUTE it deterministically. If the intent API is
    // unavailable (no GROQ_API_KEY) or errors, we fall through to the regex
    // detector below — the app keeps working in dev without a key.
    const controller = new AbortController();
    abortRef.current = controller;
    let intentResult: IntentResult | null = null;
    try {
      const intentRes = await fetch("/api/ai/intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          screenContext: {
            sectionId: screenRef.current?.sectionId ?? null,
            viewState: screenRef.current?.viewState ?? null,
          },
        }),
        signal: controller.signal,
      });
      if (intentRes.ok) {
        intentResult = (await intentRes.json()) as IntentResult;
      }
      // 503 = no GROQ_API_KEY — fall through to regex silently
      // 500 = provider error — also fall through; the regex is good enough
    } catch {
      // network error / abort — fall through to regex
    } finally {
      // If we proceeded past intent detection, clear the abort ref so the
      // follow-up /api/ai call (for "question" intent) can use a fresh one.
      // We'll re-assign below for the question path.
    }

    if (intentResult) {
      // ── EXECUTE THE LLM'S DECISION DETERMINISTICALLY ──
      if (intentResult.intent === "navigate" && intentResult.view) {
        // Write each toggle to the cache BEFORE navigating so the destination
        // view reads the new value on mount (or live-updates via pub/sub if
        // already mounted).
        const target = intentResult.view;
        if (intentResult.toggles) {
          for (const [tid, val] of Object.entries(intentResult.toggles)) {
            writeCachedToggle(target, tid, val);
          }
        }
        onNavigate?.(target);
        const reply = intentResult.reply || `Opened ${target}.`;
        setMsgs((m) => [...m, { role: "assistant", content: reply, ...(opts.live ? { live: true } : {}) }]);
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }
      if (intentResult.intent === "toggle-only") {
        // Apply toggles to the CURRENT section (no navigation)
        const section = screenRef.current?.sectionId;
        if (section && intentResult.toggles) {
          for (const [tid, val] of Object.entries(intentResult.toggles)) {
            writeCachedToggle(section, tid, val);
          }
        }
        const reply = intentResult.reply || "Updated.";
        setMsgs((m) => [...m, { role: "assistant", content: reply, ...(opts.live ? { live: true } : {}) }]);
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }
      if (intentResult.intent === "panel-size") {
        // The toggleFullscreen handler picks fullscreen vs contract based on
        // current width. For an explicit "contract" from the LLM, force the
        // default width; for "fullscreen", force the max.
        if (intentResult.panelAction === "contract") {
          const next = Math.floor(cssViewportWidth * 0.55);
          setWidth(next);
          try { localStorage.setItem(WIDTH_KEY, String(next)); } catch { /* private mode */ }
        } else if (intentResult.panelAction === "fullscreen") {
          const next = Math.floor(cssViewportWidth * 0.95);
          setWidth(next);
          try { localStorage.setItem(WIDTH_KEY, String(next)); } catch { /* private mode */ }
        } else {
          // No explicit action — use the smart toggle
          toggleFullscreen();
        }
        const reply = intentResult.reply || (intentResult.panelAction === "contract" ? "Contracted." : "Full screen.");
        setMsgs((m) => [...m, { role: "assistant", content: reply, ...(opts.live ? { live: true } : {}) }]);
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }
      if (intentResult.intent === "sidebar") {
        onToggleSidebar?.(intentResult.sidebarAction === "collapse" ? false : true);
        const reply = intentResult.reply || `Side panel ${intentResult.sidebarAction === "collapse" ? "collapsed" : "expanded"}.`;
        setMsgs((m) => [...m, { role: "assistant", content: reply, ...(opts.live ? { live: true } : {}) }]);
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }
      if (intentResult.intent === "close") {
        stopLive();
        abortRef.current?.abort();
        abortRef.current = null;
        setMsgs([]);
        setErr(null);
        lastFinalRef.current = "";
        busyRef.current = false;
        setBusy(false);
        const reply = intentResult.reply || "Conversation cleared.";
        setMsgs([{ role: "assistant", content: reply, ...(opts.live ? { live: true } : {}) }]);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }
      // intent === "question" — fall through to /api/ai for the actual answer.
      // Display the LLM's "Let me check that for you." as a transient hint
      // bubble ONLY if it's something other than the default placeholder.
      if (intentResult.intent === "question" && intentResult.reply && intentResult.reply !== "Let me check that for you." && intentResult.reply !== "Done.") {
        // Skip — keep the UX clean; just go straight to the real answer.
      }
    }

    // ── REGEX FALLBACK (only fires when intentResult is null — i.e. no GROQ key) ──
    // When the intent API returned "question", we SKIP regex entirely and go
    // straight to /api/ai (the LLM already decided this is a question, not a
    // command). When the intent API was unavailable (null), we try the old
    // regex path so the app still works in dev without a key.
    if (!intentResult) {
      const command = detectCommand(message);
      if (command) {
        let reply = "";
        if (command === "close") {
          stopLive();
          abortRef.current?.abort();
          abortRef.current = null;
          setMsgs([]);
          setErr(null);
          lastFinalRef.current = "";
          busyRef.current = false;
          setBusy(false);
          reply = "Closed. Conversation cleared.";
        } else if (command === "collapse-sidebar") {
          onToggleSidebar?.(false);
          reply = "Side panel collapsed.";
        } else if (command === "expand-sidebar") {
          onToggleSidebar?.(true);
          reply = "Side panel expanded.";
        } else if (command === "toggle-panel-size") {
          const wasFullscreen = width >= Math.floor(cssViewportWidth * 0.95) - 4;
          toggleFullscreen();
          reply = wasFullscreen ? "Contracted." : "Full screen.";
        }
        setMsgs((m) => [...m, { role: "assistant", content: reply, ...(opts.live ? { live: true } : {}) }]);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        return;
      }

      // t177/t179 — AGENTIC NAVIGATION (regex fallback). When no Groq key is
      // configured, the regex detector figures out which section to open.
      const navTarget = detectNavigation(message);
      // If no section was mentioned but there ARE toggle hints, apply them to
      // the CURRENT section the user is on. e.g. "switch to monthly view"
      // while on the dashboard → range=1m on the dashboard.
      const currentSectionId = screenRef.current?.sectionId;
      const fallbackSection = !navTarget && currentSectionId ? currentSectionId : null;
      const toggleHintsView = navTarget ?? fallbackSection;
      const isCommand = isToggleCommandMessage(message);
      const toggleHints = isCommand && toggleHintsView ? detectToggleHints(message, toggleHintsView) : {};

      if (navTarget && onNavigate) {
        // Extract any toggle hints from the message and write them to the
        // view-state cache BEFORE the navigation happens. This way the
        // destination view reads the new toggle value from cache on mount
        // (or via the in-memory pub/sub if it's already mounted).
        const hintLabels: string[] = [];
        for (const [tid, val] of Object.entries(toggleHints)) {
          writeCachedToggle(navTarget, tid, val);
          hintLabels.push(`${tid}=${val}`);
        }

        onNavigate(navTarget);
        const navEntry = NAV_ALIASES.find((e) => e.view === navTarget);
        const displayName = navEntry?.aliases[0] ?? navTarget;
        const reply = hintLabels.length > 0
          ? `Opened ${displayName} with ${hintLabels.join(", ")}.`
          : `Opened ${displayName}.`;
        setMsgs((m) => [...m, {
          role: "assistant",
          content: reply,
          ...(opts.live ? { live: true } : {}),
        }]);
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }

      // t184 — TOGGLE-ONLY COMMAND (regex fallback). No navigation verb, but
      // the message carries toggle hints for the CURRENT section.
      if (fallbackSection && Object.keys(toggleHints).length > 0) {
        const hintLabels: string[] = [];
        for (const [tid, val] of Object.entries(toggleHints)) {
          writeCachedToggle(fallbackSection, tid, val);
          hintLabels.push(`${tid}=${val}`);
        }
        const reply = `Updated ${fallbackSection}: ${hintLabels.join(", ")}.`;
        setMsgs((m) => [...m, {
          role: "assistant",
          content: reply,
          ...(opts.live ? { live: true } : {}),
        }]);
        abortRef.current = null;
        busyRef.current = false;
        setBusy(false);
        if (opts.live && isTtsSupported()) {
          const stored = readStoredVoice(currentAccount());
          const real = findVoice(ttsVoices, stored);
          try { recRef.current?.stop(); } catch { /* not running */ }
          speakingRef.current = true;
          setSpeaking(true);
          await speak(reply, real, {
            onEnd: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
            onError: () => { speakingRef.current = false; setSpeaking(false); if (liveRef.current) { try { recRef.current?.start(); } catch {} } },
          });
        }
        return;
      }
    } // end of `if (!intentResult)` regex fallback block

    busyRef.current = true;
    setBusy(true);

    // t178 — reuse the AbortController from the intent detection block. If
    // intent detection already consumed it (for a command/navigate/etc.), we
    // returned early above — so reaching here means we're going to /api/ai
    // for a real chat reply. Recreate a fresh controller in case the intent
    // detection fetch already used + aborted the old one.
    abortRef.current?.abort();
    const chatController = new AbortController();
    abortRef.current = chatController;

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          history: msgs.slice(-8).map((m) => ({ role: m.role, content: m.content })),
          range,
          liveMode: opts.live === true,
          screenContext: screenContextToPromptString(screenRef.current),
          aiName,
        }),
        signal: chatController.signal,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "AI failed");
      const spoken = (data.spoken as string | undefined) ?? (data.reply as string);
      const formatted = (data.formatted as string | null | undefined) ?? null;
      setMsgs((m) => [...m, {
        role: "assistant",
        content: spoken,
        ...(opts.live ? { live: true, formatted } : {}),
      }]);
      if (opts.live && isTtsSupported()) {
        const stored = readStoredVoice(currentAccount());
        const real = findVoice(ttsVoices, stored);
        setInterim("");
        try { recRef.current?.stop(); } catch { /* not running */ }
        speakingRef.current = true;
        setSpeaking(true);
        await speak(data.reply, real, {
          onEnd: () => {
            speakingRef.current = false;
            setSpeaking(false);
            if (liveRef.current) {
              try { recRef.current?.start(); } catch { /* already started */ }
            }
          },
          onError: () => {
            speakingRef.current = false;
            setSpeaking(false);
            if (liveRef.current) {
              try { recRef.current?.start(); } catch { /* already started */ }
            }
          },
        });
      }
    } catch (e) {
      // t178 — silently ignore AbortError (the previous request was cancelled)
      if (e instanceof DOMException && e.name === "AbortError") return;
      if (e instanceof Error && e.name === "AbortError") return;
      setErr(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  };

  /* ── LIVE TALK control ────────────────────────────────────────────────── */
  const startLive = () => {
    if (!isSttSupported()) {
      setErr("Live talk needs the Web Speech API — try Chrome desktop or Android Chrome.");
      return;
    }
    setErr(null);
    liveRef.current = true;
    setLiveMode(true);
    setInterim("");
    if (isTtsSupported()) window.speechSynthesis.cancel();

    const rec = newRecognition();
    if (!rec) {
      setErr("Speech recognition unavailable on this browser.");
      setLiveMode(false);
      liveRef.current = false;
      return;
    }
    recRef.current = rec;

    rec.onresult = (ev: SpeechRecognitionEvent) => {
      if (!liveRef.current) return;
      // t149 — if the AI is speaking (TTS playing), IGNORE every recognition
      // event. The mic gets paused via rec.stop() before TTS starts, but
      // some browsers queue a final "no-speech" or echo result that arrives
      // after stop() — discard it so no phantom live-text bubble appears.
      if (speakingRef.current) return;
      let interimText = "";
      let finalText = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const r = ev.results[i];
        const t = r[0]?.transcript ?? "";
        if (r.isFinal) finalText += t;
        else interimText += t;
      }
      setInterim(interimText);
      if (finalText.trim() && finalText.trim() !== lastFinalRef.current) {
        lastFinalRef.current = finalText.trim();
        setInterim("");
        void send(finalText.trim(), { live: true });
      }
    };
    rec.onerror = (e: SpeechRecognitionErrorEvent) => {
      // t152 — during TTS, the mic was deliberately stopped; browsers
      // sometimes fire "no-speech" / "aborted" / "network" errors as a
      // side-effect. Suppress them — the TTS completion handler will
      // resume recognition cleanly.
      if (speakingRef.current) return;
      if (e.error === "no-speech" || e.error === "aborted") return;
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        // t185 — this is the #1 cause when the preview runs in an iframe:
        // the parent page doesn't pass allow="microphone" down, so even
        // Chrome can't access the mic. The fix is to open the preview in
        // a new top-level tab where the browser can prompt properly.
        setErr("Microphone blocked — open this preview in a new tab to allow mic access. The chat-side iframe blocks it by default.");
        stopLive();
        return;
      }
      setErr(`Speech recognition error: ${e.error}. Open in a new tab if this keeps happening — the iframe may be blocking the mic.`);
    };
    rec.onend = () => {
      // t152 — only restart if live mode is on AND the AI is NOT speaking.
      // While TTS plays, the mic must stay off so it doesn't pick up the
      // AI's own voice and create an echo transcript. The TTS completion
      // handler in send() will resume recognition when speaking ends.
      if (liveRef.current && !speakingRef.current) {
        try { rec.start(); } catch { /* already started */ }
      }
    };

    try { rec.start(); } catch (e) {
      setErr(`Could not start the microphone: ${e instanceof Error ? e.message : "unknown error"}`);
      stopLive();
    }
  };

  const toggleLive = () => {
    if (liveMode) stopLive();
    else startLive();
  };

  return (
    <>
      {/* ── FAB / ORB (collapsed state) ──
          t150 — when live talk is ON and the panel is closed, the orb
          takes over the FAB slot so the user can keep talking while
          browsing the dashboard. Clicking the orb re-opens the panel
          (it does NOT stop live talk — only the mic button does). */}
      {!open && !hideFab && (
        liveMode ? (
          // t154/t157/t160 — the orb FAB sits at the EXACT same position as
          // the regular AI FAB (same bottom + right + h-14 w-14 slot). The
          // orb's native size is 140px; scale(0.4) makes the rendered orb
          // exactly 56px — IDENTICAL to the FAB's h-14 w-14 footprint.
          // NO `overflow-hidden` on the container — the orb's outer box-shadow
          // halo (the soft glow that bleeds outside the circle) must be
          // visible, otherwise the orb looks "cornered-off" / clipped to a
          // hard square. The orb's own CSS already has border-radius:50% +
          // overflow:hidden so its INNER elements are clipped to the circle;
          // we just don't want to clip the OUTER glow.
          <button
            onClick={() => setOpen(true)}
            aria-label="Open Fetch-X AI panel — live talk is on"
            data-testid="ai-fab-orb"
            className="fixed bottom-[calc(84px+env(safe-area-inset-bottom))] right-4 z-40 grid h-14 w-14 place-items-center rounded-full transition md:bottom-6 md:right-6"
          >
            {/* t164 — render the orb at 56x56 DIRECTLY (no transform wrapper).
                The old `scale(0.4)` wrapper caused the visual to drift to the
                wrapper's bottom-right, extending ~14px past the viewport edge. */}
            <LiveOrb speaking={speaking} listening={!speaking} size={56} />
          </button>
        ) : (
          <button
            onClick={() => setOpen(true)}
            aria-label="Open Fetch-X AI assistant"
            data-testid="ai-fab"
            className="fixed bottom-[calc(84px+env(safe-area-inset-bottom))] right-4 z-40 grid h-14 w-14 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)] md:bottom-6 md:right-6"
          >
            <Sparkles className="h-6 w-6" />
          </button>
        )
      )}

      {/* ── Panel ── */}
      {open && (
        <aside
          className="fixed inset-y-0 right-0 z-50 flex flex-col rounded-l-[20px] border border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[-3px_4px_0_0_var(--fx-hard)] md:rounded-none md:border-l md:border-r-0 md:border-t-0 md:border-b-0 md:shadow-none"
          style={
            isDesktop
              ? {
                  // t175 — desktop: force position:absolute via INLINE STYLE
                  // (bypasses CSS cache). Panel overlays the dashboard, stretches
                  // from sidebar's right edge to viewport right edge. When sidebar
                  // collapses, parent widens and panel auto-expands (width=min(100%,w)).
                  position: "absolute" as const,
                  top: 0,
                  bottom: 0,
                  right: 0,
                  width: `min(100%, ${width}px)`,
                  maxWidth: `${width}px`,
                  zIndex: 50,
                }
              : {
                  // mobile: fixed overlay, standard width
                  width: `min(${width}px, 100vw)`,
                }
          }
          aria-label="Fetch-X AI assistant"
        >
          {/* t174 — resize handle always visible (no more fullscreen). */}
          <div
            role="separator"
            aria-orientation="vertical"
            aria-label="Resize panel"
            onMouseDown={() => {
              dragging.current = true;
              document.body.style.userSelect = "none";
            }}
            onTouchStart={() => {
              dragging.current = true;
              document.body.style.userSelect = "none";
            }}
            className="absolute -left-1.5 top-0 z-10 h-full w-3 cursor-ew-resize touch-none"
          />

          {/* header */}
          <div className="flex items-center gap-3 border-b border-dashed border-[var(--fx-line)] px-5 py-4">
            <span className="relative grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
              <Bot className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[14px] font-extrabold tracking-tight text-[var(--fx-ink)]">
                {aiName.toUpperCase()}
              </div>
              <div className="fx-label">
                {liveMode ? "LIVE TALK · LISTENING" : "BUSINESS COPILOT · LIVE DATA"}
              </div>
            </div>
            <button
              onClick={() => setVoicePickerOpen(true)}
              data-tip="AI voice"
              aria-label="Open AI voice picker"
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <Volume2 className="h-4 w-4" />
            </button>
            {/* t185 — ONE fullscreen/contract toggle button (the owner asked
                for a single button, not two). Click to jump to fullscreen
                (95% viewport); click again to contract back to the default
                55% squeeze. The drag handle on the left edge is still there
                for fine-grained control between the two endpoints. */}
            <button
              onClick={toggleFullscreen}
              data-tip={isFullscreen ? "Contract panel (back to default)" : "Full screen"}
              aria-label={isFullscreen ? "Contract AI panel" : "Expand AI panel to full screen"}
              aria-pressed={isFullscreen}
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
            {/* t174 — fullscreen button removed. The panel is always wide;
                drag the left edge to resize. */}
            <button
              data-tip="Clear conversation"
              aria-label="Clear conversation"
              onClick={() => {
                // t158/t178 — refresh KILLS everything: abort in-flight fetch,
                // cancel TTS, stop recognition, clear messages + interim.
                stopLive();
                abortRef.current?.abort();
                abortRef.current = null;
                setMsgs([]);
                setErr(null);
                lastFinalRef.current = "";
                busyRef.current = false;
                setBusy(false);
              }}
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
            <button
              data-tip="Collapse panel"
              aria-label="Collapse AI panel"
              onClick={() => setOpen(false)}
              className="grid h-8 w-8 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* messages */}
          <div
            ref={scrollRef}
            className={`fx-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-6 py-4 w-full`}
          >
            {msgs.length === 0 && !busy && (
              <div className="px-2 py-6 text-center">
                <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                  <Sparkles className="h-5 w-5" />
                </div>
                {/* t166 — greeting using the custom AI name */}
                <p className="mt-3 text-[14px] font-extrabold text-[var(--fx-ink)]">
                  Hello, I am {aiName} — your personal assistant for your business.
                </p>
                <p className="mt-1 text-[12px] font-medium text-[var(--fx-muted)]">
                  How may I help you today? I read your live bills — sales, dishes, peak hours — and
                  answer like a business analyst. Ask anything, or start with:
                </p>
                <div className="mt-4 space-y-2">
                  {QUICK.map((id) => {
                    // One path for everything: the chip asks the AI exactly
                    // like a typed question would.
                    const question = quickLabel(id, range, salesDays);
                    return (
                      <button
                        key={id}
                        onClick={() => void send(question)}
                        className="w-full rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2.5 text-left text-[12px] font-bold text-[var(--fx-ink)] transition hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
                      >
                        {question}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Live talk orb */}
            {liveMode && (
              <div className="flex flex-col items-center gap-2 py-3">
                <LiveOrb speaking={speaking} listening={!speaking} />
                <div className="fx-label text-center">
                  {speaking ? "AI IS REPLYING…" : "LISTENING — TAP MIC TO STOP"}
                </div>
              </div>
            )}

            {msgs.map((m, i) => {
              if ("live" in m && m.live) {
                return (
                  <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                    <div className={`flex flex-col gap-1.5 max-w-[80%]`}>
                      <div className={`fx-live-bubble ${m.role === "user" ? "user" : ""}`}>
                        {m.content}
                      </div>
                      {m.role === "assistant" && m.formatted && (
                        <div className="rounded-2xl rounded-bl-md bg-[var(--fx-lav)] px-3.5 py-2.5 text-[var(--fx-ink)]">
                          <AiMarkdown text={m.formatted} />
                        </div>
                      )}
                    </div>
                  </div>
                );
              }
              return (
                <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-[12.5px] font-medium leading-relaxed ${
                      m.role === "user"
                        ? "whitespace-pre-wrap rounded-br-md bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
                        : "rounded-bl-md bg-[var(--fx-lav)] text-[var(--fx-ink)]"
                    }`}
                  >
                    {m.role === "assistant" ? <AiMarkdown text={m.content} /> : m.content}
                  </div>
                </div>
              );
            })}

            {/* Interim speech bubble */}
            {liveMode && interim && (
              <div className="flex justify-end">
                <div className={`fx-live-bubble user interim max-w-[80%]`}>{interim}</div>
              </div>
            )}

            {busy && (
              <div className="flex justify-start">
                <div className="flex items-center gap-2 rounded-2xl rounded-bl-md bg-[var(--fx-lav)] px-3.5 py-3">
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-[var(--fx-accent-ink)]" />
                  <span className="text-[11px] font-bold tracking-wider text-[var(--fx-muted)]">
                    {liveMode ? "Processing The Reply…" : "READING LIVE BILLS…"}
                  </span>
                </div>
              </div>
            )}
            {err && (
              <div className="rounded-xl bg-[color-mix(in_srgb,var(--fx-rose)_10%,transparent)] px-3 py-2.5 text-[12px] font-semibold text-[var(--fx-rose)]">
                <div>{err}</div>
                {/* t185 — when the mic fails (iframe permission / browser
                    support), the most reliable fix is to open the preview in
                    a new top-level tab — the iframe's parent chat-side UI
                    blocks microphone access by default; a new tab lets the
                    browser prompt for the permission properly. */}
                {(err.includes("Microphone") || err.includes("Web Speech") || err.includes("Speech recognition")) && (
                  <a
                    href={typeof window !== "undefined" ? window.location.href : "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center gap-1 rounded-lg bg-[var(--fx-rose)] px-2.5 py-1 text-[11px] font-extrabold tracking-wide text-white hover:opacity-90"
                  >
                    Open in new tab →
                  </a>
                )}
              </div>
            )}
          </div>

          {/* input */}
          <div className={`border-t border-dashed border-[var(--fx-line)] p-3 px-6`}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void send(input);
              }}
              className="flex items-center gap-2"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={liveMode ? "Live talk is ON — just speak…" : "Ask about your business…"}
                aria-label="Ask the AI copilot"
                disabled={liveMode}
                className="h-11 min-w-0 flex-1 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3.5 text-[13px] font-semibold text-[var(--fx-ink)] outline-none placeholder:text-[var(--fx-muted)] focus:border-[var(--fx-purple)] disabled:opacity-60"
              />
              {/* LIVE TALK toggle */}
              <button
                type="button"
                onClick={toggleLive}
                disabled={!sttSupported}
                aria-pressed={liveMode}
                aria-label={liveMode ? "Stop live talk" : "Start live talk"}
                data-tip={liveMode ? "Stop live talk" : "Start live talk"}
                data-testid="ai-live-talk"
                className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl border shadow-[2px_3px_0_0_var(--fx-hard)] transition ${
                  liveMode
                    ? "border-[var(--fx-rose)] bg-[var(--fx-rose)] text-white"
                    : "border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-accent-ink)] hover:bg-[var(--fx-lav)]"
                } disabled:cursor-not-allowed disabled:opacity-50`}
              >
                {/* t158 — sound-wave icon (AudioLines) instead of the mic.
                    ChatGPT-style vertical bars; pulses nicely when active. */}
                <AudioLines className="h-4 w-4" />
              </button>
              <Button
                type="submit"
                disabled={!input.trim() || liveMode}
                aria-label="Send message"
                className="h-11 w-11 shrink-0 rounded-xl bg-[var(--fx-purple)] p-0 text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
            {currentVoice && (
              <p className="mt-2 text-center text-[10px] font-semibold text-[var(--fx-muted)]">
                AI VOICE · {currentVoice.name}
              </p>
            )}
          </div>
        </aside>
      )}

      {/* Voice picker */}
      <VoicePickerModal
        open={voicePickerOpen}
        onClose={() => setVoicePickerOpen(false)}
        account={currentAccount()}
        onPick={(v) => setCurrentVoice(v)}
      />
    </>
  );
}
