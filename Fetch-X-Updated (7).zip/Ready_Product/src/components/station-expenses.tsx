"use client";

// ── t98 · STATION EXPENSES — the receptions' own cost entry ─────────────────
// A section on both stations: the restaurant desk logs its spends at the bottom
// of the POS, the lodge desk at the bottom of the Front Desk. Three types —
// raw materials, upgrades, maintenance — each entry lands in that book's cost
// ledger, which is exactly what the owner later reads on the Expenses page.

import * as React from "react";
import { Carrot, Loader2, Plus, Sparkles, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FxDatePicker } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import { inr } from "@/lib/format";

type Kind = "raw_material" | "upgrade" | "maintenance";
type Book = "rest" | "lodge";
type Row = { id: string; kind: Kind; label: string; amount: number; spentOn: string };

const KINDS: Array<{ key: Kind; name: string; icon: React.ReactNode; on: string; dot: string }> = [
  { key: "raw_material", name: "RAW MATERIALS", icon: <Carrot className="h-3.5 w-3.5" />, on: "bg-[#0d9488] text-white shadow-[2px_2px_0_0_var(--fx-hard)]", dot: "bg-[#0d9488]" },
  { key: "upgrade", name: "UPGRADES", icon: <Sparkles className="h-3.5 w-3.5" />, on: "bg-[#7c3aed] text-white shadow-[2px_2px_0_0_var(--fx-hard)]", dot: "bg-[#7c3aed]" },
  { key: "maintenance", name: "MAINTENANCE", icon: <Wrench className="h-3.5 w-3.5" />, on: "bg-[var(--fx-amber)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]", dot: "bg-[var(--fx-amber)]" },
];
const kindDot = (k: string) => KINDS.find((x) => x.key === k)?.dot ?? "bg-[var(--fx-muted)]";
const kindName = (k: string) => KINDS.find((x) => x.key === k)?.name ?? k;
const istDay = (iso: string) =>
  new Date(iso).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata", day: "2-digit", month: "2-digit", year: "numeric" });

export function StationExpenses({ book, station }: { book: Book; station: string }) {
  const { toast } = useToast();
  const [kind, setKind] = React.useState<Kind>("raw_material");
  const [label, setLabel] = React.useState("");
  const [amount, setAmount] = React.useState("");
  const [date, setDate] = React.useState(() => new Date().toISOString().slice(0, 10));
  const [busy, setBusy] = React.useState(false);
  const [rows, setRows] = React.useState<Row[] | null>(null);

  const load = React.useCallback(async () => {
    try {
      const res = await fetch(`/api/expenses?book=${book}&limit=8`, { cache: "no-store" });
      const data = await res.json();
      setRows(Array.isArray(data) ? data : []);
    } catch {
      /* cosmetic feed */
    }
  }, [book]);
  React.useEffect(() => {
    void load();
  }, [load]);

  const add = async () => {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast({ title: "Amount needed", description: "Enter the cost amount above zero.", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/expenses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, label: label.trim(), amount: amt, spentOn: date, book }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not save the expense");
      toast({
        title: `${kindName(kind).slice(0, -1)} cost of ${inr(amt)} recorded`,
        description: `Logged in the ${book === "lodge" ? "LODGE" : "RESTAURANT"} book — the owner reads it on the Expenses ledger.`,
      });
      setLabel("");
      setAmount("");
      await load();
    } catch (e) {
      toast({
        title: "Could not save the expense",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fx-card fx-rise p-5" data-testid={`station-expenses-${book}`} data-fx-motion="1">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label">STATION EXPENSES · {station}</span>
        <span className="mut-chip">FEEDS THE OWNER'S LEDGER AUTOMATICALLY</span>
      </div>

      {/* the three types */}
      <div className="mt-3 flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Expense type">
        {KINDS.map((k) => (
          <button
            key={k.key}
            onClick={() => setKind(k.key)}
            aria-pressed={kind === k.key}
            data-testid={`stn-kind-${k.key}-${book}`}
            className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
              kind === k.key ? k.on : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            }`}
          >
            {k.icon} {k.name}
          </button>
        ))}
      </div>

      {/* the entry row */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void add();
          }}
          placeholder={
            kind === "raw_material"
              ? "What? e.g. vegetables, rice, oil…"
              : kind === "upgrade"
                ? "What? e.g. new chairs, signage, sound system…"
                : "What? e.g. gas cylinder, repairs, pest control…"
          }
          aria-label="Expense description"
          data-testid={`stn-label-${book}`}
          className="h-10 min-w-[180px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
        />
        <Input
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="₹"
          type="number"
          min={0}
          aria-label="Expense amount in rupees"
          data-testid={`stn-amount-${book}`}
          className="fx-num h-10 w-[100px] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
        />
        <FxDatePicker value={date} onChange={setDate} ariaLabel="Expense date" />
        <Button
          onClick={() => void add()}
          disabled={busy}
          data-testid={`stn-add-${book}`}
          className="ml-auto h-10 rounded-xl bg-[var(--fx-purple)] px-5 text-[12px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          ADD EXPENSE
        </Button>
      </div>

      {/* the station's own recent entries */}
      <div className="mt-3 border-t border-dashed border-[var(--fx-line)] pt-3">
        <span className="fx-label">THIS STATION'S LAST ENTRIES</span>
        <div className="mt-2 space-y-1.5">
          {(rows ?? []).map((x) => (
            <div key={x.id} className="flex flex-wrap items-center gap-x-2.5 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-1.5">
              <span className={`h-2 w-2 shrink-0 rounded-full ${kindDot(x.kind)}`} aria-hidden />
              <span className="min-w-0 flex-1 truncate text-[12px] font-bold text-[var(--fx-ink)]">
                {x.label || kindName(x.kind)}
              </span>
              <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">
                {kindName(x.kind)} · {istDay(x.spentOn)}
              </span>
              <span className="fx-num shrink-0 text-[12.5px] font-extrabold text-[var(--fx-ink)]">{inr(x.amount)}</span>
            </div>
          ))}
          {rows !== null && rows.length === 0 && (
            <p className="py-4 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
              Nothing logged from this station yet — the first entry lands in the owner's ledger.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
