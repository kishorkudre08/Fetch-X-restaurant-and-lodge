"use client";

import * as React from "react";
import { createPortal } from "react-dom";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

// ── Block-scoped scroller with a bottom fade when content overflows ────────
// The block scrolls, the page doesn't (TEAM roster, LATEST ACTIVITY, ledger).
export function ScrollFadeBox({
  children,
  maxH = 352,
  className = "",
}: {
  children: React.ReactNode;
  maxH?: number;
  className?: string;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const [scrollable, setScrollable] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const measure = () => setScrollable(el.scrollHeight > el.clientHeight + 4);
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div className={`scrollfade ${scrollable ? "is-scrollable" : ""} ${className}`}>
      <div ref={ref} className="fx-scroll overflow-y-auto pr-1" style={{ maxHeight: maxH }}>
        {children}
      </div>
    </div>
  );
}

// ── Theme toggle (sun/moon, like the attachment header) ────────────────────
export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const dark = theme === "dark";
  return (
    <Button
      variant="outline"
      size="icon"
      aria-label="Toggle dark mode"
      data-tip="Dark / light mode"
      onClick={() => setTheme(dark ? "light" : "dark")}
      className="rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[2px_3px_0_0_var(--fx-hard)]"
    >
      {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </Button>
  );
}

// ── t76 · universal theme selector — REMOVED (t101): the theme already
//    lives in Settings, so the per-band THEME button is gone by request.

// ── Numbered tier band — the section opener from the attachment ───────────
export function TierBand({
  num,
  eyebrow,
  title,
  sub,
  tag,
  live,
  children,
}: {
  num: string;
  eyebrow: string;
  title: string;
  sub: string;
  tag?: React.ReactNode;
  live?: boolean;
  children?: React.ReactNode;
}) {
  return (
    <div className="fx-band fx-rise flex flex-wrap items-center gap-4 rounded-[18px] border-[var(--fx-line)] px-6 py-5" data-fx-motion="1">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[var(--fx-purple)] font-mono text-sm font-bold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
        {num}
      </span>
      <div className="min-w-[200px] flex-1">
        <div className="fx-label flex items-center gap-2">
          {live && <span className="fx-live-dot" aria-hidden />}
          {eyebrow}
        </div>
        <h1 className="mt-0.5 text-xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-2xl">
          {title}
        </h1>
        <p className="mt-0.5 text-[13px] font-medium text-[var(--fx-muted)]">{sub}</p>
      </div>
      {tag && (
        <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">
          {tag}
        </span>
      )}
      {children}
    </div>
  );
}

// ── Veg / Non-veg marker (Indian FSSAI convention) ─────────────────────────
export function VegDot({ veg, className = "" }: { veg: boolean; className?: string }) {
  return (
    <span
      data-tip={veg ? "Vegetarian" : "Non-vegetarian"}
      className={`inline-grid h-4 w-4 shrink-0 place-items-center rounded-[4px] border ${
        veg ? "border-[var(--fx-green)]" : "border-[var(--fx-rose)]"
      } ${className}`}
      aria-hidden
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${veg ? "bg-[var(--fx-green)]" : "bg-[var(--fx-rose)]"}`}
      />
    </span>
  );
}

// ── Stat card for the live strip ───────────────────────────────────────────
export function StatCard({
  label,
  value,
  icon,
  delta,
  footnote,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  delta?: { text: string; up: boolean } | null;
  footnote?: string;
}) {
  return (
    <div className="fx-card px-5 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="fx-label">{label}</span>
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
          {icon}
        </span>
      </div>
      <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">
        {value}
      </div>
      <div className="mt-1 h-4 text-[11px] font-semibold">
        {delta ? (
          <span className={delta.up ? "text-[var(--fx-green)]" : "text-[var(--fx-rose)]"}>
            {delta.text}
          </span>
        ) : (
          <span className="text-[var(--fx-muted)]">{footnote ?? ""}</span>
        )}
      </div>
    </div>
  );
}

// ── Fetch-X date picker — replaces the raw native <input type="date"> ──────
// Premium month grid with purple accents, dark-mode aware, TODAY + CLEAR
// footer, future dates blocked (the books only record costs already paid).
// t121 — the calendar now renders in a PORTAL on document.body with fixed
// positioning anchored to the trigger button. Stacking contexts inside cards
// (fx-rise / fx-pop-in transforms, filters) used to paint OVER the popup and
// the calendar looked overlapped on the receptions' expense forms — a
// document-level popup can never be buried again.
export function FxDatePicker({
  value,
  onChange,
  ariaLabel,
  disableFuture = true,
  min,
  max,
  compact = false,
}: {
  value: string; // yyyy-mm-dd
  onChange: (v: string) => void;
  ariaLabel?: string;
  disableFuture?: boolean;
  /** earliest selectable day (yyyy-mm-dd) — blocks the calendar cells like min= on a native input */
  min?: string;
  /** latest selectable day (yyyy-mm-dd) — takes over from disableFuture when you need a real range */
  max?: string;
  /** smaller trigger for tight strips (dashboard tab row) — the popup stays full size */
  compact?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const btnRef = React.useRef<HTMLButtonElement>(null);
  const popRef = React.useRef<HTMLDivElement>(null);
  const [pos, setPos] = React.useState<{ top: number; left: number } | null>(null);

  // t203 — anchor the popup to the button, viewport-aware, re-computed on
  // scroll/resize. COORDINATE SPACES: html runs at zoom:0.75 on desktops
  // (t161/t162 rebased web zoom). getBoundingClientRect() reports VISUAL
  // device pixels, but this popup is portaled INSIDE the zoomed <html>, so
  // its fixed top/left/width lengths live in ZOOMED local units (a fixed
  // length of 100 renders at 75 visual px). Writing the visual rect
  // straight in dropped the calendar at 0.75x of the trigger's position —
  // "opens way away from the click", worse the further down/right the
  // button sat. Convert the visual rect + visual viewport into local units
  // (÷ zoom) so the grid hugs the trigger at any zoom level. Radix poppers
  // get the same treatment in globals.css ([data-radix-popper-content-
  // -wrapper] zoom compensation). Full-viewport fixed overlays (dialogs)
  // and right/bottom-inset floaters were never affected: the zoomed html
  // is sized 133.333vw, so their edges still land on the real edges.
  const place = React.useCallback(() => {
    const btn = btnRef.current;
    const pop = popRef.current;
    if (!btn) return;
    const zoom = (() => {
      const z = parseFloat(getComputedStyle(document.documentElement).zoom || "1");
      return Number.isFinite(z) && z > 0 ? z : 1;
    })();
    const r = btn.getBoundingClientRect();
    const W = 268; // local units — the popup lives inside the zoomed tree
    const H = pop?.offsetHeight ?? 320;
    const margin = 8;
    const vw = window.innerWidth / zoom; // visual viewport → local units
    const vh = window.innerHeight / zoom;
    let left = Math.min(r.left / zoom, vw - W - margin);
    left = Math.max(margin, left);
    let top = r.bottom / zoom + 6;
    if (top + H > vh - margin) top = Math.max(margin, r.top / zoom - H - 6);
    setPos({ top, left });
  }, []);

  React.useEffect(() => {
    if (!open) {
      setPos(null);
      return;
    }
    // two frames so the popup has rendered and its height is measurable
    requestAnimationFrame(() => requestAnimationFrame(place));
    const opts: AddEventListenerOptions = { capture: true, passive: true };
    window.addEventListener("scroll", place, opts);
    window.addEventListener("resize", place, opts);
    return () => {
      window.removeEventListener("scroll", place, opts);
      window.removeEventListener("resize", place, opts);
    };
  }, [open, place]);

  // close on outside click / Escape
  React.useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => {
      const t = e.target as Node;
      if (btnRef.current?.contains(t) || popRef.current?.contains(t)) return;
      setOpen(false);
    };
    const esc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", away);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", away);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);

  const parse = (s: string) => new Date(`${s}T12:00:00`); // noon dodges DST edges
  const fmt = (s: string) =>
    `${parse(s).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })} ${parse(s).getFullYear()}`;
  const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const [view, setView] = React.useState(() => {
    const base = value || todayISO();
    const d = parse(base);
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const select = (d: Date) => {
    const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    onChange(iso);
    setOpen(false);
  };
  const shift = (n: number) => setView((v) => new Date(v.getFullYear(), v.getMonth() + n, 1));

  const y = view.getFullYear();
  const m = view.getMonth();
  const firstDow = new Date(y, m, 1).getDay();
  const daysInMonth = new Date(y, m + 1, 0).getDate();
  const daysPrev = new Date(y, m, 0).getDate();
  const cells: Array<{ d: Date; inMonth: boolean }> = [];
  for (let i = firstDow - 1; i >= 0; i--) cells.push({ d: new Date(y, m - 1, daysPrev - i), inMonth: false });
  for (let d = 1; d <= daysInMonth; d++) cells.push({ d: new Date(y, m, d), inMonth: true });
  while (cells.length % 7 !== 0) {
    const next = new Date(y, m + 1, (cells.length - firstDow - daysInMonth) + 1);
    cells.push({ d: next, inMonth: false });
  }
  const iso = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const futureISO = todayISO();
  const today = todayISO();
  // t201 — min/max range support (settings CUSTOM DATE RANGE + dashboard inline
  // pickers clamp FROM ≤ TO). A day is blocked when it falls outside [min, max].
  const isBlocked = (isoD: string) => (min && isoD < min) || (max && isoD > max) || (disableFuture && isoD > futureISO);

  return (
    <div className="relative">
      <button
        type="button"
        ref={btnRef}
        onClick={() => setOpen((o) => !o)}
        aria-label={ariaLabel ?? "Pick a date"}
        aria-expanded={open}
        data-tip={ariaLabel ?? "Pick a date"}
        className={`fx-num inline-flex items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] font-bold text-[var(--fx-ink)] transition hover:border-[color-mix(in_srgb,var(--fx-purple)_45%,var(--fx-line))] ${
          compact ? "h-8 px-2.5 text-[11px]" : "h-10 px-3 text-[12.5px]"
        }`}
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className={`${compact ? "h-3 w-3" : "h-3.5 w-3.5"} text-[var(--fx-muted)]`}>
          <rect x="3" y="4" width="18" height="18" rx="3" />
          <path d="M16 2v4M8 2v4M3 10h18" />
        </svg>
        {fmt(value || today)}
      </button>
      {open &&
        createPortal(
          <div
            ref={popRef}
            role="dialog"
            aria-label="Calendar"
            data-testid="fx-calendar"
            style={{
              position: "fixed",
              top: pos?.top ?? -9999,
              left: pos?.left ?? -9999,
              width: 268,
              zIndex: 9999,
              visibility: pos ? "visible" : "hidden",
            }}
            className="rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-surf)] p-3 shadow-[6px_10px_30px_-12px_rgba(35,32,72,.5)]"
          >
          <div className="flex items-center justify-between gap-2 pb-2">
            <button
              type="button"
              aria-label="Previous month"
              onClick={() => shift(-1)}
              className="grid h-7 w-7 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" className="h-3.5 w-3.5"><path d="M15 18l-6-6 6-6" /></svg>
            </button>
            <b className="text-[12px] font-extrabold tracking-wide text-[var(--fx-ink)]">
              {view.toLocaleDateString("en-IN", { month: "long", year: "numeric" })}
            </b>
            <button
              type="button"
              aria-label="Next month"
              onClick={() => shift(1)}
              className="grid h-7 w-7 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" className="h-3.5 w-3.5"><path d="M9 6l6 6-6 6" /></svg>
            </button>
          </div>
          <div className="grid grid-cols-7 gap-0.5 pb-1 text-center">
            {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((w) => (
              <span key={w} className="py-1 text-[8.5px] font-extrabold tracking-wider text-[var(--fx-muted)]">
                {w}
              </span>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-0.5">
            {cells.map(({ d, inMonth }, i) => {
              const isoD = iso(d);
              const isSel = isoD === value;
              const isToday = isoD === today;
              const isBlockedDay = isBlocked(isoD);
              return (
                <button
                  key={i}
                  type="button"
                  disabled={isBlockedDay}
                  onClick={() => select(d)}
                  aria-label={d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
                  className={`fx-num grid h-8 place-items-center rounded-lg text-[11.5px] font-bold transition ${
                    isSel
                      ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]"
                      : isBlockedDay
                        ? "cursor-not-allowed text-[var(--fx-muted)] opacity-35"
                        : inMonth
                          ? `text-[var(--fx-ink)] hover:bg-[var(--fx-lav)] ${isToday ? "ring-1 ring-inset ring-[var(--fx-purple)]/50" : ""}`
                          : "text-[var(--fx-muted)] opacity-50 hover:bg-[var(--fx-lav)]"
                  }`}
                >
                  {d.getDate()}
                </button>
              );
            })}
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-dashed border-[var(--fx-line)] pt-2">
            <button
              type="button"
              onClick={() => {
                const d = new Date();
                d.setDate(d.getDate() - 1);
                onChange(iso(d));
                setView(new Date(d.getFullYear(), d.getMonth(), 1));
              }}
              className="rounded-lg px-2 py-1 text-[9.5px] font-extrabold tracking-wider text-[var(--fx-muted)] transition hover:text-[var(--fx-rose)]"
            >
              YESTERDAY
            </button>
            <button
              type="button"
              onClick={() => select(parse(today))}
              className="rounded-lg bg-[var(--fx-lav)] px-3 py-1.5 text-[9.5px] font-extrabold tracking-wider text-[var(--fx-accent-ink)] transition hover:bg-[var(--fx-purple)] hover:text-[var(--fx-on-accent)]"
            >
              TODAY
            </button>
          </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
