"use client";

import * as React from "react";
import { createContext, useContext } from "react";
import { HOTEL_DEFAULT, hotelInitials } from "@/lib/brand";

/**
 * HotelProvider — supplies the VARIABLE hotel identity to every screen.
 * Fetch-X (the platform brand) stays fixed; this name is the tenant that
 * changes. Starts from the default to avoid flashes, then syncs with the DB.
 */
type HotelCtx = {
  hotelName: string;
  upperName: string;
  initials: string;
  saveHotelName: (name: string) => Promise<boolean>;
};

const Ctx = createContext<HotelCtx>({
  hotelName: HOTEL_DEFAULT.name,
  upperName: HOTEL_DEFAULT.name.toUpperCase(),
  initials: hotelInitials(HOTEL_DEFAULT.name),
  saveHotelName: async () => false,
});

export const useHotel = () => useContext(Ctx);

export function HotelProvider({ children }: { children: React.ReactNode }) {
  const [hotelName, setHotelName] = React.useState(HOTEL_DEFAULT.name);

  React.useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d: { hotelName?: string | null }) => {
        if (d.hotelName) setHotelName(d.hotelName);
      })
      .catch(() => {
        /* keep default */
      });
  }, []);

  const saveHotelName = React.useCallback(async (name: string) => {
    try {
      const res = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hotelName: name }),
      });
      const d = (await res.json()) as { ok?: boolean; hotelName?: string };
      if (res.ok && d.ok && d.hotelName) {
        setHotelName(d.hotelName);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, []);

  const value = React.useMemo<HotelCtx>(
    () => ({
      hotelName,
      upperName: hotelName.toUpperCase(),
      initials: hotelInitials(hotelName),
      saveHotelName,
    }),
    [hotelName, saveHotelName],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
