"use client";

/* t148 · t149 · t164 — LIVE ORB — the glassy-foggy orb that signals live talk is on.
 *
 * Like ChatGPT's voice-mode orb: a soft glassy sphere with multiple
 * swirling fog layers inside, a glass-surface highlight at the top-left,
 * a dual halo glow, and two orbiting rings. All themed to the active
 * accent pair (purple + gold).
 *
 * t164 — accepts a `size` prop (default 140). When size=56, the orb renders
 * at 56x56 DIRECTLY (no transform wrapper needed). This fixes the "orb
 * drifting off-screen" bug where the old `transform: scale(0.4)` wrapper
 * caused the visual to be offset to the wrapper's bottom-right (extending
 * ~14px past the viewport edge). The orb's internal elements use
 * percentages, so they scale proportionally with the size.
 *
 * Purely presentational — STT/TTS plumbing lives in ai-panel.tsx.
 * CSS keyframes do all the animation (off the main thread, respects
 * prefers-reduced-motion); JS only swaps the speaking / listening flags.
 */

import * as React from "react";

export function LiveOrb({
  speaking = false,
  listening = false,
  size = 140,
}: {
  speaking?: boolean;
  listening?: boolean;
  size?: number;
}) {
  return (
    <div
      className={`fx-orb${speaking ? " fx-orb--spk" : ""}${listening ? " fx-orb--mic" : ""}`}
      style={{ width: size, height: size }}
      aria-hidden
      data-fx-motion="3"
    >
      {/* outer aura */}
      <div className="fx-orb-glow" />
      {/* five fog swirls inside */}
      <div className="fx-orb-fog1" />
      <div className="fx-orb-fog2" />
      <div className="fx-orb-fog3" />
      <div className="fx-orb-fog4" />
      <div className="fx-orb-fog5" />
      {/* two orbiting rings, opposite directions */}
      <div className="fx-orb-ring" />
      <div className="fx-orb-ring2" />
      {/* inner bright core */}
      <div className="fx-orb-core" />
      {/* glass-surface highlight at top-left (sells the "glass sphere" look) */}
      <div className="fx-orb-glass" />
    </div>
  );
}

