"use client";

import * as React from "react";
import {
  BarChart3,
  BedDouble,
  CalendarCheck,
  ClipboardList,
  ListChecks,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Receipt,
  Settings,
  UtensilsCrossed,
  Wallet,
} from "lucide-react";
import { ThemeToggle } from "@/components/fx";
import { SettingsView } from "@/components/settings-view";
import { FxMotion } from "@/components/fx-motion";
import { HotelProvider, useHotel } from "@/components/hotel-context";
import { ReceiptProvider } from "@/components/receipt-dialog";
import { AiPanel } from "@/components/ai-panel";
import { TaskTracker } from "@/components/task-tracker";
import { PosView } from "@/components/pos-view";
import { DashboardView } from "@/components/dashboard-view";
import { LodgeView } from "@/components/lodge-view";
import { ManagementView } from "@/components/management-view";
import { AttendanceView } from "@/components/attendance-view";
import { ExpensesView } from "@/components/expenses-view";
import { TasksView } from "@/components/tasks-view";
import { LandingView, type AuthUser } from "@/components/landing-view";
import type { Dish, RangeKey } from "@/lib/types";

type View = "dashboard" | "tasks" | "menu" | "pos" | "expenses" | "lodge" | "management" | "attendance" | "settings";

const AUTH_KEY = "fx-auth";
const LEGACY_AUTH_KEY = "jk-auth"; // pre-Imperial-Spices sessions
const SIDE_KEY = "fx-side-open"; // sidebar collapsed = "0"

/* t94 — which station each role lands on + which nav items it may open.
   t104 — the developer account is gone entirely: three demo accounts,
   each landing straight on its own station.
   t113 — owner's Management is renamed Employee; BOTH receptions get a 4th
   section: Attendance (their own book's staff, date selector + marks).
   t115 — the owner runs the MENU MANAGER (menu control only — billing is the
   reception's job, so the owner no longer carries POS Billing at all).
   t118 — BOTH receptions get EXPENSES in their side panel (their own book's
   expenses page — 3 types, naming, cost entry — exactly the old one).
   t129 — SECTION ORDER is the owner's ask (18/19): the NAV array below is
   ordered so the owner reads [Live Dashboard · Menu Manager · Rooms Overview
   · Tasks · Expenses · Employee] and each reception reads [desk · Tasks ·
   Expenses · Attendance]. Point 20 — the owner's lodge nav is renamed
   "Rooms Overview"; the counters keep "Lodge Front Desk". */
const ROLE_DEFAULT_VIEW: Record<string, View> = {
  owner: "dashboard",
  reception_restaurant: "pos",
  reception_lodge: "lodge",
};
const NAV_ACCESS: Record<string, View[]> = {
  owner: ["dashboard", "menu", "lodge", "tasks", "expenses", "management"],
  reception_restaurant: ["pos", "tasks", "expenses", "attendance"],
  reception_lodge: ["lodge", "tasks", "expenses", "attendance"],
};

const NAV: Array<{ id: View; label: string; short: string; tip: string; icon: React.ReactNode }> = [
  { id: "dashboard", label: "Live Dashboard", short: "DASHBOARD", tip: "Owner intelligence", icon: <BarChart3 className="h-[18px] w-[18px]" /> },
  { id: "menu", label: "Menu Manager", short: "MENU", tip: "Dishes & sections — the owner's menu control", icon: <UtensilsCrossed className="h-[18px] w-[18px]" /> },
  { id: "pos", label: "POS Billing", short: "POS", tip: "Cashier terminal", icon: <Receipt className="h-[18px] w-[18px]" /> },
  { id: "lodge", label: "Lodge Front Desk", short: "LODGE", tip: "The room wall · status, stays & maintenance", icon: <BedDouble className="h-[18px] w-[18px]" /> },
  { id: "tasks", label: "Tasks", short: "TASKS", tip: "Forwarded work · budgets & deadlines", icon: <ListChecks className="h-[18px] w-[18px]" /> },
  { id: "expenses", label: "Expenses", short: "EXPENSES", tip: "Raw materials & maintenance — both books", icon: <Wallet className="h-[18px] w-[18px]" /> },
  { id: "management", label: "Employee", short: "STAFF", tip: "Team roster & salaries", icon: <ClipboardList className="h-[18px] w-[18px]" /> },
  { id: "attendance", label: "Attendance", short: "ATTEND", tip: "Mark daily staff attendance", icon: <CalendarCheck className="h-[18px] w-[18px]" /> },
];

export default function Page() {
  return (
    <HotelProvider>
      <FxMotion />
      <AppShell />
    </HotelProvider>
  );
}

function AppShell() {
  const { upperName, initials } = useHotel();
  const [user, setUser] = React.useState<AuthUser | null | "checking">("checking");
  const [view, setView] = React.useState<View>("dashboard");
  const [aiRange, setAiRange] = React.useState<RangeKey>("today");
  const [dishes, setDishes] = React.useState<Dish[]>([]);
  const [menuLoading, setMenuLoading] = React.useState(true);
  const [navOpen, setNavOpen] = React.useState(true);
  // t176 — AI panel width (received from AiPanel via onWidthChange callback).
  // Used to squeeze the dashboard up to a threshold (~55% of viewport), then
  // let the panel overlay beyond that point.
  const [aiPanelW, setAiPanelW] = React.useState(0);
  // t176 — the squeeze threshold: 55% of the CSS viewport. When the panel's
  // width exceeds this, the dashboard stops squeezing and the panel overlays.
  const squeezeThreshold = React.useMemo(() => {
    if (typeof window === "undefined") return 1408;
    const zoomFactor = parseFloat(getComputedStyle(document.documentElement).zoom || "1") || 1;
    return (window.innerWidth / zoomFactor) * 0.55;
  }, []);
  const squeezeWidth = Math.min(aiPanelW, squeezeThreshold);

  // t179 — stable callback for AI navigation (prevents AiPanel re-render on view change)
  const handleNavigate = React.useCallback((v: string) => setView(v as View), []);

  // t180 — stable callback for AI sidebar toggle
  const handleToggleSidebar = React.useCallback((open: boolean) => {
    setNavOpen((o) => {
      localStorage.setItem(SIDE_KEY, open ? "1" : "0");
      return open;
    });
  }, []);

  /* Sidebar collapse — remembered between sessions */
  React.useEffect(() => {
    if (localStorage.getItem(SIDE_KEY) === "0") setNavOpen(false);
  }, []);
  const toggleNav = () =>
    setNavOpen((o) => {
      localStorage.setItem(SIDE_KEY, o ? "0" : "1");
      return !o;
    });

  /* ── Auth gate: restore the demo session before rendering anything ── */
  React.useEffect(() => {
    try {
      localStorage.removeItem(LEGACY_AUTH_KEY); // retire old tenant's sessions
      const raw = localStorage.getItem(AUTH_KEY);
      setUser(raw ? (JSON.parse(raw) as AuthUser) : null);
    } catch {
      setUser(null);
    }
  }, []);

  /* t94 — land every role on its own station */
  const acctKey = user && user !== "checking" ? `${user.email ?? ""}|${user.role}` : "";
  React.useEffect(() => {
    if (user && user !== "checking") {
      setView(ROLE_DEFAULT_VIEW[user.role] ?? "dashboard");
    }
  }, [acctKey]);

  const loadMenu = React.useCallback(async () => {
    try {
      const res = await fetch("/api/menu");
      setDishes(await res.json());
    } catch {
      // keep previous dishes on failure
    } finally {
      setMenuLoading(false);
    }
  }, []);

  React.useEffect(() => {
    void loadMenu();
  }, [loadMenu]);

  const signOut = () => {
    try {
      localStorage.removeItem(AUTH_KEY);
    } catch {
      /* private mode */
    }
    /* t152 — the landing we're about to show is stage-free (normal native
       mobile scroll); drop the forced-landscape stage immediately. */
    try {
      window.__fxApplyStage?.();
    } catch {
      /* stage is cosmetic — never block the sign-out */
    }
    setView("dashboard");
    setUser(null);
  };

  /* Splash while the session is being restored (avoids a flash of the login) */
  if (user === "checking") {
    return (
      <div className="grid h-screen place-items-center bg-[var(--fx-page)]">
        <div className="flex flex-col items-center gap-3">
          <span className="grid h-12 w-12 animate-pulse place-items-center rounded-2xl bg-[var(--fx-purple)] font-mono text-[14px] font-black text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)]">
            FX
          </span>
          <span className="fx-label">LOADING FETCH-X…</span>
        </div>
      </div>
    );
  }

  /* ── Pre-login landing page ── */
  if (!user) {
    return (
      <LandingView onSignedIn={(u) => setUser(u)} />
    );
  }

  const allowedViews = NAV_ACCESS[user.role] ?? NAV_ACCESS.owner;
  const navItems = NAV.filter((n) => allowedViews.includes(n.id));
  /* t129 (pt 20) — the owner's lodge monitor is "Rooms Overview"; counters keep "Lodge Front Desk" */
  const labelFor = (n: (typeof NAV)[number]) =>
    n.id === "lodge" && user.role === "owner" ? "Rooms Overview" : n.label;

  const navButton = (n: (typeof NAV)[number]) => {
    const isActive = view === n.id;
    return (
      <button
        key={n.id}
        onClick={() => setView(n.id)}
        /* t201 — themed tooltips: the collapsed rail shows the styled data-tip
           popped out to the RIGHT (above-positioned tooltips would clip off the
           viewport's left edge); the expanded sidebar already prints the label,
           so no tooltip there at all. The raw native title= is gone. */
        data-tip={navOpen ? undefined : `${labelFor(n)} — ${n.tip}`}
        data-tip-side={navOpen ? undefined : "right"}
        aria-current={isActive ? "page" : undefined}
        className={`group flex w-full items-center gap-3 rounded-xl text-left transition ${
          navOpen ? "px-3.5 py-3" : "justify-center py-3"
        } ${
          isActive
            ? "bg-[var(--fx-purple-soft)] text-[var(--fx-accent-ink)] shadow-[inset_0_0_0_1px_rgba(91,79,233,.25)]"
            : "text-[var(--fx-ink)] hover:bg-[var(--fx-lav)]"
        }`}
      >
        <span className={isActive ? "text-[var(--fx-accent-ink)]" : "text-[var(--fx-muted)] group-hover:text-[var(--fx-ink)]"}>
          {n.icon}
        </span>
        {navOpen && <span className="text-[13px] font-bold">{labelFor(n)}</span>}
      </button>
    );
  };

  return (
    <ReceiptProvider>
      <div id="app-root" className="flex h-screen overflow-hidden bg-[var(--fx-page)]">
        {/* ── Sidebar (desktop, collapsible to an icon rail) ── */}
        <aside
          className={`hidden shrink-0 flex-col border-r border-[var(--fx-line)] bg-[var(--fx-surf)] p-4 transition-[width] duration-200 md:flex ${
            navOpen ? "w-[240px]" : "w-[68px] items-center"
          }`}
        >
          <div className={`flex items-center gap-2.5 pb-6 pt-2 ${navOpen ? "px-1.5" : "flex-col"}`}>
            <span
              className={`grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-[var(--fx-purple)] font-mono text-[13px] font-black text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] ${
                navOpen ? "" : "mb-1"
              }`}
            >
              {initials}
            </span>
            {navOpen && (
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-black tracking-tight text-[var(--fx-ink)]">
                  {upperName}
                </div>
                <div className="fx-label">POWERED BY FETCH-X</div>
              </div>
            )}
            <button
              onClick={toggleNav}
              data-tip={navOpen ? "Collapse side panel" : "Expand side panel"}
              data-tip-side="right"
              aria-label={navOpen ? "Collapse side panel" : "Expand side panel"}
              aria-expanded={navOpen}
              className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[var(--fx-muted)] transition hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)] ${
                navOpen ? "" : "h-9 w-9"
              }`}
            >
              {navOpen ? <PanelLeftClose className="h-4 w-4" /> : <PanelLeftOpen className="h-4 w-4" />}
            </button>
          </div>

          {navOpen && <div className="fx-label px-2 pb-2">CASHIER &amp; OWNER</div>}
          <nav
            className={`space-y-1.5 ${navOpen ? "" : "flex w-full flex-col items-center"}`}
            aria-label="Main"
          >
            {navItems.map((n) => navButton(n))}
          </nav>

          <div className={`mt-auto space-y-2 ${navOpen ? "" : "flex w-full flex-col items-center"}`}>
            {navOpen ? (
              <div className="rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)] px-3.5 py-3">
                <div className="fx-label">LOGGED IN</div>
                <div className="mt-0.5 text-[12.5px] font-extrabold text-[var(--fx-ink)]">
                  {user.name.toUpperCase()} · {user.role.toUpperCase()}
                </div>
                <div className="mt-1.5 flex items-center gap-1.5 text-[10px] font-bold tracking-wider text-[var(--fx-green)]">
                  <span className="fx-live-dot" aria-hidden /> SHIFT ACTIVE · PURE VEG
                </div>
              </div>
            ) : (
              <span className="fx-live-dot my-1" aria-hidden data-tip={`${user.name.toUpperCase()} · ${user.role.toUpperCase()}`} data-tip-side="right" />
            )}
            <div className={`flex items-center ${navOpen ? "justify-between" : "w-full flex-col gap-2"}`}>
              <button
                onClick={signOut}
                data-tip="Sign out of the owner console"
                data-tip-side={navOpen ? undefined : "right"}
                aria-label="Sign out"
                className={`flex items-center gap-2 rounded-xl py-2 text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)] transition hover:text-[var(--fx-rose)] ${
                  navOpen ? "px-2" : "justify-center"
                }`}
              >
                <LogOut className="h-3.5 w-3.5" /> {navOpen && "SIGN OUT"}
              </button>
              <span className="flex items-center gap-2">
                <ThemeToggle />
                {/* t99 — settings opens a WHOLE PAGE now, not a pop-up */}
                <button
                  onClick={() => setView("settings")}
                  aria-label="Open settings"
                  data-tip="Settings — themes & profile"
                  data-tip-side={navOpen ? undefined : "right"}
                  aria-current={view === "settings" ? "page" : undefined}
                  data-testid="settings-btn"
                  className={`grid h-9 w-9 place-items-center rounded-xl border shadow-[2px_3px_0_0_var(--fx-hard)] transition ${
                    view === "settings"
                      ? "border-[var(--fx-purple)] bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
                      : "border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:bg-[var(--fx-lav)]"
                  }`}
                >
                  <Settings className="h-4 w-4" />
                </button>
              </span>
            </div>
          </div>
        </aside>

        {/* ── Main + AI panel row (dashboard contracts when the panel opens) ──
            t173 — added `relative` so the AI panel's fullscreen (absolute inset-0)
            fills THIS container, NOT the whole viewport — the sidebar stays visible. */}
        <div className="relative flex min-w-0 flex-1">
          <main className="min-w-0 flex-1 overflow-y-auto" style={{ paddingRight: `${squeezeWidth}px` }}>
            <div className="mx-auto max-w-[1600px] px-4 pb-28 pt-5 md:px-7 md:pb-10">
              {view === "pos" && (
                <PosView
                  dishes={dishes}
                  loading={menuLoading}
                  role={user.role}
                  onMenuChanged={loadMenu}
                />
              )}
              {/* t115 — the owner's Menu Manager: the same component in menu mode */}
              {view === "menu" && (
                <PosView
                  dishes={dishes}
                  loading={menuLoading}
                  role={user.role}
                  onMenuChanged={loadMenu}
                />
              )}
              {view === "expenses" && (
                <ExpensesView
                  /* t118 — receptions get their OWN book's expenses page; the owner sees both books */
                  book={user.role === "reception_lodge" ? "lodge" : user.role === "reception_restaurant" ? "rest" : undefined}
                />
              )}
              {/* t116 — the owner's Lodge Front Desk is a monitor: no expenses block,
                  no check-in / check-out management, room tap shows status + resident,
                  donut above the rooms; the receptions keep the operating desk */}
              {view === "lodge" && <LodgeView role={user.role} />}
              {view === "tasks" && <TasksView role={user.role} userName={user.name} />}
              {view === "dashboard" && (
                <DashboardView onGoToPos={() => setView("pos")} onRangeChange={setAiRange} />
              )}
              {view === "management" && <ManagementView />}
              {view === "attendance" && (
                <AttendanceView book={user.role === "reception_lodge" ? "lodge" : "rest"} />
              )}
              {view === "settings" && (
                <SettingsView
                  roleName={user.role.toUpperCase()}
                  /* t124 — after a theme lands, bounce the account to its home
                     station: Live Dashboard / POS Billing / Lodge Front Desk */
                  onThemeApplied={() => setView(ROLE_DEFAULT_VIEW[user.role] ?? "dashboard")}
                />
              )}
            </div>
          </main>

          {/* ── AI copilot (adjustable right panel — inline on desktop) ──
              t118 — AI is an OWNER-ONLY function (user: "I do not want
              floating AI button in all 3 accounts, AI is a owner only
              function") — the panel + its floating button mount for the
              owner alone; the receptions run the task tracker instead. */}
          {user.role === "owner" && <AiPanel range={aiRange} onWidthChange={setAiPanelW} onNavigate={handleNavigate} onToggleSidebar={handleToggleSidebar} />}
        </div>

        {/* t118 — the FLOATING TASK TRACKER: every screen, all three accounts,
            on/off from Settings (the floating option the user remembered) */}
        <TaskTracker role={user.role} onOpenBoard={() => setView("tasks")} />

        {/* ── Mobile bottom nav — constant, Instagram-style: pure icons,
              always there, the 6 sections + settings live down here ── */}
        <nav
          className="fixed inset-x-0 bottom-0 z-30 flex items-stretch justify-around border-t border-[var(--fx-line)] bg-[var(--fx-surf)] px-1 pb-[env(safe-area-inset-bottom)] pt-1.5 md:hidden"
          aria-label="Main mobile"
        >
          {navItems.map((n) => {
            const isActive = view === n.id;
            const label = labelFor(n);
            return (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                aria-current={isActive ? "page" : undefined}
                aria-label={label}
                className="flex min-h-[56px] min-w-0 flex-1 flex-col items-center justify-center gap-0.5 pt-1"
              >
                <span
                  className={`grid h-8 w-10 place-items-center rounded-lg transition ${
                    isActive
                      ? "bg-[var(--fx-purple-soft)] text-[var(--fx-accent-ink)] shadow-[inset_0_0_0_1px_rgba(91,79,233,.25)]"
                      : "text-[var(--fx-muted)]"
                  }`}
                >
                  {n.icon}
                </span>
                <span
                  className={`text-[8px] font-extrabold tracking-wider leading-none ${
                    isActive ? "text-[var(--fx-accent-ink)]" : "text-[var(--fx-muted)]"
                  }`}
                >
                  {n.short}
                </span>
              </button>
            );
          })}
          {/* settings lives in the bar too — the gear opens the full page */}
          <button
            onClick={() => setView("settings")}
            aria-label="Open settings"
            aria-current={view === "settings" ? "page" : undefined}
            data-testid="settings-btn-mobile"
            className="flex min-h-[56px] min-w-0 flex-1 flex-col items-center justify-center gap-0.5 pt-1"
          >
            <span
              className={`grid h-8 w-10 place-items-center rounded-lg transition ${
                view === "settings"
                  ? "bg-[var(--fx-purple-soft)] text-[var(--fx-accent-ink)] shadow-[inset_0_0_0_1px_rgba(91,79,233,.25)]"
                  : "text-[var(--fx-muted)]"
              }`}
            >
              <Settings className="h-[18px] w-[18px]" />
            </span>
            <span
              className={`text-[8px] font-extrabold tracking-wider leading-none ${
                view === "settings" ? "text-[var(--fx-accent-ink)]" : "text-[var(--fx-muted)]"
              }`}
            >
              SETTINGS
            </span>
          </button>
        </nav>
      </div>
    </ReceiptProvider>
  );
}
