import { db } from "@/lib/db";

// ── t230 · LOYALTY RANKS — the owner slices customers by ALL-TIME SPEND RANK ─
// Rank 1 = the biggest spender across BOTH books (restaurant bills + lodge
// stays keyed to the same 10-digit phone). The owner carves the base into
// ordered ranges in Settings — each range earns its own % of the paid total,
// overriding the flat base loyaltyPct. Everyone beyond the last open range
// (or with no ranges at all) earns the base %.
//
// The receptions can NEVER write this table — Settings (owner) is the only
// writer; at billing they only SEE a customer's rank/tier and may hand a
// bonus to ranked customers.

export type TierRow = {
  id: string;
  label: string;
  fromRank: number;
  toRank: number | null; // null = open-ended final range
  earnPct: number;
};

export const TIER_DEFAULTS: Array<{ label: string; fromRank: number; toRank: number | null; earnPct: number }> = [
  { label: "ELITE · TOP 10", fromRank: 1, toRank: 10, earnPct: 10 },
  { label: "GOLD · 11–50", fromRank: 11, toRank: 50, earnPct: 8 },
  { label: "SILVER · 51–200", fromRank: 51, toRank: 200, earnPct: 6 },
];

const cache: { at: number; rows: TierRow[] } = { at: 0, rows: [] };
const TTL_MS = 30_000;

export function invalidateTiers() {
  cache.at = 0;
}

/** All ranges, ordered by fromRank (30s cache — Settings saves invalidate). */
export async function listTiers(): Promise<TierRow[]> {
  if (cache.rows.length || Date.now() - cache.at < TTL_MS) return cache.rows;
  const raw = await db.loyaltyTier.findMany({ orderBy: { fromRank: "asc" } });
  const rows: TierRow[] = raw.map((r) => ({
    id: r.id,
    label: r.label,
    fromRank: r.fromRank,
    toRank: r.toRank ?? null,
    earnPct: r.earnPct,
  }));
  cache.at = Date.now();
  cache.rows = rows;
  return rows;
}

/** Replace the whole range set (owner Settings SAVE). Validates ordering. */
export async function saveTiers(
  rows: Array<{ label?: unknown; fromRank?: unknown; toRank?: unknown; earnPct?: unknown }>,
): Promise<TierRow[]> {
  const clean: Array<{ label: string; fromRank: number; toRank: number | null; earnPct: number }> = [];
  for (const r of rows) {
    const label = String(r.label ?? "").trim().slice(0, 40) || "RANK RANGE";
    const fromRank = Math.max(1, Math.floor(Number(r.fromRank) || 0));
    if (!Number.isFinite(fromRank) || fromRank < 1) continue;
    const toRaw = r.toRank === null || r.toRank === undefined || r.toRank === "" ? null : Math.floor(Number(r.toRank));
    const toRank = toRaw !== null && Number.isFinite(toRaw) && toRaw >= fromRank ? toRaw : null;
    const earnPct = Math.min(100, Math.max(0, Math.floor(Number(r.earnPct) || 0)));
    clean.push({ label, fromRank, toRank, earnPct });
  }
  clean.sort((a, b) => a.fromRank - b.fromRank);
  await db.$transaction([
    db.loyaltyTier.deleteMany(),
    ...clean.map((c) => db.loyaltyTier.create({ data: c })),
  ]);
  invalidateTiers();
  return listTiers();
}

/** Seed the defaults once, when the owner hasn't crafted any ranges yet. */
export async function ensureTiersSeeded(): Promise<void> {
  const n = await db.loyaltyTier.count();
  if (n > 0) return;
  await db.loyaltyTier.createMany({ data: TIER_DEFAULTS });
  invalidateTiers();
}

/**
 * The earn % a customer of this all-time rank mints: the tightest range
 * covering the rank wins; no cover → the base % from Settings.
 */
export async function earnPctForRank(rank: number | null, basePct: number): Promise<number> {
  if (rank === null || !Number.isFinite(rank) || rank < 1) return basePct;
  const tiers = await listTiers();
  const hit = tiers.find((t) => rank >= t.fromRank && (t.toRank === null || rank <= t.toRank));
  return hit ? hit.earnPct : basePct;
}

/** The range a rank falls in (for the billing-dock badge / bonus gating). */
export async function tierForRank(
  rank: number | null,
): Promise<{ label: string; earnPct: number } | null> {
  if (rank === null || !Number.isFinite(rank) || rank < 1) return null;
  const tiers = await listTiers();
  const hit = tiers.find((t) => rank >= t.fromRank && (t.toRank === null || rank <= t.toRank));
  return hit ? { label: hit.label, earnPct: hit.earnPct } : null;
}
