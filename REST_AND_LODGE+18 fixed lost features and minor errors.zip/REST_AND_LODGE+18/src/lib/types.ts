export type Dish = {
  id: string;
  name: string;
  price: number;
  category: string;
  veg: boolean;
  active: boolean;
  createdAt: string;
};

export type BillItem = {
  id: string;
  billId?: string;
  dishId: string | null;
  name: string;
  category: string;
  qty: number;
  price: number;
};

/* The four order channels the counter can bill under — the receptionist
   picks one in the billing dock before generating. "lodge_order" covers
   in-house guests ordering food to their rooms. Every bill carries its
   channel so the owner's business-mix analytics (and the AI) can split
   restaurant revenue by how orders actually arrive. */
export const ORDER_TYPES = [
  { id: "dine_in", label: "DINE IN" },
  { id: "take_away", label: "TAKE AWAY" },
  { id: "lodge_order", label: "LODGE ORDER" },
  { id: "online_order", label: "ONLINE ORDER" },
] as const;

export type OrderType = (typeof ORDER_TYPES)[number]["id"];

export const ORDER_TYPE_IDS: string[] = ORDER_TYPES.map((o) => o.id);

export const orderTypeLabel = (t: string | null | undefined): string =>
  ORDER_TYPES.find((o) => o.id === t)?.label ?? "DINE IN";

export type Bill = {
  id: string;
  number: number;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  itemCount: number;
  orderType?: OrderType; // the counter channel this bill was billed under
  // Customer identity keyed in the billing dock above the totals — MANDATORY
  // since t225 (strict data collection), phone exactly 10 digits. The phone
  // is the identity key AND the loyalty wallet key.
  customerName?: string | null;
  customerPhone?: string | null;
  // t225 — loyalty on the bill: points minted for the customer (earn % of
  // what they paid) and the points portion of the discount (beyond the
  // owner's limit). 1 point = ₹1.
  pointsEarned?: number;
  pointsUsed?: number;
  createdAt: string;
  items: BillItem[];
  // Lodge receipts only — printed number ("L-5001") and guest/service lines.
  numberLabel?: string;
  meta2?: string;
  meta3?: string;
};

export type RangeKey = "today" | "7d" | "1m" | "3m" | "1y" | "3y" | "lifetime" | "custom";

export type Employee = {
  id: string;
  name: string;
  role: string;
  salary: number; // monthly, INR
  book: "rest" | "lodge"; // which cost book carries this salary
  active: boolean;
  createdAt: string;
};

export type Expense = {
  id: string;
  kind: "raw_material" | "upgrade" | "maintenance";
  book: "rest" | "lodge"; // which business's cost book this entry belongs to
  label: string;
  amount: number;
  spentOn: string;
  via?: string | null; // "task" — auto-registered from a completed owner task (crown row)
  taskId?: string | null;
  createdAt: string;
};

export type Category = {
  id: string;
  name: string;
  createdAt: string;
};

export type RoomStatus = "avl" | "occ" | "mnt";

export type Room = {
  number: number;
  status: RoomStatus;
  guestName: string | null;
  guestPhone: string | null;
  checkInAt: string | null;
  updatedAt: string;
};

export type LodgeBill = {
  id: string;
  number: number; // 5001… printed as L-5001
  room: number;
  guestName: string;
  guestPhone: string;
  tier: string;
  rate: number;
  checkInAt: string;
  checkOutAt: string;
  hours: number;
  stay: number;
  minApplied: boolean;
  discount: number;
  // t225 — loyalty on the stay: minted vs redeemed points (1 pt = ₹1)
  pointsEarned?: number;
  pointsUsed?: number;
  tax: number;
  total: number;
  createdAt: string;
};

export type BookCosts = {
  salaries: number;
  rawMaterials: number;
  upgrades: number; // t98 — the receptions' third expense type
  maintenance: number;
  // t132 — discounts given at billing, shown as its own breakdown line
  discounts: number;
  // t225 — loyalty points redeemed at billing (part of the discount that
  // burned the customer's wallet) — its own breakdown line + donut slice
  pointsUsed: number;
  profit: number;
};

/** t133 — one row of the discount history (both books share the shape). */
export type DiscountRow = {
  number: number;
  room: number | null;
  guestName: string | null;
  total: number;
  discount: number;
  createdAt: string;
};

/** t97 — one progress note posted on an owner task. */
export type TaskNote = {
  id: string;
  taskId: string;
  author: string;
  role: string;
  message: string;
  createdAt: string;
};

/** t97 — a task the owner forwards to the lodge or restaurant reception.
 * maxBudget = null → free task; when budgeted, kind + description are set. */
export type FxTask = {
  id: string;
  title: string;
  book: "rest" | "lodge"; // which reception the task is forwarded to
  kind: "raw_material" | "upgrade" | "maintenance" | null; // expense type (required when budgeted)
  maxBudget: number | null;
  description: string;
  deadline: string;
  status: "open" | "done";
  createdBy: string;
  createdAt: string;
  doneAt: string | null;
  doneBy: string | null;
  actualCost: number | null;
  updates: TaskNote[];
};

/** t91 — room-hours wall split (mirrors src/lib/analytics-lodge.ts). */
export type RoomHoursData = {
  guests: number; // room-hours hosted by guests inside the window
  mnt: number; // room-hours spent under maintenance
  free: number; // the wall's leftover room-hours
  total: number; // totalRooms × windowHours
  totalRooms: number; // the wall size (100) — donut slices sum to this
  windowHours: number; // window length in hours
  windowLabel: string; // "TODAY" / "LAST 7 DAYS" …
};

/**
 * t235/t236 — one campaign send for the trend markers: `at` (epoch ms) feeds
 * the tooltip list, kind/recipients style the dot.
 * t237 — `f` = the fraction of its bucket that had elapsed when the send went
 * out (0 = bucket start, 1 = bucket end): the dot sits at its true time inside
 * the bucket's slice of the axis instead of stacking on the bucket centre.
 */
export type CampSend = { at: number; kind: "personal" | "notice"; recipients: number; f: number };

/** t236 — media attached to a campaign (files streamed by /api/media/[name]) */
export type BroadcastAttachment = { url: string; kind: "image" | "video"; name: string };

export type LodgeBlock = {
  revenue: number;
  stays: number;
  avgStay: number;
  deltaPct: number | null;
  /** t132 — discounts typed into the front desk's checkout input */
  discounts: number;
  /** t133 — the newest discounted checkouts (discount history feed) */
  discountRows: Array<DiscountRow>;
  buckets: Array<{ label: string; revenue: number; stays: number; camps: number; sends: CampSend[] }>;
  peakLabel: string | null;
  dayCurve: Array<{ label: string; pct: number }>;
  dayPeak: string | null;
  inHouse: number;
  pctFull: number;
  mnt: number;
  tonight: number;
  stayMix: Array<{ label: string; share: number }>;
  tierMix: Array<{ tier: string; revenue: number; share: number }>;
  /** t91 — room-hours split of the wall for the selected window */
  roomHours: RoomHoursData;
  recent: Array<{
    number: number;
    room: number;
    guestName: string;
    total: number;
    createdAt: string;
    hours: number;
  }>;
};

export type DashboardData = {
  generatedAt: string;
  range: RangeKey;
  stats: {
    revenue: number;
    bills: number;
    items: number;
    avgTicket: number;
    discounts: number;
    revenueDeltaPct: number | null;
    billDeltaPct: number | null;
  };
  peakLabel: string | null;
  buckets: Array<{ label: string; revenue: number; bills: number; camps: number; sends: CampSend[] }>;
  /** t133 — discount history: newest discounted bills per book */
  discountLog: { rest: DiscountRow[]; lodge: DiscountRow[] };
  hourly: {
    series: Array<{ label: string; avg: number; bills: number }>;
    peak: string | null;
    quiet: string | null;
    days: number;
  };
  itemsSold: Array<{ name: string; qty: number; revenue: number }>;
  categoryMix: Array<{ category: string; revenue: number; share: number }>;
  /** t229 — how the window's restaurant revenue arrived at the counter:
   *  one row per order channel (all four always listed, zeros included).
   *  Feeds the ORDER MIX donut on the live dashboard. */
  orderTypes: Array<{ type: OrderType; label: string; bills: number; revenue: number; share: number }>;
  /** t231 — the 100 biggest spenders across BOTH books (all-time, keyed by
   *  the 10-digit phone). Feeds the TOP CUSTOMERS audience ledger in the
   *  owner's Mass Messages section (moved off the live dashboard). */
  topCustomers: Array<{
    phone: string;
    name: string | null;
    visits: number;
    restSpend: number;
    lodgeSpend: number;
    total: number;
    points: number;
    lastSeen: string | null;
  }>;
  recentBills: Bill[];
  allTime: { bills: number; revenue: number };
  team: {
    employees: Array<{ id: string; name: string; role: string; salary: number; book: "rest" | "lodge" }>;
    monthlyTotal: number;
    periodCost: number;
  };
  costs: {
    salaries: number;
    rawMaterials: number;
    upgrades: number;
    maintenance: number;
    profit: number;
    marginPct: number | null;
  };
  books: { rest: BookCosts; lodge: BookCosts };
  lodge: LodgeBlock;
};

export const CATEGORIES = [
  "Starters",
  "Main Course",
  "Breads",
  "Rice & Biryani",
  "Desserts",
  "Beverages",
  "Ready Made Goods",
] as const;
