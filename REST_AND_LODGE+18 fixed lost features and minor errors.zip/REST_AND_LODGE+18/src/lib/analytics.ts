import { db } from "@/lib/db";
import { getBookCosts, getLodgeBlock, type BookCosts, type LodgeBlock } from "@/lib/analytics-lodge";
import { accrueSalaries } from "@/lib/salary-accrual";
import { invalidateCustomers } from "@/lib/customers";
import { ORDER_TYPES, type CampSend, type DiscountRow, type OrderType } from "@/lib/types";

// ── Ranges ──────────────────────────────────────────────────────────────────
// t192 — added "3y" (3 years / 1095 days), "lifetime" (all-time — 50 years
// ceiling), "custom" (owner-picked start + end dates passed via URL params).
export const RANGE_KEYS = ["today", "7d", "1m", "3m", "1y", "3y", "lifetime", "custom"] as const;
export type RangeKey = (typeof RANGE_KEYS)[number];

export const RANGE_META: Record<
  RangeKey,
  { label: string; days: number; bucket: "hour" | "day" | "week" | "month"; chartTitle: string }
> = {
  today: { label: "Today", days: 1, bucket: "hour", chartTitle: "SALES CURVE · TODAY (IST)" },
  "7d": { label: "Last 7 days", days: 7, bucket: "day", chartTitle: "REVENUE · LAST 7 DAYS" },
  "1m": { label: "Last 1 month", days: 30, bucket: "day", chartTitle: "REVENUE · LAST 30 DAYS" },
  "3m": { label: "Last 3 months", days: 91, bucket: "week", chartTitle: "REVENUE · LAST 3 MONTHS" },
  "1y": { label: "Last 1 year", days: 365, bucket: "month", chartTitle: "REVENUE · LAST 12 MONTHS" },
  // t192 — new long ranges
  "3y": { label: "Last 3 years", days: 1095, bucket: "month", chartTitle: "REVENUE · LAST 3 YEARS" },
  lifetime: { label: "Lifetime", days: 365 * 50, bucket: "month", chartTitle: "REVENUE · LIFETIME (ALL-TIME)" },
  // custom — days/bucket are placeholders; the actual range is built from the
  // ?start=&end= URL params at query time.
  custom: { label: "Custom", days: 30, bucket: "day", chartTitle: "REVENUE · CUSTOM RANGE" },
};

export function parseRange(v: string | null): RangeKey {
  return (RANGE_KEYS as readonly string[]).includes(v ?? "") ? (v as RangeKey) : "today";
}

// Salary proration: monthly salaries ÷ 30 × these day-counts per range.
// 1m = exactly 1 month, 3m = 3 months, 1y = 12 months. 3y = 36 months,
// lifetime = the actual days-since-first-record (calculated live), custom
// = end - start (calculated live). Both lifetime + custom pass the dynamic
// day-count into SALARY_DAYS at query-time so the union stays complete.
export const SALARY_DAYS: Record<RangeKey, number> = {
  today: 1,
  "7d": 7,
  "1m": 30,
  "3m": 90,
  "1y": 360,
  "3y": 1080,
  lifetime: 365 * 50, // placeholder — overridden at query-time
  custom: 30, // placeholder — overridden at query-time with (end - start)
};

// ── IST (UTC+5:30) helpers ──────────────────────────────────────────────────
const IST_OFFSET_MIN = 330;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function istShift(d: Date): Date {
  return new Date(d.getTime() + IST_OFFSET_MIN * 60000);
}
function istDayStart(d: Date): Date {
  const s = istShift(d);
  s.setUTCHours(0, 0, 0, 0);
  return new Date(s.getTime() - IST_OFFSET_MIN * 60000);
}
function istHour(d: Date): number {
  return istShift(d).getUTCHours();
}
function istDateKey(d: Date): string {
  return istShift(d).toISOString().slice(0, 10);
}
function hourLabel(h: number): string {
  const suffix = h >= 12 ? "PM" : "AM";
  const base = h % 12 === 0 ? 12 : h % 12;
  return `${base} ${suffix}`;
}
function dateKeyLabel(key: string): string {
  const [, m, d] = key.split("-").map(Number);
  return `${d} ${MONTHS[m - 1]}`;
}
function monthKeyLabel(key: string): string {
  const [y, m] = key.split("-").map(Number);
  return `${MONTHS[m - 1]} '${String(y).slice(2)}`;
}
function weekStartOf(d: Date): Date {
  const s = istDayStart(d);
  s.setUTCDate(s.getUTCDate() - s.getUTCDay()); // weeks start Sunday (IST calendar)
  return s;
}

const round2 = (n: number) => Math.round(n * 100) / 100;

// t235 — camps = mass-message campaign sends that fired inside this bucket
// (the small marker dots on the Live Dashboard's revenue-trend lines)
// t236 — EVERY send gets its own dot: `sends` carries each send individually
// (time, kind, reach) so a bucket with three campaigns wears three beads and
// the tooltip can list them one by one. camps stays = sends.length.
export type Bucket = { label: string; revenue: number; bills: number; camps: number; sends: CampSend[] };

export type DashboardResult = {
  generatedAt: string;
  range: RangeKey;
  stats: {
    revenue: number;
    bills: number;
    items: number;
    avgTicket: number;
    discounts: number;
    revenueDeltaPct: number | null;
    billDeltaPct: number | null;
  };
  peakLabel: string | null;
  buckets: Bucket[];
  /* t133 — discount history: the newest discounted bills per book, so the
     dashboard can list exactly which bill got how much taken off, and when. */
  discountLog: { rest: DiscountRow[]; lodge: DiscountRow[] };
  hourly: {
    series: Array<{ label: string; avg: number; bills: number }>;
    peak: string | null;
    quiet: string | null;
    days: number;
  };
  itemsSold: Array<{ name: string; qty: number; revenue: number }>;
  categoryMix: Array<{ category: string; revenue: number; share: number }>;
  // t229 — how the window's restaurant revenue arrived at the counter
  orderTypes: Array<{ type: OrderType; label: string; bills: number; revenue: number; share: number }>;
  // t229 — top 10 spenders across BOTH books (all-time, phone-keyed)
  topCustomers: Array<{
    phone: string;
    name: string | null;
    visits: number;
    restSpend: number;
    lodgeSpend: number;
    total: number;
    points: number;
    lastSeen: string | null;
  }>;
  recentBills: Array<{
    id: string;
    number: number;
    createdAt: Date;
    itemCount: number;
    total: number;
    subtotal: number;
    discount: number;
    tax: number;
    items: Array<{ id: string; dishId: string | null; name: string; qty: number; price: number }>;
  }>;
  allTime: { bills: number; revenue: number };
  team: {
    employees: Array<{ id: string; name: string; role: string; salary: number }>;
    monthlyTotal: number;
    periodCost: number;
    projectedCost: number;
    paidCount: number;
  };
  costs: {
    salaries: number;
    rawMaterials: number;
    upgrades: number;
    maintenance: number;
    profit: number;
    marginPct: number | null;
  };
  books: { rest: BookCosts; lodge: BookCosts };
  lodge: LodgeBlock;
};

// ── Main aggregation ────────────────────────────────────────────────────────
// Small TTL cache: the dashboard polls every 15s and each poll used to scan
// up to 2× the range. With a year of history (~10k bills) we cache results
// briefly and invalidate the moment a new bill is written.
const dashboardCache = new Map<RangeKey, { at: number; data: DashboardResult }>();
const CACHE_TTL_MS = 5000;

export function invalidateDashboardCache() {
  dashboardCache.clear();
  topCustomersCache.at = 0; // t229 — a new bill/stay can change the top-spender board
  invalidateCustomers(); // t229 — and the mass-message composer's audience
}

/* t229 — TOP CUSTOMERS (both books, all-time, keyed by the 10-digit phone).
   The dashboard polls every 15s, so this runs on its OWN 60s TTL cache and
   invalidates with the dashboard cache (invalidateDashboardCache) whenever
   the ledger changes. Restaurant rows key Bill.customerPhone; lodge rows key
   LodgeBill.guestPhone; the wallet (points) is the shared earned−used sum. */
const topCustomersCache: { at: number; rows: DashboardResult["topCustomers"] } = { at: 0, rows: [] };
const TOP_TTL_MS = 60_000;

export async function getTopCustomers(): Promise<DashboardResult["topCustomers"]> {
  if (topCustomersCache.rows.length && Date.now() - topCustomersCache.at < TOP_TTL_MS) {
    return topCustomersCache.rows;
  }
  const [restRows, lodgeRows, restNames, lodgeNames] = await Promise.all([
    db.bill.groupBy({
      by: ["customerPhone"],
      where: { customerPhone: { not: null } },
      _count: { _all: true },
      _sum: { total: true, pointsEarned: true, pointsUsed: true, bonusPoints: true },
      _max: { createdAt: true },
    }),
    db.lodgeBill.groupBy({
      by: ["guestPhone"],
      _count: { _all: true },
      _sum: { total: true, pointsEarned: true, pointsUsed: true, bonusPoints: true },
      _max: { createdAt: true },
    }),
    // SQLite bare-column rule: with MAX(createdAt) in play, the bare
    // customerName is taken FROM the newest row — the latest name per phone.
    db.$queryRaw<Array<{ phone: string | null; name: string | null }>>
      `SELECT "customerPhone" AS phone, "customerName" AS name, MAX("createdAt") FROM "Bill" WHERE "customerName" IS NOT NULL AND "customerPhone" IS NOT NULL GROUP BY "customerPhone"`,
    db.$queryRaw<Array<{ phone: string; name: string }>>
      `SELECT "guestPhone" AS phone, "guestName" AS name, MAX("createdAt") FROM "LodgeBill" GROUP BY "guestPhone"`,
  ]);
  const nameOf = new Map<string, string>();
  for (const r of restNames) if (r.phone && r.name) nameOf.set(r.phone, r.name);
  for (const l of lodgeNames) if (!nameOf.has(l.phone) && l.name) nameOf.set(l.phone, l.name);
  const acc = new Map<string, { phone: string; name: string | null; visits: number; restSpend: number; lodgeSpend: number; points: number; last: Date | null }>();
  for (const r of restRows) {
    if (!r.customerPhone) continue;
    acc.set(r.customerPhone, {
      phone: r.customerPhone,
      name: nameOf.get(r.customerPhone) ?? null,
      visits: r._count._all,
      restSpend: r._sum.total ?? 0,
      lodgeSpend: 0,
      points: (r._sum.pointsEarned ?? 0) - (r._sum.pointsUsed ?? 0) + (r._sum.bonusPoints ?? 0),
      last: r._max.createdAt ?? null,
    });
  }
  for (const l of lodgeRows) {
    const cur = acc.get(l.guestPhone);
    const lastL = l._max.createdAt ?? null;
    const last = !cur?.last ? lastL : !lastL ? cur.last : lastL > cur.last ? lastL : cur.last;
    acc.set(l.guestPhone, {
      phone: l.guestPhone,
      name: cur?.name ?? nameOf.get(l.guestPhone) ?? null,
      visits: (cur?.visits ?? 0) + l._count._all,
      restSpend: cur?.restSpend ?? 0,
      lodgeSpend: l._sum.total ?? 0,
      points: (cur?.points ?? 0) + (l._sum.pointsEarned ?? 0) - (l._sum.pointsUsed ?? 0) + (l._sum.bonusPoints ?? 0),
      last,
    });
  }
  const rows = [...acc.values()]
    .map((r) => ({
      ...r,
      total: round2(r.restSpend + r.lodgeSpend),
      restSpend: round2(r.restSpend),
      lodgeSpend: round2(r.lodgeSpend),
      points: Math.round(r.points),
      lastSeen: r.last ? r.last.toISOString() : null,
    }))
    .sort((a, b) => b.total - a.total || b.visits - a.visits)
    // t231 — the owner reads the TOP 100 inside the Mass Messages section's
    // audience ledger (internal scroll on the card); the AI digest re-slices
    // its own top dozen from the same rows.
    .slice(0, 100);
  topCustomersCache.at = Date.now();
  topCustomersCache.rows = rows;
  return rows;
}

/**
 * t235 — CAMPAIGN MARKERS: broadcast sends grouped per trend bucket, so the
 * Live Dashboard's revenue lines can drop a small dot at every hour/day/week/
 * month a mass-message campaign went out (same bucketing as the charts).
 * t236 — one entry PER SEND (not a count): every campaign send is marked with
 * its own dot, so the map carries the full send list per bucket.
 * t237 — every send also carries `f`, the fraction of its bucket that had
 * elapsed when it fired — the renderer places the dot at its true time inside
 * the bucket's slice and lets sends that fired within a blink share one dot.
 */
export async function getCampaignBucketSends(
  since: Date,
  bucket: "hour" | "day" | "week" | "month",
): Promise<Map<string, CampSend[]>> {
  const rows = await db.broadcast.findMany({
    where: { createdAt: { gte: since } },
    select: { createdAt: true, message: true, recipients: true },
    orderBy: { createdAt: "asc" },
  });
  // t237 — the [start, end) span (epoch ms) of the bucket containing d, IST
  // calendar — the denominator that turns a send's timestamp into a fraction.
  const spanOf = (d: Date): { s: number; e: number } => {
    if (bucket === "hour") {
      const h = istShift(d);
      h.setUTCMinutes(0, 0, 0);
      const s = h.getTime() - IST_OFFSET_MIN * 60000;
      return { s, e: s + 3600000 };
    }
    if (bucket === "day") {
      const s = istDayStart(d).getTime();
      return { s, e: s + 86400000 };
    }
    if (bucket === "week") {
      const s = weekStartOf(d).getTime();
      return { s, e: s + 7 * 86400000 };
    }
    const m = istShift(d); // month — IST calendar month bounds
    m.setUTCDate(1);
    m.setUTCHours(0, 0, 0, 0);
    const e = new Date(m);
    e.setUTCMonth(e.getUTCMonth() + 1);
    return { s: m.getTime() - IST_OFFSET_MIN * 60000, e: e.getTime() - IST_OFFSET_MIN * 60000 };
  };
  const m = new Map<string, CampSend[]>();
  for (const r of rows) {
    const key =
      bucket === "hour" ? String(istHour(r.createdAt))
      : bucket === "day" ? istDateKey(r.createdAt)
      : bucket === "week" ? istDateKey(weekStartOf(r.createdAt))
      : istDateKey(r.createdAt).slice(0, 7);
    const sp = spanOf(r.createdAt);
    const f = Math.min(Math.max((r.createdAt.getTime() - sp.s) / Math.max(sp.e - sp.s, 1), 0), 1);
    const list = m.get(key) ?? [];
    list.push({ at: r.createdAt.getTime(), kind: r.message.trim() ? "personal" : "notice", recipients: r.recipients, f });
    m.set(key, list);
  }
  return m;
}

/**
 * t235 — the Mass Messages points cards, computed from the bill rows (the
 * ground truth — never a stored balance):
 *   live  = Σ every phone-keyed wallet's balance RIGHT NOW (per-wallet floor
 *           at zero, exactly like the redemption UI) across BOTH books;
 *   used  = points redeemed on bills inside the window (both books);
 *   users = distinct customers who redeemed inside the window.
 */
export async function getPointsSummary(since: Date): Promise<{ live: number; used: number; users: number }> {
  const [rest, lodge, restWin, lodgeWin] = await Promise.all([
    db.bill.groupBy({
      by: ["customerPhone"],
      where: { customerPhone: { not: null } },
      _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true },
    }),
    db.lodgeBill.groupBy({
      by: ["guestPhone"],
      _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true },
    }),
    db.bill.findMany({ where: { createdAt: { gte: since }, pointsUsed: { gt: 0 } }, select: { customerPhone: true, pointsUsed: true } }),
    db.lodgeBill.findMany({ where: { createdAt: { gte: since }, pointsUsed: { gt: 0 } }, select: { guestPhone: true, pointsUsed: true } }),
  ]);
  const bal = new Map<string, number>();
  const bump = (ph: string | null, earned: number, used: number, bonus: number) => {
    const p = (ph ?? "").replace(/\D/g, "");
    if (p.length !== 10) return;
    bal.set(p, (bal.get(p) ?? 0) + earned + bonus - used);
  };
  for (const r of rest) bump(r.customerPhone, r._sum.pointsEarned ?? 0, r._sum.pointsUsed ?? 0, r._sum.bonusPoints ?? 0);
  for (const l of lodge) bump(l.guestPhone, l._sum.pointsEarned ?? 0, l._sum.pointsUsed ?? 0, l._sum.bonusPoints ?? 0);
  let live = 0;
  for (const v of bal.values()) live += Math.max(0, Math.round(v));
  let used = 0;
  const users = new Set<string>();
  for (const r of restWin) {
    used += r.pointsUsed ?? 0;
    if (r.customerPhone) users.add(r.customerPhone);
  }
  for (const l of lodgeWin) {
    used += l.pointsUsed ?? 0;
    if (l.guestPhone) users.add(l.guestPhone);
  }
  return { live, used: Math.round(used), users: users.size };
}

/**
 * Fetch dashboard data for a range. For "custom" range, the caller must pass
 * `customStart` and `customEnd` as YYYY-MM-DD strings — they override the
 * RANGE_META.days calculation. For "lifetime", the start is the earliest bill
 * timestamp (queried live). The cache key includes the custom range so
 * different custom ranges don't collide.
 */
export async function getDashboardData(
  range: RangeKey,
  opts: { customStart?: string; customEnd?: string } = {},
): Promise<DashboardResult> {
  // Build a cache key that distinguishes custom ranges
  const cacheKey: RangeKey | string = range === "custom" && opts.customStart && opts.customEnd
    ? `custom:${opts.customStart}:${opts.customEnd}`
    : range;
  const hit = dashboardCache.get(cacheKey as RangeKey);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.data;
  const data = await buildDashboard(range, opts);
  dashboardCache.set(cacheKey as RangeKey, { at: Date.now(), data });
  return data;
}

async function buildDashboard(
  range: RangeKey,
  opts: { customStart?: string; customEnd?: string } = {},
): Promise<DashboardResult> {
  const meta = RANGE_META[range];
  const now = new Date();

  // t192 — compute the date window:
  // - today/7d/1m/3m/1y/3y: standard "last N days back from today"
  // - lifetime: start = first bill ever (queried live); end = now
  // - custom: start/end from the owner's date pickers (YYYY-MM-DD strings)
  let start: Date;
  let windowDays: number;
  if (range === "custom" && opts.customStart && opts.customEnd) {
    // Parse the YYYY-MM-DD as IST midnight (so the day is captured whole)
    start = istDayStart(new Date(opts.customStart + "T00:00:00"));
    const endMidnight = istDayStart(new Date(opts.customEnd + "T00:00:00"));
    // end = end-of-the-end-day (add 24h so the gte/lt covers the full day)
    const end = new Date(endMidnight.getTime() + 86_400_000);
    windowDays = Math.max(1, Math.round((end.getTime() - start.getTime()) / 86_400_000));
  } else if (range === "lifetime") {
    // Find the earliest bill (the system's actual start). Falls back to
    // 50 years ago if the table is empty (fresh install).
    const firstBill = await db.bill.findFirst({ orderBy: { createdAt: "asc" }, select: { createdAt: true } });
    start = firstBill ? istDayStart(firstBill.createdAt) : new Date(now.getTime() - 365 * 50 * 86_400_000);
    windowDays = Math.max(1, Math.round((now.getTime() - start.getTime()) / 86_400_000));
  } else {
    start = istDayStart(new Date(now.getTime() - (meta.days - 1) * 86400000));
    windowDays = meta.days;
  }
  // Previous period = same length, just before `start`
  const prevStart = istDayStart(new Date(start.getTime() - windowDays * 86400000));
  // End of the current window. For "today" + standard ranges = now. For
  // custom range = end-of-the-picked-end-day (calculated above). For lifetime
  // = now.
  const end: Date = (range === "custom" && opts.customEnd)
    ? new Date(istDayStart(new Date(opts.customEnd + "T00:00:00")).getTime() + 86_400_000)
    : now;

  // Current range: full rows (buckets + item/category mix need line items).
  const bills = await db.bill.findMany({
    where: { createdAt: { gte: start, lt: end } },
    select: {
      total: true,
      discount: true,
      itemCount: true,
      orderType: true,
      createdAt: true,
      items: { select: { name: true, category: true, qty: true, price: true } },
    },
    orderBy: { createdAt: "asc" },
  });

  // Previous period: cheap SQL aggregate — no rows pulled into Node.
  const prevAgg = await db.bill.aggregate({
    where: { createdAt: { gte: prevStart, lt: start } },
    _count: true,
    _sum: { total: true, discount: true, itemCount: true },
  });

  // Team + manually-entered costs. t119 kept ACTUAL settled payments; t129 —
  // salaries in every window are the ATTENDANCE-RECALCULATED accrual (user:
  // "keep updating this month, this week, today employee salary according to
  // the employee attendance" + "the recalculated paid salary should be
  // considered as the given business's employee salary"): each day pays its
  // day-wage when the register marks present (or a paid-holiday absence), so
  // the running month updates live — settled or not.
  const [emps, expAgg, salaryPaidCount, accrual] = await Promise.all([
    db.employee.findMany({ where: { active: true }, orderBy: { salary: "desc" } }),
    db.expense.groupBy({
      by: ["kind"],
      where: { spentOn: { gte: start } },
      _sum: { amount: true },
    }),
    db.salaryPayment.count({ where: { status: "paid", paidAt: { gte: start } } }),
    accrueSalaries(istDateKey(start), istDateKey(new Date())),
  ]);
  const monthlyTotal = round2(emps.reduce((s, e) => s + e.salary, 0));
  // RECALCULATED — attendance-derived salary money for the window.
  const salaries = accrual.total;
  // PROJECTED — the roster proration, kept as the comparison figure.
  const salaryProjected = round2((monthlyTotal / 30) * SALARY_DAYS[range]);
  const rawMaterials = round2(expAgg.find((e) => e.kind === "raw_material")?._sum.amount ?? 0);
  const upgrades = round2(expAgg.find((e) => e.kind === "upgrade")?._sum.amount ?? 0);
  const maintenance = round2(expAgg.find((e) => e.kind === "maintenance")?._sum.amount ?? 0);
  const prev = {
    revenue: prevAgg._sum.total ?? 0,
    bills: prevAgg._count,
    items: prevAgg._sum.itemCount ?? 0,
    discounts: prevAgg._sum.discount ?? 0,
  };

  const cur = { revenue: 0, bills: 0, items: 0, discounts: 0 };

  // t194 — dynamically choose the bucket size for custom + lifetime ranges
  // so the chart doesn't try to render thousands of daily data points (which
  // crashes the browser). < 60 days → daily, < 365 → weekly, else monthly.
  const bucket: "hour" | "day" | "week" | "month" =
    range === "custom" || range === "lifetime"
      ? windowDays <= 60 ? "day"
        : windowDays <= 365 ? "week"
        : "month"
      : meta.bucket;

  // buckets keyed by hour / date / week-start / month
  const bucketMap = new Map<string, { at: number; label: string; revenue: number; bills: number }>();
  const itemAgg = new Map<string, { name: string; qty: number; revenue: number }>();
  const catAgg = new Map<string, number>();
  // Hour-of-day accumulation across the WHOLE range — powers the permanent
  // "average day" hourly rhythm chart (avg = total per hour ÷ days in range).
  const hourly = Array.from({ length: 24 }, (_, h) => ({ h, revenue: 0, bills: 0 }));

  const bucketKeyOf = (d: Date): string => {
    if (bucket === "hour") return String(istHour(d));
    if (bucket === "day") return istDateKey(d);
    if (bucket === "week") return istDateKey(weekStartOf(d));
    return istDateKey(d).slice(0, 7); // month
  };
  const bucketLabelOf = (key: string): string => {
    if (bucket === "hour") return hourLabel(Number(key));
    if (bucket === "month") return monthKeyLabel(key);
    return dateKeyLabel(key);
  };
  // t235/t236 — campaign send markers per bucket (one dot per send)
  const campSends = await getCampaignBucketSends(start, bucket);

  for (const b of bills) {
    cur.revenue += b.total;
    cur.bills += 1;
    cur.items += b.itemCount;
    cur.discounts += b.discount;

    const key = bucketKeyOf(b.createdAt);
    const bk = bucketMap.get(key) ?? { at: 0, label: bucketLabelOf(key), revenue: 0, bills: 0 };
    bk.revenue += b.total;
    bk.bills += 1;
    bucketMap.set(key, bk);

    hourly[istHour(b.createdAt)].revenue += b.total;
    hourly[istHour(b.createdAt)].bills += 1;
    for (const it of b.items) {
      const it2 = itemAgg.get(it.name) ?? { name: it.name, qty: 0, revenue: 0 };
      it2.qty += it.qty;
      it2.revenue += it.qty * it.price;
      itemAgg.set(it.name, it2);
      catAgg.set(it.category, (catAgg.get(it.category) ?? 0) + it.qty * it.price);
    }
  }

  // ── Build full bucket series (fill gaps) ──
  const buckets: Bucket[] = [];
  if (bucket === "hour") {
    // show 7 AM → 11 PM (restaurant hours)
    for (let h = 7; h <= 23; h++) {
      const bk = bucketMap.get(String(h));
      buckets.push({ label: hourLabel(h), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0, camps: campSends.get(String(h))?.length ?? 0, sends: campSends.get(String(h)) ?? [] });
    }
  } else if (bucket === "day") {
    for (let i = windowDays - 1; i >= 0; i--) {
      const key = istDateKey(new Date(now.getTime() - i * 86400000));
      const bk = bucketMap.get(key);
      buckets.push({ label: dateKeyLabel(key), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0, camps: campSends.get(key)?.length ?? 0, sends: campSends.get(key) ?? [] });
    }
  } else if (bucket === "week") {
    const first = weekStartOf(start).getTime();
    const last = weekStartOf(now).getTime();
    for (let t = first; t <= last; t += 7 * 86400000) {
      const key = istDateKey(new Date(t));
      const bk = bucketMap.get(key);
      buckets.push({ label: dateKeyLabel(key), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0, camps: campSends.get(key)?.length ?? 0, sends: campSends.get(key) ?? [] });
    }
  } else {
    // month — t194: show up to 72 months back (was fixed at 12)
    const monthCount = Math.min(Math.ceil(windowDays / 30), 72);
    for (let m = monthCount - 1; m >= 0; m--) {
      const d = new Date(Date.UTC(istShift(now).getUTCFullYear(), istShift(now).getUTCMonth() - m, 1));
      const key = d.toISOString().slice(0, 7);
      const bk = bucketMap.get(key);
      buckets.push({ label: monthKeyLabel(key), revenue: round2(bk?.revenue ?? 0), bills: bk?.bills ?? 0, camps: campSends.get(key)?.length ?? 0, sends: campSends.get(key) ?? [] });
    }
  }

  // ── Peak ──
  let peakLabel: string | null = null;
  if (range === "today") {
    const peak = hourly.reduce((best, h) => (h.revenue > best.revenue ? h : best), hourly[0]);
    peakLabel = cur.revenue > 0 ? hourLabel(peak.h) : null;
  } else {
    const peak = buckets.reduce(
      (best, b) => (b.revenue > best.revenue ? b : best),
      buckets[0] ?? { label: "", revenue: 0, bills: 0 },
    );
    peakLabel = peak.revenue > 0 ? peak.label : null;
  }

  // ── Hourly rhythm: the AVERAGE day across this range (peak & bottom hours) ──
  const days = windowDays;
  const hourlySeries: Array<{ label: string; avg: number; bills: number }> = [];
  for (let h = 7; h <= 23; h++) {
    hourlySeries.push({
      label: hourLabel(h),
      avg: round2(hourly[h].revenue / days),
      bills: hourly[h].bills,
    });
  }
  const withSales = hourlySeries.filter((x) => x.avg > 0);
  const hourlyPeak =
    withSales.length > 0
      ? withSales.reduce((best, x) => (x.avg > best.avg ? x : best), withSales[0]).label
      : null;
  const hourlyQuiet =
    withSales.length > 1
      ? withSales.reduce((worst, x) => (x.avg < worst.avg ? x : worst), withSales[0]).label
      : null;

  const catTotal = [...catAgg.values()].reduce((s, v) => s + v, 0);
  // t221 — ORDER CHANNELS: bills/revenue/share per channel across the selected
  // window, straight off the range-scoped rows already in memory.
  const otAgg = new Map<string, { bills: number; revenue: number }>();
  for (const b of bills) {
    const e = otAgg.get(b.orderType) ?? { bills: 0, revenue: 0 };
    e.bills += 1;
    e.revenue += b.total;
    otAgg.set(b.orderType, e);
  }
  const otTotal = [...otAgg.values()].reduce((s, v) => s + v.revenue, 0);
  const pct = (a: number, b: number) => (b > 0 ? round2(((a - b) / b) * 100) : null);
  const profit = round2(cur.revenue - salaries - rawMaterials - upgrades - maintenance - cur.discounts);
  const marginPct = cur.revenue > 0 ? round2((profit / cur.revenue) * 100) : null;

  const recent = await db.bill.findMany({
    orderBy: { createdAt: "desc" },
    take: 10,
    include: { items: true },
  });
  const allTime = await db.bill.aggregate({ _count: true, _sum: { total: true } });

  const [books, lodge] = await Promise.all([getBookCosts(range, windowDays, accrual), getLodgeBlock(range, opts)]);
  // t132 — NET PROFIT now sits AFTER the discounts the receptions gave: the
  // breakdown shows the discount line, so the net must reflect it everywhere.
  books.rest.profit = round2(cur.revenue - books.rest.salaries - books.rest.rawMaterials - books.rest.upgrades - books.rest.maintenance - books.rest.discounts);
  books.lodge.profit = round2(lodge.revenue - books.lodge.salaries - books.lodge.rawMaterials - books.lodge.upgrades - books.lodge.maintenance - books.lodge.discounts);

  // t133 — the newest discounted restaurant bills (the discount history feed)
  const restDiscRows = await db.bill.findMany({
    where: { createdAt: { gte: istDayStart(new Date(now.getTime() - (windowDays - 1) * 86400000)) }, discount: { gt: 0 } },
    orderBy: { createdAt: "desc" },
    take: 12,
    select: { number: true, total: true, discount: true, createdAt: true },
  });

  return {
    generatedAt: now.toISOString(),
    range,
    books,
    lodge,
    // t133 — discount history: the newest bills that carried a discount,
    // per book (restaurant rows here, lodge rows ride on lodge.discountRows)
    discountLog: {
      rest: restDiscRows.map((b) => ({
        number: b.number,
        room: null,
        guestName: null,
        total: round2(b.total),
        discount: round2(b.discount),
        createdAt: b.createdAt.toISOString(),
      })),
      lodge: lodge.discountRows,
    },
    stats: {
      revenue: round2(cur.revenue),
      bills: cur.bills,
      items: cur.items,
      avgTicket: cur.bills ? round2(cur.revenue / cur.bills) : 0,
      discounts: round2(cur.discounts),
      revenueDeltaPct: pct(cur.revenue, prev.revenue),
      billDeltaPct: pct(cur.bills, prev.bills),
    },
    peakLabel,
    buckets,
    hourly: { series: hourlySeries, peak: hourlyPeak, quiet: hourlyQuiet, days },
    itemsSold: [...itemAgg.values()]
      .sort((a, b) => b.qty - a.qty)
      .map((d) => ({ ...d, revenue: round2(d.revenue) })),
    categoryMix: [...catAgg.entries()]
      .map(([category, revenue]) => ({
        category,
        revenue: round2(revenue),
        share: catTotal ? round2((revenue / catTotal) * 100) : 0,
      }))
      .sort((a, b) => b.revenue - a.revenue),
    // t221 — the four channels always listed, zeros included
    orderTypes: ORDER_TYPES.map((o) => {
      const e = otAgg.get(o.id);
      return {
        type: o.id,
        label: o.label,
        bills: e?.bills ?? 0,
        revenue: round2(e?.revenue ?? 0),
        share: otTotal && e ? round2((e.revenue / otTotal) * 100) : 0,
      };
    }),
    // t229 — the biggest spenders across both books (all-time, phone-keyed)
    topCustomers: await getTopCustomers(),
    // full receipt shape — dashboard reprint renders these straight into the
    // thermal sheet, so subtotal/discount/tax + per-item price MUST ride along
    recentBills: recent.map((b) => ({
      id: b.id,
      number: b.number,
      createdAt: b.createdAt,
      itemCount: b.itemCount,
      total: b.total,
      subtotal: round2(b.subtotal),
      discount: round2(b.discount),
      tax: round2(b.tax),
      items: b.items.map((it) => ({
        id: it.id,
        dishId: it.dishId,
        name: it.name,
        qty: it.qty,
        price: it.price,
      })),
    })),
    allTime: { bills: allTime._count, revenue: round2(allTime._sum.total ?? 0) },
    team: {
      employees: emps.map((e) => ({
        id: e.id,
        name: e.name,
        role: e.role,
        salary: round2(e.salary),
        book: e.book === "lodge" ? "lodge" : "rest",
      })),
      monthlyTotal,
      periodCost: salaries,
      projectedCost: salaryProjected,
      paidCount: salaryPaidCount,
    },
    costs: { salaries, rawMaterials, upgrades, maintenance, profit, marginPct },
  };
}
