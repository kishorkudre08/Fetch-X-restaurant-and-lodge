import { db } from "@/lib/db";

// ── t229 · CUSTOMER BASE (phone-keyed identities across BOTH books) ─────────
// One shared reader for the mass-message composer (both receptions) and the
// broadcasts API: every 10-digit phone that ever keyed a restaurant bill or a
// lodge stay, with its live loyalty wallet (earned − used, recomputed from the
// bill rows — the exact discipline of /api/loyalty). 60s TTL cache so the
// composer's audience toggles stay instant while the ledger grows.

export type CustomerRow = {
  phone: string;
  name: string | null;
  visits: number; // restaurant bills + lodge stays combined
  balance: number; // loyalty points (1 pt = ₹1)
  restSpend: number;
  lodgeSpend: number;
  totalSpend: number; // t230 — both books combined (the rank key)
  rank: number | null; // t230 — 1 = biggest spender across both books
  lastSeen: string | null; // ISO
};

const cache: { at: number; rows: CustomerRow[] } = { at: 0, rows: [] };
const TTL_MS = 60_000;

export function invalidateCustomers() {
  cache.at = 0;
}

export async function listCustomers(): Promise<CustomerRow[]> {
  if (cache.rows.length && Date.now() - cache.at < TTL_MS) return cache.rows;
  const [restRows, lodgeRows, restNames, lodgeNames] = await Promise.all([
    db.bill.groupBy({
      by: ["customerPhone"],
      where: { customerPhone: { not: null } },
      _count: { _all: true },
      _sum: { total: true, pointsEarned: true, pointsUsed: true, bonusPoints: true },
      _max: { createdAt: true },
    }),
    db.lodgeBill.groupBy({
      by: ["guestPhone"],
      _count: { _all: true },
      _sum: { total: true, pointsEarned: true, pointsUsed: true, bonusPoints: true },
      _max: { createdAt: true },
    }),
    // SQLite bare-column rule: bare customerName rides the MAX(createdAt) row —
    // the newest non-null name each phone has keyed.
    db.$queryRaw<Array<{ phone: string | null; name: string | null }>>
      `SELECT "customerPhone" AS phone, "customerName" AS name, MAX("createdAt") FROM "Bill" WHERE "customerName" IS NOT NULL AND "customerPhone" IS NOT NULL GROUP BY "customerPhone"`,
    db.$queryRaw<Array<{ phone: string; name: string }>>
      `SELECT "guestPhone" AS phone, "guestName" AS name, MAX("createdAt") FROM "LodgeBill" GROUP BY "guestPhone"`,
  ]);

  const nameOf = new Map<string, string>();
  for (const r of restNames) if (r.phone && r.name) nameOf.set(r.phone, r.name);
  for (const l of lodgeNames) if (!nameOf.has(l.phone) && l.name) nameOf.set(l.phone, l.name);

  const acc = new Map<string, CustomerRow & { last: Date | null }>();
  const touch = (phone: string) => {
    let row = acc.get(phone);
    if (!row) {
      row = { phone, name: null, visits: 0, balance: 0, restSpend: 0, lodgeSpend: 0, totalSpend: 0, rank: null, lastSeen: null, last: null };
      acc.set(phone, row);
    }
    return row;
  };
  for (const r of restRows) {
    if (!r.customerPhone) continue;
    const row = touch(r.customerPhone);
    row.visits += r._count._all;
    row.restSpend += r._sum.total ?? 0;
    row.balance += (r._sum.pointsEarned ?? 0) - (r._sum.pointsUsed ?? 0) + (r._sum.bonusPoints ?? 0);
    if (r._max.createdAt && (!row.last || r._max.createdAt > row.last)) row.last = r._max.createdAt;
  }
  for (const l of lodgeRows) {
    const row = touch(l.guestPhone);
    row.visits += l._count._all;
    row.lodgeSpend += l._sum.total ?? 0;
    row.balance += (l._sum.pointsEarned ?? 0) - (l._sum.pointsUsed ?? 0) + (l._sum.bonusPoints ?? 0);
    if (l._max.createdAt && (!row.last || l._max.createdAt > row.last)) row.last = l._max.createdAt;
  }
  const rows: CustomerRow[] = [...acc.values()]
    .map((r) => ({
      phone: r.phone,
      name: r.name ?? nameOf.get(r.phone) ?? null,
      visits: r.visits,
      balance: Math.round(r.balance),
      restSpend: Math.round(r.restSpend),
      lodgeSpend: Math.round(r.lodgeSpend),
      totalSpend: Math.round(r.restSpend + r.lodgeSpend),
      rank: null,
      lastSeen: r.last ? r.last.toISOString() : null,
    }))
    // t230 — rank is by ALL-TIME SPEND across both books (1 = biggest wallet
    // of money spent, the owner's tier key), ties broken by visits.
    .sort((a, b) => b.totalSpend - a.totalSpend || b.visits - a.visits)
    .map((r, i) => ({ ...r, rank: i + 1 }))
    // the composer lists wallets by balance — restore that order for it
    .sort((a, b) => b.balance - a.balance || b.visits - a.visits);
  cache.at = Date.now();
  cache.rows = rows;
  return rows;
}

/** t230 — a phone's all-time SPEND RANK (1-based), null when unknown/unranked. */
export async function rankOfPhone(phone: string): Promise<number | null> {
  const rows = await listCustomers();
  return rows.find((r) => r.phone === phone)?.rank ?? null;
}

/** The audience filters the composer offers — preset minimum balances + custom. */
export function filterByAudience(
  rows: CustomerRow[],
  audience: string,
  threshold: number,
): CustomerRow[] {
  const min =
    audience === "pts_500" ? 500
    : audience === "pts_1000" ? 1000
    : audience === "pts_3000" ? 3000
    : audience === "custom" ? Math.max(0, Math.round(threshold || 0))
    : 0; // "all"
  return min > 0 ? rows.filter((r) => r.balance >= min) : rows;
}

/** Render the personalised template for one customer ({NAME}/{POINTS}). */
export function renderTemplate(tpl: string, row: CustomerRow): string {
  return tpl
    .replaceAll("{NAME}", row.name ?? "Guest")
    .replaceAll("{POINTS}", String(Math.max(0, row.balance)));
}
