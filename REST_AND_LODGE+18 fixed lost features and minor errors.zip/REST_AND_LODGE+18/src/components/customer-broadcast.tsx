"use client";

/**
 * t229 — CUSTOMER MESSAGES · MASS SEND — the receptions' outreach desk.
 * t230 — ONE BOX, TWO MODES: the counter writes a single message. The moment
 * it carries a {PLACEHOLDER} it files itself as a PERSONAL message (rendered
 * per customer with their name and live points); without placeholders it
 * files as a plain NOTICE — the word-for-word advertisement blast. The
 * audience filter (ALL · 500+ · 1000+ · 3000+ · CUSTOM) picks WHO receives
 * it; SEND logs the campaign server-side (the server re-counts the wallets
 * itself) — no SMS gateway in this build, the log row IS the send.
 * t232 — `senderLabel` ("MANAGER") overrides the derived sent-by on the log
 * row when the manager fires the campaign from the manager account.
 * t233 — NO BUSINESS TOGGLE: pass NO `book` and the desk turns FRANCHISE —
 * one customer book for the whole property (points are universal across the
 * restaurant and the lodge), sends stamped book "franchise" under MANAGER.
 * t233 — RECENT SENDS is its own collapsible card now (the recent-bills
 * pattern: the header row is the toggle, chevron flips, state persists via
 * useCachedToggle, the log unfolds beneath).
 * t236 — CAMPAIGN MEDIA: the sender can attach up to 4 photos/videos (≤ 12 MB
 * each) to a campaign. Files upload to /api/uploads (stored under
 * uploads/broadcasts/, streamed by /api/media/[name]) and ride the send —
 * they show as thumbnails/inline players in RECENT SENDS and on the owner's
 * Mass Messages log rows.
 */

import * as React from "react";
import { ChevronDown, Film, Megaphone, MessageSquare, Paperclip, Send, Users, WandSparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useHotel } from "@/components/hotel-context";
import { useCachedToggle } from "@/lib/view-state-cache";
import type { BroadcastAttachment } from "@/lib/types";
import type { CustomerRow } from "@/lib/customers";

type AudienceId = "all" | "pts_500" | "pts_1000" | "pts_3000" | "custom";

const AUDIENCES: Array<{ id: AudienceId; label: string }> = [
  { id: "all", label: "ALL" },
  { id: "pts_500", label: "500+ PTS" },
  { id: "pts_1000", label: "1000+ PTS" },
  { id: "pts_3000", label: "3000+ PTS" },
  { id: "custom", label: "CUSTOM" },
];

type BroadcastRow = {
  id: string;
  audience: string;
  threshold: number | null;
  recipients: number;
  message: string;
  notice: string;
  sample: string;
  book: string;
  sentBy: string;
  attachments: BroadcastAttachment[]; // t236 — campaign media
  createdAt: string;
};

const DEFAULT_MSG =
  "Hello {NAME}, you have {POINTS} loyalty points waiting at the hotel — 1 pt = ₹1 off your next bill or stay. See you soon!";

const audienceLabel = (a: string): string =>
  AUDIENCES.find((x) => x.id === a)?.label ?? a.toUpperCase();

/** t230 — any {TOKEN} in the text → personal message; none → plain notice. */
const isPersonalText = (t: string): boolean => /\{[^{}]{1,24}\}/.test(t);

export function CustomerBroadcast({ book, senderLabel }: { book?: "rest" | "lodge"; senderLabel?: "MANAGER" }) {
  const { toast } = useToast();
  const { hotelName } = useHotel();
  // t233 — franchise mode when no book is passed (the manager account):
  // one franchise, both desks, universal points — no business stamp.
  const franchise = !book;
  // t233 — RECENT SENDS collapsed by default, like the recent-bills blocks
  const [logOpen, setLogOpen] = useCachedToggle<boolean>("campaign", "logOpen", false);

  const [rows, setRows] = React.useState<CustomerRow[] | null>(null);
  const [audience, setAudience] = React.useState<AudienceId>("all");
  const [threshold, setThreshold] = React.useState("750");
  const [text, setText] = React.useState(DEFAULT_MSG);
  const [sending, setSending] = React.useState(false);
  const [history, setHistory] = React.useState<BroadcastRow[]>([]);
  // t236 — campaign media: the photos/videos riding this send
  const MAX_FILES = 4;
  const MAX_MB = 12;
  const [files, setFiles] = React.useState<Array<{ file: File; preview: string | null }>>([]);
  const fileRef = React.useRef<HTMLInputElement | null>(null);

  const loadCustomers = React.useCallback(() => {
    fetch("/api/customers", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setRows(Array.isArray(d.customers) ? d.customers : []))
      .catch(() => setRows([]));
  }, []);

  const loadHistory = React.useCallback(() => {
    fetch("/api/broadcasts", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setHistory(Array.isArray(d.broadcasts) ? d.broadcasts : []))
      .catch(() => setHistory([]));
  }, []);

  React.useEffect(() => {
    loadCustomers();
    loadHistory();
  }, [loadCustomers, loadHistory]);

  const minPts =
    audience === "pts_500" ? 500
    : audience === "pts_1000" ? 1000
    : audience === "pts_3000" ? 3000
    : audience === "custom" ? Math.max(0, Math.round(Number(threshold) || 0))
    : 0;
  const recipients = React.useMemo(
    () => (rows ?? []).filter((r) => (minPts > 0 ? r.balance >= minPts : true)),
    [rows, minPts],
  );

  const personal = isPersonalText(text);
  const insert = (ph: string) =>
    setText((m) => (m.includes(ph) ? m : `${m}${m.endsWith(" ") || m === "" ? "" : " "}${ph}`));

  // t236 — pick campaign media (images/videos only, ≤ 12 MB, ≤ 4 per send)
  const onPick = (list: FileList | null) => {
    if (!list || list.length === 0) return;
    setFiles((cur) => {
      const next = [...cur];
      for (const f of Array.from(list)) {
        if (next.length >= MAX_FILES) break;
        if (!(f.type.startsWith("image/") || f.type.startsWith("video/"))) continue;
        if (f.size > MAX_MB * 1024 * 1024) continue;
        next.push({ file: f, preview: f.type.startsWith("image/") ? URL.createObjectURL(f) : null });
      }
      return next;
    });
  };
  const removeAt = (i: number) =>
    setFiles((cur) => {
      const gone = cur[i];
      if (gone?.preview) URL.revokeObjectURL(gone.preview);
      return cur.filter((_, j) => j !== i);
    });
  const clearFiles = () => {
    for (const f of files) if (f.preview) URL.revokeObjectURL(f.preview);
    setFiles([]);
  };

  const send = async () => {
    if (!text.trim()) {
      toast({ title: "Nothing to send", description: "Write the message first." });
      return;
    }
    setSending(true);
    try {
      // t236 — upload the campaign media first, then ride the metas on the send
      const attachments: BroadcastAttachment[] = [];
      for (const f of files) {
        const fd = new FormData();
        fd.append("file", f.file);
        const up = await fetch("/api/uploads", { method: "POST", body: fd });
        const ud = await up.json();
        if (!up.ok) throw new Error(ud.error ?? "Upload failed");
        const m = (ud.files ?? [ud.file])[0];
        attachments.push({ url: m.url, kind: m.kind, name: m.name });
      }
      const res = await fetch("/api/broadcasts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ audience, threshold: minPts, text, book: book ?? "franchise", attachments, ...(senderLabel ? { sentBy: senderLabel } : {}) }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error ?? "Send failed");
      toast({
        title: `Sent to ${recipients.length} ${recipients.length === 1 ? "customer" : "customers"}`,
        description: `${personal ? "PERSONAL MESSAGE" : "NOTICE"} · ${audienceLabel(audience)} · ${senderLabel ? "MANAGER · one franchise — points universal" : `${book === "lodge" ? "Lodge" : "Restaurant"} desk`}${attachments.length ? ` · ${attachments.length} ${attachments.length === 1 ? "file" : "files"} attached` : ""} · logged in the send history.`,
      });
      clearFiles();
      loadHistory();
    } catch (e) {
      toast({ title: "Could not send", description: e instanceof Error ? e.message : "Try again." });
    } finally {
      setSending(false);
    }
  };

  const preview = recipients.slice(0, 3);
  const renderOne = (r: CustomerRow, tpl: string) =>
    tpl.replaceAll("{NAME}", r.name ?? "Guest").replaceAll("{POINTS}", String(Math.max(0, r.balance)));

  return (
    <>
    <div className="fx-card fx-rise p-5" data-fx-motion="1" data-testid={`bc-section-${book ?? "franchise"}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          {book === "lodge" ? <Megaphone className="h-3.5 w-3.5" /> : <MessageSquare className="h-3.5 w-3.5" />}
          CAMPAIGNING · MASS MESSAGE
        </span>
        <span className="flex flex-wrap items-center gap-1.5">
          <span className="mut-chip">SAVED IDENTITIES ONLY · 10-DIGIT PHONE</span>
          {/* t233 — no desk chip in franchise mode: one customer book, universal points */}
          <span className="mut-chip" data-testid="bc-desk-chip">
            {franchise ? "ONE FRANCHISE · POINTS UNIVERSAL" : book === "lodge" ? "LODGE DESK" : "RESTAURANT DESK"}
          </span>
        </span>
      </div>
      <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
        {franchise
          ? "One box, two kinds of send — and one audience: every saved wallet of the franchise, restaurant and lodge alike, because the points wallet is the same book for both businesses. Include "
          : "One box, two kinds of send — write a single message and the placeholders decide. Include "}
        {" "}{`{NAME}`} / {`{POINTS}`}{" "}and every customer gets their own copy with their name and live loyalty
        points; leave them out and the same words broadcast to everyone as a notice.
      </p>

      {/* audience filter */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="fx-label inline-flex items-center gap-1.5">
          <Users className="h-3.5 w-3.5" /> AUDIENCE · LOYALTY POINTS
        </span>
        <span className="scope-spacer" />
        <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Audience filter">
          {AUDIENCES.map((a) => (
            <button
              key={a.id}
              onClick={() => setAudience(a.id)}
              aria-pressed={audience === a.id}
              className={`scope-chip${audience === a.id ? " on" : ""}`}
              data-testid={`bc-aud-${a.id}`}
            >
              {a.label}
            </button>
          ))}
        </div>
        {audience === "custom" && (
          <span className="flex items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-2.5 py-1.5">
            <span className="fx-label whitespace-nowrap">MIN POINTS</span>
            <Input
              value={threshold}
              onChange={(e) => setThreshold(e.target.value.replace(/[^0-9]/g, ""))}
              inputMode="numeric"
              className="fx-num h-7 w-[92px] rounded-lg font-bold"
              aria-label="Custom minimum points"
              data-testid="bc-threshold"
            />
          </span>
        )}
      </div>

      {/* recipient counter + preview */}
      <div className="mt-3 rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/60 px-4 py-3" data-testid="bc-recipients">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-[12.5px] font-extrabold text-[var(--fx-ink)]">
            {rows === null ? "COUNTING WALLETS…" : `${recipients.length} OF ${(rows ?? []).length} CUSTOMERS WILL RECEIVE THIS`}
          </span>
          {minPts > 0 && <span className="mut-chip">BALANCE ≥ {minPts} PTS</span>}
        </div>
        {preview.length > 0 && text.trim() && personal && (
          <div className="mt-2 space-y-1.5" data-testid="bc-preview">
            {preview.map((r) => (
              <div key={r.phone} className="truncate text-[11px] font-semibold text-[var(--fx-muted)]">
                <b className="text-[var(--fx-accent-ink)]">{r.name ?? "Guest"}</b> · {r.phone} → “{renderOne(r, text).slice(0, 110)}{renderOne(r, text).length > 110 ? "…" : ""}”
              </div>
            ))}
          </div>
        )}
        {preview.length > 0 && text.trim() && !personal && (
          <div className="mt-2 truncate text-[11px] font-semibold text-[var(--fx-muted)]" data-testid="bc-preview">
            NOTICE → “{text.slice(0, 130)}{text.length > 130 ? "…" : ""}”
          </div>
        )}
      </div>

      {/* t230 — THE ONE BOX: placeholders decide the mode */}
      <div className="mt-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label">MESSAGE · ONE BOX FOR BOTH KINDS</span>
          <span
            className={`rounded-full px-2.5 py-1 text-[9px] font-extrabold tracking-[0.08em] ${
              personal
                ? "bg-[color-mix(in_srgb,var(--fx-green)_14%,transparent)] text-[var(--fx-green)]"
                : "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
            }`}
            data-testid="bc-mode"
          >
            <WandSparkles className="mr-1 inline h-3 w-3" />
            {personal ? "SENDS AS PERSONAL MESSAGE · FILLED PER CUSTOMER" : "SENDS AS NOTICE · SAME WORDS TO EVERYONE"}
          </span>
        </div>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
          className="mt-2 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] text-[12.5px] font-semibold"
          placeholder={`Hello {NAME}, you have {POINTS} points waiting at ${hotelName}…  — or, with no placeholders, a festival offer that reaches everyone word-for-word.`}
          data-testid="bc-msg"
        />
        <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1.5">
          <p className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
            {`{NAME}`} prints the customer's saved name; {`{POINTS}`} prints their live loyalty balance (1 pt = ₹1). Rows without a saved name read “Guest”.
          </p>
          <span className="flex items-center gap-1.5">
            <button onClick={() => insert("{NAME}")} className="mut-chip cursor-pointer" data-testid="bc-ins-name">+ {"{NAME}"}</button>
            <button onClick={() => insert("{POINTS}")} className="mut-chip cursor-pointer" data-testid="bc-ins-points">+ {"{POINTS}"}</button>
          </span>
        </div>
      </div>

      {/* t236 — CAMPAIGN MEDIA: attach up to 4 photos/videos to the send.
          Files upload at send time (/api/uploads → uploads/broadcasts/) and
          ride the log everywhere — recent sends + the owner's Mass Messages. */}
      <div className="mt-3 flex flex-wrap items-center gap-2" data-testid="bc-attach-row">
        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/*"
          multiple
          className="hidden"
          onChange={(e) => {
            onPick(e.target.files);
            e.target.value = "";
          }}
          data-testid="bc-attach-input"
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="mut-chip inline-flex cursor-pointer items-center gap-1.5"
          data-testid="bc-attach-btn"
        >
          <Paperclip className="h-3 w-3" /> ATTACH PHOTOS / VIDEOS
        </button>
        {files.map((f, i) => (
          <span key={i} className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] py-1 pl-1 pr-2" data-testid="bc-att-chip">
            {f.preview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={f.preview} alt={f.file.name} className="h-8 w-11 rounded-lg object-cover" />
            ) : (
              <span className="grid h-8 w-11 place-items-center rounded-lg bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
                <Film className="h-3.5 w-3.5" />
              </span>
            )}
            <span className="max-w-[130px] truncate text-[10px] font-extrabold text-[var(--fx-muted)]">{f.file.name}</span>
            <button type="button" onClick={() => removeAt(i)} aria-label={`Remove ${f.file.name}`} className="cursor-pointer text-[var(--fx-muted)] hover:text-[var(--fx-ink)]" data-testid="bc-att-remove">
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}
        {files.length > 0 && <span className="mut-chip">{files.length}/{MAX_FILES} · ≤ {MAX_MB} MB EACH</span>}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <Button
          onClick={() => void send()}
          disabled={sending || rows === null || recipients.length === 0}
          className="h-10 rounded-xl bg-[var(--fx-purple)] px-5 text-[12px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          data-testid="bc-send"
        >
          <Send className="mr-1.5 h-3.5 w-3.5" />
          {sending ? "SENDING…" : `SEND TO ${recipients.length} ${recipients.length === 1 ? "CUSTOMER" : "CUSTOMERS"}`}
        </Button>
        <span className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
          The send lands in the RECENT SENDS log below — audience, reach, the exact words that went out and the photos/videos attached.
        </span>
      </div>
    </div>

    {/* ── t233 — RECENT SENDS · its own collapsible card (the recent-bills
          pattern from the POS: the header row is the toggle, the chevron
          flips, the state persists via useCachedToggle, the log unfolds
          beneath). One franchise log — the receptions' and the manager's
          sends all land here. ── */}
    <div className="fx-card fx-rise p-5" data-fx-motion="1" data-testid="bc-recent-sends">
      <button
        onClick={() => setLogOpen((o) => !o)}
        aria-expanded={logOpen}
        data-testid="bc-recent-sends-toggle"
        className="flex w-full flex-wrap items-center justify-between gap-2 text-left"
      >
        <span className="fx-label flex items-center gap-2">
          <Megaphone className="h-3.5 w-3.5" /> RECENT SENDS
        </span>
        <span className="flex items-center gap-2">
          <span className="mut-chip">LAST {history.length}{franchise ? " · ONE FRANCHISE LOG" : " SENDS"}</span>
          <ChevronDown
            aria-hidden
            className={`h-4 w-4 text-[var(--fx-muted)] transition-transform ${logOpen ? "" : "-rotate-90"}`}
          />
        </span>
      </button>
      {logOpen && (
        <div className="mt-3 space-y-2" data-testid="bc-history">
          {history.length === 0 && (
            <p className="rounded-xl border border-dashed border-[var(--fx-line)] px-4 py-3 text-[11.5px] font-semibold text-[var(--fx-muted)]">
              Nothing sent yet — the first campaign lands here.
            </p>
          )}
          {history.map((h) => {
            const hPersonal = !!h.message.trim();
            return (
              <div key={h.id} className="feed-row" data-testid="bc-history-row">
                <span className="f-av">{hPersonal ? <MessageSquare className="h-3.5 w-3.5" /> : <Megaphone className="h-3.5 w-3.5" />}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[12px] font-extrabold text-[var(--fx-ink)]">{h.sentBy}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[8.5px] font-extrabold tracking-wider ${hPersonal ? "bg-[color-mix(in_srgb,var(--fx-green)_14%,transparent)] text-[var(--fx-green)]" : "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"}`}>
                      {hPersonal ? "PERSONAL" : "NOTICE"}
                    </span>
                    <span className="mut-chip">{audienceLabel(h.audience)}{h.audience === "custom" && h.threshold ? ` · ≥ ${h.threshold}` : ""}</span>
                    <span className="mut-chip">{h.recipients} RECIPIENTS</span>
                    <span className="text-[10px] font-bold text-[var(--fx-muted)]">
                      {new Date(h.createdAt).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}
                    </span>
                  </div>
                  <p className="mt-0.5 truncate text-[11px] font-semibold text-[var(--fx-muted)]">
                    {h.message ? h.sample || h.message : h.notice}
                  </p>
                  {/* t236 — the campaign's own media: photos as thumbs, videos inline */}
                  {(h.attachments?.length ?? 0) > 0 && (
                    <div className="mt-1.5 flex flex-wrap items-center gap-2" data-testid="bc-row-atts">
                      {h.attachments.map((a, i) =>
                        a.kind === "video" ? (
                          <video key={i} src={a.url} controls preload="metadata" className="h-20 w-32 rounded-lg border border-[var(--fx-line)] bg-black object-cover" data-testid="bc-att-video" />
                        ) : (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img key={i} src={a.url} alt={a.name} className="h-16 w-24 rounded-lg border border-[var(--fx-line)] object-cover" data-testid="bc-att-img" />
                        ),
                      )}
                      <span className="mut-chip">{h.attachments.length} {h.attachments.length === 1 ? "FILE" : "FILES"} · WITH THE SEND</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
    </>
  );
}
