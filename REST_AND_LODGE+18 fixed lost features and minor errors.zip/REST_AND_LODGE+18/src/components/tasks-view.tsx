"use client";

// ── t97 · TASKS — the owner forwards work to the lodge or restaurant ───────
// The owner creates a task (title, book, deadline, optional max budget —
// budgeted tasks must name their expense type and describe the spend), the
// receptions see only their own book's tasks, post progress updates, and
// close them with the money it cost — never above the owner's assumption.
// Every rupee spent auto-registers in that book's expense ledger wearing the
// owner's crown, and the same data feeds the budget/completion graphs.

import * as React from "react";
import {
  BedDouble,
  Carrot,
  CheckCheck,
  ChevronDown,
  Crown,
  IndianRupee,
  ListChecks,
  Loader2,
  Plus,
  Send,
  Sparkles,
  Timer,
  Trash2,
  TriangleAlert,
  UtensilsCrossed,
  Wrench,
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FxDatePicker, TierBand } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { inr } from "@/lib/format";
import type { RangeKey, FxTask } from "@/lib/types";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";

type Book = "rest" | "lodge";
type Kind = "raw_material" | "upgrade" | "maintenance";

const BUDGET_CHIPS = [500, 1000, 2000, 5000];
const BOOK_LABEL: Record<Book, string> = { rest: "RESTAURANT", lodge: "LODGE" };
const KIND_LABEL: Record<Kind, string> = {
  raw_material: "RAW MATERIAL",
  upgrade: "UPGRADES",
  maintenance: "MAINTENANCE",
};
const KIND_ICON: Record<Kind, React.ReactNode> = {
  raw_material: <Carrot className="h-3.5 w-3.5" />,
  upgrade: <Sparkles className="h-3.5 w-3.5" />,
  maintenance: <Wrench className="h-3.5 w-3.5" />,
};
/* t99 — all three expense types everywhere: teal / violet / amber */
const KIND_ON: Record<Kind, string> = {
  raw_material: "bg-[#0d9488] text-white shadow-[2px_2px_0_0_var(--fx-hard)]",
  upgrade: "bg-[#7c3aed] text-white shadow-[2px_2px_0_0_var(--fx-hard)]",
  maintenance: "bg-[var(--fx-amber)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]",
};
function KindChips({
  kind,
  onPick,
  testPrefix,
}: {
  kind: Kind | null;
  onPick: (k: Kind) => void;
  testPrefix: string;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {(Object.keys(KIND_LABEL) as Kind[]).map((k) => (
        <button
          key={k}
          type="button"
          onClick={() => onPick(k)}
          aria-pressed={kind === k}
          data-testid={`${testPrefix}-${k}`}
          className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
            kind === k ? KIND_ON[k] : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
          }`}
        >
          {KIND_ICON[k]} {KIND_LABEL[k]}
        </button>
      ))}
    </div>
  );
}

/* t98/t167 — the board's own time window (mirrors the dashboard's tabs).
   t167 — "LATE" is a SEPARATE tab: when active, shows ONLY overdue tasks so
   they never flood today/7d/1m/3m/1y. (t208 — restored after the brief t206
   removal, by user request: "bring back the late toggle".) */
type TaskRangeKey = RangeKey | "late" | "custom";
const RANGE_TABS: Array<{ key: TaskRangeKey; short: string; days: number }> = [
  { key: "today", short: "TODAY", days: 1 },
  { key: "7d", short: "7 DAYS", days: 7 },
  { key: "1m", short: "1 MONTH", days: 30 },
  { key: "3m", short: "3 MONTHS", days: 91 },
  { key: "1y", short: "1 YEAR", days: 365 },
  { key: "late", short: "LATE", days: 0 },
  // t193 — custom range (read from Settings). days is a placeholder; the
  // actual window is built from customStart + customEnd when fRange=custom.
  { key: "custom", short: "CUSTOM", days: 30 },
];
const rangeSince = (days: number) => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return new Date(d.getTime() - (days - 1) * 86_400_000);
};

const istDay = (iso: string) =>
  new Date(iso).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata", day: "2-digit", month: "2-digit", year: "numeric" });
const istStamp = (iso: string) =>
  new Date(iso).toLocaleString("en-GB", { timeZone: "Asia/Kolkata", day: "2-digit", month: "2-digit", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
const isOverdue = (t: FxTask) => t.status === "open" && new Date(t.deadline).getTime() + 86_400_000 < Date.now();

/* ── ADD TASK — the owner's forwarding form ──────────────────────────────── */
function AddTaskModal({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const { toast } = useToast();
  const [book, setBook] = React.useState<Book>("rest");
  const [title, setTitle] = React.useState("");
  const [budget, setBudget] = React.useState(""); // "" = free task
  const [kind, setKind] = React.useState<Kind | null>(null);
  const [description, setDescription] = React.useState("");
  const [deadline, setDeadline] = React.useState(
    new Date(Date.now() + 7 * 86_400_000).toISOString().slice(0, 10),
  );
  const [err, setErr] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);

  const budgeted = budget.trim() !== "" && Number(budget) > 0;

  const reset = () => {
    setBook("rest");
    setTitle("");
    setBudget("");
    setKind(null);
    setDescription("");
    setDeadline(new Date(Date.now() + 7 * 86_400_000).toISOString().slice(0, 10));
    setErr(null);
  };

  const submit = async () => {
    setErr(null);
    if (title.trim().length < 2) return setErr("Give the task a short title.");
    if (budgeted) {
      if (!kind) return setErr("Pick the expense type — a budgeted task books its spend in the cost ledger.");
      if (description.trim().length < 3) return setErr("Describe what the budget covers — budgeted tasks need a description.");
    }
    setBusy(true);
    try {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          book,
          deadline,
          maxBudget: budgeted ? Number(budget) : null,
          kind: budgeted ? kind : kind, // allowed on free tasks too — the ledger still needs a type
          description: description.trim(),
        }),
      });
      const out = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(out.error ?? "Could not create the task");
      toast({
        title: "Task forwarded",
        description: `“${title.trim()}” is now on the ${BOOK_LABEL[book]} reception's desk${budgeted ? ` with a max budget of ${inr(Number(budget))}` : " as a free task"}.`,
      });
      reset();
      onClose();
      onCreated();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not create the task");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent className="fx-pop-in max-h-[92vh] max-w-[560px] overflow-y-auto" data-testid="task-add-modal">
        <DialogHeader>
          <DialogTitle className="text-[17px] font-extrabold tracking-tight">Forward a task</DialogTitle>
          <DialogDescription>
            Pick the book it goes to, set a deadline, and attach a max budget — or leave it free.
          </DialogDescription>
        </DialogHeader>

        {/* forwarded to */}
        <div>
          <span className="fx-label">FORWARDED TO · PICK THE BOOK</span>
          <div className="mt-2 grid grid-cols-2 gap-2.5">
            {([
              ["rest", <UtensilsCrossed className="h-4 w-4" key="r" />, "RESTAURANT", "FOOD & BEV desk"],
              ["lodge", <BedDouble className="h-4 w-4" key="l" />, "LODGE", "ROOMS & STAYS desk"],
            ] as const).map(([b, icon, label, sub]) => (
              <button
                key={b}
                type="button"
                onClick={() => setBook(b)}
                aria-pressed={book === b}
                data-testid={`task-book-${b}`}
                className={`rounded-2xl border px-3.5 py-3 text-left transition ${
                  book === b
                    ? b === "lodge"
                      ? "border-[var(--fx-gold)] bg-[color-mix(in_srgb,var(--fx-gold)_12%,transparent)]"
                      : "border-[var(--fx-accent-ink)] bg-[var(--fx-lav)]"
                    : "border-[var(--fx-line)] bg-[var(--fx-page)] hover:border-[var(--fx-muted)]"
                }`}
              >
                <span className="flex items-center gap-2 text-[12.5px] font-extrabold text-[var(--fx-ink)]">
                  {icon} {label}
                </span>
                <span className="mt-0.5 block text-[10px] font-bold tracking-[0.08em] text-[var(--fx-muted)]">{sub}</span>
              </button>
            ))}
          </div>
        </div>

        {/* title */}
        <div>
          <span className="fx-label">WHAT IS THE TASK?</span>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Deep-clean the kitchen exhaust · repaint room 12"
            aria-label="Task title"
            data-testid="task-title-input"
            className="mt-1.5 h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
          />
        </div>

        {/* budget */}
        <div>
          <span className="fx-label">MAXIMUM BUDGET · OPTIONAL</span>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {BUDGET_CHIPS.map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => setBudget(String(v))}
                aria-pressed={budget === String(v)}
                className={`fx-num rounded-full px-3.5 py-1.5 text-[11px] font-extrabold transition ${
                  budget === String(v)
                    ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                ₹{v.toLocaleString("en-IN")}
              </button>
            ))}
            <div className="relative">
              <IndianRupee className="pointer-events-none absolute left-2.5 top-1/2 h-3 w-3 -translate-y-1/2 text-[var(--fx-muted)]" />
              <Input
                value={budget}
                onChange={(e) => setBudget(e.target.value.replace(/[^\d]/g, ""))}
                placeholder="custom"
                type="number"
                min={0}
                aria-label="Custom maximum budget in rupees"
                data-testid="task-budget-input"
                className="fx-num h-8 w-[110px] rounded-full border-[var(--fx-line)] bg-[var(--fx-page)] pl-7 text-[11.5px] font-bold"
              />
            </div>
            <span
              data-testid="task-budget-flag"
              className={`rounded-full px-3 py-1.5 text-[9px] font-extrabold tracking-[0.1em] ${
                budgeted
                  ? "bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]"
                  : "bg-[color-mix(in_srgb,var(--fx-green)_12%,transparent)] text-[var(--fx-green)]"
              }`}
            >
              {budgeted ? `BUDGETED · ₹${Number(budget).toLocaleString("en-IN")} MAX` : "FREE TASK · NO BUDGET"}
            </span>
          </div>
        </div>

        {/* expense type */}
        <div>
          <span className="fx-label">
            EXPENSE TYPE {budgeted ? <b className="text-[var(--fx-rose)]">· REQUIRED</b> : "· OPTIONAL"}
          </span>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <KindChips kind={kind} onPick={setKind} testPrefix="task-kind" />
            <span className="text-[9.5px] font-bold tracking-[0.06em] text-[var(--fx-muted)]">
              THE SPEND REGISTERS IN THIS BOOK'S COST LEDGER WEARING YOUR CROWN
            </span>
          </div>
        </div>

        {/* deadline */}
        <div>
          <span className="fx-label">DEADLINE</span>
          <div className="mt-1.5">
            <FxDatePicker value={deadline} onChange={setDeadline} disableFuture={false} ariaLabel="Task deadline" />
          </div>
        </div>

        {/* description */}
        <div>
          <span className="fx-label">
            DESCRIPTION {budgeted ? <b className="text-[var(--fx-rose)]">· DESCRIBE WHAT THE BUDGET COVERS</b> : "· OPTIONAL"}
          </span>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What exactly should the desk do — and if money is attached, what is it for?"
            aria-label="Task description"
            data-testid="task-desc-input"
            rows={3}
            className="mt-1.5 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] text-[12.5px] font-semibold"
          />
        </div>

        {err && (
          <div role="alert" className="rounded-[9px] border border-[rgba(220,38,38,.3)] bg-[rgba(220,38,38,.08)] px-3 py-2 text-[11.5px] font-bold text-[#dc2626]" data-testid="task-form-err">
            {err}
          </div>
        )}

        <div className="flex items-center justify-end gap-2">
          <Button variant="ghost" onClick={onClose} className="rounded-xl text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)]">
            CANCEL
          </Button>
          <Button
            onClick={() => void submit()}
            disabled={busy}
            data-testid="task-submit"
            className="rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} FORWARD TASK
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ── CLOSE TASK — the reception's completion form ────────────────────────── */
function DoneModal({
  task,
  onClose,
  onDone,
}: {
  task: FxTask;
  onClose: () => void;
  onDone: () => void;
}) {
  const { toast } = useToast();
  const [cost, setCost] = React.useState("");
  const [kind, setKind] = React.useState<Kind | null>(task.kind);
  const [err, setErr] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);

  const n = Number(cost);
  const costNum = cost.trim() === "" || !Number.isFinite(n) ? null : n;
  const over = task.maxBudget !== null && costNum !== null && costNum > task.maxBudget;
  const under = task.maxBudget !== null && costNum !== null && costNum <= task.maxBudget;
  const needKind = costNum !== null && costNum > 0 && !kind;

  const submit = async () => {
    setErr(null);
    if (over) return;
    if (costNum === null || costNum < 0) return setErr("Enter what the task cost — 0 if nothing was spent.");
    if (needKind) return setErr("Pick the expense type — this spend books into the cost ledger.");
    setBusy(true);
    try {
      const res = await fetch("/api/tasks", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: task.id, action: "done", cost: costNum, kind: task.kind ?? kind }),
      });
      const out = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(out.error ?? "Could not close the task");
      toast({
        title: "Task closed",
        description:
          costNum > 0
            ? `${inr(costNum)} of ${task.maxBudget !== null ? `${inr(task.maxBudget)} budgeted` : "a free task"} — booked in the ${BOOK_LABEL[task.book]} ledger with the owner's crown.`
            : "Closed with nothing spent — the owner sees it on the board.",
      });
      onDone();
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not close the task");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent className="fx-pop-in max-w-[460px]" data-testid="task-done-modal">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight">Close “{task.title}”</DialogTitle>
          <DialogDescription>Fill the money it cost — the owner compares it against their assumption.</DialogDescription>
        </DialogHeader>

        {/* the owner's assumption */}
        <div className="rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-3" data-testid="task-done-assumption">
          <span className="fx-label inline-flex items-center gap-1.5">
            <Crown className="h-3 w-3 text-[var(--fx-gold)]" /> OWNER'S ASSUMPTION
          </span>
          <div className="mt-1 flex items-baseline gap-2">
            {task.maxBudget !== null ? (
              <>
                <b className="fx-num text-[22px] font-extrabold tracking-tight text-[var(--fx-ink)]">{inr(task.maxBudget)}</b>
                <span className="text-[10px] font-extrabold tracking-[0.1em] text-[var(--fx-muted)]">
                  MAX · {task.kind ? KIND_LABEL[task.kind] : "—"}
                </span>
              </>
            ) : (
              <span className="text-[13px] font-extrabold tracking-[0.08em] text-[var(--fx-green)]">FREE TASK · NO CAP SET</span>
            )}
          </div>
        </div>

        {/* the cost */}
        <div>
          <span className="fx-label">WHAT DID IT COST? · {task.maxBudget !== null ? "YOU CAN SPEND LESS, NEVER MORE" : "LEAVE 0 IF NOTHING WAS SPENT"}</span>
          <div className="relative mt-1.5">
            <IndianRupee className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--fx-muted)]" />
            <Input
              value={cost}
              onChange={(e) => {
                const v = e.target.value.replace(/[^\d.]/g, "");
                setCost(v);
                setErr(null);
              }}
              placeholder="0"
              type="number"
              min={0}
              step="0.01"
              aria-label="Money the task cost in rupees"
              data-testid="task-cost-input"
              className={`fx-num h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] pl-8 text-[15px] font-extrabold ${over ? "border-[var(--fx-rose)]" : ""}`}
            />
          </div>
          {over && (
            <div className="mt-2 rounded-[9px] border border-[rgba(220,38,38,.3)] bg-[rgba(220,38,38,.08)] px-3 py-2 text-[11px] font-bold text-[#dc2626]" data-testid="task-cost-err">
              Above the owner's assumption — this task was budgeted at {inr(task.maxBudget ?? 0)} max. Enter {inr(task.maxBudget ?? 0)} or less, or ask the owner to raise the budget.
            </div>
          )}
          {under && (
            <div className="mt-2 text-[10.5px] font-extrabold tracking-[0.06em] text-[var(--fx-green)]" data-testid="task-cost-under">
              {inr((task.maxBudget ?? 0) - costNum)} UNDER THE OWNER'S ASSUMPTION
            </div>
          )}
        </div>

        {/* free tasks can carry a type chosen at close time */}
        {!task.kind && (
          <div>
            <span className="fx-label">EXPENSE TYPE {costNum !== null && costNum > 0 ? <b className="text-[var(--fx-rose)]">· REQUIRED TO BOOK THE SPEND</b> : "· OPTIONAL"}</span>
            <div className="mt-2">
              <KindChips kind={kind} onPick={setKind} testPrefix="task-done-kind" />
            </div>
          </div>
        )}

        {err && (
          <div role="alert" className="rounded-[9px] border border-[rgba(220,38,38,.3)] bg-[rgba(220,38,38,.08)] px-3 py-2 text-[11.5px] font-bold text-[#dc2626]">
            {err}
          </div>
        )}

        <div className="flex items-center justify-end gap-2">
          <Button variant="ghost" onClick={onClose} className="rounded-xl text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)]">
            NOT YET
          </Button>
          <Button
            onClick={() => void submit()}
            disabled={busy || over}
            data-testid="task-done-submit"
            className="rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCheck className="h-4 w-4" />} CLOSE THE TASK
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ── one task card ────────────────────────────────────────────────────────── */
function TaskCard({
  task,
  index,
  canClose,
  isOwner,
  busy,
  open,
  onToggle,
  onDone,
  onNote,
  onDelete,
}: {
  task: FxTask;
  index: number;
  canClose: boolean;
  isOwner: boolean; // t130 — the owner REPLIES on the trail instead of just watching it
  busy: boolean;
  open: boolean;
  onToggle: () => void;
  onDone: () => void;
  onNote: (msg: string) => Promise<void>;
  onDelete: () => void; // owner-only — remove the task (and its update trail)
}) {
  const [msg, setMsg] = React.useState("");
  const [sending, setSending] = React.useState(false);
  const [deleting, setDeleting] = React.useState(false);
  const [armed, setArmed] = React.useState(false);
  const overdue = isOverdue(task);
  const spent = task.actualCost ?? 0;

  const send = async () => {
    if (msg.trim().length < 2 || sending) return;
    setSending(true);
    await onNote(msg.trim());
    setMsg("");
    setSending(false);
  };

  return (
    <div
      /* t129 — NO fx-rise here: the entrance observer leaves cards at opacity 0
         until they intersect, and a 250-card board scrolled inside <main> never
         triggers it — worse, React rewriting className on expand re-adds
         "fx-rise" AFTER the observer stripped it, so an expanded card turned
         INVISIBLE ("tasks not visible when expanded"). The board now renders
         plain and always-visible; the hover drift (fx-motion) still applies. */
      className={`fx-card tk-card${open ? " open" : ""}`}
      data-testid={`tk-card-${index}`}
    >
      <span className={`tk-spine ${task.book === "lodge" ? "lodge" : "rest"}`} aria-hidden />
      <button type="button" className="tk-top" aria-expanded={open} onClick={onToggle} data-testid={`tk-expand-${index}`}>
        <span className="tk-title">{task.title}</span>
        <span className={`tk-chip ${task.status === "open" ? "open" : "done"}`} data-testid={`tk-status-${index}`}>
          {task.status === "open" ? (
            <>
              <Timer className="h-3 w-3" /> OPEN
            </>
          ) : (
            <>
              <CheckCheck className="h-3 w-3" /> DONE
            </>
          )}
        </span>
        <span className="tk-ic" aria-hidden>
          <ChevronDown />
        </span>
      </button>
      {isOwner && (
        <button
          type="button"
          onClick={async () => {
            if (deleting) return;
            if (!armed) {
              setArmed(true);
              setTimeout(() => setArmed(false), 2500);
              return;
            }
            setArmed(false);
            setDeleting(true);
            await onDelete();
            setDeleting(false);
          }}
          disabled={deleting}
          aria-label={armed ? "Confirm delete task" : "Delete task"}
          data-testid={`tk-del-${index}`}
          className={`tk-del${armed ? " armed" : ""}`}
        >
          {deleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
          {armed && <span className="tk-del-lbl">SURE?</span>}
        </button>
      )}

      <div className="tk-chips">
        <span className={`tk-tag ${task.book === "lodge" ? "lodge" : "rest"}`}>{BOOK_LABEL[task.book]}</span>
        {task.maxBudget !== null ? (
          <span className="tk-tag budget fx-num">MAX {inr(task.maxBudget)}</span>
        ) : (
          <span className="tk-tag free">FREE TASK</span>
        )}
        {task.kind && (
          <span className={`tk-tag ${task.kind === "raw_material" ? "raw" : task.kind === "upgrade" ? "upg" : "maint"}`}>
            {task.kind === "raw_material" ? <Carrot className="h-3 w-3" /> : task.kind === "upgrade" ? <Sparkles className="h-3 w-3" /> : <Wrench className="h-3 w-3" />}
            {KIND_LABEL[task.kind]}
          </span>
        )}
        {/* t193 — UNIFIED day format for ALL tasks: "Xd given · Yd used".
            Open: Y = days from created to today (grows; can exceed X for overdue).
            Completed: Y = days from created to doneAt (frozen at close time;
            can exceed X if completed late). The chip turns red when Y > X. */}
        <span className={`tk-tag due${overdue || (task.status === "done" && task.doneAt && new Date(task.doneAt).getTime() > new Date(task.deadline).getTime()) ? " hot" : ""}`}>
          {overdue && <TriangleAlert className="h-3 w-3" />}
          {(() => {
            const given = Math.max(1, Math.round((new Date(task.deadline).getTime() - new Date(task.createdAt).getTime()) / 86_400_000));
            const endDate = task.status === "done" && task.doneAt ? new Date(task.doneAt) : new Date();
            const used = Math.max(0, Math.round((endDate.getTime() - new Date(task.createdAt).getTime()) / 86_400_000));
            return `${given}d given · ${used}d used`;
          })()}
        </span>
      </div>

      <div className="tk-body" data-testid={`tk-body-${index}`}>
        <div>
          <div className="tk-body-in">
            {task.description && <p className="tk-desc">{task.description}</p>}

            {task.status === "done" && (
              <p className="tk-result" data-testid={`tk-result-${index}`}>
                <Crown className="h-3.5 w-3.5 text-[var(--fx-gold)]" />
                {spent > 0 ? (
                  <>
                    <b className="fx-num">{inr(spent)}</b> SPENT
                    {task.maxBudget !== null && (
                      <span className="fx-num">
                        {" "}· {inr(task.maxBudget)} ASSUMED · {Math.max(0, Math.round((1 - spent / task.maxBudget) * 100))}% UNDER
                      </span>
                    )}
                    <span className="tk-crown-note">· IN THE {BOOK_LABEL[task.book]} LEDGER</span>
                  </>
                ) : (
                  <span>NOTHING WAS SPENT ON THIS TASK</span>
                )}
                {task.doneBy && <span className="tk-by">· CLOSED BY {task.doneBy}</span>}
              </p>
            )}

            {/* the update trail — t130: the owner reads AND replies here */}
            <div className="tk-notes" data-testid={`tk-notes-${index}`}>
              <span className="fx-label">UPDATES · {task.updates.length}</span>
              <div className="tk-note-feed">
                {task.updates.map((u) => (
                  <div key={u.id} className="tk-note">
                    <span className={`tk-dot ${u.role === "owner" ? "owner" : ""}`} aria-hidden />
                    <span className="tk-note-main">
                      <b>{u.author}</b>
                      {u.role === "owner" && <span className="tk-owner-tag">OWNER</span>}
                      <em>{istStamp(u.createdAt)}</em>
                      <p>{u.message}</p>
                    </span>
                  </div>
                ))}
                {task.updates.length === 0 && <p className="tk-note-none">No updates yet — the desk posts progress here.</p>}
              </div>
            </div>

            {task.status === "open" && (
              <div className="tk-note-post">
                <Input
                  value={msg}
                  onChange={(e) => setMsg(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void send();
                  }}
                  placeholder={isOwner ? "Reply to the desk — answer their query, guide the work…" : "Post an update — what is done, what is left…"}
                  aria-label={isOwner ? `Reply on ${task.title}` : `Post an update on ${task.title}`}
                  data-testid={`tk-note-input-${index}`}
                  className="h-9 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] text-[12px] font-semibold"
                />
                <Button
                  size="sm"
                  disabled={sending || msg.trim().length < 2}
                  onClick={() => void send()}
                  data-testid={`tk-note-send-${index}`}
                  className="h-9 rounded-xl bg-[var(--fx-ink)] px-3 text-[var(--fx-page)] hover:bg-[var(--fx-ink)]/85"
                >
                  {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                </Button>
              </div>
            )}

            {canClose && task.status === "open" && (
              <Button
                size="sm"
                disabled={busy}
                onClick={onDone}
                data-testid={`tk-done-btn-${index}`}
                className="mt-2 rounded-xl bg-[var(--fx-purple)] text-[10.5px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
              >
                <CheckCheck className="h-3.5 w-3.5" /> MARK DONE · FILL THE COST
              </Button>
            )}
          </div>
        </div>
      </div>

      <span className="tk-cbar" aria-hidden>
        <i className={task.status === "open" ? (overdue ? "late" : "run") : "fin"} />
      </span>
    </div>
  );
}

/* ── the section ──────────────────────────────────────────────────────────── */
export function TasksView({ role, userName }: { role: string; userName: string }) {
  const { toast } = useToast();
  const isOwner = role === "owner";
  // t232 — the MANAGER runs both books' board: no lock (both books load + the
  // ALL/RESTAURANT/LODGE filter shows), can close tasks, cannot create/delete
  // (the owner keeps forwarding + deleting).
  const isManager = role === "manager";
  const bookLock: Book | null = role === "reception_restaurant" ? "rest" : role === "reception_lodge" ? "lodge" : null;

  const [tasks, setTasks] = React.useState<FxTask[] | null>(null);
  const [addOpen, setAddOpen] = React.useState(false);
  const [doneFor, setDoneFor] = React.useState<FxTask | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);
  const [openIds, setOpenIds] = React.useState<Set<string>>(new Set());
  // t184 — fRange, fBook, fStatus now persist across section switches +
  // AI-writable ("open tasks", "show open only"). The fRange toggleId matches
  // the AI panel's RANGE_TOGGLE_ID_PER_VIEW["tasks"] = "fRange".
  const [fBook, setFBook] = useCachedToggle<"all" | Book>("tasks", "fBook", "all");
  // t121 — the board opens on ALL: open tasks lead the sort, the DONE history
  // sits right under them (defaulting to "open" hid every past task, which read
  // to the owner as "no tasks history").
  const [fStatus, setFStatus] = useCachedToggle<"open" | "done" | "all">("tasks", "fStatus", "all");
  const [fRange, setFRange] = useCachedToggle<TaskRangeKey>("tasks", "fRange", "1y");
  // t195 — EXPIRE vs GIVEN — what the window counts. EXPIRE (default) = the
  // classic deadline windows (tasks expiring inside the unit). GIVEN = tasks
  // the owner FORWARDED inside the unit (createdAt, past-looking, today
  // included). LATE stays deadline-based in both modes — overdue is overdue.
  const [fMode, setFMode] = useCachedToggle<"expire" | "given">("tasks", "fMode", "expire");
  // t209 — LATE lives under EXPIRE only (it is deadline-based; GIVEN windows
  // anchor on createdAt where "late" makes no sense). Safety net: a cached
  // session resting on LATE while mode is GIVEN falls back to TODAY.
  React.useEffect(() => {
    if (fMode === "given" && fRange === "late") setFRange("today");
  }, [fMode, fRange, setFRange]);
  // t193 — read the global custom range (set in Settings) when fRange=custom.
  const [globalStart] = useCachedToggle<string>("global", "customStart", "2020-01-01");
  const [globalEnd] = useCachedToggle<string>("global", "customEnd", (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; })());
  // t194 — master toggle from Settings. When OFF, the CUSTOM tab is hidden.
  const [useCustomRange] = useCachedToggle<boolean>("global", "useCustomRange", false);
  useRegisterScreen("tasks", "Tasks", { range: fRange, book: fBook, status: fStatus });

  const load = React.useCallback(async () => {
    try {
      const res = await fetch(`/api/tasks${bookLock ? `?book=${bookLock}` : ""}`, { cache: "no-store" });
      const data = (await res.json()) as { tasks?: FxTask[] };
      setTasks(data.tasks ?? []);
    } catch {
      /* keep the board as-is on failure */
    }
  }, [bookLock]);

  React.useEffect(() => {
    void load();
    // t123 — cross-device sync: tasks posted/closed on another device land here
    const t = setInterval(() => void load(), 15000);
    return () => clearInterval(t);
  }, [load]);

  const postNote = async (task: FxTask, message: string) => {
    try {
      const res = await fetch("/api/tasks", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: task.id, action: "note", message, author: userName, role: isOwner ? "owner" : isManager ? "manager" : "reception" }),
      });
      const out = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(out.error ?? "Could not post the update");
      await load();
    } catch (e) {
      toast({ title: "Update failed", description: e instanceof Error ? e.message : "Try again.", variant: "destructive" });
    }
  };

  // owner-only — remove the task and its update trail (cascade wipes the notes)
  const deleteTask = async (task: FxTask) => {
    try {
      const res = await fetch(`/api/tasks?id=${encodeURIComponent(task.id)}`, { method: "DELETE" });
      const out = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(out.error ?? "Could not delete the task");
      toast({ title: "Task removed", description: `"${task.title}" — gone, with its trail.` });
      await load();
    } catch (e) {
      toast({ title: "Delete failed", description: e instanceof Error ? e.message : "Try again.", variant: "destructive" });
    }
  };

  /* t136/t167 — the time unit toggle is a DEADLINE window, same as the task
     tracker: the board lists tasks that EXPIRE inside the chosen unit — the
     deadline's IST day must land between today and the window's last day.
     t167/t208 — LATE tasks are SEPARATED: they ONLY show when the "LATE" tab
     is active. When on today/7d/1m/3m/1y, late tasks are NOT included. */
  const rangeDays = RANGE_TABS.find((r) => r.key === fRange)?.days ?? 365;
  const IST_OFFSET = 330 * 60_000; // UTC+5:30 — deadline days are IST days
  const dayKey = (iso: string) => Math.floor((new Date(iso).getTime() + IST_OFFSET) / 86_400_000);
  const todayKey = dayKey(new Date().toISOString());
  const expiresInWindow = (t: FxTask) => {
    const k = dayKey(t.deadline);
    return k >= todayKey && k <= todayKey + (rangeDays - 1);
  };
  const lateOpen = (t: FxTask) => t.status === "open" && dayKey(t.deadline) < todayKey;
  // t195 — GIVEN mode: the createdAt IST day must land in the LAST rangeDays
  // days, today included — "given today" on TODAY, "given this week" on 7D…
  const givenInWindow = (t: FxTask) => {
    const k = dayKey(t.createdAt);
    return k <= todayKey && k >= todayKey - (rangeDays - 1);
  };
  // t193 — custom range: deadline falls between globalStart and globalEnd.
  const customKey = (iso: string) => Math.floor((new Date(iso).getTime() + IST_OFFSET) / 86_400_000);
  const customStartKey = customKey(globalStart + "T00:00:00");
  const customEndKey = customKey(globalEnd + "T23:59:59");
  const inCustomWindow = (t: FxTask) => {
    const k = customKey(t.deadline);
    return k >= customStartKey && k <= customEndKey;
  };
  // t195 — custom range in GIVEN mode anchors on createdAt instead.
  const inCustomWindowGiven = (t: FxTask) => {
    const k = customKey(t.createdAt);
    return k >= customStartKey && k <= customEndKey;
  };
  // t167/t195/t208 — inRange: for time windows, show ONLY the current mode's
  // window (no late). For the "late" tab, show ONLY lateOpen (both modes).
  // For "custom", deadline window (expire) or createdAt window (given).
  const inRange = (tasks ?? []).filter((t) =>
    fRange === "late" ? lateOpen(t)
    : fRange === "custom" ? (fMode === "given" ? inCustomWindowGiven(t) : inCustomWindow(t))
    : (fMode === "given" ? givenInWindow(t) : expiresInWindow(t))
  );
  const windowCount = inRange.length;
  const lateCount = (tasks ?? []).filter(lateOpen).length;
  const openCount = inRange.filter((t) => t.status === "open").length;
  const overdueCount = inRange.filter(isOverdue).length;
  // t192 — sort by days-remaining ASCENDING (least/most-overdue first).
  // Open tasks lead, done tasks follow. For open tasks with the same
  // remaining, the one with FEWER days given (shorter overall window) leads
  // — it's tighter on time. For done tasks, newest-done-first.
  const daysRemaining = (t: FxTask) =>
    Math.round((new Date(t.deadline).getTime() - Date.now()) / 86_400_000);
  const daysGiven = (t: FxTask) =>
    Math.max(1, Math.round((new Date(t.deadline).getTime() - new Date(t.createdAt).getTime()) / 86_400_000));
  const shown = inRange
    .filter((t) => (fBook === "all" || t.book === fBook) && (fStatus === "all" || t.status === fStatus))
    .sort((a, b) => {
      const aOpen = a.status === "open";
      const bOpen = b.status === "open";
      if (aOpen && !bOpen) return -1;          // open first
      if (!aOpen && bOpen) return 1;           // done after open
      if (aOpen && bOpen) {
        // Open: least days remaining first. Tiebreak: fewer days given
        // (tighter deadline) first.
        const dr = daysRemaining(a) - daysRemaining(b);
        return dr !== 0 ? dr : daysGiven(a) - daysGiven(b);
      }
      // Both done — newest done first
      return new Date(b.doneAt ?? b.createdAt).getTime() - new Date(a.doneAt ?? a.createdAt).getTime();
    });

  const toggle = (id: string) =>
    setOpenIds((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  return (
    <div className="space-y-5" data-testid="tasks-view">
      <TierBand
        num={FX_TIERS.tasks.num}
        eyebrow={tierEyebrow(FX_TIERS.tasks)}
        title={isOwner ? "Tasks" : bookLock ? (bookLock === "lodge" ? "Lodge Tasks" : "Restaurant Tasks") : "Tasks · Both Books"}
        sub={
          isOwner
            ? "Forward work to either reception with a deadline and an optional max budget — the desks post updates, you reply to their queries, and every rupee spent lands in the ledger wearing your crown."
            : isManager
              ? "Both businesses' forwarded work — filter by book, post progress updates, and close each task with the money it cost."
              : "Work forwarded by the owner — post progress updates, and close each task with the money it cost."
        }
        tag={`${openCount} OPEN${lateCount ? ` · ${lateCount} LATE` : ""}`}
      />

      {/* t136 — the board's time window is a DEADLINE window (tracker rules):
            today / 7 days / 1 month / 3 months / 1 year of expiries */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="fx-card inline-flex flex-wrap gap-1.5 p-1.5" role="tablist" aria-label="Tasks time range">
          {/* t209 — the LATE tab shows ONLY under EXPIRE: overdue is a
              deadline concept, so GIVEN mode (createdAt windows) hides it. */}
          {RANGE_TABS.filter((t) => fMode === "expire" || t.key !== "late").map((t) => (
            <button
              key={t.key}
              role="tab"
              aria-selected={fRange === t.key}
              onClick={() => setFRange(t.key)}
              data-testid={`tk-range-${t.key}`}
              className={`rounded-xl px-3.5 py-2 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
                fRange === t.key
                  ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
              }`}
            >
              {t.short}
            </button>
          ))}
        </div>
        <span className="mut-chip">
          {fRange === "late"
            ? `${lateCount} LATE · STILL OPEN`
            : `${windowCount} ${fMode === "given" ? "GIVEN" : "EXPIRE"} IN WINDOW${lateCount ? ` · ${lateCount} LATE` : ""}`}
        </span>
        {/* t195 — EXPIRE / GIVEN — sits right above the ADD TASK button and
            switches what the window counts: expiry deadlines vs forwarded
            dates. Kept to two tiny chips so the row never crowds. */}
        <div className="fx-card ml-auto inline-flex gap-1.5 p-1.5" role="tablist" aria-label="Window mode — expiry or given" data-testid="tk-mode-toggle">
          {([
            ["expire", "EXPIRE", Timer],
            ["given", "GIVEN", Send],
          ] as const).map(([v, l, Icon]) => (
            <button
              key={v}
              role="tab"
              aria-selected={fMode === v}
              onClick={() => {
                // t209 — flipping to GIVEN while on the LATE tab: LATE does
                // not exist under GIVEN — land on TODAY instead.
                if (v === "given" && fRange === "late") setFRange("today");
                setFMode(v);
              }}
              data-testid={`tk-mode-${v}`}
              title={v === "expire" ? "Window counts tasks EXPIRING inside it (deadline)" : "Window counts tasks GIVEN inside it (forwarded date)"}
              className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
                fMode === v
                  ? "bg-[var(--fx-ink)] text-[var(--fx-page)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* controls */}
      <div className="flex flex-wrap items-center gap-2">
        {!bookLock && (
          <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Filter by book">
            {([["all", "ALL BOOKS"], ["rest", "RESTAURANT"], ["lodge", "LODGE"]] as const).map(([v, l]) => (
              <button
                key={v}
                onClick={() => setFBook(v)}
                aria-pressed={fBook === v}
                className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                  fBook === v
                    ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        )}
        {bookLock && (
          <span className={`tk-tag ${bookLock === "lodge" ? "lodge" : "rest"}`}>
            {bookLock === "lodge" ? <BedDouble className="h-3 w-3" /> : <UtensilsCrossed className="h-3 w-3" />}
            YOUR BOOK · {BOOK_LABEL[bookLock]}
          </span>
        )}
        <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Filter by status">
          {([["open", "OPEN"], ["done", "DONE"], ["all", "ALL"]] as const).map(([v, l]) => (
            <button
              key={v}
              onClick={() => setFStatus(v)}
              aria-pressed={fStatus === v}
              className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                fStatus === v
                  ? "bg-[var(--fx-ink)] text-[var(--fx-page)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
              }`}
            >
              {l}
            </button>
          ))}
        </div>
        {isOwner && (
          <Button
            onClick={() => setAddOpen(true)}
            data-testid="task-add-btn"
            className="ml-auto rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            <Plus className="h-4 w-4" /> ADD TASK
          </Button>
        )}
      </div>

      {/* the board */}
      {tasks === null ? (
        <div className="fx-card grid place-items-center px-6 py-12">
          <span className="fx-label inline-flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" /> LOADING THE BOARD…
          </span>
        </div>
      ) : shown.length > 0 ? (
        /* t99 — one task per column: a single calm list, never a grid */
        <div className="grid grid-cols-1 gap-3.5">
          {shown.map((t, i) => (
            <TaskCard
              key={t.id}
              task={t}
              index={i}
              canClose={!isOwner}
              isOwner={isOwner}
              busy={busyId === t.id}
              open={openIds.has(t.id)}
              onToggle={() => toggle(t.id)}
              onDone={() => setDoneFor(t)}
              onNote={(m) => postNote(t, m)}
              onDelete={() => deleteTask(t)}
            />
          ))}
        </div>
      ) : (
        <div className="fx-card grid place-items-center px-6 py-12 text-center" data-testid="tk-empty">
          <span className="fx-label inline-flex items-center gap-2">
            <ListChecks className="h-4 w-4" />
            {tasks.length === 0
              ? isOwner
                ? "NOTHING FORWARDED YET — ADD THE FIRST TASK"
                : "THE OWNER HAS NOT FORWARDED ANYTHING YET"
              : "NOTHING UNDER THIS FILTER"}
          </span>
        </div>
      )}

      {isOwner && (
        <p className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
          You monitor the board — the receptions post the progress updates, and you can reply to any
          of them right on the task: expand it, type your answer, send. Free tasks cost
          nothing unless the desk reports a spend. Budgeted tasks can come in under the assumption —
          never over it — and every rupee auto-registers in that book's expense ledger wearing your
          crown.
        </p>
      )}

      {isOwner && <AddTaskModal open={addOpen} onClose={() => setAddOpen(false)} onCreated={() => void load()} />}
      {doneFor && (
        <DoneModal
          task={doneFor}
          onClose={() => setDoneFor(null)}
          onDone={() => {
            setBusyId(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

