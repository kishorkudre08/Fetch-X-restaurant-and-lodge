"use client";

/**
 * t91/t92 — the lodge wall as one donut.
 *
 * The room-hours math stays server-side (analytics-lodge.ts); this donut only
 * ever DISPLAYS rooms: 24 room-hours fold back into one room, and the three
 * slices are the time-weighted share of the window, normalised so they always
 * sum to the 100-room wall. 40 rooms filled for 12 hours reads as 20 rooms —
 * never "%", never raw "room-days".
 *
 * Without `hours` (Lodge Front Desk live snapshot) it falls back to the
 * current room counts with each row's share of the wall.
 */

import * as React from "react";
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import { useFxColors } from "@/lib/fx-colors";
import { useDonutMode } from "@/components/donut-toggle";
import type { RoomHoursData } from "@/lib/types";

export type RoomStatusCounts = { avl: number; occ: number; mnt: number };

type StatusId = "free" | "guests" | "mnt";

const ORDER: StatusId[] = ["free", "guests", "mnt"];
const NAMES: Record<StatusId, string> = { free: "FREE", guests: "GUESTS", mnt: "MAINTENANCE" };

/** Largest-remainder rounding — integer rooms that always sum to `total`. */
function largestRemainder(values: number[], total: number): number[] {
  const sum = values.reduce((s, v) => s + v, 0);
  if (sum <= 0 || total <= 0) return values.map(() => 0);
  const exact = values.map((v) => (v / sum) * total);
  const floors = exact.map((v) => Math.floor(v));
  let rem = total - floors.reduce((s, v) => s + v, 0);
  const byFrac = exact
    .map((v, i) => ({ i, frac: v - Math.floor(v) }))
    .sort((a, b) => b.frac - a.frac || a.i - b.i);
  const out = [...floors];
  for (let k = 0; rem > 0; k++, rem--) out[byFrac[k % byFrac.length].i] += 1;
  return out;
}

export function RoomStatusDonut({
  counts,
  hours,
  testId = "room-status-donut",
  legendPrefix = "lroom",
  emptyText = "THE WALL IS RESTING",
}: {
  counts: RoomStatusCounts;
  hours?: RoomHoursData | null;
  testId?: string;
  legendPrefix?: string;
  emptyText?: string;
}) {
  const C = useFxColors();
  /* t227 — the room wall follows the UNIVERSAL chart-shape lever (owner
     Settings); this hook only reads it. Pie mode keeps the exact donut
     layout — the figure rides ON the pie, smaller, nothing else moves. */
  const [mode] = useDonutMode();
  const pie = mode === "pie";
  const sliceColor: Record<StatusId, string> = { free: C.gold, guests: C.ink, mnt: C.purple };

  /* ── values: rooms (time-weighted) when room-hours exist, else live counts ── */
  const rhOf = (id: StatusId): number =>
    id === "free" ? hours?.free ?? 0 : id === "guests" ? hours?.guests ?? 0 : hours?.mnt ?? 0;

  const hasHours = !!hours && hours.total > 0;
  const rooms = largestRemainder(
    ORDER.map((id) => (hasHours ? rhOf(id) : id === "free" ? counts.avl : id === "guests" ? counts.occ : counts.mnt)),
    hasHours ? hours.totalRooms : counts.avl + counts.occ + counts.mnt,
  );
  const wallTotal = hasHours ? hours.totalRooms : counts.avl + counts.occ + counts.mnt;
  const amtOf = (i: number): number => rooms[i];
  const legendVal = (i: number): string => {
    if (hasHours) return `${rooms[i]} ROOMS`;
    return wallTotal > 0 ? `${rooms[i]} · ${Math.round((rooms[i] / wallTotal) * 100)}%` : `${rooms[i]}`;
  };

  const windowLabel = hasHours ? hours.windowLabel : "LIVE";
  /* t99 — the ring hole is 124px; compact the window so the label never
     leaks out of the donut (the card header carries the full label anyway) */
  const COMPACT: Record<string, string> = {
    TODAY: "TODAY",
    "LAST 7 DAYS": "7 DAYS",
    "LAST 30 DAYS": "30 DAYS",
    "LAST 3 MONTHS": "3 MONTHS",
    "LAST 12 MONTHS": "12 MONTHS",
  };
  const centreTop = `${wallTotal}`;
  const centreLabel = hasHours
    ? `ROOMS · ${COMPACT[hours.windowLabel] ?? hours.windowLabel}`
    : "ROOMS ON THE WALL";
  const fit = pie
    ? centreTop.length <= 8
      ? 13
      : centreTop.length <= 10
        ? 12
        : 11
    : centreTop.length <= 8
      ? 20
      : centreTop.length <= 10
        ? 17
        : 15;

  /* t230 — hover flipped: the centre figure NEVER moves; the TOOLTIP is what
     steps outside — the hovered slice's name · rooms · share prints on the
     floating .donut-out pill above the chart box. */
  const [hovIdx, setHovIdx] = React.useState<number | null>(null);

  if (wallTotal <= 0) {
    return (
      <div className="grid h-[170px] place-items-center" data-testid={testId}>
        <span className="fx-label">{emptyText}</span>
      </div>
    );
  }

  const figure = (
    <>
      <div
        className="dc-v fx-num whitespace-nowrap"
        style={{ fontSize: `${fit}px`, letterSpacing: "-0.02em" }}
      >
        {centreTop}
      </div>
      <div className="fx-label">{centreLabel}</div>
    </>
  );

  return (
    <div data-testid={testId}>
      <div className="donut-flex">
        <div className="donut-w">
          <div className="h-[170px] w-[240px]">
            {/* t230 — the TOOLTIP pill, OUTSIDE the figure; the centre below
                never moves */}
            <span className={`donut-out${hovIdx !== null ? " is-on" : ""}`} aria-hidden={hovIdx === null}>
              {hovIdx !== null && ORDER[hovIdx] ? (
                <>
                  <span className="ct-l">{NAMES[ORDER[hovIdx]]} · {windowLabel}</span>
                  <span className="ct-v fx-num">{amtOf(hovIdx)} ROOMS · {wallTotal > 0 ? Math.round((rooms[hovIdx] / wallTotal) * 100) : 0}%</span>
                </>
              ) : null}
            </span>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={ORDER.map((id, i) => ({ name: NAMES[id], value: Math.max(rooms[i], 0.4), amt: amtOf(i) }))}
                  dataKey="value"
                  innerRadius={pie ? 0 : 62}
                  outerRadius={84}
                  paddingAngle={2}
                  stroke="none"
                  onMouseEnter={(_: unknown, i: number) => setHovIdx(i)}
                  onMouseLeave={() => setHovIdx(null)}
                >
                  {ORDER.map((id, i) => (
                    <Cell key={id} fill={sliceColor[id]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* t227 — the figure rides the chart's centre in BOTH shapes: in the
             ring's hole (donut) or ON the pie, one size smaller, on a soft
             chip (pie — no hole to live in). t230 — it never moves, not even
             on hover; the tooltip is what goes outside. */}
          <div className="donut-c">
            <div className={pie ? "on-pie" : undefined}>{figure}</div>
          </div>
        </div>
        <div className="donut-legend">
          {ORDER.map((id, i) => (
            <div
              className="dl-row"
              key={id}
              data-testid={`${legendPrefix}-${id}`}
              data-amt={amtOf(i)}
            >
              <i className="scope-dot" style={{ background: sliceColor[id] }} />
              {NAMES[id]}
              <span className="dl-v fx-num">{legendVal(i)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
