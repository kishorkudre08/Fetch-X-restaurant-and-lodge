"use client";

// ── t98 + t99 · EXPENSES — the owner's cost ledger ──────────────────────────
// The receptions enter their own spends on their own Expenses page (raw
// materials / upgrades / maintenance), and this page is where the owner reads
// them.
// t99: a 3-metric donut compares the three expense types' totals, a
// today/7d/1m/3m/1y window toggle drives the WHOLE section (stat cards +
// donut + ledger), and the ledger got its own 3-expenses filter.
// t114 — the ENTER EXPENSES section on the owner page was REMOVED at t129
// (user: "remove expense entry from expenses section [owner account] — bring
// the rest up").
// t129 — the receptions' page carries ONE entry block with THREE TOGGLES
// (user: "instead of 3 blocks keep one block with 3 toggles"), and the
// COST SPLIT donut is gone from their page ("remove expenses breakdown donut
// from both the reception's expenses section").
// t118 — the view takes an optional `book` prop — when set
// (reception_restaurant → "rest", reception_lodge → "lodge") the page locks
// to THAT book: the window cards and ledger read that book only.

import * as React from "react";
import {
  BedDouble,
  Carrot,
  Crown,
  Gift,
  Loader2,
  Pencil,
  Plus,
  Save,
  Sparkles,
  UtensilsCrossed,
  Wrench,
  X,
} from "lucide-react";
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { FxDatePicker, ScrollFadeBox, TierBand } from "@/components/fx";
import { useToast } from "@/hooks/use-toast";
import type { RangeKey, Expense } from "@/lib/types";
import { inr } from "@/lib/format";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";
import { useDonutMode } from "@/components/donut-toggle";

const istDayLabel = (iso: string) =>
  new Date(iso).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short" });

type ExpenseKind = "raw_material" | "upgrade" | "maintenance" | "discount_rewards";
type Book = "rest" | "lodge";
// t230 — a ledger row whose kind may also be the synthetic AUTO kind
// (Expense in lib/types only knows the three DB kinds).
type LedgerRow = Omit<Expense, "kind"> & { kind: ExpenseKind };

// t230 — DISCOUNT & REWARDS is the fourth, AUTO kind: the bill discounts + the
// loyalty points minted on the same bills (1 pt = ₹1), registered by itself
// from the ledger — nobody enters it, nobody deletes it, receptions never
// even see it. Owner-only in the split donut + ledger.
const KIND_NAME: Record<ExpenseKind, string> = {
  raw_material: "RAW MATERIAL",
  upgrade: "UPGRADES",
  maintenance: "MAINTENANCE",
  discount_rewards: "DISCOUNT & REWARDS",
};
const KIND_DOT: Record<ExpenseKind, string> = {
  raw_material: "bg-[#0d9488]",
  upgrade: "bg-[#7c3aed]",
  maintenance: "bg-[var(--fx-amber)]",
  discount_rewards: "bg-[#0ea5e9]",
};
const KIND_HEX: Record<ExpenseKind, string> = {
  raw_material: "#0d9488",
  upgrade: "#7c3aed",
  maintenance: "var(--fx-amber)",
  discount_rewards: "#0ea5e9",
};
const KIND_ICON: Record<ExpenseKind, React.ReactNode> = {
  raw_material: <Carrot className="h-3.5 w-3.5" />,
  upgrade: <Sparkles className="h-3.5 w-3.5" />,
  maintenance: <Wrench className="h-3.5 w-3.5" />,
  discount_rewards: <Gift className="h-3.5 w-3.5" />,
};

/* t99 — the whole section runs on one window (mirrors the dashboard tabs).
   t188 — added an "all" range key for the ALL-TIME history view the owner
   asked for ("no expenses history"). With "all", `rangeSinceMs(0)` returns
   0 (no cutoff) so the ledger shows every expense ever entered. */
type ExpenseRangeKey = RangeKey | "all" | "custom";

const RANGE_TABS: Array<{ key: ExpenseRangeKey; short: string; label: string; days: number }> = [
  { key: "today", short: "TODAY", label: "TODAY", days: 1 },
  { key: "7d", short: "7 DAYS", label: "LAST 7 DAYS", days: 7 },
  { key: "1m", short: "1 MONTH", label: "THIS MONTH", days: 30 },
  { key: "3m", short: "3 MONTHS", label: "LAST 3 MONTHS", days: 91 },
  { key: "1y", short: "1 YEAR", label: "LAST 1 YEAR", days: 365 },
  { key: "all", short: "ALL", label: "ALL TIME", days: 0 },
  // t193 — custom range (read from Settings via useCachedToggle("global", ...))
  { key: "custom", short: "CUSTOM", label: "CUSTOM RANGE", days: 0 },
];
const rangeSinceMs = (days: number) => {
  if (days === 0) return 0; // t188 — ALL-TIME: no cutoff, show every entry
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.getTime() - (days - 1) * 86_400_000;
};

// ── book tag chip — RESTAURANT purple / LODGE gold ──────────────────────────
function BookTag({ b }: { b: Book }) {
  return b === "lodge" ? (
    <span className="shrink-0 rounded-full bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] px-2.5 py-1 text-[8.5px] font-extrabold tracking-[0.09em] text-[var(--fx-gold)]">
      LODGE
    </span>
  ) : (
    <span className="shrink-0 rounded-full bg-[var(--fx-lav)] px-2.5 py-1 text-[8.5px] font-extrabold tracking-[0.09em] text-[var(--fx-accent-ink)]">
      RESTAURANT
    </span>
  );
}

// ── per-book window stat card ───────────────────────────────────────────────
function BookWindowCard({ b, amount, count, windowLabel }: { b: Book; amount: number; count: number; windowLabel: string }) {
  return (
    <div className="fx-card px-5 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="fx-label">{windowLabel} · {b === "lodge" ? "LODGE" : "RESTAURANT"}</span>
        {b === "lodge" ? (
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]">
            <BedDouble className="h-4 w-4" />
          </span>
        ) : (
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
            <UtensilsCrossed className="h-4 w-4" />
          </span>
        )}
      </div>
      <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">
        {inr(amount)}
      </div>
      <div className="mt-1 h-4 text-[11px] font-semibold text-[var(--fx-muted)]">
        {count} {count === 1 ? "ENTRY" : "ENTRIES"} · ABSORBED BY THIS BOOK'S PROFIT
      </div>
    </div>
  );
}

// ── the cost-split donut — the expense types compared ───────────────────────
function CostSplitDonut({
  slices,
  windowLabel,
}: {
  slices: Array<{ key: ExpenseKind; value: number; count: number }>;
  windowLabel: string;
}) {
  /* t227 — the expenses ring follows the UNIVERSAL chart-shape lever (owner
     Settings); this hook only reads it. Pie mode keeps the exact donut
     layout — the figure rides ON the pie, smaller, nothing else moves. */
  const [mode] = useDonutMode();
  const pie = mode === "pie";
  const total = slices.reduce((s, x) => s + x.value, 0);
  const totalStr = inr(total);
  const fit = pie
    ? totalStr.length <= 8
      ? 13
      : totalStr.length <= 10
        ? 12
        : 11
    : totalStr.length <= 8
      ? 19
      : totalStr.length <= 10
        ? 16
        : 14;
  /* t230 — hover flipped: the centre figure NEVER moves; the TOOLTIP is what
     steps outside — the hovered slice's name · amount · share prints on the
     floating .donut-out pill above the chart box. */
  const [hovIdx, setHovIdx] = React.useState<number | null>(null);

  if (total <= 0) {
    return (
      <div className="grid h-[170px] place-items-center" data-testid="exp-split-empty">
        <span className="fx-label">NO SPENDS IN THIS WINDOW</span>
      </div>
    );
  }

  const figure = (
    <>
      <div className="dc-v fx-num whitespace-nowrap" style={{ fontSize: `${fit}px`, letterSpacing: "-0.02em" }}>
        {totalStr}
      </div>
      <div className="fx-label">TOTAL · {windowLabel}</div>
    </>
  );

  return (
    <div>
      <div className="donut-flex">
        <div className="donut-w">
          <div className="h-[170px] w-[240px]">
            {/* t230 — the TOOLTIP pill, OUTSIDE the figure; the centre below
                never moves */}
            <span className={`donut-out${hovIdx !== null ? " is-on" : ""}`} aria-hidden={hovIdx === null}>
              {hovIdx !== null && slices[hovIdx] ? (
                <>
                  <span className="ct-l">{KIND_NAME[slices[hovIdx].key]} · {windowLabel}</span>
                  <span className="ct-v fx-num">{inr(slices[hovIdx].value)} · {total > 0 ? Math.round((slices[hovIdx].value / total) * 100) : 0}%</span>
                </>
              ) : null}
            </span>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={slices.map((s) => ({
                    name: KIND_NAME[s.key],
                    value: Math.max(s.value, 0.01),
                    amt: s.value,
                  }))}
                  dataKey="value"
                  innerRadius={pie ? 0 : 62}
                  outerRadius={84}
                  paddingAngle={2}
                  stroke="none"
                  onMouseEnter={(_: unknown, i: number) => setHovIdx(i)}
                  onMouseLeave={() => setHovIdx(null)}
                >
                  {slices.map((s) => (
                    <Cell key={s.key} fill={KIND_HEX[s.key]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* t227 — the figure rides the chart's centre in BOTH shapes: in the
             ring's hole (donut) or ON the pie, one size smaller, on a soft
             chip (pie — no hole to live in). t230 — it never moves, not even
             on hover; the tooltip is what goes outside. */}
          <div className="donut-c">
            <div className={pie ? "on-pie" : undefined}>{figure}</div>
          </div>
        </div>
        <div className="donut-legend">
          {slices.map((s) => {
            const pct = total > 0 ? Math.round((s.value / total) * 100) : 0;
            return (
              <div className="dl-row" key={s.key} data-testid={`exp-split-${s.key}`} data-amt={s.value}>
                <i className="scope-dot" style={{ background: KIND_HEX[s.key] }} />
                {KIND_NAME[s.key]}
                <span className="dl-v fx-num">
                  {inr(s.value)} · {pct}% · {s.count} {s.count === 1 ? "ENTRY" : "ENTRIES"}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function ExpensesView({ book, manager }: { book?: Book; manager?: boolean } = {}) {
  /* t184 — view-level toggles cached across section switches + AI-writable
   * so "open expenses in monthly view, raw materials only" lands on the
   * right tab + chip. entryKind is the add-form kind selector
   * — also cached (the reception usually logs the same kind in a row).
   * entryLabel/Amount/Date are form state — not cached.
   * t232 — manager mode: NO book prop but `manager` set — the entry block
   * carries a RESTAURANT/LODGE toggle and the ledger reads BOTH books. */
  const [range, setRange] = useCachedToggle<ExpenseRangeKey>("expenses", "range", "1m");
  const [feedBook, setFeedBook] = useCachedToggle<"all" | Book>("expenses", "feedBook", "all");
  const [feedKind, setFeedKind] = useCachedToggle<"all" | ExpenseKind>("expenses", "feedKind", "all");
  const [entryKind, setEntryKind] = useCachedToggle<ExpenseKind>("expenses", "entryKind", "raw_material");
  // t232 — the manager's entry desk toggle (which book the next entry stamps)
  const [entryBook, setEntryBook] = useCachedToggle<Book>("expenses", "entryBook", "rest");
  useRegisterScreen("expenses", "Expenses", {
    range,
    feedBook,
    feedKind,
    entryKind,
    desk: book === "rest" || book === "lodge" ? book : manager ? entryBook : undefined,
  });
  const { toast } = useToast();
  /* t118 — reception mode: `book` set = this desk's own expenses page.
     t232 — manager mode: both books + entry rights; owner stays the only
     reader of the AUTO discount & rewards kind. */
  const scoped = book === "rest" || book === "lodge" ? book : null;
  const ownerView = !scoped && !manager;

  // ── data ──────────────────────────────────────────────────────────────────
  const [rawCosts, setRawCosts] = React.useState<Expense[]>([]);
  const [upgCosts, setUpgCosts] = React.useState<Expense[]>([]);
  const [maintCosts, setMaintCosts] = React.useState<Expense[]>([]);
  // t230 — the AUTO discount & rewards rows (per IST day, both books) — the
  // owner's view only; receptions never fetch (or see) this kind.
  const [discRows, setDiscRows] = React.useState<LedgerRow[]>([]);
  const [opLoading, setOpLoading] = React.useState(false);
  const [confirming, setConfirming] = React.useState<string | null>(null); // two-step delete

  const loadOps = React.useCallback(async () => {
    try {
      const bk = book ? `&book=${book}` : ""; // t118 — receptions read their own book only
      const [r, u, m] = await Promise.all([
        fetch(`/api/expenses?kind=raw_material&limit=400${bk}`).then((x) => x.json()),
        fetch(`/api/expenses?kind=upgrade&limit=400${bk}`).then((x) => x.json()),
        fetch(`/api/expenses?kind=maintenance&limit=400${bk}`).then((x) => x.json()),
      ]);
      setRawCosts(Array.isArray(r) ? r : []);
      setUpgCosts(Array.isArray(u) ? u : []);
      setMaintCosts(Array.isArray(m) ? m : []);
      // t230 — the auto discount & rewards ledger (owner only — t232: never
      // the manager; receptions never fetch (or see) this kind)
      if (ownerView) {
        fetch("/api/expenses?kind=discount_rewards&limit=400&from=0")
          .then((x) => x.json())
          .then((d) => setDiscRows(Array.isArray(d) ? d : []))
          .catch(() => setDiscRows([]));
      }
    } catch {
      // keep old data on failure
    }
  }, [book]);

  React.useEffect(() => {
    void loadOps();
    // t123 — cross-device sync: entries made on another device land here too
    const t = setInterval(() => void loadOps(), 20000);
    return () => clearInterval(t);
  }, [loadOps]);

  // t193 — read the global custom range (set in Settings) for the "custom" tab.
  const [globalStart] = useCachedToggle<string>("global", "customStart", "2020-01-01");
  const [globalEnd] = useCachedToggle<string>("global", "customEnd", (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; })());
  // t194 — master toggle from Settings. When OFF, the CUSTOM tab is hidden.
  const [useCustomRange] = useCachedToggle<boolean>("global", "useCustomRange", false);

  // ── t99 — the section's time window: today / 7d / month / 3 months / year ──
  // (range itself is cached above; this derives the human label + window math)
  // t193 — for range=custom, build the window from globalStart + globalEnd.
  const rangeTab = RANGE_TABS.find((r) => r.key === range) ?? RANGE_TABS[2];
  let sinceMs: number;
  let untilMs: number | null = null; // null = open-ended (today/7d/1m/3m/1y/all)
  if (range === "custom") {
    sinceMs = new Date(globalStart + "T00:00:00").getTime();
    untilMs = new Date(globalEnd + "T23:59:59").getTime();
  } else {
    sinceMs = rangeSinceMs(rangeTab.days);
  }
  const inWindow = (x: { spentOn: string }) => {
    const t = new Date(x.spentOn).getTime();
    if (t < sinceMs) return false;
    if (untilMs !== null && t > untilMs) return false;
    return true;
  };

  // ── t129 — THE SINGLE ENTRY (receptions only): one block, three type
  // toggles — the shape the station blocks used, moved onto the Expenses page.
  /* local YYYY-MM-DD — never toISOString (UTC would shift the day after 19:00 IST) */
  const todayStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const [entryLabel, setEntryLabel] = React.useState("");
  const [entryAmount, setEntryAmount] = React.useState("");
  const [entryDate, setEntryDate] = React.useState(todayStr);

  const addExpense = async () => {
    const amt = Number(entryAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast({
        title: "Amount needed",
        description: "Enter the cost amount above zero.",
        variant: "destructive",
      });
      return;
    }
    const kind = entryKind;
    const kindName =
      kind === "raw_material" ? "Raw material" : kind === "upgrade" ? "Upgrade" : "Maintenance";
    // t232 — the stamped book: the reception's locked book, or the manager's
    // desk toggle (defaults rest for any future caller without either)
    const stampedBook: Book = scoped ?? (manager ? entryBook : "rest");
    // single toast here — mutate's okMsg is left empty so the entry doesn't toast twice
    const ok = await mutate(
      "/api/expenses",
      "POST",
      { kind, label: entryLabel.trim(), amount: amt, spentOn: entryDate, book: stampedBook },
      undefined,
      loadOps,
    );
    if (ok) {
      toast({
        title: `${kindName} cost of ${inr(amt)} recorded`,
        description: `Logged in the ${stampedBook === "lodge" ? "LODGE" : "RESTAURANT"} book — that book's net profit absorbs it.`,
      });
      setEntryLabel("");
      setEntryAmount("");
    }
  };

  // ── mutation helper ───────────────────────────────────────────────────────
  const mutate = async (
    url: string,
    method: string,
    body?: unknown,
    okMsg?: string,
    after?: () => Promise<void>,
  ): Promise<boolean> => {
    setOpLoading(true);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Request failed");
      }
      if (after) await after();
      if (okMsg) toast({ title: okMsg });
      return true;
    } catch (e) {
      toast({
        title: "Action failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
      return false;
    } finally {
      setOpLoading(false);
    }
  };

  // two-step delete: first click arms the button, second click executes
  const confirmBtn = (key: string, onConfirm: () => void, label = "Remove") => {
    const armed = confirming === key;
    return (
      <Button
        size="sm"
        variant="ghost"
        disabled={opLoading}
        onClick={() => {
          if (armed) {
            setConfirming(null);
            onConfirm();
          } else {
            setConfirming(key);
            setTimeout(() => setConfirming((c) => (c === key ? null : c)), 3000); // auto-disarm
          }
        }}
        className={`h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider ${
          armed
            ? "bg-[var(--fx-rose)] text-white hover:bg-[var(--fx-rose)]"
            : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
        }`}
      >
        {armed ? "SURE?" : label.toUpperCase()}
      </Button>
    );
  };

  // ── inline row editing (one row in edit mode at a time) ───────────────────
  const [editing, setEditing] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState<Record<string, Record<string, string>>>({});
  const setD = (k: string, patch: Record<string, string>) =>
    setDraft((m) => ({ ...m, [k]: { ...m[k], ...patch } }));

  const startEdit = (k: string, vals: Record<string, string>) => {
    setConfirming(null);
    setEditing(k);
    setDraft((m) => ({ ...m, [k]: vals }));
  };
  const cancelEdit = () => setEditing(null);

  const editBtn = (key: string, vals: Record<string, string>) => (
    <Button
      size="sm"
      variant="ghost"
      disabled={opLoading}
      onClick={() => startEdit(key, vals)}
      className="h-8 shrink-0 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-accent-ink)]"
    >
      <Pencil className="mr-1 h-3 w-3" /> EDIT
    </Button>
  );
  const saveBtn = (onSave: () => void) => (
    <Button
      size="sm"
      disabled={opLoading}
      onClick={onSave}
      className="h-8 shrink-0 rounded-lg bg-[var(--fx-purple)] px-3 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
    >
      {opLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="mr-1 h-3 w-3" /> SAVE</>}
    </Button>
  );
  const cancelBtn = () => (
    <Button
      size="sm"
      variant="ghost"
      onClick={cancelEdit}
      aria-label="Cancel editing"
      className="h-8 w-8 shrink-0 rounded-lg p-0 text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
    >
      <X className="h-3.5 w-3.5" />
    </Button>
  );

  const saveExpense = async (x: LedgerRow, xk: string) => {
    const d = draft[xk] ?? {};
    const amount = Number(d.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast({
        title: "Amount needed",
        description: "Amount must be above zero.",
        variant: "destructive",
      });
      return;
    }
    const ok = await mutate(
      "/api/expenses",
      "PATCH",
      {
        id: x.id,
        label: (d.label ?? "").trim(),
        amount,
        spentOn: d.date,
        ...(d.book === "rest" || d.book === "lodge" ? { book: d.book } : {}),
      },
      "Entry updated",
      loadOps,
    );
    if (ok) setEditing(null);
  };

  // one mixed ledger — all four kinds (t230 adds the AUTO discount & rewards
  // day-rows, owner view only), both books, newest first
  const allExpenses: LedgerRow[] = React.useMemo(
    () =>
      [
        ...rawCosts.map((x) => ({ ...x, kind: "raw_material" as ExpenseKind })),
        ...upgCosts.map((x) => ({ ...x, kind: "upgrade" as ExpenseKind })),
        ...maintCosts.map((x) => ({ ...x, kind: "maintenance" as ExpenseKind })),
        ...discRows.map((x) => ({ ...x, kind: "discount_rewards" as ExpenseKind })),
      ].sort((a, b) => b.spentOn.localeCompare(a.spentOn)),
    [rawCosts, upgCosts, maintCosts, discRows],
  );

  /* the window drives EVERYTHING below — cards, donut, ledger */
  const winExpenses = allExpenses.filter(inWindow);
  const expShown = winExpenses.filter(
    (x) => (feedBook === "all" || x.book === feedBook) && (feedKind === "all" || x.kind === feedKind),
  );

  const sumKind = (kind: ExpenseKind, book?: Book) =>
    winExpenses.filter((x) => x.kind === kind && (!book || x.book === book)).reduce((s, x) => s + x.amount, 0);
  const countKind = (kind: ExpenseKind, book?: Book) =>
    winExpenses.filter((x) => x.kind === kind && (!book || x.book === book)).length;

  const restRows = winExpenses.filter((x) => x.book === "rest");
  const lodgeRows = winExpenses.filter((x) => x.book === "lodge");

  return (
    <div className="space-y-5">
      <TierBand
        num={FX_TIERS.expenses.num}
        eyebrow={tierEyebrow(FX_TIERS.expenses)}
        title="Expenses"
        sub={
          scoped
            ? `Your station's own cost book — enter raw materials, upgrades & maintenance for the ${scoped === "lodge" ? "LODGE" : "RESTAURANT"} below; every row stays tagged and your book's revenue absorbs it on the owner's dashboard.`
            : manager
              ? "Both businesses' cost book in one desk — pick the desk, enter raw materials, upgrades & maintenance for either book, and every row stays tagged so each book's own revenue absorbs its costs."
              : "Raw materials, upgrades & maintenance for both businesses — every row stays tagged, and each book's own revenue absorbs its costs on the dashboard. The manager enters spends for either book from the manager account."
        }
        tag={`${rangeTab.label} · ${inr(winExpenses.reduce((s, x) => s + x.amount, 0))}`}
      />

      {/* ── t99 — the window toggle that drives the whole section ── */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="fx-card inline-flex flex-wrap gap-1.5 p-1.5" role="tablist" aria-label="Expenses time range">
          {RANGE_TABS.map((t) => (
            <button
              key={t.key}
              role="tab"
              aria-selected={range === t.key}
              onClick={() => setRange(t.key)}
              data-testid={`exp-range-${t.key}`}
              className={`rounded-xl px-3.5 py-2 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
                range === t.key
                  ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
              }`}
            >
              {t.short}
            </button>
          ))}
        </div>
        <span className="mut-chip">{winExpenses.length} ENTRIES IN WINDOW</span>
      </div>

      {/* ── per-book window cards — t118: receptions see their own book only ── */}
      <div className={scoped ? "grid grid-cols-1" : "grid grid-cols-1 gap-4 sm:grid-cols-2"}>
        {(scoped ? ([scoped] as Book[]) : (["rest", "lodge"] as Book[])).map((b) => (
          <BookWindowCard
            key={b}
            b={b}
            amount={(b === "rest" ? restRows : lodgeRows).reduce((s, x) => s + x.amount, 0)}
            count={(b === "rest" ? restRows : lodgeRows).length}
            windowLabel={rangeTab.label}
          />
        ))}
      </div>

      {/* ── t129 — THE ENTRY: receptions only, ONE block with THREE type
          toggles. t232 — the MANAGER gets the same block for BOTH books:
          a RESTAURANT/LODGE toggle stamps the entry's book. The owner still
          carries no entry at all. ── */}
      {(scoped || manager) && (
        <div className="fx-card p-5" data-testid="exp-entry">
          <div className="flex flex-wrap items-center gap-3">
            <span className="fx-label inline-flex items-center gap-2">
              ENTER {manager ? "EXPENSES · BOTH BOOKS" : scoped === "lodge" ? "LODGE" : "RESTAURANT"} EXPENSES
            </span>
            {manager ? (
              /* t232 — the manager's desk toggle: which book the entry stamps */
              <span className="inline-flex gap-1.5" role="tablist" aria-label="Entry book">
                {(["rest", "lodge"] as Book[]).map((b) => (
                  <button
                    key={b}
                    onClick={() => setEntryBook(b)}
                    aria-pressed={entryBook === b}
                    data-testid={`exp-entry-book-${b}`}
                    className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] transition ${
                      entryBook === b
                        ? b === "lodge"
                          ? "bg-[var(--fx-gold)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                          : "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                        : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                    }`}
                  >
                    {b === "lodge" ? <BedDouble className="h-3.5 w-3.5" /> : <UtensilsCrossed className="h-3.5 w-3.5" />}
                    {b === "lodge" ? "LODGE" : "RESTAURANT"}
                  </button>
                ))}
              </span>
            ) : (
              <span
                data-testid={`exp-entry-book-${scoped}`}
                className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[10.5px] font-extrabold tracking-[0.09em] ${
                  scoped === "lodge"
                    ? "bg-[var(--fx-gold)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                }`}
              >
                {scoped === "lodge" ? <BedDouble className="h-3.5 w-3.5" /> : <UtensilsCrossed className="h-3.5 w-3.5" />}
                {scoped === "lodge" ? "LODGE" : "RESTAURANT"} · THIS DESK
              </span>
            )}
            <span className="ml-auto text-[10px] font-bold tracking-[0.08em] text-[var(--fx-muted)]">
              PICK THE TYPE · THE ENTRY LANDS IN THE{" "}
              <b className={(manager ? entryBook : scoped) === "lodge" ? "text-[var(--fx-gold)]" : "text-[var(--fx-accent-ink)]"}>
                {(manager ? entryBook : scoped) === "lodge" ? "LODGE" : "RESTAURANT"}
              </b>{" "}
              BOOK
            </span>
          </div>

          {/* the three type toggles */}
          <div className="mt-3 flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Expense type">
            {(["raw_material", "upgrade", "maintenance"] as ExpenseKind[]).map((k) => (
              <button
                key={k}
                onClick={() => setEntryKind(k)}
                aria-pressed={entryKind === k}
                data-testid={`exp-entry-kind-${k}`}
                className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[10.5px] font-extrabold tracking-[0.08em] transition ${
                  entryKind === k
                    ? k === "raw_material"
                      ? "bg-[#0d9488] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
                      : k === "upgrade"
                        ? "bg-[#7c3aed] text-white shadow-[2px_2px_0_0_var(--fx-hard)]"
                        : "bg-[var(--fx-amber)] text-[var(--fx-surf)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {KIND_ICON[k]} {KIND_NAME[k]}
              </button>
            ))}
          </div>

          {/* the one entry row */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Input
              value={entryLabel}
              onChange={(e) => setEntryLabel(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void addExpense();
              }}
              placeholder={
                entryKind === "raw_material"
                  ? "What? e.g. vegetables, rice, oil…"
                  : entryKind === "upgrade"
                    ? "What? e.g. new chairs, signage, sound system…"
                    : "What? e.g. gas cylinder, repairs, pest control…"
              }
              aria-label="Expense description"
              data-testid="exp-entry-label"
              className="h-10 min-w-[180px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
            />
            <Input
              value={entryAmount}
              onChange={(e) => setEntryAmount(e.target.value)}
              placeholder="₹"
              type="number"
              min={0}
              aria-label="Expense amount in rupees"
              data-testid="exp-entry-amount"
              className="fx-num h-10 w-[100px] rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
            <FxDatePicker value={entryDate} onChange={setEntryDate} ariaLabel="Expense date" />
            <Button
              onClick={() => void addExpense()}
              disabled={opLoading}
              data-testid="exp-entry-add"
              className="ml-auto h-10 rounded-xl bg-[var(--fx-purple)] px-5 text-[12px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
            >
              {opLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              ADD EXPENSE
            </Button>
          </div>
        </div>
      )}

      {/* ── t99 — THE COST-SPLIT DONUT — the expense types compared. t230 — a
          fourth AUTO slice: DISCOUNT & REWARDS (bill discounts + loyalty
          points minted, 1 pt = ₹1). t129 — REMOVED from the receptions'
          page — owner keeps it. ── */}
      {ownerView && (
        <div className="fx-card p-5" data-testid="exp-cost-split">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label">COST SPLIT · {rangeTab.label}</span>
          <span className="mut-chip">RAW MATERIALS vs UPGRADES vs MAINTENANCE vs DISCOUNT &amp; REWARDS · BOTH BOOKS</span>
        </div>
        <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
          What each expense type added up to inside the window — teal eats, violet builds, amber repairs, and the sky-blue
          DISCOUNT &amp; REWARDS slice registers itself from the bills (every discount the counters typed + every loyalty
          point minted). Move the window above to re-compare.
        </p>
        <div className="mt-3">
          <CostSplitDonut
            windowLabel={rangeTab.label}
            slices={("raw_material upgrade maintenance discount_rewards".split(" ") as ExpenseKind[]).map((k) => ({
              key: k,
              value: sumKind(k),
              count: countKind(k),
            }))}
          />
        </div>
      </div>
      )}

      {/* ── THE LEDGER — one mixed list, tagged, filterable by book AND type ── */}
      <div className="fx-card p-5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="fx-label inline-flex items-center gap-2">EXPENSE LEDGER · NEWEST FIRST</span>
          {/* t118 — the receptions' ledger reads their own book: no book filter */}
          {!scoped && (
            <div className="flex flex-wrap items-center gap-1.5">
              {([["all", "ALL BOOKS"], ["rest", "RESTAURANT"], ["lodge", "LODGE"]] as const).map(([v, l]) => (
              <button
                key={v}
                onClick={() => setFeedBook(v)}
                aria-pressed={feedBook === v}
                data-testid={`exp-book-${v}`}
                className={`rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                  feedBook === v
                    ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {l}
              </button>
            ))}
            </div>
          )}
          {/* t99 — the expense-type toggle. t230 — the AUTO DISCOUNT & REWARDS
              chip rides along for the owner; receptions never see it (they
              cannot enter it — it registers itself from the bills). */}
          <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Filter by expense type">
            {(["all", "raw_material", "upgrade", "maintenance", ...(ownerView ? (["discount_rewards"] as const) : [])] as const).map((v) => (
              <button
                key={v}
                onClick={() => setFeedKind(v)}
                aria-pressed={feedKind === v}
                data-testid={`exp-kind-${v}`}
                className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[9.5px] font-extrabold tracking-[0.09em] transition ${
                  feedKind === v
                    ? "bg-[var(--fx-ink)] text-[var(--fx-page)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {v !== "all" && KIND_ICON[v]}
                {v === "all" ? (scoped || manager ? "ALL 3 EXPENSES" : "ALL EXPENSES") : KIND_NAME[v]}
              </button>
            ))}
          </div>
          <span className="mut-chip ml-auto">{expShown.length} ENTRIES</span>
        </div>

        <ScrollFadeBox className="mt-3" maxH={420}>
          <div className="flex flex-col gap-1.5">
            {expShown.map((x) => {
              const xk = `exp:${x.id}`;
              const kindName = KIND_NAME[x.kind];
              if (editing === xk) {
                const dd = draft[xk] ?? {};
                return (
                  <div
                    key={x.id}
                    className="flex flex-wrap items-center gap-2 rounded-xl border border-[var(--fx-purple)]/40 bg-[var(--fx-lav)] px-3 py-2"
                  >
                    <Input
                      value={dd.label ?? ""}
                      onChange={(e) => setD(xk, { label: e.target.value })}
                      placeholder="What?"
                      aria-label={`Edit description of ${x.label || kindName}`}
                      className="h-9 min-w-[140px] flex-1 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
                    />
                    <Input
                      value={dd.amount ?? ""}
                      onChange={(e) => setD(xk, { amount: e.target.value })}
                      type="number"
                      min={0}
                      placeholder="₹"
                      aria-label={`Edit amount of ${x.label || kindName}`}
                      className="fx-num h-9 w-[96px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] font-bold"
                    />
                    <FxDatePicker
                      value={dd.date ?? x.spentOn.slice(0, 10)}
                      onChange={(v) => setD(xk, { date: v })}
                      ariaLabel={`Edit date of ${x.label || kindName}`}
                    />
                    <select
                      value={dd.book ?? x.book}
                      onChange={(e) => setD(xk, { book: e.target.value === "lodge" ? "lodge" : "rest" })}
                      aria-label={`Edit book of ${x.label || kindName}`}
                      className="h-9 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2 pr-7 text-[10.5px] font-extrabold text-[var(--fx-ink)]"
                    >
                      <option value="rest">RESTAURANT BOOK</option>
                      <option value="lodge">LODGE BOOK</option>
                    </select>
                    {saveBtn(() => void saveExpense(x, xk))}
                    {cancelBtn()}
                  </div>
                );
              }
              return (
                <div
                  key={x.id}
                  className="flex flex-wrap items-center gap-x-2.5 gap-y-1.5 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2"
                >
                  <span
                    className={`h-2.5 w-2.5 shrink-0 rounded-full ${KIND_DOT[x.kind]}`}
                    aria-hidden
                  />
                  <span className="min-w-[160px] flex-1">
                    <span className="flex flex-wrap items-center gap-1.5">
                      <span className="block truncate text-[13px] font-bold text-[var(--fx-ink)]">
                        {x.label || (x.kind === "raw_material" ? "Raw material" : x.kind === "upgrade" ? "Upgrade" : x.kind === "discount_rewards" ? "Discount & rewards" : "Maintenance")}
                      </span>
                      {x.via === "task" && (
                        <span
                          className="tk-crown-chip"
                          data-testid="exp-crown"
                          data-tip="Personally given by the owner — auto-registered from a completed task"
                        >
                          <Crown className="h-3 w-3" /> OWNER'S TASK
                        </span>
                      )}
                      {/* t230 — the AUTO badge: discount & rewards rows register
                          themselves from the bills — no one can edit/delete */}
                      {x.kind === "discount_rewards" && (
                        <span
                          className="rounded-full bg-[color-mix(in_srgb,#0ea5e9_14%,transparent)] px-2 py-0.5 text-[8.5px] font-extrabold tracking-wider text-[#0ea5e9]"
                          data-tip="Registered automatically from the day's bill discounts + loyalty points minted (1 pt = ₹1)"
                        >
                          AUTO
                        </span>
                      )}
                    </span>
                    <span className="text-[10.5px] font-semibold text-[var(--fx-muted)]">
                      {kindName} · {istDayLabel(x.spentOn)}
                    </span>
                  </span>
                  <BookTag b={x.book} />
                  <span className="fx-num shrink-0 text-[13px] font-extrabold text-[var(--fx-ink)]">
                    {inr(x.amount)}
                  </span>
                  <span className="ml-auto flex shrink-0 items-center gap-1 sm:ml-0">
                    {x.kind !== "discount_rewards" &&
                      editBtn(xk, {
                        label: x.label || "",
                        amount: String(x.amount),
                        date: x.spentOn.slice(0, 10),
                        book: x.book,
                      })}
                    {x.kind !== "discount_rewards" &&
                      confirmBtn(xk, () =>
                        void mutate(`/api/expenses?id=${x.id}`, "DELETE", undefined, "Entry deleted", loadOps),
                      )}
                  </span>
                </div>
              );
            })}
            {expShown.length === 0 && (
              <p className="py-8 text-center text-[13px] font-semibold text-[var(--fx-muted)]">
                {winExpenses.length === 0
                  ? scoped || manager
                    ? "No expenses in this window yet — enter the spends above."
                    : "No expenses in this window yet — the manager enters spends from the manager account."
                  : "Nothing under this filter — widen the toggle or switch the book / expense type."}
              </p>
            )}
          </div>
        </ScrollFadeBox>
        <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
          {ownerView
            ? "One mixed ledger — raw materials in teal, upgrades in violet, maintenance in amber, and the AUTO discount & rewards day-rows in sky blue (registered from the bills — read-only, no edit, no delete). Every row tagged with its book; crown rows came from the owner's tasks. The receptions' page never shows the auto kind — they cannot enter it. The dashboard subtracts each book's costs from that book's own revenue."
            : "One mixed ledger — raw materials in teal, upgrades in violet, maintenance in amber. Every row tagged with its book; crown rows came from the owner's tasks. The dashboard subtracts each book's costs from that book's own revenue."}
        </p>
      </div>
    </div>
  );
}
