"use client";

/**
 * t230 — CAMPAIGNING — the mass-message feature's own dedicated section.
 * t232 — the section moved OFF the receptions into the MANAGER account.
 * t233 — NO BUSINESS TOGGLE ANYMORE: one franchise, one customer book, one
 * universal points wallet (a dinner and a stay draw the same balance), so the
 * manager's campaigning drops the RESTAURANT DESK / LODGE DESK picker — every
 * send is franchise-wide and stamped MANAGER. Recent sends live in their own
 * collapsible block (see customer-broadcast).
 */

import { Megaphone } from "lucide-react";
import { TierBand } from "@/components/fx";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { CustomerBroadcast } from "@/components/customer-broadcast";

export function CampaignView({ book, manager }: { book?: "rest" | "lodge"; manager?: boolean }) {
  return (
    <div className="flex flex-col gap-5">
      <TierBand
        num={FX_TIERS.campaign.num}
        eyebrow={tierEyebrow(FX_TIERS.campaign)}
        title="Campaigning"
        sub={
          manager
            ? "One franchise, one outreach desk — every saved wallet of both businesses in a single send, personalised by placeholder or broadcast word-for-word. Points are universal, so there is no desk to pick."
            : "The counters' outreach desk — one message to every saved wallet, personalised by placeholder or broadcast word-for-word."
        }
      >
        {manager ? (
          <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]" data-testid="campaign-franchise-chip">
            <Megaphone className="mr-1.5 inline h-3.5 w-3.5" />
            ONE FRANCHISE · BOTH DESKS
          </span>
        ) : (
          <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">
            <Megaphone className="mr-1.5 inline h-3.5 w-3.5" />
            {book === "lodge" ? "LODGE FRONT DESK" : "RESTAURANT COUNTER"}
          </span>
        )}
      </TierBand>
      {/* t233 — the manager passes NO book: franchise mode (points universal,
          no desk stamp) — sends wear MANAGER and carry book "franchise". */}
      <CustomerBroadcast book={manager ? undefined : (book ?? "rest")} senderLabel={manager ? "MANAGER" : undefined} />
    </div>
  );
}
