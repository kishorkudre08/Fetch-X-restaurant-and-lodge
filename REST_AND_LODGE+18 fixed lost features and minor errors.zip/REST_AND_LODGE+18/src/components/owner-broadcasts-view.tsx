"use client";

/**
 * t230 — MASS MESSAGES — the owner's preview of everything the two counters
 * campaigned to the customer base (styled after the owner's Expenses section).
 * A WINDOW toggle (7 DAYS · 1 MONTH · 3 MONTHS · 1 YEAR) drives the whole
 * section, and a TYPE toggle (ALL · NOTICE · PERSONAL) splits the log:
 * personal sends carry {NAME}/{POINTS} placeholders and were rendered per
 * customer; notices are the word-for-word advertisement blasts.
 *
 * t231 — the TOP CUSTOMERS · ALL TIME ledger (the 100 biggest spenders across
 * BOTH books) moved here OFF the live dashboard: this is the campaigning
 * audience — the list to aim the next campaign (or reward) at — scrolled
 * INSIDE its card below the send log.
 *
 * t235 — the recipient-count cards are GONE (user): the three cards beside
 * SENDS are loyalty-points cards now — points customers hold RIGHT NOW, and
 * (inside the selected window) points used + distinct customers using them.
 */

import * as React from "react";
import { Coins, Megaphone, MessageSquare, RefreshCcw, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TierBand } from "@/components/fx";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { useCachedToggle } from "@/lib/view-state-cache";
import { useRegisterScreen } from "@/lib/screen-context";
import type { BroadcastAttachment } from "@/lib/types";
import { inr, num } from "@/lib/format";

type BroadcastRow = {
  id: string;
  audience: string;
  threshold: number | null;
  recipients: number;
  message: string;
  notice: string;
  sample: string;
  book: string;
  sentBy: string;
  attachments: BroadcastAttachment[]; // t236 — the campaign's photos/videos
  createdAt: string;
};

// t231 — one row of the audience ledger (same shape the dashboard payload
// carries; served standalone by /api/top-customers)
type TopRow = {
  phone: string;
  name: string | null;
  visits: number;
  restSpend: number;
  lodgeSpend: number;
  total: number;
  points: number;
  lastSeen: string | null;
};

type WinKey = "7d" | "1m" | "3m" | "1y";
type TypeKey = "all" | "notice" | "personal";

const WINDOWS: Array<{ key: WinKey; short: string; label: string }> = [
  { key: "7d", short: "7 DAYS", label: "LAST 7 DAYS" },
  { key: "1m", short: "1 MONTH", label: "THIS MONTH" },
  { key: "3m", short: "3 MONTHS", label: "LAST 3 MONTHS" },
  { key: "1y", short: "1 YEAR", label: "LAST 1 YEAR" },
];

const TYPES: Array<{ key: TypeKey; short: string }> = [
  { key: "all", short: "ALL" },
  { key: "notice", short: "NOTICE" },
  { key: "personal", short: "PERSONAL" },
];

const audienceLabel = (a: string): string => {
  const map: Record<string, string> = {
    all: "ALL CUSTOMERS",
    pts_500: "500+ PTS",
    pts_1000: "1000+ PTS",
    pts_3000: "3000+ PTS",
    custom: "CUSTOM",
  };
  return map[a] ?? a.toUpperCase();
};

export function OwnerBroadcastsView() {
  const [win, setWin] = useCachedToggle<WinKey>("broadcasts", "win", "1m");
  const [type, setType] = useCachedToggle<TypeKey>("broadcasts", "type", "all");

  const [rows, setRows] = React.useState<BroadcastRow[] | null>(null);
  const [loading, setLoading] = React.useState(false);
  // t235 — the loyalty-points summary that drives the three new cards
  const [pts, setPts] = React.useState<{ live: number; used: number; users: number } | null>(null);
  // t231 — the audience ledger (TOP 100, both books)
  const [custs, setCusts] = React.useState<TopRow[] | null>(null);

  useRegisterScreen("broadcasts", "Mass Messages", {
    win,
    type,
    topShown: (custs ?? []).length,
  });

  const load = React.useCallback(() => {
    setLoading(true);
    fetch(`/api/broadcasts?window=${win}&type=${type}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        setRows(Array.isArray(d.broadcasts) ? d.broadcasts : []);
        setPts(d.points ?? null);
      })
      .catch(() => {
        setRows([]);
        setPts(null);
      })
      .finally(() => setLoading(false));
  }, [win, type]);

  const loadCusts = React.useCallback(() => {
    fetch("/api/top-customers", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setCusts(Array.isArray(d.topCustomers) ? d.topCustomers : []))
      .catch(() => setCusts([]));
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  React.useEffect(() => {
    loadCusts();
  }, [loadCusts]);

  const winLabel = WINDOWS.find((w) => w.key === win)?.label ?? "LAST 7 DAYS";
  const sends = rows ?? [];
  const personalN = sends.filter((r) => !!r.message.trim()).length;
  const noticeN = sends.length - personalN;

  return (
    <div className="flex flex-col gap-5">
      <TierBand
        num={FX_TIERS.broadcasts.num}
        eyebrow={tierEyebrow(FX_TIERS.broadcasts)}
        title="Mass Messages"
        sub="Every campaign the counters fired at the saved customer base — personalised sends and plain notices, exactly as they went out."
      >
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            load();
            loadCusts();
          }}
          disabled={loading}
          className="rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] text-[11px] font-extrabold tracking-wider"
          data-testid="omb-refresh"
        >
          <RefreshCcw className={`mr-1.5 h-3.5 w-3.5${loading ? " animate-spin" : ""}`} /> REFRESH
        </Button>
      </TierBand>

      {/* window + type toggles (expenses-style) */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Mass message window">
          {WINDOWS.map((w) => (
            <button
              key={w.key}
              onClick={() => setWin(w.key)}
              aria-pressed={win === w.key}
              className={`scope-chip${win === w.key ? " on" : ""}`}
              data-testid={`omb-win-${w.key}`}
            >
              {w.short}
            </button>
          ))}
        </div>
        <span className="scope-spacer" />
        <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Message type">
          <span className="fx-label mr-1">TYPE</span>
          {TYPES.map((t) => (
            <button
              key={t.key}
              onClick={() => setType(t.key)}
              aria-pressed={type === t.key}
              className={`scope-chip${type === t.key ? " on" : ""}`}
              data-testid={`omb-type-${t.key}`}
            >
              {t.short}
            </button>
          ))}
        </div>
      </div>

      {/* window stat cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <div className="fx-card px-5 py-4">
          <div className="flex items-center justify-between gap-3">
            <span className="fx-label">SENDS · {winLabel}</span>
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
              <Megaphone className="h-4 w-4" />
            </span>
          </div>
          <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">{sends.length}</div>
          <div className="mt-1 h-4 text-[11px] font-semibold text-[var(--fx-muted)]">
            {personalN} PERSONAL · {noticeN} NOTICE
          </div>
        </div>
        <div className="fx-card px-5 py-4" data-testid="omb-pts-live">
          <div className="flex items-center justify-between gap-3">
            <span className="fx-label">POINTS WITH CUSTOMERS</span>
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
              <Coins className="h-4 w-4" />
            </span>
          </div>
          {/* t235 — the wallets' live balance RIGHT NOW (not window-bound) */}
          <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">{pts ? num(pts.live) : "…"}</div>
          <div className="mt-1 h-4 text-[11px] font-semibold text-[var(--fx-muted)]">LIVE BALANCE · 1 PT = ₹1 OFF</div>
        </div>
        <div className="fx-card px-5 py-4" data-testid="omb-pts-used">
          <div className="flex items-center justify-between gap-3">
            <span className="fx-label">POINTS USED · {winLabel}</span>
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]">
              <Coins className="h-4 w-4" />
            </span>
          </div>
          {/* t235 — points redeemed on bills inside the selected window */}
          <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">{pts ? num(pts.used) : "…"}</div>
          <div className="mt-1 h-4 text-[11px] font-semibold text-[var(--fx-muted)]">REDEEMED AT BOTH COUNTERS</div>
        </div>
        <div className="fx-card px-5 py-4" data-testid="omb-pts-users">
          <div className="flex items-center justify-between gap-3">
            <span className="fx-label">USING POINTS · {winLabel}</span>
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]">
              <Users className="h-4 w-4" />
            </span>
          </div>
          {/* t235 — distinct customers who redeemed inside the window */}
          <div className="fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">{pts ? num(pts.users) : "…"}</div>
          <div className="mt-1 h-4 text-[11px] font-semibold text-[var(--fx-muted)]">CUSTOMERS WHO REDEEMED</div>
        </div>
      </div>

      {/* the log ledger */}
      <div className="fx-card fx-rise p-5" data-testid="omb-ledger">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label">{winLabel} · {type === "personal" ? "PERSONAL SENDS" : type === "notice" ? "NOTICES" : "ALL SENDS"}</span>
          <span className="flex items-center gap-1.5">
            <span className="mut-chip">NEWEST FIRST</span>
            <span className="mut-chip">BOTH COUNTERS</span>
          </span>
        </div>
        <div className="mt-3 space-y-2">
          {rows === null && (
            <p className="rounded-xl border border-dashed border-[var(--fx-line)] px-4 py-6 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
              LOADING THE SEND LOG…
            </p>
          )}
          {rows !== null && rows.length === 0 && (
            <p className="rounded-xl border border-dashed border-[var(--fx-line)] px-4 py-6 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
              No {type === "personal" ? "personal messages" : type === "notice" ? "notices" : "sends"} in this window — the counters' campaigns will land here the moment they fire one.
            </p>
          )}
          {(rows ?? []).map((h) => {
            const personal = !!h.message.trim();
            return (
              <div key={h.id} className="feed-row" data-testid="omb-row">
                <span className="f-av">{personal ? <MessageSquare className="h-3.5 w-3.5" /> : <Megaphone className="h-3.5 w-3.5" />}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[12px] font-extrabold text-[var(--fx-ink)]">{h.sentBy}</span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[8.5px] font-extrabold tracking-wider ${
                        personal
                          ? "bg-[color-mix(in_srgb,var(--fx-green)_14%,transparent)] text-[var(--fx-green)]"
                          : "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
                      }`}
                    >
                      {personal ? "PERSONAL MESSAGE" : "NOTICE"}
                    </span>
                    <span className="mut-chip">{audienceLabel(h.audience)}{h.audience === "custom" && h.threshold ? ` · ≥ ${h.threshold}` : ""}</span>
                    <span className="mut-chip">{h.recipients} RECIPIENTS</span>
                    <span
                      className="shrink-0 rounded-full px-2.5 py-1 text-[8.5px] font-extrabold tracking-[0.09em]"
                      style={
                        // t233 — franchise rows: the manager's no-desk campaigning
                        h.book === "franchise"
                          ? { background: "color-mix(in srgb, var(--fx-purple) 14%, transparent)", color: "var(--fx-purple)" }
                          : h.book === "lodge"
                            ? { background: "color-mix(in srgb, var(--fx-gold) 14%, transparent)", color: "var(--fx-gold)" }
                            : { background: "var(--fx-lav)", color: "var(--fx-accent-ink)" }
                      }
                    >
                      {h.book === "franchise" ? "FRANCHISE" : h.book === "lodge" ? "LODGE DESK" : "RESTAURANT DESK"}
                    </span>
                    <span className="text-[10px] font-bold text-[var(--fx-muted)]">
                      {new Date(h.createdAt).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}
                    </span>
                  </div>
                  <p className="mt-1 text-[11.5px] font-semibold leading-relaxed text-[var(--fx-muted)]">
                    “{personal ? h.sample || h.message : h.notice}”
                  </p>
                  {/* t236 — the owner sees the FILES the sender campaigned with:
                      photos render as thumbnails, videos as inline players */}
                  {(h.attachments?.length ?? 0) > 0 && (
                    <div className="mt-2 flex flex-wrap items-center gap-2" data-testid="omb-row-atts">
                      {h.attachments.map((a, i) =>
                        a.kind === "video" ? (
                          <video key={i} src={a.url} controls preload="metadata" className="h-24 w-36 rounded-lg border border-[var(--fx-line)] bg-black object-cover" data-testid="omb-att-video" />
                        ) : (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img key={i} src={a.url} alt={a.name} className="h-20 w-28 rounded-lg border border-[var(--fx-line)] object-cover" data-testid="omb-att-img" />
                        ),
                      )}
                      <span className="mut-chip">{h.attachments.length} {h.attachments.length === 1 ? "FILE" : "FILES"} · SENT WITH THE CAMPAIGN</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11.5px] font-medium text-[var(--fx-muted)]">
          PERSONAL rows show the rendered copy of the biggest matching wallet — the exact words that customer received. Campaigns that carried
          media wear their photos and videos right on the row. There is no
          SMS gateway in this build: the log row IS the send, counted server-side from the live wallets at the moment the counter
          pressed SEND.
        </p>
      </div>

      {/* t231 — TOP CUSTOMERS · ALL TIME: the campaigning audience, moved here
          off the live dashboard. The 100 biggest spenders across BOTH books
          (every restaurant bill + lodge stay keyed to the same 10-digit
          phone), scrolled INSIDE the card (sticky header, internal scrollbar),
          so 100 rows never stretch the section. This is the list to aim the
          next campaign — or reward — at. */}
      <div className="fx-card fx-rise p-5" data-testid="top-customers">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="fx-label inline-flex items-center gap-2">
            <Users className="h-3.5 w-3.5" />
            TOP CUSTOMERS · ALL TIME
          </span>
          <span className="flex items-center gap-1.5">
            <span className="mut-chip">TOP 100 · BOTH BOOKS</span>
            <span className="mut-chip">KEYED BY 10-DIGIT PHONE</span>
            <span className="mut-chip">CAMPAIGN AUDIENCE</span>
          </span>
        </div>
        {/* INTERNAL SCROLL: a fixed-height pane scrolls the ledger inside the
            card (sticky column heads ride along) */}
        <div className="fx-scroll mt-3 max-h-[560px] overflow-y-auto">
          <table className="w-full min-w-[880px] text-left">
            <thead className="sticky top-0 z-10 bg-[var(--fx-surf)]">
              <tr className="fx-label border-b border-[var(--fx-line)]">
                <th className="py-2 pr-3 font-extrabold">#</th>
                <th className="py-2 pr-3 font-extrabold">CUSTOMER</th>
                <th className="py-2 pr-3 font-extrabold">PHONE</th>
                <th className="py-2 pr-3 text-right font-extrabold">VISITS</th>
                <th className="py-2 pr-3 text-right font-extrabold">FOOD &amp; BEV</th>
                <th className="py-2 pr-3 text-right font-extrabold">ROOMS &amp; STAYS</th>
                <th className="py-2 pr-3 text-right font-extrabold">TOTAL SPEND</th>
                <th className="py-2 pr-3 text-right font-extrabold">POINTS</th>
                <th className="py-2 text-right font-extrabold">LAST SEEN</th>
              </tr>
            </thead>
            <tbody>
              {custs === null && (
                <tr>
                  <td colSpan={9} className="py-6 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                    LOADING THE AUDIENCE…
                  </td>
                </tr>
              )}
              {custs !== null && custs.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-6 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                    No keyed customers yet — the first named bill or lodge stay will open this ledger.
                  </td>
                </tr>
              )}
              {(custs ?? []).map((c, i) => (
                <tr
                  key={c.phone}
                  className="border-b border-[var(--fx-line)] text-[12px] font-semibold"
                  data-testid={`top-cust-${i + 1}`}
                >
                  <td className="py-2.5 pr-3"><span className="rk-n fx-num">{String(i + 1).padStart(2, "0")}</span></td>
                  <td className="max-w-[180px] truncate py-2.5 pr-3 font-extrabold text-[var(--fx-ink)]">{c.name ?? "WALK-IN"}</td>
                  <td className="py-2.5 pr-3 fx-num text-[var(--fx-muted)]">{c.phone}</td>
                  <td className="py-2.5 pr-3 text-right fx-num">{num(c.visits)}</td>
                  <td className="py-2.5 pr-3 text-right fx-num">{inr(c.restSpend)}</td>
                  <td className="py-2.5 pr-3 text-right fx-num">{inr(c.lodgeSpend)}</td>
                  <td className="py-2.5 pr-3 text-right fx-num font-extrabold text-[var(--fx-ink)]">{inr(c.total)}</td>
                  <td className="py-2.5 pr-3 text-right fx-num text-[var(--fx-accent-ink)]">{num(c.points)} PTS</td>
                  <td className="py-2.5 text-right fx-num text-[var(--fx-muted)]">
                    {c.lastSeen ? new Date(c.lastSeen).toLocaleDateString("en-IN", { day: "numeric", month: "short" }).toUpperCase() : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-[11.5px] font-medium text-[var(--fx-muted)]">
          The campaigning audience at a glance — the top 100 of every wallet the counters have ever keyed, scrolled inside the card. Restaurant bills and lodge stays keyed to the same 10-digit phone, summed across both businesses. POINTS is the customer's live loyalty balance (1 pt = ₹1 of future bills) and the rank decides which earn % they mint next — fire the next campaign at this list from either counter's CAMPAIGNING section.
        </p>
      </div>
    </div>
  );
}
