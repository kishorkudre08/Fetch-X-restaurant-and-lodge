"use client";

/**
 * t226/t227 — the chart-shape switch behind every donut diagram.
 *
 * t227 made it UNIVERSAL, per the owner: "I want the toggle to be universal
 * in settings, one for all". One PIE ⇄ DONUT lever lives in the owner's
 * Settings (CHART SHAPE card) and rules EVERY donut at once — dashboard
 * rings, expenses split, lodge room wall. One localStorage key + one custom
 * event, so flipping the lever repaints every mounted donut on the spot and
 * the choice survives reloads. DONUT stays the default: the classic ring
 * with the figure in the hole and the squeezed legend on the right. PIE
 * keeps that exact layout — the ring simply fills solid and the hole-figure
 * rides ON the pie, one size smaller (a pie has no hole). t230 — in BOTH
 * shapes the centre figure stays put; hovering a slice pops the TOOLTIP
 * outside the figure (a floating pill above the chart), so the two never
 * fight for the same pixels.
 */

import * as React from "react";

export type DonutMode = "donut" | "pie";

const MODE_KEY = "fx-donut-mode";
const MODE_EVENT = "fx-donut-mode-change";

function readMode(): DonutMode {
  if (typeof window === "undefined") return "donut";
  try {
    return window.localStorage.getItem(MODE_KEY) === "pie" ? "pie" : "donut";
  } catch {
    return "donut";
  }
}

/**
 * The universal chart-shape mode. Every donut reads it; only the Settings
 * lever writes it. All readers (and other browser tabs) sync live.
 */
export function useDonutMode(): [DonutMode, (m: DonutMode) => void] {
  const [mode, setMode] = React.useState<DonutMode>(readMode);
  React.useEffect(() => {
    const sync = () => setMode(readMode());
    window.addEventListener(MODE_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(MODE_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  const set = React.useCallback((m: DonutMode) => {
    setMode(m);
    try {
      window.localStorage.setItem(MODE_KEY, m);
    } catch {
      /* private browsing — the lever still works for this session */
    }
    window.dispatchEvent(new Event(MODE_EVENT));
  }, []);
  return [mode, set];
}

/** The segmented pill — lives ONCE, in the owner's Settings CHART SHAPE card. */
export function DonutModeToggle({ testId = "chart-shape-toggle" }: { testId?: string }) {
  const [mode, set] = useDonutMode();
  return (
    <span className="donut-mode-tg" role="group" aria-label="Chart shape" data-testid={testId}>
      <button
        type="button"
        className={mode === "pie" ? "on" : ""}
        aria-pressed={mode === "pie"}
        onClick={() => set("pie")}
        data-testid={`${testId}-pie`}
      >
        PIE
      </button>
      <button
        type="button"
        className={mode === "donut" ? "on" : ""}
        aria-pressed={mode === "donut"}
        onClick={() => set("donut")}
        data-testid={`${testId}-donut`}
      >
        DONUT
      </button>
    </span>
  );
}
