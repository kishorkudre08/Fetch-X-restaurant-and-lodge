"use client";

// ── t230 · LOYALTY RANKS — the rank categorizer (owner only, Settings) ──────
// Just like ROOMS & RATES: the owner slices the customer base — this time by
// ALL-TIME SPEND RANK (1 = the biggest spender across BOTH books) — into
// ranges, each earning its own % of what they pay. Ranges must start at rank
// 1, no gaps or overlaps; the LAST range may be left open-ended (TO blank)
// to catch everyone beyond it. Customers outside every range mint the base
// LOYALTY % (the other Settings card). The receptions can't touch any of it
// — they only SEE a ranked customer's tier at billing and may hand a bonus.

import * as React from "react";
import { Award, Loader2, Plus, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

type TierDraft = { label: string; from: string; to: string; pct: string };

export function LoyaltyTiersEditor() {
  const { toast } = useToast();

  const [tiers, setTiers] = React.useState<Array<{ id: string; label: string; fromRank: number; toRank: number | null; earnPct: number }> | null>(null);
  const [draft, setDraft] = React.useState<TierDraft[]>([]);
  const [busy, setBusy] = React.useState(false);
  const [armedRemove, setArmedRemove] = React.useState<number | null>(null);
  const [editMode, setEditMode] = React.useState(false);

  const load = React.useCallback(async () => {
    try {
      const d = await fetch("/api/loyalty-tiers", { cache: "no-store" }).then((x) => x.json());
      const rows = Array.isArray(d.tiers) ? d.tiers : [];
      setTiers(rows);
      setDraft(rows.map((r: { label: string; fromRank: number; toRank: number | null; earnPct: number }) => ({
        label: r.label,
        from: String(r.fromRank),
        to: r.toRank === null ? "" : String(r.toRank),
        pct: String(r.earnPct),
      })));
    } catch {
      setTiers(null);
    }
  }, []);
  React.useEffect(() => {
    void load();
  }, [load]);

  const setAt = (i: number, patch: Partial<TierDraft>) =>
    setDraft((m) => m.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const check = (): { ok: boolean; msg: string | null; bad: Set<number> } => {
    const bad = new Set<number>();
    const rows = draft.map((r, i) => ({
      i,
      label: r.label.trim().toUpperCase(),
      from: Math.round(Number(r.from)),
      to: r.to.trim() === "" ? null : Math.round(Number(r.to)),
      pct: Math.round(Number(r.pct)),
    }));
    if (!rows.length) return { ok: false, msg: "Add at least one rank range — or leave the whole table empty and every customer earns the base %.", bad };
    rows.forEach((r) => {
      if (!r.label) bad.add(r.i);
      if (!Number.isFinite(r.pct) || r.pct < 0 || r.pct > 100) bad.add(r.i);
      if (!Number.isFinite(r.from) || r.from < 1) bad.add(r.i);
      if (r.to !== null && (!Number.isFinite(r.to) || r.to < r.from)) bad.add(r.i);
    });
    const sorted = [...rows].sort((a, b) => a.from - b.from);
    let msg: string | null = null;
    if (sorted.some((r) => bad.has(r.i))) {
      msg = "Fix the highlighted rows — every range needs a name, a FROM rank ≥ 1, an earn % between 0 and 100, and a TO rank not below FROM (blank TO = open-ended).";
    } else if (sorted[0].from !== 1) {
      bad.add(sorted[0].i);
      msg = `The first range must start at rank 1 — it starts at ${sorted[0].from}.`;
    } else {
      for (let j = 1; j < sorted.length; j++) {
        const prev = sorted[j - 1];
        const cur = sorted[j];
        if (prev.to === null) {
          bad.add(prev.i); bad.add(cur.i);
          msg = `"${prev.label}" is open-ended (no TO) — no range can sit after it. Give it a TO rank or drop "${cur.label}".`;
          break;
        }
        if (cur.from <= prev.to) {
          bad.add(prev.i); bad.add(cur.i);
          msg = `OVERLAP — "${prev.label}" and "${cur.label}" both claim rank ${cur.from}. No two ranges may share a rank.`;
          break;
        }
        if (cur.from > prev.to + 1) {
          bad.add(prev.i); bad.add(cur.i);
          msg = `GAP — ranks ${prev.to + 1}–${cur.from - 1} belong to no range. Extend "${prev.label}" or "${cur.label}" to cover them.`;
          break;
        }
      }
      if (!msg) {
        const names = rows.map((r) => r.label);
        if (new Set(names).size !== names.length) {
          rows.forEach((r) => { if (names.indexOf(r.label) !== r.i) bad.add(r.i); });
          msg = "Two ranges share a name — rename one.";
        }
      }
    }
    return { ok: !msg, msg, bad };
  };
  const ck = check();

  const addRange = () => {
    if (draft.length >= 12) {
      toast({ title: "Twelve ranges is the limit", description: "Merge two ranges instead of adding more." });
      return;
    }
    const last = draft[draft.length - 1];
    const nextFrom = last ? (last.to.trim() === "" ? Number(last.from) + 1 : Number(last.to) + 1) : 1;
    setDraft((m) => [...m, { label: `RANK RANGE ${m.length + 1}`, from: String(Math.max(1, nextFrom)), to: "", pct: "5" }]);
  };

  const removeRange = (i: number) => {
    setDraft((m) => m.filter((_, j) => j !== i));
    setArmedRemove(null);
  };

  const apply = async () => {
    if (!ck.ok || busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/loyalty-tiers", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tiers: draft.map((r) => ({
            label: r.label.trim().toUpperCase(),
            fromRank: Math.round(Number(r.from)),
            toRank: r.to.trim() === "" ? null : Math.round(Number(r.to)),
            earnPct: Math.round(Number(r.pct)),
          })),
        }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Save failed");
      toast({
        title: "Loyalty ranks applied",
        description: "Every future bill now mints points by the customer's rank — the docks and the ledger rebuild on the next read.",
      });
      setEditMode(false);
      await load();
    } catch (e) {
      toast({
        title: "Could not save the rank ranges",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fx-card fx-rise p-5" data-testid="loyalty-tiers-editor" data-fx-motion="1">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          <Award className="h-3.5 w-3.5" /> LOYALTY RANKS · EARN % BY SPEND RANK
        </span>
        <div className="flex items-center gap-2">
          <span className="mut-chip">
            {tiers?.length ? `${tiers.length} RANGES` : "NO RANGES · BASE % FOR ALL"}
          </span>
          {!editMode && (
            <Button
              onClick={() => setEditMode(true)}
              className="h-8 rounded-xl bg-[var(--fx-purple)] px-4 text-[10px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
            >
              EDIT
            </Button>
          )}
          {editMode && (
            <Button
              onClick={() => { setEditMode(false); setArmedRemove(null); void load(); }}
              className="h-8 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
            >
              CANCEL EDIT
            </Button>
          )}
        </div>
      </div>

      {/* ── READ-ONLY mode ── */}
      {!editMode && tiers && (
        <div className="mt-3 space-y-1.5">
          {tiers.length === 0 && (
            <p className="rounded-xl border border-dashed border-[var(--fx-line)] px-3 py-2 text-[11.5px] font-semibold text-[var(--fx-muted)]">
              No rank ranges yet — every customer earns the flat base % below. Press EDIT to craft the first ones.
            </p>
          )}
          {tiers.map((lv, i) => (
            <div key={lv.id} className="flex items-center gap-2 rounded-xl bg-[var(--fx-lav)]/40 px-3 py-2">
              <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${i % 3 === 0 ? "bg-[var(--fx-green)]" : i % 3 === 1 ? "bg-[#f97316]" : "bg-[var(--fx-purple)]"}`} aria-hidden />
              <span className="min-w-[100px] flex-1 text-[13px] font-extrabold text-[var(--fx-ink)]">{lv.label}</span>
              <span className="text-[11px] font-bold text-[var(--fx-muted)]">
                RANK {lv.fromRank} – {lv.toRank === null ? "∞ (everyone beyond)" : lv.toRank}
              </span>
              <span className="text-[11px] font-extrabold text-[var(--fx-accent-ink)]">{lv.earnPct}% EARN</span>
            </div>
          ))}
          <p className="mt-2 text-[10px] font-semibold text-[var(--fx-muted)]">
            Rank 1 = the biggest spender across BOTH businesses (all-time). A customer whose rank falls in a range mints that
            range's % of what they pay instead of the base % — the better the rank, the richer the earn. The receptions see
            the badge at billing and may hand ranked customers a bonus; only the owner edits this table.
          </p>
        </div>
      )}

      {/* ── EDIT mode ── */}
      {editMode && (
        <>
          <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
            Name each range, set its rank span and the earn %. Ranges must start at rank 1 with no gaps or overlaps; the LAST
            range may leave TO empty (open-ended — catches everyone beyond). Everyone outside every range earns the base %.
          </p>
          <div className="mt-3 flex flex-col gap-2">
            {draft.map((t, i) => {
              const bad = ck.bad.has(i);
              return (
                <div key={i} className="flex flex-wrap items-center gap-2">
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${bad ? "bg-[var(--fx-rose)]" : i % 3 === 0 ? "bg-[var(--fx-green)]" : i % 3 === 1 ? "bg-[#f97316]" : "bg-[var(--fx-purple)]"}`} aria-hidden />
                  <Input value={t.label} onChange={(e) => setAt(i, { label: e.target.value })} placeholder="Range name" aria-label={`Range ${i + 1} name`} className={`h-9 min-w-[120px] flex-[1.4] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">RANK</span>
                  <Input value={t.from} onChange={(e) => setAt(i, { from: e.target.value })} type="number" min={1} aria-label={`Range ${i + 1} first rank`} className={`fx-num h-9 w-[72px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">TO</span>
                  <Input value={t.to} onChange={(e) => setAt(i, { to: e.target.value.replace(/[^0-9]/g, "") })} placeholder="∞" type="number" min={1} aria-label={`Range ${i + 1} last rank (blank = open-ended)`} className={`fx-num h-9 w-[72px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <Input value={t.pct} onChange={(e) => setAt(i, { pct: e.target.value })} type="number" min={0} max={100} aria-label={`Range ${i + 1} earn percent`} className={`fx-num h-9 w-[72px] rounded-xl bg-[var(--fx-page)] font-bold ${bad ? "border-[var(--fx-rose)]" : "border-[var(--fx-line)]"}`} />
                  <span className="text-[9.5px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">% EARN</span>
                  {armedRemove === i ? (
                    <Button size="sm" onClick={() => removeRange(i)} className="h-9 rounded-xl bg-[var(--fx-rose)] px-3 text-[10px] font-extrabold tracking-wider text-white">SURE?</Button>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => setArmedRemove(i)} data-tip="Drop this range" className="h-9 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 text-[10px] font-extrabold tracking-wider text-[var(--fx-muted)]">REMOVE</Button>
                  )}
                </div>
              );
            })}
          </div>
          {ck.msg && (
            <p role="alert" className="mt-3 rounded-xl border border-[var(--fx-rose)]/40 bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold text-[var(--fx-rose)]">{ck.msg}</p>
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button onClick={addRange} className="h-9 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-lav)]">
              <Plus className="h-3.5 w-3.5" /> ADD RANGE
            </Button>
            <Button onClick={() => void apply()} disabled={!ck.ok || busy} className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-50">
              {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} APPLY RANKS
            </Button>
            {!ck.ok && <span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-rose)]">FIX THE RANGES TO ENABLE APPLY</span>}
          </div>
        </>
      )}
    </div>
  );
}
