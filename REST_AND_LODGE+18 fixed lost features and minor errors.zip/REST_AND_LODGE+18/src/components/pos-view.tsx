"use client";

// ── POS Terminal — the counter bills, the owner runs the menu ───────────────
// t98: the menu editor moved here from Management. t115: the OWNER's screen is
// the MENU MANAGER — menu control only (no billing dock, no bills feed, no
// expense entry — the counter bills, the stations keep their own expenses).
// Every removal (a dish or a whole section) opens a WARNING dialog that stays
// LOCKED for 10 seconds before the delete can fire. The receptions keep the
// pure counter: tap dishes → generate the bill.

import * as React from "react";
import { Minus, Plus, Receipt, Search, Trash2, Loader2, Pencil, Zap, LayoutGrid, Check, X, AlertTriangle, ChevronDown, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand, VegDot, ScrollFadeBox } from "@/components/fx";
import { BillsFeed } from "@/components/bills-feed";
import { useReceipt } from "@/components/receipt-dialog";
import { useHotel } from "@/components/hotel-context";
import { useToast } from "@/hooks/use-toast";
import { ORDER_TYPES, orderTypeLabel, type Bill, type Category, type Dish, type OrderType } from "@/lib/types";
import { bindFxTouchScroll } from "@/lib/fx-touch";
import { inr, inr2, istTime } from "@/lib/format";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";

const GST_RATE = 0.05;

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-");

/* t224 — the customer tag for bills-feed rows: "Name · 10-digit-phone" when
   the counter keyed a customer identity above the totals, empty otherwise. */
const customerTag = (b: Bill): string => {
  const parts = [b.customerName, b.customerPhone].filter(Boolean).join(" · ");
  return parts ? `${parts} · ` : "";
};

type CartLine = { dish: Dish; qty: number };

// ── the owner's blank add-dish block — one in every single-section view ──────
// t152 — the blended ALL grid no longer carries an ADD DISH block (owner's
// ask): adding happens from the SECTION view only — tap a category chip and
// use that section's trailing block.
function AddDishTile({
  category,
  onAdded,
}: {
  category: string;
  onAdded: () => void;
}) {
  const { toast } = useToast();
  const [cat, setCat] = React.useState(category);
  React.useEffect(() => setCat(category), [category]);
  const [name, setName] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [veg, setVeg] = React.useState(true);
  const [busy, setBusy] = React.useState(false);

  const add = async () => {
    const amt = Number(price);
    if (!name.trim() || !Number.isFinite(amt) || amt <= 0) {
      toast({
        title: "Missing details",
        description: "The dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/menu", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), price: amt, category: cat, veg }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not add the dish");
      toast({ title: `“${name.trim()}” added to ${cat}` });
      setName("");
      setPrice("");
      setVeg(true);
      onAdded();
    } catch (e) {
      toast({
        title: "Could not add the dish",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/45 px-3.5 py-3 text-left"
      data-testid={`pos-add-dish-${cat.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
    >
      <span className="fx-label flex flex-wrap items-center gap-1.5">
        <Plus className="h-3 w-3" /> ADD DISH · {category.toUpperCase()}
      </span>
      <div className="mt-2 space-y-1.5">
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Dish name…"
          aria-label={`New dish name for ${category}`}
          className="h-8 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-semibold"
        />
        <div className="flex items-center gap-1.5">
          <Input
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="₹"
            type="number"
            min={0}
            aria-label={`New dish price for ${category}`}
            className="fx-num h-8 w-[86px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-bold"
          />
          <label className="flex h-8 items-center gap-1.5 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2 text-[10px] font-extrabold text-[var(--fx-ink)]">
            <VegDot veg={veg} /> VEG
            <Switch checked={veg} onCheckedChange={setVeg} aria-label={`Vegetarian toggle for new ${category} dish`} />
          </label>
          <Button
            size="sm"
            onClick={() => void add()}
            disabled={busy}
            className="ml-auto h-8 rounded-lg bg-[var(--fx-purple)] px-2.5 text-[10px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />} ADD
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── the owner's edit-dish dialog ─────────────────────────────────────────────
function EditDishDialog({
  dish,
  onClose,
  onSaved,
}: {
  dish: Dish;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [name, setName] = React.useState(dish.name);
  const [price, setPrice] = React.useState(String(dish.price));
  const [veg, setVeg] = React.useState(dish.veg);
  const [busy, setBusy] = React.useState(false);

  const save = async () => {
    const amt = Number(price);
    if (!name.trim() || !Number.isFinite(amt) || amt <= 0) {
      toast({
        title: "Missing details",
        description: "Dish needs a name and a price above zero.",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/menu/${dish.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), price: amt, veg }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Save failed");
      toast({
        title: name.trim() === dish.name ? `${name.trim()} → ${inr(amt)}` : `Renamed to “${name.trim()}” — past bills keep their history`,
      });
      onSaved();
      onClose();
    } catch (e) {
      toast({
        title: "Could not save",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent className="fx-pop-in max-w-[400px]" data-testid="pos-dish-edit-modal">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight">Edit “{dish.name}”</DialogTitle>
          <DialogDescription>
            Renames and price changes keep the dish's full sales history — old bills stay exactly as printed.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2.5">
          <div>
            <span className="fx-label">DISH NAME</span>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              aria-label="Dish name"
              data-testid="pos-dish-edit-name"
              className="mt-1.5 h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold"
            />
          </div>
          <div>
            <span className="fx-label">PRICE ₹</span>
            <Input
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              type="number"
              min={0}
              aria-label="Dish price"
              data-testid="pos-dish-edit-price"
              className="fx-num mt-1.5 h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
          </div>
          <label className="flex h-10 items-center justify-between rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 text-[11.5px] font-extrabold text-[var(--fx-ink)]">
            <span className="flex items-center gap-2"><VegDot veg={veg} /> VEGETARIAN</span>
            <Switch checked={veg} onCheckedChange={setVeg} aria-label="Toggle vegetarian" />
          </label>
        </div>
        <div className="flex items-center justify-end gap-2">
          <Button variant="ghost" onClick={onClose} className="rounded-xl text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)]">
            CANCEL
          </Button>
          <Button
            onClick={() => void save()}
            disabled={busy}
            data-testid="pos-dish-edit-save"
            className="rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} SAVE DISH
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── t115 — the delete WARNING dialog: armed deletions stay LOCKED for 10s ───
function DeleteWarningDialog({
  kind,
  name,
  live,
  busy,
  onClose,
  onConfirm,
}: {
  kind: "dish" | "category";
  name: string;
  live?: number;
  busy: boolean;
  onClose: () => void;
  onConfirm: () => void;
}) {
  /* the 10-second lock — the dialog remounts per target, so the countdown
     always restarts from 10 */
  const [left, setLeft] = React.useState(10);
  React.useEffect(() => {
    const t = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);
  const locked = left > 0;
  const catBlocked = kind === "category" && (live ?? 0) > 0;

  return (
    <Dialog open onOpenChange={(v) => (v ? undefined : onClose())}>
      <DialogContent
        className="fx-pop-in max-w-[430px]"
        data-testid={kind === "dish" ? "pos-delete-dish-modal" : "pos-delete-cat-modal"}
      >
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight">
            {kind === "dish" ? `Remove “${name}” from the menu?` : `Delete section “${name}”?`}
          </DialogTitle>
          <DialogDescription>
            {kind === "dish"
              ? `“${name}” leaves the counter immediately. Past bills keep their printed snapshots — history stays intact.`
              : catBlocked
                ? `“${name}” still has ${live} live ${live === 1 ? "dish" : "dishes"} — a section can only be deleted once its dishes are removed or moved. Already-removed dishes under it are purged with it.`
                : "The section closes at once — any already-removed dishes under it are purged with it. Past bills keep their printed snapshots."}
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-start gap-2 rounded-xl border border-dashed border-[var(--fx-rose)]/50 bg-[var(--fx-rose)]/5 px-3.5 py-2.5 text-[11.5px] font-bold leading-snug text-[var(--fx-rose)]">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            THIS CANNOT BE UNDONE — THE DELETE STAYS LOCKED FOR 10 SECONDS.
            {catBlocked ? " THE MENU GUARD WILL REFUSE WHILE LIVE DISHES REMAIN." : " READ THE WARNING BEFORE YOU FIRE."}
          </span>
        </div>
        <div className="flex items-center justify-end gap-2">
          <Button
            variant="ghost"
            onClick={onClose}
            data-testid={kind === "dish" ? "pos-delete-dish-cancel" : "pos-delete-cat-cancel"}
            className="rounded-xl text-[11px] font-extrabold tracking-wider text-[var(--fx-muted)]"
          >
            KEEP IT
          </Button>
          <Button
            onClick={onConfirm}
            disabled={locked || busy}
            data-testid={kind === "dish" ? "pos-delete-dish-confirm" : "pos-delete-cat-confirm"}
            className="rounded-xl bg-[var(--fx-rose)] px-4 text-[11.5px] font-extrabold text-white shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-rose)]/90 disabled:opacity-60"
          >
            {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : null}
            {locked ? `LOCKED · ${left}s` : "YES, DELETE"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── one dish tile — the counter's tap-to-bill card; the owner's menu card
//    carries ✎/🗑 corner controls instead (t115 — Menu Manager) ─────────────
function DishTile({
  d,
  qty,
  owner,
  onAdd,
  onDec,
  onInc,
  onEdit,
  onDelete,
}: {
  d: Dish;
  qty: number; // counter mode only — the menu card never bills
  owner: boolean;
  onAdd?: () => void;
  onDec?: () => void;
  onInc?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
}) {
  if (owner) {
    /* t115 — the owner's MENU CARD: name, price, edit + delete. No cart, no
       steppers — billing lives at the reception counter.
       t181 — the ROW owns the height now: the grid lays exactly 4 rows into
       the full-screen block (--fx-row) and stretch fills each tile to its
       row — no more vh-guessed min-heights that clip row 4 on short
       windows. Content stays compact so even the floor rows fit. */
    return (
      <div className="fx-tile group relative flex flex-col justify-center overflow-hidden px-4 py-2.5 text-left" data-testid={`pos-dish-owner-${slug(d.name)}`}>
        <span className="absolute right-1.5 top-1.5 flex items-center gap-1 opacity-70 transition group-hover:opacity-100">
          <button
            aria-label={`Edit ${d.name}`}
            data-tip="Edit dish"
            data-testid={`pos-dish-edit-${slug(d.name)}`}
            onClick={(e) => {
              e.stopPropagation();
              onEdit?.();
            }}
            className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] transition hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
          >
            <Pencil className="h-3 w-3" />
          </button>
          <button
            aria-label={`Delete ${d.name}`}
            data-tip="Remove from the menu — a warning with a 10s lock opens first"
            data-testid={`pos-dish-delete-${slug(d.name)}`}
            onClick={(e) => {
              e.stopPropagation();
              onDelete?.();
            }}
            className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] transition hover:border-[var(--fx-rose)] hover:text-[var(--fx-rose)]"
          >
            <Trash2 className="h-3 w-3" />
          </button>
        </span>
        <div className="flex items-start gap-2 pr-16">
          <VegDot veg={d.veg} className="mt-0.5" />
          <span className="line-clamp-2 min-h-[40px] text-[15px] font-bold leading-snug text-[var(--fx-ink)]">
            {d.name}
          </span>
        </div>
        <div className="mt-2.5 flex items-center justify-between">
          <span className="fx-num text-[16px] font-extrabold text-[var(--fx-accent-ink)]">
            {inr(d.price)}
          </span>
        </div>
      </div>
    );
  }
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`Add ${d.name} to the bill`}
      onClick={onAdd}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onAdd?.();
        }
      }}
      /* t212 — overflow-hidden REMOVED: it sheared the qty badge (absolute
         -right/-top) into a cut-off corner blob; the tile's children never
         overflow (line-clamp-2 name, in-padding controls), so the clip was
         pure loss. The badge now hangs its full circle into the grid gaps. */
      className={`fx-tile group relative flex cursor-pointer flex-col justify-center px-4 py-2.5 text-left ${qty > 0 ? "in-cart" : ""}`}
    >
      {qty > 0 && (
        <span className="fx-num absolute -right-1.5 -top-1.5 grid h-6 min-w-6 place-items-center rounded-full bg-[var(--fx-purple)] px-1 text-[11px] font-extrabold text-[var(--fx-on-accent)] shadow-[1px_2px_0_0_var(--fx-hard)]">
          {qty}
        </span>
      )}
      {/* t212 — pr-6 keeps the name clear of the corner badge's in-tile zone
          (the badge is 24px wide, 18px of it inside the tile); without the
          reserve a long first line ran UNDER the badge's purple disc. */}
      <div className="flex items-start gap-2 pr-6">
        <VegDot veg={d.veg} className="mt-0.5" />
        <span className="line-clamp-2 min-h-[40px] text-[15px] font-bold leading-snug text-[var(--fx-ink)]">
          {d.name}
        </span>
      </div>
      <div className="mt-2.5 flex items-center justify-between">
        <span className="fx-num text-[16px] font-extrabold text-[var(--fx-accent-ink)]">
          {inr(d.price)}
        </span>
        {qty === 0 ? (
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--fx-lav)] text-[var(--fx-accent-ink)] transition group-hover:bg-[var(--fx-purple)] group-hover:text-[var(--fx-on-accent)]">
            <Plus className="h-4 w-4" />
          </span>
        ) : (
          <span className="flex items-center gap-1">
            <span
              role="button"
              aria-label={`Decrease ${d.name}`}
              onClick={(e) => {
                e.stopPropagation();
                onDec?.();
              }}
              className="grid h-7 w-7 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)]"
            >
              <Minus className="h-3.5 w-3.5" />
            </span>
            <span
              role="button"
              aria-label={`Increase ${d.name}`}
              onClick={(e) => {
                e.stopPropagation();
                onInc?.();
              }}
              className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
            >
              <Plus className="h-3.5 w-3.5" />
            </span>
          </span>
        )}
      </div>
    </div>
  );
}

// ── Billing dock — lives at the BOTTOM of the POS screen ────────────────────
function BillingDock({
  lines,
  setQty,
  removeLine,
  discount,
  setDiscount,
  onGenerate,
  generating,
  billCount,
  discLimit,
  orderType,
  setOrderType,
  custName,
  setCustName,
  custPhone,
  setCustPhone,
  wallet,
  bonusPts,
  setBonusPts,
}: {
  lines: CartLine[];
  setQty: (dishId: string, qty: number) => void;
  removeLine: (dishId: string) => void;
  discount: number;
  setDiscount: (n: number) => void;
  onGenerate: () => void;
  generating: boolean;
  billCount: number;
  /** t143 — the owner's discount limit % from Settings; inputs clamp to it */
  discLimit: number;
  /** t221 — the order channel this bill is billed under (dock toggle) */
  orderType: OrderType;
  setOrderType: (t: OrderType) => void;
  /** t224/t225 — the customer identity keyed above the totals (name on top,
      10-digit phone below). MANDATORY now — no bill without it. */
  custName: string;
  setCustName: (s: string) => void;
  custPhone: string;
  setCustPhone: (s: string) => void;
  /** t225 — the phone-keyed loyalty wallet: balance (1 pt = ₹1) + earn %.
      Null until the counter keys a full 10-digit phone. t226 — also carries
      the customer's KNOWN name + visit count from the lookup, so the box
      can show who walked in and how many bills they've run. t230 — rank +
      the owner's tier (drives the TOP CUSTOMER badge and the BONUS PTS input). */
  wallet: {
    balance: number;
    earnPct: number;
    name?: string | null;
    visits?: number;
    rank?: number | null;
    tierLabel?: string | null;
    bonusAllowed?: boolean;
  } | null;
  /** t230 — the TOP-CUSTOMER BONUS the reception may hand a ranked customer */
  bonusPts: string;
  setBonusPts: (s: string) => void;
}) {
  const { toast } = useToast();
  const { upperName } = useHotel();
  const subtotal = lines.reduce((s, l) => s + l.dish.price * l.qty, 0);
  const disc = Math.min(discount || 0, subtotal);
  /* t143 — the reception may never discount more than the owner's limit % of
     this bill (paise-exact, rounded down). The input clamps live and the
     generate call + the API re-check it again.
     t225 — the cap GROWS by the customer's loyalty wallet: past the owner's
     limit the discount burns points (1 pt = ₹1), never above the balance. */
  const phoneOk = custPhone.length === 10;
  const pts = wallet?.balance ?? 0;
  const discCap = Math.floor(subtotal * discLimit) / 100;
  const totalCap = Math.min(subtotal, discCap + (phoneOk ? pts : 0));
  const burn = phoneOk ? Math.max(0, Math.min(disc - discCap, pts)) : 0;
  const earnPct = wallet?.earnPct ?? 0;
  const earnPreview = phoneOk && earnPct > 0 ? Math.round(((subtotal - disc) * 1.05 * earnPct) / 100) : 0;
  const taxable = subtotal - disc;
  const tax = Math.round(taxable * GST_RATE * 100) / 100;
  const total = taxable + tax;
  const items = lines.reduce((s, l) => s + l.qty, 0);
  /* t225 — the strict-identity lock: GENERATE stays dead until the counter
     keys a real name and the full 10-digit phone. */
  const identityReady = custName.trim().length >= 2 && phoneOk;

  return (
    /* t210 — layout-agnostic dock: the familiar bottom bar on phones, a
       full-height RIGHT RAIL beside the menu on md+ — chips stack vertically
       and scroll inside the rail, totals + GENERATE pin to its bottom. */
    <div className="space-y-1.5 md:flex md:min-h-0 md:flex-1 md:flex-col md:space-y-0 md:gap-3">
      {/* t221 — DOCK HEADER: the CURRENT BILL identity is the dock's top text,
          and the 4-way ORDER CHANNEL toggle sits directly beneath it — the
          receptionist declares how this order arrived (dine in / take away /
          lodge order / online order) BEFORE tapping dishes, so every bill
          lands in the ledger tagged with its channel. Pins to the rail's top
          on md+, rides the sticky bar's first row on phones. */}
      <div className="shrink-0">
        <div className="flex items-center justify-between gap-2">
          <div className="fx-label">CURRENT BILL · {upperName}</div>
          <span className="fx-num rounded-full bg-[var(--fx-purple)] px-2.5 py-0.5 text-[10.5px] font-extrabold text-[var(--fx-on-accent)]">
            {items} ITEM{items === 1 ? "" : "S"}
          </span>
        </div>
        <div className="mt-1.5 flex flex-wrap gap-1.5" role="radiogroup" aria-label="Order type" data-testid="order-type-toggle">
          {ORDER_TYPES.map((o) => {
            const active = orderType === o.id;
            return (
              <button
                key={o.id}
                type="button"
                role="radio"
                aria-checked={active}
                data-testid={`order-type-${o.id}`}
                onClick={() => setOrderType(o.id)}
                className={`rounded-full border px-2.5 py-1 text-[10px] font-extrabold tracking-wider transition ${
                  active
                    ? "border-[var(--fx-purple)] bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
                    : "border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
                }`}
              >
                {o.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* item chips — horizontal strip on the bottom bar, vertical feed in the rail */}
      <div className="fx-scroll -mx-1 flex gap-2 overflow-x-auto px-1 py-0.5 md:mx-0 md:min-h-0 md:flex-1 md:flex-col md:overflow-y-auto md:px-0.5 md:py-0">
        {lines.length === 0 ? (
          <p className="py-1.5 text-[12.5px] font-semibold text-[var(--fx-muted)] md:py-0">
            Cart is empty — tap dishes on the menu and they land here. The bill writes itself to
            the database.
          </p>
        ) : (
          lines.map((l) => (
            <div
              key={l.dish.id}
              className="flex shrink-0 items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] py-1.5 pl-2.5 pr-2"
            >
              <VegDot veg={l.dish.veg} />
              <span className="max-w-[150px] truncate text-[12.5px] font-bold text-[var(--fx-ink)]">
                {l.dish.name}
              </span>
              <span className="flex items-center gap-1">
                <button
                  aria-label={`Decrease ${l.dish.name}`}
                  onClick={() => setQty(l.dish.id, l.qty - 1)}
                  className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
                >
                  <Minus className="h-3 w-3" />
                </button>
                <span className="fx-num w-5 text-center text-[12.5px] font-extrabold">{l.qty}</span>
                <button
                  aria-label={`Increase ${l.dish.name}`}
                  onClick={() => setQty(l.dish.id, l.qty + 1)}
                  className="grid h-6 w-6 place-items-center rounded-lg bg-[var(--fx-purple)] text-[var(--fx-on-accent)] hover:bg-[var(--fx-purple-deep)]"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </span>
              <span className="fx-num min-w-[52px] text-right text-[12px] font-extrabold text-[var(--fx-accent-ink)]">
                {inr(l.dish.price * l.qty)}
              </span>
              <button
                aria-label={`Remove ${l.dish.name}`}
                onClick={() => removeLine(l.dish.id)}
                className="grid h-6 w-6 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-rose)]"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* t224 — CUSTOMER IDENTITY: name + 10-digit phone keyed ABOVE the
          totals — above the dashed lining, stacked VERTICALLY (name on top,
          phone under it) exactly as the owner asked.
          t225 — MANDATORY now: the owner collects data strictly, so GENERATE
          stays locked until both are keyed. The phone doubles as the loyalty
          wallet key — digits only, exactly 10, mirroring the lodge desk. */}
      <div
        className="shrink-0 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-2.5 py-2"
        data-testid="pos-customer-box"
      >
        <div className="fx-label flex items-center gap-1 text-[9.5px]">
          <UserRound className="h-3 w-3" /> CUSTOMER · NAME & PHONE
          <span className="ml-1 rounded-full bg-[color-mix(in_srgb,var(--fx-rose)_14%,transparent)] px-1.5 py-px text-[8.5px] font-extrabold tracking-wider text-[var(--fx-rose)]">
            REQUIRED
          </span>
          {/* t226 — the phone introduced itself: name auto-filled from the
              customer's history (restaurant bills + lodge stays), so a
              returning guest never gets retyped. */}
          {wallet?.name && custName.trim().toUpperCase() === wallet.name.trim().toUpperCase() && (
            <span
              className="ml-auto rounded-full bg-[color-mix(in_srgb,var(--fx-green)_14%,transparent)] px-1.5 py-px text-[8.5px] font-extrabold tracking-wider text-[var(--fx-green)]"
              data-testid="pos-customer-known"
            >
              AUTO · {wallet.visits ?? 0} VISIT{(wallet.visits ?? 0) === 1 ? "" : "S"}
            </span>
          )}
        </div>
        <div className="mt-1.5 space-y-1.5">
          <Input
            value={custName}
            onChange={(e) => setCustName(e.target.value)}
            placeholder="Customer name…"
            aria-label="Customer name"
            data-testid="pos-customer-name"
            className="h-8 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-semibold"
          />
          <div>
            <Input
              value={custPhone}
              onChange={(e) => setCustPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder="10-digit phone number…"
              inputMode="numeric"
              aria-label="Customer phone — digits only, 10 numbers"
              data-testid="pos-customer-phone"
              className="fx-num h-8 rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-bold"
            />
            {custPhone.length > 0 && custPhone.length < 10 && (
              <p className="mt-1 text-[9.5px] font-extrabold tracking-wide text-[var(--fx-rose)]">
                {10 - custPhone.length} MORE {10 - custPhone.length === 1 ? "DIGIT" : "DIGITS"} — NUMBERS ONLY
              </p>
            )}
          </div>
          {/* t230 — TOP CUSTOMER: the phone's all-time SPEND RANK + the owner's
              tier, plus the BONUS PTS input the reception may use to hand a
              ranked customer extra points on the spot (server clamps 0–1000
              and only for ranked customers). */}
          {wallet?.bonusAllowed && (
            <div className="mt-1.5 rounded-xl border border-[color-mix(in_srgb,var(--fx-gold)_45%,transparent)] bg-[color-mix(in_srgb,var(--fx-gold)_10%,transparent)] px-2.5 py-2" data-testid="pos-top-customer">
              <div className="flex flex-wrap items-center gap-1.5">
                <span
                  className="rounded-full px-2 py-0.5 text-[8.5px] font-extrabold tracking-wider"
                  style={{ background: "color-mix(in srgb, var(--fx-gold) 20%, transparent)", color: "var(--fx-gold)" }}
                  data-testid="pos-rank-badge"
                >
                  ★ RANK #{wallet.rank} · {(wallet.tierLabel ?? "TOP CUSTOMER").toUpperCase()}
                </span>
                <span className="text-[9.5px] font-bold text-[var(--fx-muted)]">earns {wallet.earnPct}% on this bill — top-customer treatment</span>
              </div>
              <div className="mt-1.5 flex items-center gap-2">
                <span className="fx-label whitespace-nowrap">BONUS PTS</span>
                <Input
                  value={bonusPts}
                  onChange={(e) => setBonusPts(e.target.value.replace(/[^0-9]/g, ""))}
                  placeholder="0"
                  inputMode="numeric"
                  aria-label="Bonus loyalty points for this top customer"
                  data-testid="pos-bonus-input"
                  className="fx-num h-7 w-[76px] rounded-lg border-[var(--fx-line)] bg-[var(--fx-surf)] text-[12px] font-bold"
                />
                <span className="text-[9px] font-bold text-[var(--fx-muted)]">extra points this bill · max 1,000</span>
              </div>
            </div>
          )}
        </div>
        {!identityReady && (
          <p className="mt-1.5 text-[9.5px] font-extrabold tracking-wide text-[var(--fx-amber)]">
            NAME + 10-DIGIT PHONE REQUIRED TO GENERATE THE BILL
          </p>
        )}
      </div>

      {/* t201 — ONE merged row: identity + items badge + totals + discount +
          GENERATE (t221 — the identity + order-channel moved UP to the dock
          header; the money row keeps everything it had below them). The old
          three-row dock (header / chips / totals) cost the menu block ~80px of
          permanently reserved height. */}
      <div className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-2 border-t border-dashed border-[var(--fx-line)] pt-2">
        {billCount > 0 && (
          <span className="fx-num hidden whitespace-nowrap text-[10px] font-bold tracking-[0.1em] text-[var(--fx-muted)] lg:inline">
            {billCount} BILL{billCount === 1 ? "" : "S"} TODAY
          </span>
        )}
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]" data-testid="pos-points-indicator">
          <span>POINTS</span>
          <span className={phoneOk && pts > 0 ? "text-[var(--fx-accent-ink)]" : "text-[var(--fx-ink)]"}>
            {phoneOk ? `${pts} PTS` : "—"}
          </span>
          {burn > 0 && (
            <span className="text-[var(--fx-rose)]">· USES {Math.round(burn)}</span>
          )}
          {phoneOk && earnPct > 0 && lines.length > 0 && (
            <span className="text-[var(--fx-green)]">· +{earnPreview} THIS BILL</span>
          )}
        </div>
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>SUBTOTAL</span>
          <span className="text-[var(--fx-ink)]">{inr2(subtotal)}</span>
        </div>
        <div className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>GST 5%</span>
          <span className="text-[var(--fx-ink)]">{inr2(tax)}</span>
        </div>
        <label className="fx-num flex items-center gap-1.5 text-[12px] font-bold text-[var(--fx-muted)]">
          <span>DISCOUNT ₹</span>
          <Input
            type="number"
            min={0}
            value={discount || ""}
            placeholder="0"
            onChange={(e) => {
              const next = Math.max(0, Number(e.target.value) || 0);
              if (next > totalCap) {
                /* t143 — the owner's rule bites right at the keystroke;
                   t225 — the cap grows by the wallet when the phone is keyed */
                setDiscount(totalCap);
                toast({
                  title: "Discount capped by the owner's limit",
                  description: phoneOk && pts > 0
                    ? `At most ${discLimit}% of the bill (${inr2(discCap)}) + ${pts} loyalty points — ${inr2(totalCap)} on this one.`
                    : `Receptions can discount at most ${discLimit}% of the bill — ${inr2(discCap)} on this one.`,
                });
              } else {
                setDiscount(next);
              }
            }}
            className="fx-num h-8 w-20 border-[var(--fx-line)] bg-[var(--fx-page)] text-right text-[12.5px] font-bold"
            aria-label="Discount in rupees"
          />
          {subtotal > 0 && (discLimit < 100 || (phoneOk && pts > 0)) && (
            <span
              className="fx-num whitespace-nowrap rounded-full border border-dashed border-[var(--fx-line)] px-2 py-0.5 text-[9.5px] font-extrabold tracking-wider text-[var(--fx-muted)]"
              data-tip={phoneOk && pts > 0
                ? `The owner allows ${discLimit}% of the bill plus the customer's ${pts} loyalty points`
                : `The owner allows at most ${discLimit}% of the bill as discount`}
            >
              MAX {inr2(totalCap)}
            </span>
          )}
        </label>
        <div className="flex items-baseline gap-2">
          <span className="fx-label">TOTAL</span>
          <span className="fx-num text-xl font-extrabold text-[var(--fx-ink)]">{inr2(total)}</span>
        </div>
        <Button
          disabled={lines.length === 0 || generating || !identityReady}
          onClick={onGenerate}
          className="ml-auto h-11 rounded-2xl bg-[var(--fx-purple)] px-6 text-[13px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[3px_4px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)] disabled:opacity-60 md:ml-0 md:w-full md:justify-center"
        >
          {generating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> SAVING BILL…
            </>
          ) : !identityReady && lines.length > 0 ? (
            <>
              <UserRound className="mr-2 h-4 w-4" /> NAME + PHONE REQUIRED
            </>
          ) : (
            <>
              <Zap className="mr-2 h-4 w-4" /> GENERATE BILL · {inr2(total)}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

// ── The POS view ───────────────────────────────────────────────────────────
export function PosView({
  dishes,
  loading,
  role = "owner",
  onMenuChanged,
}: {
  dishes: Dish[];
  loading: boolean;
  role?: string;
  onMenuChanged?: () => void | Promise<void>;
}) {
  // t184 — view toggles (search, category filter, owner-only collapsibles)
  // persist across section switches AND live-update when the AI writes a
  // hint (e.g. future "open pos in snacks category"). The cart, discount,
  // owner-bills, add-form fields are intentionally NOT cached — they're
  // session/form state, not view filters.
  const isOwner = role === "owner";
  const [query, setQuery] = useCachedToggle<string>("pos", "query", "");
  const [cat, setCat] = useCachedToggle<string>("pos", "cat", "All");
  const [billsOpen, setBillsOpen] = useCachedToggle<boolean>("pos", "billsOpen", false);
  const [addCatOpen, setAddCatOpen] = useCachedToggle<boolean>("pos", "addCatOpen", false);
  /* t221 — the counter's ORDER CHANNEL: dine in / take away / lodge order /
     online order. The receptionist picks it in the billing dock before
     generating; the choice rides on the bill into the ledger, feeds the AI,
     and gives the owner's business-mix analytics its raw data. */
  const [orderType, setOrderType] = React.useState<OrderType>("dine_in");
  /* t224/t225 — the CUSTOMER IDENTITY the receptionist keys in the dock above
     the totals: name on top, 10-digit phone under it. MANDATORY per bill
     (strict data collection); cleared after a successful generate so the
     next bill never inherits a stale customer. The phone is the reliable
     identity key (names collide) AND the loyalty wallet key. */
  const [custName, setCustName] = React.useState("");
  const [custPhone, setCustPhone] = React.useState("");
  /* t225 — the phone-keyed LOYALTY WALLET, fetched the moment a full 10-digit
     phone sits in the dock: balance (1 pt = ₹1) + the owner's earn %, so the
     money row can show the points available and what this bill mints.
     t226 — the lookup also returns the customer's NAME (newest identity
     across both books) + visit count, and the name AUTO-FILLS itself into
     the box — a returning guest never gets retyped. If the counter already
     keyed a proper name, theirs wins; the lookup only ever fills an empty
     (or too-short) field. */
  const [wallet, setWallet] = React.useState<{
    balance: number;
    earnPct: number;
    name?: string | null;
    visits?: number;
    rank?: number | null;
    tierLabel?: string | null;
    bonusAllowed?: boolean;
  } | null>(null);
  // t230 — the reception's TOP-CUSTOMER BONUS (points) for a ranked customer
  const [bonusPts, setBonusPts] = React.useState("");
  React.useEffect(() => {
    if (custPhone.length !== 10) {
      setWallet(null);
      setBonusPts("");
      return;
    }
    let dead = false;
    fetch(`/api/loyalty?phone=${custPhone}`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (!dead && d && Number.isFinite(d.balance))
          setWallet({
            balance: Math.max(0, Math.round(d.balance)),
            earnPct: Math.max(0, Number(d.earnPct) || 0),
            name: typeof d.name === "string" ? d.name : null,
            visits: Number.isFinite(d.visits) ? Math.max(0, Math.round(d.visits)) : 0,
            rank: Number.isFinite(d.rank) && d.rank !== null ? Math.round(d.rank) : null,
            tierLabel: typeof d.tierLabel === "string" ? d.tierLabel : null,
            bonusAllowed: !!d.bonusAllowed,
          });
        if (!dead && d && typeof d.name === "string" && d.name.trim().length >= 2)
          setCustName((prev) => (prev.trim().length >= 2 ? prev : d.name.trim()));
      })
      .catch(() => {
        /* the indicator is cosmetic — never block the counter */
      });
    return () => {
      dead = true;
    };
  }, [custPhone]);
  const customerOnCounter =
    [custName.trim(), custPhone].filter(Boolean).join(" · ") || undefined;
  // Expose all view toggles to the AI's screen context so it knows what the
  // user is filtering/searching for right now. t221 — the receptions' billing
  // screen also reports the dock's selected ORDER CHANNEL (dine in / take
  // away / lodge order / online order) so the AI always knows how the
  // counter is currently billing.
  useRegisterScreen(
    "pos",
    isOwner ? "Menu Manager" : "POS Billing",
    isOwner ? { query, cat, billsOpen, addCatOpen } : { query, cat, billsOpen, addCatOpen, orderType, customer: customerOnCounter },
  );
  const { toast } = useToast();
  const { openReceipt } = useReceipt();
  const { hotelName, upperName } = useHotel();
  const [cart, setCart] = React.useState<Record<string, number>>({});
  const [discount, setDiscount] = React.useState(0);
  /* t143 — the owner's discount limit %, fetched from Settings; every discount
     the reception types is clamped to this % of the current bill */
  const [discLimit, setDiscLimit] = React.useState(10);
  const [generating, setGenerating] = React.useState(false);
  const [billsToday, setBillsToday] = React.useState(0);
  const [recent, setRecent] = React.useState<Bill[]>([]);

  /* t117 — the owner's own window into the restaurant bills: last 50, collapsible,
     read-only (no reprint, no undo — the counter does the billing actions) */
  const [ownerBills, setOwnerBills] = React.useState<Bill[]>([]);
  React.useEffect(() => {
    if (!isOwner) return;
    const load = () =>
      fetch("/api/bills?limit=50", { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : []))
        .then((d) => setOwnerBills(Array.isArray(d) ? d : []))
        .catch(() => undefined);
    void load();
    const t = setInterval(load, 60000); // stays live by itself, like the dashboard
    return () => clearInterval(t);
  }, [isOwner]);

  /* t143 — receptions pull the owner's discount limit once (owner doesn't bill) */
  React.useEffect(() => {
    if (isOwner) return;
    fetch("/api/settings")
      .then((x) => x.json())
      .then((s) => {
        const n = Math.floor(Number(s?.discountLimit));
        if (Number.isFinite(n) && n >= 0) setDiscLimit(Math.min(n, 100));
      })
      .catch(() => {
        /* the default of 10% stands */
      });
  }, [isOwner]);

  /* t98 — owner menu editing · t115 — warning-locked deletions */
  const [cats, setCats] = React.useState<Category[]>([]);
  const [newCat, setNewCat] = React.useState("");
  const [editDish, setEditDish] = React.useState<Dish | null>(null);
  const [confirmDish, setConfirmDish] = React.useState<Dish | null>(null);
  const [confirmCat, setConfirmCat] = React.useState<{ id: string; name: string; live: number } | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  const reloadCats = React.useCallback(async () => {
    try {
      const res = await fetch("/api/categories", { cache: "no-store" });
      const data = await res.json();
      setCats(Array.isArray(data) ? data : []);
    } catch {
      /* cosmetic */
    }
  }, []);
  React.useEffect(() => {
    if (isOwner) void reloadCats();
  }, [isOwner, reloadCats]);

  const menuChanged = React.useCallback(() => {
    void onMenuChanged?.();
    if (isOwner) void reloadCats();
  }, [onMenuChanged, isOwner, reloadCats]);

  const addCategory = async () => {
    const name = newCat.trim();
    if (!name) {
      toast({ title: "Section name needed", description: "Examples: Rice, Ice Cream, Smoothies…", variant: "destructive" });
      return;
    }
    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not add the category");
      toast({ title: `Category “${name}” added — its blank add-dish block is on the board` });
      setNewCat("");
      setAddCatOpen(false);
      setCat(name);
      await reloadCats();
      void onMenuChanged?.();
    } catch (e) {
      toast({
        title: "Could not add the category",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    }
  };

  /* t115 — the warning dialog owns the flow: this fires only after the 10s lock */
  const deleteDish = async (d: Dish) => {
    setDeleting(true);
    try {
      const res = await fetch(`/api/menu/${d.id}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Delete failed");
      toast({ title: `“${d.name}” removed from the menu — past bills keep their snapshots` });
      setConfirmDish(null);
      menuChanged();
    } catch (e) {
      toast({
        title: "Could not delete",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  };

  /* t115 — delete a whole SECTION. The server guard refuses while live dishes
     remain (409) — the dialog's warning says so up front. */
  const deleteCategory = async (c: { id: string; name: string }) => {
    setDeleting(true);
    try {
      const res = await fetch(`/api/categories?id=${encodeURIComponent(c.id)}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Could not delete the section");
      toast({
        title: `Section “${c.name}” deleted`,
        description:
          out.purged > 0
            ? `${out.purged} already-removed dish${out.purged === 1 ? "" : "es"} purged — past bills keep their snapshots`
            : "The menu re-flows at once.",
      });
      setConfirmCat(null);
      setCat((cur) => (cur === c.name ? "All" : cur));
      menuChanged();
    } catch (e) {
      toast({
        title: "Could not delete the section",
        description: e instanceof Error ? e.message : "Try again.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
    }
  };

  const active = React.useMemo(() => dishes.filter((d) => d.active), [dishes]);
  const dishCats = React.useMemo(() => [...new Set(active.map((d) => d.category))], [active]);
  const catNames = React.useMemo(() => {
    const fromDb = cats.map((c) => c.name);
    const orphans = dishCats.filter((c) => !fromDb.includes(c));
    return [...fromDb, ...orphans];
  }, [cats, dishCats]);
  const chipCats = React.useMemo(() => ["All", ...catNames], [catNames]);

  const filtered = React.useMemo(
    () =>
      active.filter(
        (d) =>
          (cat === "All" || d.category === cat) &&
          d.name.toLowerCase().includes(query.trim().toLowerCase()),
      ),
    [active, cat, query],
  );

  // owner renders grouped sections (every category gets its add-dish block)
  const ownerGroups = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return catNames
      .filter((c) => cat === "All" || c === cat)
      .map((c) => ({ cat: c, list: filtered.filter((d) => d.category === c) }))
      .filter((g) => g.list.length > 0 || !q); // keep empty sections when not searching
  }, [catNames, cat, filtered, query]);

  const lines: CartLine[] = React.useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const dish = active.find((d) => d.id === id);
          return dish ? { dish, qty } : null;
        })
        .filter((x): x is CartLine => x !== null),
    [cart, active],
  );

  // how many bills today (from the same auto-fed analytics the owner sees)
  React.useEffect(() => {
    if (isOwner) return; // t115 — the Menu Manager never bills
    fetch("/api/dashboard?range=today")
      .then((r) => r.json())
      .then((d) => setBillsToday(d?.stats?.bills ?? 0))
      .catch(() => {});
  }, [generating, isOwner]);

  // the register's own feed — newest restaurant bills, tap to reprint, UNDO to tear.
  // t214 — the feed lives BELOW the vh-fixed menu card: out of view on load, the
  // user scrolls the shell MAIN to reach it (their explicit ask).
  // t215 — the feed card is now COLLAPSIBLE (billsOpen, default shut).
  const loadRecent = React.useCallback(async () => {
    if (isOwner) return; // t115 — bills live on the counter, not in the menu
    try {
      const res = await fetch("/api/bills?limit=14", { cache: "no-store" });
      if (!res.ok) return;
      setRecent(await res.json());
    } catch {
      /* the feed is cosmetic — never block the counter */
    }
  }, [isOwner]);
  React.useEffect(() => {
    void loadRecent();
  }, [loadRecent, generating]);

  const undoBill = async (b: Bill) => {
    try {
      const res = await fetch(`/api/bills/${b.id}`, { method: "DELETE" });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Undo failed");
      toast({
        title: `Bill #${b.number} undone`,
        description: "Removed everywhere — totals, trends & top dishes recompute instantly.",
      });
    } catch (e) {
      toast({
        title: "Undo failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    }
    void loadRecent();
    fetch("/api/dashboard?range=today")
      .then((r) => r.json())
      .then((d) => setBillsToday(d?.stats?.bills ?? 0))
      .catch(() => {});
  };

  const add = (id: string) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const setQty = (id: string, qty: number) =>
    setCart((c) => {
      const next = { ...c };
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  const removeLine = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      delete next[id];
      return next;
    });

  const generate = async () => {
    if (lines.length === 0) return;
    /* t225 — the identity is STRICT: the dock locks GENERATE until the name
       and the full 10-digit phone are keyed; these toasts are the backup
       path (and speak exactly what's missing). */
    if (custName.trim().length < 2) {
      toast({
        title: "Customer name is required",
        description: "Every bill now carries its customer — key the name above the totals.",
        variant: "destructive",
      });
      return;
    }
    if (custPhone.length !== 10) {
      toast({
        title: "Phone needs exactly 10 digits",
        description: "Every bill now carries its customer — key all 10 digits (numbers only).",
        variant: "destructive",
      });
      return;
    }
    setGenerating(true);
    try {
      /* t143 — belt & braces: the POST re-checks server-side too, but never
         send more than the owner's limit % of the bill's value.
         t225 — the cap grows by the wallet's points (1 pt = ₹1) — the API
         re-splits the discount into regular + points server-side. */
      const sub = lines.reduce((s, l) => s + l.dish.price * l.qty, 0);
      const ptsOnCounter = custPhone.length === 10 ? wallet?.balance ?? 0 : 0;
      const safeDiscount = Math.min(discount, Math.floor(sub * discLimit) / 100 + ptsOnCounter, sub);
      const res = await fetch("/api/bills", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: lines.map((l) => ({ dishId: l.dish.id, qty: l.qty })),
          discount: safeDiscount,
          orderType,
          customerName: custName.trim(),
          customerPhone: custPhone,
          bonusPoints: wallet?.bonusAllowed ? Math.max(0, Math.round(Number(bonusPts) || 0)) : 0,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? "Bill generation failed");
      }
      const bill: Bill = await res.json();
      openReceipt(bill);
      setCart({});
      setDiscount(0);
      setBonusPts("");
      /* t224 — the next bill starts customerless: no stale identity may
         silently attach to a different walk-in. The wallet read resets with
         the phone (the fresh balance is one generate away). */
      setCustName("");
      setCustPhone("");
      toast({
        title: `Bill #${bill.number} saved · ${hotelName}`,
        description:
          `${bill.itemCount} item(s) auto-fed to the database — no entry needed.` +
          (bill.pointsEarned ? ` +${Math.round(bill.pointsEarned)} loyalty pts for ${custName.trim() || "the customer"}.` : ""),
      });
    } catch (e) {
      toast({
        title: "Could not generate bill",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  /* t149 — the dish grid carries the JS touch driver too: inside the rotated
     stage its native pan is dead on the user's phone (same as the landing);
     the driver gives it the same 1:1 drag + natural fling. Dormant on
     desktops and whenever the grid has no overflow. */
  const gridRef = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    const g = gridRef.current;
    if (!g) return;
    /* t149 — the dish grid carries the JS touch driver: inside the rotated
       stage its native pan is dead on the user's phone (same as the landing);
       the driver gives it the same 1:1 drag + natural fling. Dormant on
       desktops and whenever the grid has no overflow. */
    return bindFxTouchScroll(g);
  }, []);

  /* t216 — the ResizeObserver shrink-to-fit experiment is GONE: it contracted
     the tiles to force 6 rows into the viewport-locked card and the user
     rejected it outright — "I did not ask you to contract dishes block, just
     stretch the whole frame". FINAL WORD (same round): "I want 6 rows with
     internal scroll and keep the size of the tiles as they were, just as in
     the screenshot". So the frame STRETCHES — the card drops its 100vh lock
     and the scroller is pinned to EXACTLY SIX rows at the floor-guarded tile
     size (93px on the user's zoomed 1920×1080, pixel-identical to the
     screenshot) — and the grid scrolls INTERNALLY for the rows beyond the
     sixth; the shell MAIN scrolls to the bills card below. */

  return (
    <div className="space-y-5">
      {/* t201 — RECEPTION runs a slim ONE-LINE header instead of the full
          TierBand: every pixel above the menu block is a pixel stolen from the
          dishes, and the owner wants the counter's dish tiles at the EXACT
          Menu-Manager size. The owner's Menu Manager keeps the full band. */}
      {isOwner ? (
        <TierBand
          num={FX_TIERS.menu.num}
          eyebrow={tierEyebrow(FX_TIERS.menu)}
          title="Menu Manager"
          sub="The menu runs from here — add categories on top, a blank add-dish block in every section, edit or remove any dish. Billing lives at the reception counter."
          tag={`${upperName} · PURE VEG · ${active.length} LIVE DISHES`}
        />
      ) : (
        <div className="flex items-center gap-3 py-1" data-fx-motion="1">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[var(--fx-purple)] font-mono text-[12px] font-bold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)]">
            {FX_TIERS.pos.num}
          </span>
          <div className="min-w-0 flex-1">
            <span className="text-[15px] font-extrabold tracking-tight text-[var(--fx-ink)]">
              POS Terminal
            </span>
            <span className="ml-2 hidden text-[12px] font-semibold text-[var(--fx-muted)] md:inline">
              Tap dishes → generate the bill. Everything else happens by itself.
            </span>
          </div>
          <span className="hidden whitespace-nowrap rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-3 py-1.5 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)] md:inline-block">
            {upperName} · PURE VEG · {active.length} LIVE DISHES
          </span>
        </div>
      )}

      {/* ── Dishes ──
          t201 — RECEPTION: the card is a fixed-height FLEX COLUMN spanning the
          viewport under the slim header — search + chips on top, then the
          dish grid. The rows use the OWNER'S EXACT row var (--fx-row), so the
          counter's dish tiles are the same size as the Menu Manager's at any
          window size; if the viewport runs short of four full rows the grid
          scrolls (size wins — the owner's explicit ask).
          t210 — the CURRENT BILL dock no longer sits at the bottom: from md up
          it stands as a fixed-width RIGHT RAIL beside the grid (menu left,
          live bill right, inside the same card). Phones keep the sticky
          bottom bar. The OWNER keeps the vh-math block.
          t214 — the card spans the viewport EXACTLY (100vh−84: main pt 20 +
          slim header 40 + space-y 20 + main pb-1 4 — the old 80px calc ran
          the card 4px past the fold). On load the user sees ONLY the menu;
          the register's bills feed below the card starts OUT OF VIEW and
          MAIN scrolls down to reach it (the user: "extend the menu
          until it is not visible — the user should have to scroll to see
          it").
          t215 — SIX rows of dishes now fill that exact-fit card (row var
          /6, constant 299) and the bills feed below is COLLAPSIBLE —
          default shut, tap the header to unfold it.
          t216 — THE VIEWPORT LOCK IS OFF: shrinking tiles to keep six rows
          inside 100vh was rejected ("I did not ask you to contract dishes
          block, just stretch the whole frame"), and the final word brings
          the internal scroll BACK: "I want 6 rows with internal scroll and
          keep the size of the tiles as they were, just as in the
          screenshot". The card grows to exactly SIX rows at the floor-
          guarded tile size — on short screens (the user's zoomed 1920×1080:
          CSS vh ≈ 685) it STRETCHES PAST the fold; the shell MAIN scrolls
          to the bills card, the GRID scrolls internally for rows 7+. */}
      <div
        className={`fx-card min-w-0 ${
          isOwner
            ? "p-5"
            : /* t219 — FULL-HEIGHT SIDEBAR, user's words: "stretch the height
                 of the bill dock to match the height of menu". The card is a
                 TWO-COLUMN frame on md+: the menu column (search + chips +
                 grid) keeps the familiar p-5 gutters inside, the bill rail
                 becomes a true sidebar touching the card's top, right and
                 bottom edges — the same height as the whole menu card. */
              "p-5 md:items-stretch md:flex md:p-0"
        }`}
        data-fx-motion="1"
      >
        {/* t219 — the MENU COLUMN: search, chips and grid live in here with
            the card's familiar p-5 gutters; the bill rail stands beside it as
            the card's second column (stretch = the card's full height). */}
        <div className={isOwner ? "" : "md:flex md:min-w-0 md:flex-1 md:flex-col md:p-5"}>
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--fx-muted)]" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dishes…"
              aria-label="Search dishes"
              className={`${isOwner ? "h-11" : "h-10"} rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] pl-9 font-semibold`}
            />
          </div>
          <span className="fx-label hidden md:block">{filtered.length} SHOWN</span>
        </div>

        {/* category row — the ADD CATEGORY option lives on top of it (owner).
            t201 trimmed the reception's margins to fund the fourth row;
            t211 keeps the trim but the GRID re-funds its own 12px top gap
            from the row var (366→378), so the tiles no longer hug the chips. */}
        <div className={`fx-scroll flex gap-2 overflow-x-auto ${isOwner ? "mt-4 pb-1" : "mt-3 pb-0.5"}`}>
          {chipCats.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`whitespace-nowrap rounded-full border px-4 py-2 text-[11.5px] font-extrabold tracking-wide transition ${
                cat === c
                  ? "border-[var(--fx-purple)] bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                  : "border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-ink)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
              }`}
            >
              {c.toUpperCase()}
            </button>
          ))}
          {isOwner && (
            <button
              onClick={() => setAddCatOpen((o) => !o)}
              aria-expanded={addCatOpen}
              data-testid="pos-add-category"
              className={`inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border border-dashed px-4 py-2 text-[11.5px] font-extrabold tracking-wide transition ${
                addCatOpen
                  ? "border-[var(--fx-purple)] bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
                  : "border-[var(--fx-line)] bg-[var(--fx-page)] text-[var(--fx-muted)] hover:border-[var(--fx-purple)] hover:text-[var(--fx-accent-ink)]"
              }`}
            >
              {addCatOpen ? <X className="h-3.5 w-3.5" /> : <LayoutGrid className="h-3.5 w-3.5" />}
              {addCatOpen ? "CLOSE" : "ADD CATEGORY"}
            </button>
          )}
        </div>

        {/* the inline add-category form (owner) */}
        {isOwner && addCatOpen && (
          <div className="fx-pop-in mt-3 flex flex-wrap items-center gap-2 rounded-2xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-lav)]/60 p-3" data-testid="pos-add-category-form">
            <LayoutGrid className="h-4 w-4 text-[var(--fx-accent-ink)]" />
            <span className="text-[11px] font-extrabold tracking-wider text-[var(--fx-ink)]">NEW CATEGORY</span>
            <Input
              value={newCat}
              onChange={(e) => setNewCat(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void addCategory();
              }}
              placeholder="e.g. Rice, Ice Cream, Smoothies, Combos…"
              aria-label="New category name"
              data-testid="pos-add-category-input"
              className="h-9 min-w-[200px] flex-1 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] font-semibold"
            />
            <Button
              onClick={() => void addCategory()}
              data-testid="pos-add-category-create"
              className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
            >
              <Plus className="mr-1 h-4 w-4" /> CREATE
            </Button>
          </div>
        )}

        {/* t210 — MENU + LIVE BILL side by side (reception, md+): the dishes own
            the left, the CURRENT BILL dock stands as a fixed-width right rail
            inside the same card — the bottom strip no longer steals menu
            height. Phones keep the dock as the sticky bottom bar. The owner's
            Menu Manager keeps its plain single-column flow.
            t219 — the dock moved OUT of this wrapper (it is now the card's
            second, full-height column), so this div only carries the --fx-row
            var the grid scroller sizes its six rows from. */}
        <div className={isOwner ? "" : "[--fx-row:max(93px,calc((100vh-299px)/6))]"}>
        {/* t201 — the menu block shows the OWNER-SIZED tiles: the reception's
            rows run the SAME --fx-row var as the Menu Manager (identical tile
            heights at every window size), the grid area is whatever the row
            hands it after search + chips, and extra rows scroll. */}
        <div
          ref={gridRef}
          className={`fx-scroll overflow-y-auto ${
            isOwner
              ? "pl-1 pr-1 mt-4 h-[max(420px,calc(100vh-318px))] pb-1 pt-2 [--fx-row:max(93px,calc((100vh-366px)/4))]"
              : /* reception — a plain flex-1 scroller; rows are the owner's
                   fixed row var, so tiles never shrink to fit the dock.
                   t211 — the chips-to-grid gap is BACK: the t201 trim left the
                   tiles ~2px under the category chips on desktop (the user:
                   "dishes arranged so close to categories"), so the grid keeps
                   its mt-3 on md+ too — a 14px breathing line (12px margin +
                   the chips' 2px pad). The row constant is rebalanced 366→378
                   by the SAME 12px, so 4 rows + 3 gaps still fill the flex-1
                   area EXACTLY (the same exact-fit contract the owner ships).
                   t212 — pt/pr/pb-1.5 (6px each) give the qty badge's 6px
                   corner overhang clearance at the scroller's top, right and
                   bottom edges (it used to be cut by the scroll box); the
                   constant is rebalanced again 378→390 by the same 12px so
                   the exact-fit contract survives.
                   t213 — FIVE rows: t210 moved the bill to the right rail but
                   the row var still carried the dock-era chrome, so the grid
                   under-filled its (now taller) flex area by ~119px — a dead
                   strip exactly where the dock used to sit (the user: "expand
                   the menu size till where the bill was at the bottom").
                   Measured at 100vh=900: area 677 = pt 6 + N rows + (N−1)·12
                   + pb 6 → 5 rows of (100vh−283)/5 = 123.4px fill it EXACTLY
                   (tiles −3% vs the 4-row size, one full extra row gained;
                   the 93px floor still guards short windows → scroll).
                   t214 — the card is pinned to the exact fold (80→84 calc) so
                   the bills feed below starts OUT of view; the scroller drops
                   677→673 at 100vh=900, so the constant is rebalanced 283→287
                   by the same 4px: 5 rows of (100vh−287)/5 = 122.6px fill it
                   EXACTLY again.
                   t215 — SIX rows: the user wants 6 lines of dishes visible,
                   so the row var switches to /6. Each extra row costs one more
                   12px gap, so the rows' share drops 613→601px and the
                   constant is rebalanced 287→299: 6 rows of (100vh−299)/6 =
                   100.2px fill the scroller EXACTLY (tiles −18% vs the 5-row
                   size, a full extra line gained; the 93px floor still guards
                   windows under ~857px tall → scroll).
                   t216 — FINAL, user's words: "I want 6 rows with internal
                   scroll and keep the size of the tiles as they were, just
                   as in the screenshot". The tile-shrink experiment is dead
                   (constant back 295→299, the t215 size) and the scroller is
                   PINNED to exactly six rows: height = var×6 + 72 (6px top
                   + 6px bottom pad + 5×12px gaps). Six full tiles always
                   show at once — 93px on the user's zoomed screen, pixel-
                   identical to the screenshot — rows beyond the sixth
                   scroll INSIDE the grid (the fx-scroll driver keeps the
                   phone fling), and the frame itself stretches past the
                   fold on short screens (MAIN scrolls to the bills card).
                   t217 — the row var MOVED UP to the flex wrapper above, so
                   the billing rail can size itself against the very same
                   grid (see the dock's md:h-[min(...)] below).
                   t218 — WIDE-SCREEN FILL, user's words: "either stretch the
                   dish tiles horizontally or make the bill dock full size,
                   the empty space is making the page look broke, I view in
                   1920×1080". The scroller was a bare flex item, so it only
                   sized to the grid's max-content width — on wide screens
                   (≥~1730px viewport) that left a ~107px dead strip of card
                   between the rail and the card's right edge (at 1920:
                   grid 1054 vs 1172 available). md:flex-1 + md:min-w-0 make
                   the scroller GROW to fill every pixel left of the dock:
                   the 1fr columns stretch the tiles horizontally and the
                   rail now ends flush at the card edge. Narrow screens are
                   untouched — they were already shrinking to fit (the same
                   flex behavior, now explicit).
                   t219 — the dock left this wrapper for the card's second
                   column, so the scroller is a plain block child of the menu
                   column again and fills it naturally (the flex classes stay
                   as harmless belt-and-braces). */
                "mt-3 min-w-0 pl-1 pt-1.5 pb-1.5 pr-1.5 md:h-[calc(var(--fx-row)*6+72px)] md:flex-1"
          }`}
        >
          {loading ? (
            <div className="grid place-items-center py-20 text-[var(--fx-muted)]">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : isOwner ? (
            cat === "All" ? (
              /* t152 — ALL blends every category into ONE seamless grid (the
               user: a new category's dishes must flow into the big grid, not
               start on a next line). NO ADD DISH here anymore (owner's ask) —
               adding happens on the single-SECTION view, which keeps headers,
               counts, section delete and its own ADD DISH block. */
              <div className="auto-rows-[var(--fx-row)] grid grid-cols-2 gap-3 md:grid-cols-4" data-testid="pos-owner-groups">
                {filtered.map((d) => (
                  <DishTile
                    key={d.id}
                    d={d}
                    qty={0}
                    owner
                    onEdit={() => setEditDish(d)}
                    onDelete={() => setConfirmDish(d)}
                  />
                ))}
                {filtered.length === 0 && (
                  <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                    No dishes match “{query}”.
                  </p>
                )}
              </div>
            ) : (
            /* single section — the original grouped rendering, header + controls */
            <div className="space-y-6" data-testid="pos-owner-groups">
              {ownerGroups.map(({ cat: c, list }) => {
                const catId = cats.find((x) => x.name === c)?.id;
                return (
                <div key={c}>
                  <div className="flex items-center gap-2">
                    <span className="text-[12px] font-extrabold tracking-wide text-[var(--fx-ink)]">{c.toUpperCase()}</span>
                    <span className="fx-num rounded-full bg-[var(--fx-lav)] px-2 py-0.5 text-[10px] font-extrabold text-[var(--fx-muted)]">
                      {list.length}
                    </span>
                    <span className="h-px flex-1 border-t border-dashed border-[var(--fx-line)]" />
                    {catId && (
                      <button
                        aria-label={`Delete section ${c}`}
                        data-tip="Delete this section — a warning with a 10s lock opens first"
                        data-testid={`pos-cat-delete-${slug(c)}`}
                        onClick={() =>
                          setConfirmCat({ id: catId, name: c, live: active.filter((d) => d.category === c).length })
                        }
                        className="grid h-6 w-6 place-items-center rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] text-[var(--fx-muted)] transition hover:border-[var(--fx-rose)] hover:text-[var(--fx-rose)]"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  <div className="auto-rows-[var(--fx-row)] mt-2.5 grid grid-cols-2 gap-3 md:grid-cols-4">
                    {list.map((d) => (
                      <DishTile
                        key={d.id}
                        d={d}
                        qty={0}
                        owner
                        onEdit={() => setEditDish(d)}
                        onDelete={() => setConfirmDish(d)}
                      />
                    ))}
                    <AddDishTile category={c} onAdded={menuChanged} />
                  </div>
                </div>
                );
              })}
              {ownerGroups.length === 0 && (
                <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                  No dishes match “{query}”.
                </p>
              )}
            </div>
            )
          ) : (
            <div
              className="auto-rows-[var(--fx-row)] grid grid-cols-2 gap-3 md:grid-cols-4"
              data-testid="pos-dish-grid"
            >
              {filtered.map((d) => (
                <DishTile
                  key={d.id}
                  d={d}
                  qty={cart[d.id] ?? 0}
                  owner={false}
                  onAdd={() => add(d.id)}
                  onDec={() => setQty(d.id, (cart[d.id] ?? 0) - 1)}
                  onInc={() => add(d.id)}
                />
              ))}
              {filtered.length === 0 && (
                <p className="col-span-full py-12 text-center text-sm font-semibold text-[var(--fx-muted)]">
                  No dishes match “{query}”.
                </p>
              )}
            </div>
          )}
        </div>
        </div>
        </div>

        {/* ── t147/t210 — the CURRENT BILL, right-rail edition: from md up it
           stands BESIDE the menu as a fixed-width column inside this very
           card (menu left, live bill right); on phones it rides sticky at the
           viewport bottom exactly where the old floating dock always sat
           (same offsets, same z). ──
           t217 — WELL-FITTED RAIL, user's words: "the billing block is
           contracted from its full space, stretch it until it looks
           well-fitted". The t216 frame stretch pushed the rail's bottom
           (totals + GENERATE) ~130px below the fold on the user's zoomed
           screen, so on load only the rail's empty top was visible. Now the
           rail is VIEWPORT-FITTED and STICKY: height = min(100vh−194,
           grid footprint) — 194 = card top 80 + p-5 20 + search 40 + chips
           12+36 + main pb-1 4 — so on short screens it ends EXACTLY at the
           fold with totals + GENERATE always on screen; on
           tall screens it ends EXACTLY at the grid's bottom edge (same
           --fx-row math, +12 for the grid's mt-3). md:top-20 (the card's
           top line) keeps the whole rail pinned while MAIN scrolls the
           stretched frame and the bills card past it.
           t218 — the grid's scroller grew md:flex-1, so the rail now also
           ends FLUSH at the card's right edge on wide screens (1920×1080:
           no more dead strip beside it).
           t219 — FULL HEIGHT, user's words: "stretch the height of the bill
           dock to match the height of menu". The rail left the grid's wrapper
           and became the CARD's second flex column: no more min() height
cap — it stretches to the card's full height (menu card top line to
           bottom edge); totals + GENERATE ride to its bottom and the chips
           feed flexes/scrolls in between. On short screens the rail now
           extends with the menu past the fold (MAIN scrolls to it — the
           same journey the dishes take); md:rounded-r-[17px] hugs the
           card's 18px corner curve, md:bottom-auto cancels the phone's
           sticky bottom bar. */}
        {!isOwner && (
          <div
            data-testid="billing-dock"
            className="sticky bottom-[calc(76px+env(safe-area-inset-bottom))] z-30 -mx-5 -mb-5 mt-3 shrink-0 rounded-b-[18px] border-t border-[var(--fx-line)] bg-[var(--fx-surf)] px-4 py-2.5 md:z-auto md:bottom-auto md:mx-0 md:mb-0 md:mt-0 md:flex md:min-h-0 md:w-[320px] md:shrink-0 md:flex-col md:rounded-b-none md:rounded-r-[17px] md:border-l md:border-t-0 md:py-4"
          >
            <BillingDock
              lines={lines}
              setQty={setQty}
              removeLine={removeLine}
              discount={discount}
              setDiscount={setDiscount}
              onGenerate={generate}
              generating={generating}
              billCount={billsToday}
              discLimit={discLimit}
              orderType={orderType}
              setOrderType={setOrderType}
              custName={custName}
              setCustName={setCustName}
              custPhone={custPhone}
              setCustPhone={setCustPhone}
              wallet={wallet}
              bonusPts={bonusPts}
              setBonusPts={setBonusPts}
            />
          </div>
        )}
        {isOwner && (
          <p className="mt-3 text-[10.5px] font-semibold text-[var(--fx-muted)]">
            OWNER MENU CONTROLS — ADD CATEGORY sits on top of the category row, every SECTION
            (tap a category chip) ends with a blank ADD DISH block — the blended ALL grid is
            browse/edit/delete only — each tile carries EDIT, and DELETE (tile or whole section)
            opens a WARNING that stays LOCKED for 10 seconds before it can fire. Billing lives at
            the reception counter.
          </p>
        )}
      </div>

      {/* t117 — LATEST RESTAURANT BILLS — the owner's collapsible read-only feed.
          Last 50 bills, no reprint, no undo — billing actions stay at the counter. */}
      {isOwner && (
        <div className="fx-card p-5" data-fx-motion="1" data-testid="menu-latest-bills">
          <button
            onClick={() => setBillsOpen((o) => !o)}
            aria-expanded={billsOpen}
            data-testid="menu-latest-bills-toggle"
            className="flex w-full flex-wrap items-center justify-between gap-2 text-left"
          >
            <span className="fx-label flex items-center gap-2">
              <Receipt className="h-3.5 w-3.5" /> LATEST RESTAURANT BILLS
            </span>
            <span className="flex items-center gap-2">
              <span className="mut-chip">LAST {ownerBills.length} · READ ONLY</span>
              <ChevronDown
                aria-hidden
                className={`h-4 w-4 text-[var(--fx-muted)] transition-transform ${billsOpen ? "" : "-rotate-90"}`}
              />
            </span>
          </button>
          {billsOpen && (
            <ScrollFadeBox className="mt-3" maxH={352}>
              <BillsFeed
                rows={ownerBills.map((b) => ({
                  key: b.id,
                  kind: "rest" as const,
                  bill: b,
                  title: `BILL #${b.number}`,
                  sub: `${b.itemCount} ${b.itemCount === 1 ? "ITEM" : "ITEMS"} · ${orderTypeLabel(b.orderType)} · ${customerTag(b)}${b.items.map((i) => i.name).slice(0, 2).join(", ")}${b.items.length > 2 ? "…" : ""}`,
                  amt: inr2(b.total),
                  at: istTime(b.createdAt),
                }))}
              />
            </ScrollFadeBox>
          )}
        </div>
      )}

      {/* ── t210 — the dock's old bottom position is gone at md+: the CURRENT
           BILL lives as the right rail of the dishes card above — one block
           with the search + dishes, menu left / bill right. Phones keep the
           sticky bottom bar. ── */}

      {/* ── Restaurant bills — the register's own feed, reprint + UNDO (counter only).
           t214 — it stays, but BELOW the vh-fixed menu card: out of view on
           load, scroll down to reach it (the first t214 pass removed it by
           misreading "until the restaurant bills disappear"; the user:
           "I did not want you to remove the restaurant bill… user should
           have to scroll to see it").
           t215 — COLLAPSIBLE like the owner's block: the header row is the
           toggle (chevron flips, state persists via useCachedToggle), the
           feed unfolds beneath. Shares the owner's billsOpen state — the two
           blocks never render together (isOwner splits them). ── */}
      {!isOwner && (
        <div className="fx-card p-5" data-fx-motion="1" data-testid="pos-recent-bills">
          <button
            onClick={() => setBillsOpen((o) => !o)}
            aria-expanded={billsOpen}
            data-testid="pos-recent-bills-toggle"
            className="flex w-full flex-wrap items-center justify-between gap-2 text-left"
          >
            <span className="fx-label flex items-center gap-2">
              <Receipt className="h-3.5 w-3.5" /> RESTAURANT BILLS · TAP TO REPRINT
            </span>
            <span className="flex items-center gap-2">
              <span className="mut-chip">{billsToday} TODAY · TAP UNDO TWICE TO TEAR ONE</span>
              <ChevronDown
                aria-hidden
                className={`h-4 w-4 text-[var(--fx-muted)] transition-transform ${billsOpen ? "" : "-rotate-90"}`}
              />
            </span>
          </button>
          {billsOpen && (
            <ScrollFadeBox className="mt-3" maxH={352}>
              <BillsFeed
                rows={recent.map((b) => ({
                  key: b.id,
                  kind: "rest" as const,
                  bill: b,
                  title: `BILL #${b.number}`,
                  sub: `${b.itemCount} ${b.itemCount === 1 ? "ITEM" : "ITEMS"} · ${orderTypeLabel(b.orderType)} · ${customerTag(b)}${b.items.map((i) => i.name).slice(0, 2).join(", ")}${b.items.length > 2 ? "…" : ""}`,
                  amt: inr2(b.total),
                  at: istTime(b.createdAt),
                }))}
                onReprint={(b) => openReceipt(b, "reprint")}
                onUndo={(r) => void undoBill(r.bill)}
              />
            </ScrollFadeBox>
          )}
        </div>
      )}

      {/* t230 — the mass-message desk MOVED OUT to its own CAMPAIGNING section
          (side panel → Campaigning); the billing page stays billing-only. */}

      {/* t129 — the STATION EXPENSES entry block is gone from the desk: the
          reception enters spends on the Expenses page (one block, three
          toggles) instead of here. */}

      {editDish && (
        <EditDishDialog
          dish={editDish}
          onClose={() => setEditDish(null)}
          onSaved={menuChanged}
        />
      )}

      {/* t115 — the delete warnings: dish + whole section, both locked 10s */}
      {confirmDish && (
        <DeleteWarningDialog
          kind="dish"
          name={confirmDish.name}
          busy={deleting}
          onClose={() => setConfirmDish(null)}
          onConfirm={() => void deleteDish(confirmDish)}
        />
      )}
      {confirmCat && (
        <DeleteWarningDialog
          kind="category"
          name={confirmCat.name}
          live={confirmCat.live}
          busy={deleting}
          onClose={() => setConfirmCat(null)}
          onConfirm={() => void deleteCategory(confirmCat)}
        />
      )}
    </div>
  );
}
