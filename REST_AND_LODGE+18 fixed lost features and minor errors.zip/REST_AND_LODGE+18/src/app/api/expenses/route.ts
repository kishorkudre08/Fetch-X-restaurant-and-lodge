import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";

export const dynamic = "force-dynamic";

const KINDS = ["raw_material", "upgrade", "maintenance"] as const;
type Kind = (typeof KINDS)[number];

// GET /api/expenses?limit=60&kind=raw_material|upgrade|maintenance&book=rest|lodge — recent cost entries
// t230 — kind=discount_rewards is a SYNTHETIC kind (no Expense rows): the
// money given away through discounts + the loyalty points minted on the same
// bills (1 pt = ₹1 of future bills), grouped per IST business day, per book.
// Read-only — it registers itself from the bills; nobody can enter or delete
// it (receptions never see it at all).
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 60) || 60, 200);
  const kind = req.nextUrl.searchParams.get("kind");
  const book = req.nextUrl.searchParams.get("book");

  if (kind === "discount_rewards") {
    const from = req.nextUrl.searchParams.get("from");
    const fromN = from === null ? NaN : Number(from);
    const since = Number.isFinite(fromN) ? new Date(fromN) : new Date(Date.now() - 365 * 86_400_000);
    if (isNaN(since.getTime())) return NextResponse.json([], { status: 400 });
    const books = book === "rest" || book === "lodge" ? [book] : ["rest", "lodge"];
    const rows: Array<Record<string, unknown>> = [];
    for (const bk of books) {
      const raw =
        bk === "rest"
          ? await db.$queryRaw<Array<{ d: string; disc: number; pts: number; n: bigint }>>`
              SELECT date("createdAt" / 1000 + 19800, 'unixepoch') AS d,
                     SUM("discount") AS disc, SUM("pointsEarned") AS pts, COUNT(*) AS n
              FROM "Bill" WHERE "createdAt" >= ${since}
              GROUP BY d ORDER BY d DESC LIMIT 400`
          : await db.$queryRaw<Array<{ d: string; disc: number; pts: number; n: bigint }>>`
              SELECT date("createdAt" / 1000 + 19800, 'unixepoch') AS d,
                     SUM("discount") AS disc, SUM("pointsEarned") AS pts, COUNT(*) AS n
              FROM "LodgeBill" WHERE "createdAt" >= ${since}
              GROUP BY d ORDER BY d DESC LIMIT 400`;
      for (const r of raw) {
        const disc = Math.round(r.disc ?? 0);
        const pts = Math.round(r.pts ?? 0);
        if (disc + pts <= 0) continue; // a bill-day with nothing given away
        rows.push({
          id: `auto-${bk}-${r.d}`,
          kind: "discount_rewards",
          book: bk,
          label: `AUTO · ${Number(r.n)} ${bk === "rest" ? "bills" : "stays"} · ${disc.toLocaleString("en-IN")} discounts + ${pts.toLocaleString("en-IN")} pts minted`,
          amount: disc + pts,
          spentOn: new Date(`${r.d}T12:00:00+05:30`),
          via: "auto",
          taskId: null,
          createdAt: new Date(`${r.d}T12:00:00+05:30`),
        });
      }
    }
    rows.sort((a, b) => new Date(b.spentOn as Date).getTime() - new Date(a.spentOn as Date).getTime());
    return NextResponse.json(rows.slice(0, Math.max(limit, 400)));
  }

  const expenses = await db.expense.findMany({
    where: {
      ...(kind && KINDS.includes(kind as Kind) ? { kind } : {}),
      ...(book === "rest" || book === "lodge" ? { book } : {}),
    },
    orderBy: [{ spentOn: "desc" }, { createdAt: "desc" }],
    take: limit,
  });
  return NextResponse.json(expenses);
}

// PATCH /api/expenses — { id, label?, amount?, spentOn?, kind? } — fix a wrong entry
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const id = String(body.id ?? "");
    if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

    const data: Record<string, unknown> = {};
    if (body.label !== undefined) data.label = String(body.label).trim().slice(0, 120);
    if (body.amount !== undefined) {
      const amount = Math.round(Number(body.amount) * 100) / 100;
      if (!Number.isFinite(amount) || amount <= 0)
        return NextResponse.json({ error: "Amount must be above zero" }, { status: 400 });
      data.amount = amount;
    }
    if (body.spentOn !== undefined) {
      const d = new Date(String(body.spentOn));
      if (!Number.isFinite(d.getTime()))
        return NextResponse.json({ error: "Invalid date" }, { status: 400 });
      if (d.getTime() > Date.now() + 86_400_000)
        return NextResponse.json({ error: "Costs cannot be dated in the future" }, { status: 400 });
      data.spentOn = d;
    }
    if (body.kind !== undefined) {
      const kind = String(body.kind) as Kind;
      if (!KINDS.includes(kind))
        return NextResponse.json({ error: "Invalid kind" }, { status: 400 });
      data.kind = kind;
    }
    if (body.book === "rest" || body.book === "lodge") data.book = body.book;
    if (Object.keys(data).length === 0)
      return NextResponse.json({ error: "Nothing to update" }, { status: 400 });

    const expense = await db.expense.update({ where: { id }, data });
    invalidateDashboardCache();
    return NextResponse.json(expense);
  } catch {
    return NextResponse.json({ error: "Could not update expense" }, { status: 500 });
  }
}

// POST /api/expenses — { kind, label?, amount, spentOn?, book? }
// The owner's manual data-entry moment — and since t98 both receptions log
// their own station costs here too (raw materials, upgrades, maintenance).
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const kind = String(body.kind ?? "") as Kind;
    if (!KINDS.includes(kind))
      return NextResponse.json(
        { error: "kind must be raw_material, upgrade or maintenance" },
        { status: 400 },
      );

    const amount = Math.round(Number(body.amount) * 100) / 100;
    if (!Number.isFinite(amount) || amount <= 0)
      return NextResponse.json({ error: "Amount must be above zero" }, { status: 400 });

    const label = String(body.label ?? "").trim().slice(0, 120);
    const spentOnRaw = body.spentOn ? new Date(String(body.spentOn)) : new Date();
    const spentOn = Number.isFinite(spentOnRaw.getTime()) ? spentOnRaw : new Date();
    if (spentOn.getTime() > Date.now() + 86_400_000)
      return NextResponse.json({ error: "Costs cannot be dated in the future" }, { status: 400 });

    const book = body.book === "lodge" ? "lodge" : "rest"; // which cost book carries this entry
    const expense = await db.expense.create({ data: { kind, book, label, amount, spentOn } });
    invalidateDashboardCache();
    return NextResponse.json(expense, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not save expense" }, { status: 500 });
  }
}

// DELETE /api/expenses?id=… — hard delete a wrong entry
export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });
  try {
    await db.expense.delete({ where: { id } });
    invalidateDashboardCache();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Could not delete expense" }, { status: 500 });
  }
}
