import { NextRequest, NextResponse } from "next/server";
import { ensureTiersSeeded, listTiers, saveTiers } from "@/lib/loyalty-tiers";

export const dynamic = "force-dynamic";

// t230 — the owner's LOYALTY RANK ranges (Settings → LOYALTY RANKS).
// GET  → the ranges, seeded with defaults the first time the owner looks.
// PUT  → replace the whole set (the editor saves all rows at once, exactly
//        like the room-levels editor does for graded rates).
export async function GET() {
  await ensureTiersSeeded();
  return NextResponse.json({ tiers: await listTiers() });
}

export async function PUT(req: NextRequest) {
  const body = (await req.json().catch(() => null)) as { tiers?: unknown } | null;
  if (!body || !Array.isArray(body.tiers))
    return NextResponse.json({ error: "Bad body — tiers[] required" }, { status: 400 });
  if (body.tiers.length > 12)
    return NextResponse.json({ error: "At most 12 rank ranges" }, { status: 400 });
  const tiers = await saveTiers(body.tiers as never);
  return NextResponse.json({ ok: true, tiers });
}
