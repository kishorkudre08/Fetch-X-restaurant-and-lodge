import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getLoyaltyPct } from "@/lib/settings";
import { rankOfPhone } from "@/lib/customers";
import { tierForRank } from "@/lib/loyalty-tiers";

export const dynamic = "force-dynamic";

// GET /api/loyalty?phone=9876500011 — the customer's POINTS WALLET.
// t225 — the loyalty wallet is keyed by the 10-digit phone and SHARED across
// both books: restaurant bills (customerPhone) and lodge stays (guestPhone)
// mint points into it, and redemptions burn from it. The balance is always
// RECOMPUTED from the bill rows (earned + bonus − used) — never stored in a
// separate table — so undoing any bill heals the wallet by itself.
// t230 — the response also carries the customer's ALL-TIME SPEND RANK and the
// owner's tier that rank falls in (the billing docks show the badge and gate
// the reception's top-customer bonus on bonusAllowed).
// Response: { phone, name, visits, earned, used, bonus, balance, earnPct,
//             basePct, rank, tierLabel, tierEarnPct, bonusAllowed, lastSeen }
export async function GET(req: NextRequest) {
  const phone = String(req.nextUrl.searchParams.get("phone") ?? "").replace(/\D/g, "").slice(0, 10);
  if (phone.length !== 10)
    return NextResponse.json({ error: "A 10-digit phone is required" }, { status: 400 });

  try {
    const [restAgg, lodgeAgg, lastRest, lastLodge, basePct, rank] = await Promise.all([
      db.bill.aggregate({
        where: { customerPhone: phone },
        _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true },
        _count: true,
      }),
      db.lodgeBill.aggregate({
        where: { guestPhone: phone },
        _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true },
        _count: true,
      }),
      db.bill.findFirst({
        where: { customerPhone: phone },
        orderBy: { createdAt: "desc" },
        select: { customerName: true, createdAt: true },
      }),
      db.lodgeBill.findFirst({
        where: { guestPhone: phone },
        orderBy: { createdAt: "desc" },
        select: { guestName: true, createdAt: true },
      }),
      getLoyaltyPct(),
      rankOfPhone(phone),
    ]);

    const earned = Math.round((restAgg._sum.pointsEarned ?? 0) + (lodgeAgg._sum.pointsEarned ?? 0));
    const used = Math.round((restAgg._sum.pointsUsed ?? 0) + (lodgeAgg._sum.pointsUsed ?? 0));
    const bonus = Math.round((restAgg._sum.bonusPoints ?? 0) + (lodgeAgg._sum.bonusPoints ?? 0));
    const tier = await tierForRank(rank);
    // Newest identity wins (bills are newest-first): a name from either book.
    const restTs = lastRest?.createdAt ? new Date(lastRest.createdAt).getTime() : 0;
    const lodgeTs = lastLodge?.createdAt ? new Date(lastLodge.createdAt).getTime() : 0;
    const name = restTs >= lodgeTs ? lastRest?.customerName ?? lastLodge?.guestName ?? null : lastLodge?.guestName ?? lastRest?.customerName ?? null;
    const lastSeenTs = Math.max(restTs, lodgeTs);

    return NextResponse.json({
      phone,
      name,
      visits: (restAgg._count ?? 0) + (lodgeAgg._count ?? 0),
      earned,
      used,
      bonus,
      balance: Math.max(0, earned + bonus - used),
      earnPct: tier ? tier.earnPct : basePct, // t230 — the rank's earn wins
      basePct,
      rank,
      tierLabel: tier?.label ?? null,
      tierEarnPct: tier?.earnPct ?? null,
      bonusAllowed: !!tier, // receptions may bonus ranked (top) customers only
      lastSeen: lastSeenTs ? new Date(lastSeenTs).toISOString() : null,
    });
  } catch {
    return NextResponse.json({ error: "Could not read the loyalty wallet" }, { status: 500 });
  }
}
