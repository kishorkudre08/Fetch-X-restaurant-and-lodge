import { NextResponse } from "next/server";
import { getTopCustomers } from "@/lib/analytics";

export const dynamic = "force-dynamic";

// t231 — the TOP CUSTOMERS ledger moved OFF the live dashboard INTO the
// owner's Mass Messages section (the campaigning audience). Served as its
// own endpoint so the broadcasts view doesn't need the whole dashboard
// payload; rows come from the same 60s-cached getTopCustomers() the
// dashboard/AI use, so every reader sees the same rank order.
export async function GET() {
  return NextResponse.json({ topCustomers: await getTopCustomers() });
}
