import { NextRequest, NextResponse } from "next/server";
import { stat } from "fs/promises";
import path from "path";
import { db } from "@/lib/db";
import { filterByAudience, listCustomers, renderTemplate } from "@/lib/customers";
import { getPointsSummary, invalidateDashboardCache } from "@/lib/analytics";
import type { BroadcastAttachment } from "@/lib/types";

export const dynamic = "force-dynamic";

const WINDOWS: Record<string, number> = { "7d": 7, "1m": 30, "3m": 91, "1y": 365 };

// t229 — mass-message log for both receptions' composer.
// t230 — GET reads two ways:
//   · no params → the latest 20 sends (the composer's RECENT SENDS log);
//   · ?window=7d|1m|3m|1y&type=all|notice|personal → the OWNER's Mass
//     Messages preview (expenses-style): every send inside the window,
//     optionally only the advertisement notices or the personalised sends.
// POST → log one send: the audience filter, the text (ONE box — if it carries
//        {PLACEHOLDERS} it is filed as a personal message, otherwise as a
//        plain notice), how many wallets matched (recomputed server-side from
//        the live ledger — never trusted from the client) and one rendered
//        sample. There is no SMS gateway in the sandbox: "sending" records
//        the campaign the counter fired, exactly like a real CRM log row.
// t232 — `sentBy: "MANAGER"` is accepted verbatim (the manager account fires
//        campaigns for both desks); anything else derives from `book`.
// t233 — the manager's campaigning has NO business toggle (one franchise,
//        universal points): book "franchise" is accepted and stamped as-is.
// t235 — window GETs also return `points`: the loyalty-points cards — total
//        points customers hold RIGHT NOW, points used inside the window and
//        distinct customers using them (computed from the bill rows).
// t236 — every row carries `attachments`: the photos/videos the sender
//        attached (uploaded via /api/uploads, streamed by /api/media/[name])
//        — the manager's campaign media, visible in Recent Sends and the
//        owner's Mass Messages log.

/** t236 — the stored JSON string → a clean attachment list (never throws) */
function parseAtts(raw: string): BroadcastAttachment[] {
  try {
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((a) => a && typeof a.url === "string" && /^\/api\/media\/[A-Za-z0-9._-]+$/.test(a.url) && (a.kind === "image" || a.kind === "video"))
      .slice(0, 4)
      .map((a) => ({ url: a.url as string, kind: a.kind as "image" | "video", name: typeof a.name === "string" ? a.name.slice(0, 120) : "" }));
  } catch {
    return [];
  }
}
export async function GET(req: NextRequest) {
  const win = req.nextUrl.searchParams.get("window") ?? "";
  const type = req.nextUrl.searchParams.get("type") ?? "all";
  if (win && WINDOWS[win]) {
    const since = new Date(Date.now() - WINDOWS[win] * 86_400_000);
    const rows = await db.broadcast.findMany({
      where: {
        createdAt: { gte: since },
        ...(type === "personal" ? { message: { not: "" } } : type === "notice" ? { notice: { not: "" } } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 500,
    });
    return NextResponse.json({ broadcasts: rows.map((r) => ({ ...r, attachments: parseAtts(r.attachments) })), points: await getPointsSummary(since) });
  }
  const rows = await db.broadcast.findMany({ orderBy: { createdAt: "desc" }, take: 20 });
  return NextResponse.json({ broadcasts: rows.map((r) => ({ ...r, attachments: parseAtts(r.attachments) })) });
}

const AUDIENCES = ["all", "pts_500", "pts_1000", "pts_3000", "custom"];

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => null)) as {
    audience?: string;
    threshold?: number;
    text?: string; // t230 — the ONE box (auto-filed personal vs notice)
    message?: string; // legacy two-box fields still accepted
    notice?: string;
    book?: string;
    sentBy?: string; // t232 — "MANAGER" override, allow-listed
    attachments?: Array<{ url?: string; kind?: string; name?: string }>; // t236 — campaign media
  } | null;
  if (!body) return NextResponse.json({ error: "Bad body" }, { status: 400 });

  const audience = AUDIENCES.includes(body.audience ?? "") ? body.audience! : "all";
  const threshold = Math.max(0, Math.round(Number(body.threshold) || 0));
  const book = body.book === "lodge" ? "lodge" : body.book === "franchise" ? "franchise" : "rest";

  // t230 — ONE BOX: when `text` is present the server files it itself —
  // any {PLACEHOLDER} makes it a personal message, none makes it a notice.
  let message = String(body.message ?? "").slice(0, 2000);
  let notice = String(body.notice ?? "").slice(0, 2000);
  if (typeof body.text === "string") {
    const text = body.text.slice(0, 2000);
    if (/\{[^{}]{1,24}\}/.test(text)) {
      message = text;
      notice = "";
    } else {
      notice = text;
      message = "";
    }
  }
  if (!message.trim() && !notice.trim()) {
    return NextResponse.json({ error: "Write a message first — nothing to send." }, { status: 400 });
  }

  const base = await listCustomers();
  const recipients = filterByAudience(base, audience, threshold);
  if (recipients.length === 0) {
    return NextResponse.json({ error: "No customers match this audience." }, { status: 400 });
  }
  // the sample rides the biggest matching wallet — the least surprising preview
  const sampleRow = recipients[0];
  const sample = message.trim() ? renderTemplate(message, sampleRow) : notice;

  // t236 — campaign media: only files this server handed out earlier
  // (/api/uploads → /api/media/<name>), at most 4 per send. The URL must
  // match the server-generated shape AND the file must exist on disk — a
  // reference to a media file that was never uploaded is dropped here.
  const attachments: BroadcastAttachment[] = [];
  if (Array.isArray(body.attachments)) {
    for (const a of body.attachments.slice(0, 4)) {
      if (!a || typeof a.url !== "string" || (a.kind !== "image" && a.kind !== "video")) continue;
      const m = /^\/api\/media\/([A-Za-z0-9._-]+)$/.exec(a.url);
      if (!m || m[1].includes("..")) continue;
      try {
        await stat(path.join(process.cwd(), "uploads", "broadcasts", m[1]));
      } catch {
        continue; // never-uploaded (or deleted) media — not riding this send
      }
      attachments.push({ url: a.url, kind: a.kind, name: String(a.name ?? "").slice(0, 120) });
    }
  }

  const row = await db.broadcast.create({
    data: {
      audience,
      threshold: audience === "custom" ? threshold : null,
      message,
      notice,
      recipients: recipients.length,
      sample,
      book,
      attachments: JSON.stringify(attachments),
      // t232 — the manager's sends wear MANAGER; the desks keep their names.
      // t233 — franchise sends (no desk) fall back to FRANCHISE DESK if a
      // caller ever forgets the MANAGER override.
      sentBy: body.sentBy === "MANAGER" ? "MANAGER" : book === "lodge" ? "LODGE RECEPTION" : book === "franchise" ? "FRANCHISE DESK" : "RESTAURANT RECEPTION",
    },
  });

  // t235 — a fresh send must appear at once: as a marker dot on the Live
  // Dashboard's revenue trend and in the audience counts
  invalidateDashboardCache();

  return NextResponse.json({ ok: true, broadcast: { ...row, attachments: parseAtts(row.attachments) } });
}
