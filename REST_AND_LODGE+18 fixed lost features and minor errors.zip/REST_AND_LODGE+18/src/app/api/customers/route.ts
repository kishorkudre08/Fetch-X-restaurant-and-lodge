import { NextResponse } from "next/server";
import { listCustomers } from "@/lib/customers";

export const dynamic = "force-dynamic";

// t229 — the customer base behind BOTH receptions' mass-message composer:
// every phone-keyed identity across restaurant + lodge, with its live loyalty
// wallet. The composer filters audiences client-side (all / 500+ / 1000+ /
// 3000+ / custom threshold) off this single snapshot (60s server cache).
export async function GET() {
  const rows = await listCustomers();
  return NextResponse.json({
    total: rows.length,
    pts500: rows.filter((r) => r.balance >= 500).length,
    pts1000: rows.filter((r) => r.balance >= 1000).length,
    pts3000: rows.filter((r) => r.balance >= 3000).length,
    customers: rows,
  });
}
