import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";
import { getDiscountLimit, getLoyaltyPct } from "@/lib/settings";
import { rankOfPhone } from "@/lib/customers";
import { earnPctForRank, tierForRank } from "@/lib/loyalty-tiers";
import { ORDER_TYPE_IDS } from "@/lib/types";

export const dynamic = "force-dynamic";

const GST_RATE = 0.05;

// GET /api/bills?limit=20 — most recent bills with their items
export async function GET(req: NextRequest) {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 20) || 20, 100);
  const bills = await db.bill.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { items: true },
  });
  return NextResponse.json(bills);
}

// POST /api/bills — THE ZERO-ENTRY DATA PIPELINE.
// The cashier only taps dishes + quantities. Prices are pulled from the menu,
// the timestamp is stamped here, and every line is written automatically.
// t225 — the identity is STRICT now: an order channel, the customer's name
// and a 10-digit phone are ALL mandatory — no bill leaves the counter
// without them. Loyalty rides the same call: the discount's portion beyond
// the owner's limit burns the phone-keyed points (1 pt = ₹1), and the bill
// mints new points worth loyaltyPct% of what the customer actually pays.
// body: { items: [{ dishId, qty }], discount?, orderType, customerName, customerPhone }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const rawItems: Array<{ dishId?: unknown; qty?: unknown }> = Array.isArray(body.items)
      ? body.items
      : [];
    const discount = Math.max(0, Number(body.discount) || 0);
    // t225 — the order channel is MANDATORY: the dock's 4-way toggle always
    // carries a selection, so a missing/unknown one means a hand-crafted
    // request — refuse it instead of silently filing the bill as dine-in.
    if (!ORDER_TYPE_IDS.includes(String(body.orderType)))
      return NextResponse.json(
        { error: "Pick an order type before generating the bill" },
        { status: 400 },
      );
    const orderType = String(body.orderType);
    // t225 — CUSTOMER IDENTITY IS MANDATORY (the owner collects data strictly):
    // every bill belongs to a keyed name + 10-digit phone. Names collide,
    // numbers don't — the phone is the identity key (and the loyalty wallet
    // key), the same discipline as the lodge desk.
    const customerName = String(body.customerName ?? "").trim().slice(0, 80);
    if (customerName.length < 2)
      return NextResponse.json(
        { error: "Enter the customer's name before generating the bill" },
        { status: 400 },
      );
    const customerPhone = String(body.customerPhone ?? "").replace(/\D/g, "");
    if (customerPhone.length !== 10)
      return NextResponse.json(
        { error: "The customer phone needs exactly 10 digits" },
        { status: 400 },
      );

    // Merge duplicate dishes, validate quantities
    const qtyByDish = new Map<string, number>();
    for (const it of rawItems) {
      const dishId = String(it.dishId ?? "");
      const qty = Math.floor(Number(it.qty));
      if (!dishId || !Number.isFinite(qty) || qty <= 0) continue;
      qtyByDish.set(dishId, (qtyByDish.get(dishId) ?? 0) + qty);
    }
    if (qtyByDish.size === 0)
      return NextResponse.json({ error: "Bill has no items" }, { status: 400 });

    const dishIds = [...qtyByDish.keys()];
    const dishes = await db.dish.findMany({ where: { id: { in: dishIds }, active: true } });
    if (dishes.length !== dishIds.length)
      return NextResponse.json({ error: "One or more dishes are unavailable" }, { status: 400 });

    const lines = dishes.map((d) => {
      const qty = qtyByDish.get(d.id)!;
      return { dishId: d.id, name: d.name, category: d.category, qty, price: d.price };
    });

    const subtotal = lines.reduce((s, l) => s + l.qty * l.price, 0);
    // t143 — the owner's discount rule is re-checked SERVER-SIDE: whatever the
    // client sends, a reception can never write a discount above the limit %
    // of the bill's value (paise-exact, rounded down).
    // t225 — the cap GROWS by the customer's loyalty wallet: beyond the owner's
    // limit the discount burns points (1 pt = ₹1), never more than the wallet
    // holds. Regular discount fills the limit first; points cover the excess.
    const [discLimit, basePct, rank] = await Promise.all([
      getDiscountLimit(),
      getLoyaltyPct(),
      rankOfPhone(customerPhone),
    ]);
    const discCap = Math.floor(subtotal * discLimit) / 100;
    const [restWallet, lodgeWallet] = await Promise.all([
      db.bill.aggregate({ where: { customerPhone }, _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true } }),
      db.lodgeBill.aggregate({ where: { guestPhone: customerPhone }, _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true } }),
    ]);
    const wallet =
      Math.round((restWallet._sum.pointsEarned ?? 0) + (lodgeWallet._sum.pointsEarned ?? 0)) +
      Math.round((restWallet._sum.bonusPoints ?? 0) + (lodgeWallet._sum.bonusPoints ?? 0)) -
      Math.round((restWallet._sum.pointsUsed ?? 0) + (lodgeWallet._sum.pointsUsed ?? 0));
    const balance = Math.max(0, wallet);
    const safeDiscount = Math.min(discount, discCap + balance, subtotal);
    const pointsUsed = Math.min(Math.max(0, safeDiscount - discCap), balance);
    const taxable = Math.max(0, subtotal - safeDiscount);
    const tax = Math.round(taxable * GST_RATE * 100) / 100;
    const total = Math.round((taxable + tax) * 100) / 100;
    // t225 → t230 — the bill MINTS points worth the customer's RANK % of what
    // they actually pay (after discount + GST), rounded to whole points. The
    // owner's LoyaltyTier ranges override the base % for top-ranked customers.
    const loyaltyPct = await earnPctForRank(rank, basePct);
    const pointsEarned = loyaltyPct > 0 ? Math.round((total * loyaltyPct) / 100) : 0;
    // t230 — TOP-CUSTOMER BONUS: the reception may hand extra points to a
    // ranked customer (their rank falls inside one of the owner's ranges).
    // Clamped server-side: whole points, 0–1,000, never for unranked walk-ins.
    const tier = await tierForRank(rank);
    const bonusPoints = tier
      ? Math.min(1000, Math.max(0, Math.round(Number(body.bonusPoints) || 0)))
      : 0;
    const itemCount = lines.reduce((s, l) => s + l.qty, 0);

    const bill = await db.$transaction(async (tx) => {
      // Successive numbering: normally count upward, but when an UNDO tore a
      // hole out of the series (e.g. #11268 was torn, #11269 exists), the next
      // bill reuses the first free number so the sequence never skips.
      const maxAgg = await tx.bill.aggregate({ _max: { number: true } });
      const count = await tx.bill.count();
      const max = maxAgg._max.number ?? 1000;
      let number: number;
      if (count === max - 1000) {
        number = max + 1; // dense series 1001…max — keep counting up
      } else {
        const nums = await tx.bill.findMany({ select: { number: true }, orderBy: { number: "asc" } });
        number = 1001;
        for (const n of nums) {
          if (n.number === number) number += 1;
          else break;
        }
      }
      return tx.bill.create({
        data: {
          number,
          subtotal: Math.round(subtotal * 100) / 100,
          discount: Math.round(safeDiscount * 100) / 100,
          tax,
          total,
          itemCount,
          orderType,
          customerName,
          customerPhone,
          pointsEarned,
          pointsUsed: Math.round(pointsUsed * 100) / 100,
          bonusPoints,
          items: {
            create: lines.map((l) => ({
              dishId: l.dishId,
              name: l.name,
              category: l.category,
              qty: l.qty,
              price: l.price,
            })),
          },
        },
        include: { items: true },
      });
    });

    // The instant a bill lands, the dashboard must reflect it on next fetch.
    invalidateDashboardCache();

    return NextResponse.json(bill, { status: 201 });
  } catch (e) {
    console.error("Bill creation failed:", e);
    return NextResponse.json({ error: "Bill generation failed" }, { status: 500 });
  }
}
