import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Demo sign-in — four fixed demo accounts (no account creation, everything
 * stays local). t104 — the developer account is gone entirely:
 *   • OWNER                — full platform: dashboard, menu, lodge, expenses, employee
 *   • RECEPTION_RESTAURANT — cashier station: POS billing
 *   • RECEPTION_LODGE      — front-desk station: the 100-room wall
 * t232 — MANAGER: one account for BOTH businesses — campaigning, expenses,
 * tasks and attendance live there now (the receptions carry only their desk).
 */
const ACCOUNTS = [
  {
    email: "spiceowner@gmail.com",
    password: "spiceowner",
    name: "Imperial",
    role: "owner",
    label: "OWNER",
  },
  {
    email: "spicerestaurant@gmail.com",
    password: "spicerestaurant",
    name: "Imperial",
    role: "reception_restaurant",
    label: "RESTAURANT RECEPTION",
  },
  {
    email: "spicelodge@gmail.com",
    password: "spicelodge",
    name: "Imperial",
    role: "reception_lodge",
    label: "LODGE RECEPTION",
  },
  {
    email: "spicemanager@gmail.com",
    password: "spicemanager",
    name: "Imperial",
    role: "manager",
    label: "MANAGER",
  },
];

export async function POST(req: Request) {
  let body: { email?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request." }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (!email || !password) {
    return NextResponse.json({ ok: false, error: "Email and password are required." }, { status: 400 });
  }

  const acct = ACCOUNTS.find((a) => a.email === email && a.password === password);
  if (!acct) {
    return NextResponse.json({ ok: false, error: "Wrong email or password." }, { status: 401 });
  }

  return NextResponse.json({
    ok: true,
    user: { name: acct.name, role: acct.role, email: acct.email },
    label: acct.label,
  });
}
