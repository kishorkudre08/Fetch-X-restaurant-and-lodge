import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

/**
 * t236 — CAMPAIGN MEDIA UPLOAD: the manager attaches photos/videos to a mass
 * message. Files arrive as multipart/form-data (field "file", one call per
 * file), are validated (images/videos only, ≤ 12 MB) and written to
 * uploads/broadcasts/<unique>.<ext> OUTSIDE the public/ tree — they are
 * streamed back by GET /api/media/[name] (with video Range support), so the
 * build mode never matters. Returns the attachment meta the composer then
 * rides inside POST /api/broadcasts.
 */

const MAX_BYTES = 12 * 1024 * 1024; // 12 MB per file
const MAX_FILES = 4; // per request (the composer allows 4 per campaign)

const KINDS: Record<string, { kind: "image" | "video"; ext: string }> = {
  "image/png": { kind: "image", ext: "png" },
  "image/jpeg": { kind: "image", ext: "jpg" },
  "image/webp": { kind: "image", ext: "webp" },
  "image/gif": { kind: "image", ext: "gif" },
  "video/mp4": { kind: "video", ext: "mp4" },
  "video/webm": { kind: "video", ext: "webm" },
  "video/quicktime": { kind: "video", ext: "mov" },
  "video/x-m4v": { kind: "video", ext: "m4v" },
};

export async function POST(req: NextRequest) {
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Expected multipart form data." }, { status: 400 });
  }
  const files = form.getAll("file").filter((f): f is File => f instanceof File);
  if (files.length === 0) {
    return NextResponse.json({ error: "No file in the upload." }, { status: 400 });
  }
  if (files.length > MAX_FILES) {
    return NextResponse.json({ error: `At most ${MAX_FILES} files per upload.` }, { status: 400 });
  }

  const dir = path.join(process.cwd(), "uploads", "broadcasts");
  await mkdir(dir, { recursive: true });

  const saved: Array<{ url: string; kind: "image" | "video"; name: string; size: number }> = [];
  for (const f of files) {
    const kind = KINDS[f.type];
    if (!kind) {
      return NextResponse.json({ error: `“${f.name}” is not an image or video the campaign can carry.` }, { status: 400 });
    }
    if (f.size > MAX_BYTES) {
      return NextResponse.json({ error: `“${f.name}” is over the 12 MB limit.` }, { status: 400 });
    }
    const stored = `${Date.now().toString(36)}-${randomUUID().slice(0, 8)}.${kind.ext}`;
    const buf = Buffer.from(await f.arrayBuffer());
    await writeFile(path.join(dir, stored), buf);
    saved.push({ url: `/api/media/${stored}`, kind: kind.kind, name: f.name.slice(0, 120), size: f.size });
  }

  return NextResponse.json({ ok: true, files: saved, file: saved[0] });
}
