import { NextRequest, NextResponse } from "next/server";
import { stat, readFile } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

/**
 * t236 — CAMPAIGN MEDIA STREAMER: serves the images/videos attached to mass
 * messages from uploads/broadcasts/ (kept outside public/ so files added at
 * runtime work in every build mode). Filenames are server-generated
 * (<base36 ts>-<uuid8>.<ext>), so a strict allow-list pattern doubles as the
 * path-traversal guard. Videos get byte-Range support so <video> can seek.
 */

const MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
  mp4: "video/mp4",
  webm: "video/webm",
  mov: "video/quicktime",
  m4v: "video/x-m4v",
};

export async function GET(req: NextRequest, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  if (!/^[A-Za-z0-9._-]+$/.test(name) || name.includes("..")) {
    return NextResponse.json({ error: "Bad media name" }, { status: 400 });
  }
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  const mime = MIME[ext];
  if (!mime) return NextResponse.json({ error: "Unsupported media type" }, { status: 400 });

  const file = path.join(process.cwd(), "uploads", "broadcasts", name);
  let size: number;
  try {
    size = (await stat(file)).size;
  } catch {
    return NextResponse.json({ error: "Media not found" }, { status: 404 });
  }

  const range = req.headers.get("range");
  // byte-Range support (video seeking) — reply 206 with the requested slice
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    if (m) {
      const start = m[1] ? Number(m[1]) : 0;
      const end = m[2] ? Math.min(Number(m[2]), size - 1) : size - 1;
      if (Number.isNaN(start) || start >= size || start > end) {
        return new NextResponse(null, { status: 416, headers: { "Content-Range": `bytes */${size}` } });
      }
      const buf = await readFile(file);
      const slice = buf.subarray(start, end + 1);
      return new NextResponse(new Uint8Array(slice), {
        status: 206,
        headers: {
          "Content-Type": mime,
          "Content-Length": String(slice.byteLength),
          "Content-Range": `bytes ${start}-${end}/${size}`,
          "Accept-Ranges": "bytes",
          "Cache-Control": "public, max-age=31536000, immutable",
        },
      });
    }
  }

  const buf = await readFile(file);
  return new NextResponse(new Uint8Array(buf), {
    status: 200,
    headers: {
      "Content-Type": mime,
      "Content-Length": String(size),
      "Accept-Ranges": "bytes",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
