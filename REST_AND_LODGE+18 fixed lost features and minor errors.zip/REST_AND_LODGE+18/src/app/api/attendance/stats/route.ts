import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { RANGE_META, parseRange } from "@/lib/analytics";

export const dynamic = "force-dynamic";

// ── t120 · ATTENDANCE GRAPH — consistent per-employee day math ─────────────
// The dashboard's attendance bars must show the SAME total days for every
// employee — the length of the selected window — no matter how many rows
// exist in the attendance table:
//   today = 1 · 7 days = 7 · 1 month = 30 · 3 months = 91 · 1 year = 365
// present  = attendance rows marked present inside the window
// absent   = totalDays − present (unmarked days count as absent)
//
// t2xx · WHY EMPLOYEES LOOKED "VERY ABSENT" — the owner's question, answered
// in data. Two honest causes, both now measured instead of hidden:
//   1. WINDOW OVERREACH — the lifetime ceiling (365 × 50 days) and even 3y
//      reach back BEFORE the attendance register exists (first row 2020), and
//      include every closed Sunday. Unmarked days defaulted to absent, so an
//      employee with ~2,300 present days showed ~15,900 "absent" ones.
//      FIX — lifetime now clamps its start to the FIRST attendance row,
//      exactly the way the dashboard clamps its revenue lifetime to the first
//      bill. 3y clamps to the register too when the register is younger.
//   2. UNMARKED ≠ LEAVE — the response now carries the split: days the
//      register actually marked absent (real leave) vs days it never marked
//      (before the register started, closed Sundays, future days of an open
//      window). The dashboard prints both so the wall explains itself.
export async function GET(req: NextRequest) {
  const range = parseRange(req.nextUrl.searchParams.get("range"));
  const requestedDays = RANGE_META[range].days;

  // IST date keys covering the window (same convention as the attendance UI).
  const IST_OFFSET_MIN = 330;
  const nowIst = new Date(Date.now() + IST_OFFSET_MIN * 60000);
  const todayKey = nowIst.toISOString().slice(0, 10);

  // Clamp the window start to the register's first row for long ranges —
  // lifetime follows the dashboard's "start = first record" convention, and
  // 3y clamps too when the register is younger than three years. Short ranges
  // (today…1y) keep their plain calendar math.
  const firstRow = await db.attendance.findFirst({
    orderBy: { date: "asc" },
    select: { date: true },
  });
  const firstKey = firstRow?.date ?? null;
  let from: string;
  if ((range === "lifetime" || range === "3y") && firstKey) {
    from = range === "lifetime" ? firstKey : (firstKey > isoDaysAgo(requestedDays) ? firstKey : isoDaysAgo(requestedDays));
  } else {
    from = isoDaysAgo(requestedDays);
  }

  // Build the day-key list from the (possibly clamped) window.
  const keys: string[] = [];
  for (let key = from; key <= todayKey; key = nextDayKey(key)) keys.push(key);
  const days = keys.length;
  const to = todayKey;

  const [employees, marks] = await Promise.all([
    db.employee.findMany({ where: { active: true }, orderBy: [{ book: "asc" }, { salary: "desc" }] }),
    db.attendance.groupBy({
      by: ["employeeId", "status"],
      where: { date: { gte: from, lte: to } },
      _count: true,
    }),
  ]);

  const presentOf = new Map<string, number>();
  const absentMarkedOf = new Map<string, number>();
  for (const m of marks) {
    if (m.status === "present") presentOf.set(m.employeeId, m._count);
    if (m.status === "absent") absentMarkedOf.set(m.employeeId, m._count);
  }

  const employeesOut = employees.map((e) => {
    const present = Math.min(presentOf.get(e.id) ?? 0, days);
    const absentMarked = absentMarkedOf.get(e.id) ?? 0;
    return {
      id: e.id,
      name: e.name,
      role: e.role,
      book: e.book as "rest" | "lodge",
      present,
      absent: days - present,
      // t2xx — the marked-absent count rides along so the UI can separate
      // real leave from unmarked days (absent = marked + unmarked now).
      absentMarked,
      unmarked: Math.max(0, days - present - absentMarked),
      total: days,
    };
  });

  // ── t2xx · ABSENCE INSIGHTS — "why are employees very absent?" ──────────
  // Everything below is computed from real rows only: weekday rhythm, the
  // heaviest absence dates, per-employee rates, and the marked/unmarked wall
  // split that used to masquerade as absence. Rows of employees who have since
  // been deactivated are excluded so the split matches the active roster.
  const activeIds = new Set(employees.map((e) => e.id));
  const insightRows = await db.attendance.findMany({
    where: { date: { gte: from, lte: to }, employeeId: { in: [...activeIds] } },
    select: { date: true, status: true, employeeId: true },
  });

  const WD = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
  const wdMap = new Map<string, { present: number; absent: number }>();
  const dateMap = new Map<string, { present: number; absent: number }>();
  let markedPresent = 0;
  let markedAbsent = 0;
  for (const r of insightRows) {
    const isPresent = r.status === "present";
    if (isPresent) markedPresent += 1;
    else markedAbsent += 1;
    const wd = WD[new Date(r.date + "T00:00:00Z").getUTCDay()];
    const w = wdMap.get(wd) ?? { present: 0, absent: 0 };
    if (isPresent) w.present += 1;
    else w.absent += 1;
    wdMap.set(wd, w);
    const d = dateMap.get(r.date) ?? { present: 0, absent: 0 };
    if (isPresent) d.present += 1;
    else d.absent += 1;
    dateMap.set(r.date, d);
  }

  const markedTotal = markedPresent + markedAbsent;
  const unmarkedDays = Math.max(0, days * employees.length - markedTotal);
  const byWeekday = WD.map((label) => {
    const w = wdMap.get(label) ?? { present: 0, absent: 0 };
    const total = w.present + w.absent;
    return {
      label,
      present: w.present,
      absent: w.absent,
      // no marks at all (closed Sundays) → null so the UI can grey it out
      ratePct: total ? Math.round((w.absent / total) * 100) : null,
    };
  });
  const topDates = [...dateMap.entries()]
    .map(([date, d]) => ({ date, absent: d.absent, present: d.present }))
    .sort((a, b) => b.absent - a.absent)
    .slice(0, 5);

  const insights = {
    windowStart: from,
    windowEnd: to,
    days,
    requestedDays: requestedDays,
    clamped: from !== isoDaysAgo(requestedDays),
    employees: employees.length,
    markedDays: markedTotal,
    unmarkedDays,
    markedAbsent,
    markedPresent,
    absenceRatePct: markedTotal ? Math.round((markedAbsent / markedTotal) * 100) : 0,
    // the honest headline for the owner: of all employee-days in the window,
    // how many the register never touched
    unmarkedPct: days * employees.length
      ? Math.round((unmarkedDays / (days * employees.length)) * 100)
      : 0,
    byWeekday,
    topDates,
    perEmployee: employeesOut
      .map((e) => ({
        id: e.id,
        name: e.name,
        role: e.role,
        book: e.book,
        present: e.present,
        absent: e.absent,
        absentMarked: e.absentMarked,
        unmarked: e.unmarked,
        days: e.total,
        ratePct: e.total ? Math.round((e.absent / e.total) * 100) : 0,
      }))
      .sort((a, b) => b.absent - a.absent),
  };

  return NextResponse.json({ range, days, from, to, employees: employeesOut, insights });
}

// ── small IST-safe date-key helpers ─────────────────────────────────────────
function isoDaysAgo(n: number): string {
  return new Date(Date.now() + 330 * 60000 - n * 86_400_000).toISOString().slice(0, 10);
}
function nextDayKey(key: string): string {
  const t = new Date(key + "T00:00:00Z").getTime() + 86_400_000;
  return new Date(t).toISOString().slice(0, 10);
}
