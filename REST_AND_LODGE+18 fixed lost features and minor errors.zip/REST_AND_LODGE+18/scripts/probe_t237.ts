// t237 probe — state of the points economy + campaign media (D check)
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

async function main() {
  const since = new Date(Date.now() - 30 * 86400e3);
  const [billsPts, lodgePts, camps, campsWithMedia, recent] = await Promise.all([
    db.bill.groupBy({ by: ["customerPhone"], where: { customerPhone: { not: null }, pointsUsed: { gt: 0 } }, _count: true, _sum: { pointsUsed: true } }),
    db.lodgeBill.groupBy({ by: ["guestPhone"], where: { pointsUsed: { gt: 0 } }, _count: true, _sum: { pointsUsed: true } }),
    db.broadcast.count(),
    db.broadcast.count({ where: { attachments: { not: "[]" } } }),
    db.broadcast.findMany({ orderBy: { createdAt: "desc" }, take: 5, select: { createdAt: true, recipients: true, book: true, sentBy: true, attachments: true } }),
  ]);
  const restUsers = billsPts.length;
  const restUsed = billsPts.reduce((a, r) => a + (r._sum.pointsUsed ?? 0), 0);
  const lodgeUsers = lodgePts.length;
  const lodgeUsed = lodgePts.reduce((a, r) => a + (r._sum.pointsUsed ?? 0), 0);
  console.log("REST book redeemers(30d):", restUsers, "used pts:", restUsed);
  console.log("LODGE book redeemers(30d):", lodgeUsers, "used pts:", lodgeUsed);
  console.log("broadcasts total:", camps, "| with attachments:", campsWithMedia);
  for (const r of recent) {
    console.log("  send:", r.createdAt.toISOString(), r.book, r.sentBy, r.recipients, "atts:", (r.attachments ?? "").slice(0, 60));
  }
  // sends inside the last 7 days (the chart the owner usually watches)
  const week = await db.broadcast.findMany({
    where: { createdAt: { gte: new Date(Date.now() - 7 * 86400e3) } },
    select: { createdAt: true },
    orderBy: { createdAt: "asc" },
  });
  console.log("sends in last 7d:", week.length);
  const byDay = new Map<string, number>();
  for (const w of week) {
    const k = new Date(w.createdAt.getTime() + 330 * 60000).toISOString().slice(0, 10);
    byDay.set(k, (byDay.get(k) ?? 0) + 1);
  }
  console.log("per IST day:", [...byDay.entries()].map(([k, v]) => `${k}=${v}`).join("  "));
}

main().finally(() => db.$disconnect());
