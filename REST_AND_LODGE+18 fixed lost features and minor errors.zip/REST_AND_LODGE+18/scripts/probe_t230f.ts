import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const b = await db.bill.findFirst({ where: { customerName: "T230 Probe" } });
if (b) {
  await db.billItem.deleteMany({ where: { billId: b.id } });
  await db.bill.delete({ where: { id: b.id } });
  console.log("probe bill removed:", b.number);
} else console.log("no probe bill found");
const bc = await db.broadcast.findMany({ where: { sample: { contains: "T230" } } });
process.exit(0);
