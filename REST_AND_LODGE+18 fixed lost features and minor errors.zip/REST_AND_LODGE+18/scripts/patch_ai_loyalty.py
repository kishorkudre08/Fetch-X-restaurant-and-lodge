# t225 — feed LOYALTY to the AI copilot (digest block + encoders + prompts)
import io

P = "src/app/api/ai/route.ts"
s = io.open(P, encoding="utf-8").read()
n0 = len(s)


def rep(old: str, new: str, count: int = 1) -> None:
    global s
    assert s.count(old) == count, f"pattern x{s.count(old)} (want {count}): {old[:90]!r}"
    s = s.replace(old, new)


# A. import the earn-rate reader
rep(
    'import { getHotelName } from "@/lib/settings";',
    'import { getHotelName, getLoyaltyPct } from "@/lib/settings";',
)

# B. compute the loyalty block right before digestCore
anchor = "    const digestCore = {\n      hotel: {"
loyalty_block = '''    /* ── t225 · LOYALTY — the owner's earn rule + every phone-keyed wallet ──
       The wallet is SHARED across both books (restaurant customerPhone and
       lodge guestPhone are the same 10-digit key). Everything here is
       recomputed from the bill rows — the ground truth, never a stored
       balance. topBalances is THE source for "how many points does X have". */
    const loyaltyPct = await getLoyaltyPct();
    const sinceLoy = new Date(Date.now() - (RANGE_META[range].days - 1) * 86400000);
    const walletMap = new Map<string, { name: string | null; earned: number; used: number; visits: number; last: Date | null }>();
    let loyWinEarn = 0;
    let loyWinUsed = 0;
    const bumpWallet = (phone: string | null, name: string | null, earned: number, used: number, at: Date) => {
      const ph = (phone ?? "").replace(/\\D/g, "");
      if (ph.length !== 10) return;
      if (at >= sinceLoy) {
        loyWinEarn += earned;
        loyWinUsed += used;
      }
      const e = walletMap.get(ph) ?? { name: null, earned: 0, used: 0, visits: 0, last: null };
      e.earned += earned;
      e.used += used;
      e.visits += 1;
      if (!e.last || at > e.last) {
        e.last = at;
        if (name) e.name = name;
      }
      walletMap.set(ph, e);
    };
    for (const b of billsAll) bumpWallet(b.customerPhone, b.customerName, b.pointsEarned ?? 0, b.pointsUsed ?? 0, b.createdAt);
    for (const b of lodgeBillsAll) bumpWallet(b.guestPhone, b.guestName, b.pointsEarned ?? 0, b.pointsUsed ?? 0, b.createdAt);
    const loyalty = {
      rule:
        "every bill (restaurant counter + lodge front desk) keys its customer by a 10-digit phone; the customer MINTS points worth loyaltyPct% of what they actually pay (after discount + GST, whole points, 1 point = Rs.1 off a future bill); a discount beyond the owner's discount-limit % automatically BURNS the wallet; the wallet is SHARED across both books — a lodge stay and a dinner draw the same balance; balances are recomputed from bill rows, so an undone bill heals the wallet",
      earnPct: loyaltyPct,
      window: RANGE_META[range].label,
      mintedThisWindow: round2(loyWinEarn),
      redeemedThisWindow: round2(loyWinUsed),
      wallets: loyaltyRowsCount,
      topBalances: loyaltyTopRows,
    };

'''
# the block references two helpers defined after the loops — build them inline:
loyalty_block = loyalty_block.replace(
    "      wallets: loyaltyRowsCount,\n      topBalances: loyaltyTopRows,\n    };",
    "    };\n    const loyaltyRows = [...walletMap.entries()]\n"
    "      .map(([ph, e]) => ({\n"
    "        ph,\n"
    "        name: e.name,\n"
    "        earned: Math.round(e.earned),\n"
    "        used: Math.round(e.used),\n"
    "        balance: Math.max(0, Math.round(e.earned - e.used)),\n"
    "        visits: e.visits,\n"
    "        lastSeen: e.last ? istDayLabel(istDayKey(e.last)) : null,\n"
    "      }))\n"
    "      .sort((a, b) => b.balance - a.balance || b.visits - a.visits);\n"
    "    const loyaltyRowsCount = loyaltyRows.length;\n"
    "    const loyaltyTopRows = loyaltyRows.slice(0, 60);",
)
# reorder: rows must be built BEFORE the loyalty object — restructure cleanly
loyalty_block = '''    /* ── t225 · LOYALTY — the owner's earn rule + every phone-keyed wallet ──
       The wallet is SHARED across both books (restaurant customerPhone and
       lodge guestPhone are the same 10-digit key). Everything here is
       recomputed from the bill rows — the ground truth, never a stored
       balance. topBalances is THE source for "how many points does X have". */
    const loyaltyPct = await getLoyaltyPct();
    const sinceLoy = new Date(Date.now() - (RANGE_META[range].days - 1) * 86400000);
    const walletMap = new Map<string, { name: string | null; earned: number; used: number; visits: number; last: Date | null }>();
    let loyWinEarn = 0;
    let loyWinUsed = 0;
    const bumpWallet = (phone: string | null, name: string | null, earned: number, used: number, at: Date) => {
      const ph = (phone ?? "").replace(/\\D/g, "");
      if (ph.length !== 10) return;
      if (at >= sinceLoy) {
        loyWinEarn += earned;
        loyWinUsed += used;
      }
      const e = walletMap.get(ph) ?? { name: null, earned: 0, used: 0, visits: 0, last: null };
      e.earned += earned;
      e.used += used;
      e.visits += 1;
      if (!e.last || at > e.last) {
        e.last = at;
        if (name) e.name = name;
      }
      walletMap.set(ph, e);
    };
    for (const b of billsAll) bumpWallet(b.customerPhone, b.customerName, b.pointsEarned ?? 0, b.pointsUsed ?? 0, b.createdAt);
    for (const b of lodgeBillsAll) bumpWallet(b.guestPhone, b.guestName, b.pointsEarned ?? 0, b.pointsUsed ?? 0, b.createdAt);
    const loyaltyRows = [...walletMap.entries()]
      .map(([ph, e]) => ({
        ph,
        name: e.name,
        earned: Math.round(e.earned),
        used: Math.round(e.used),
        balance: Math.max(0, Math.round(e.earned - e.used)),
        visits: e.visits,
        lastSeen: e.last ? istDayLabel(istDayKey(e.last)) : null,
      }))
      .sort((a, b) => b.balance - a.balance || b.visits - a.visits);
    const loyalty = {
      rule:
        "every bill (restaurant counter + lodge front desk) keys its customer by a 10-digit phone; the customer MINTS points worth loyaltyPct% of what they actually pay (after discount + GST, whole points, 1 point = Rs.1 off a future bill); a discount beyond the owner's discount-limit % automatically BURNS the wallet; the wallet is SHARED across both books — a lodge stay and a dinner draw the same balance; balances are recomputed from bill rows, so an undone bill heals the wallet",
      earnPct: loyaltyPct,
      window: RANGE_META[range].label,
      mintedThisWindow: round2(loyWinEarn),
      redeemedThisWindow: round2(loyWinUsed),
      wallets: loyaltyRows.length,
      topBalancesNote: "EVERY phone-keyed wallet, sorted by balance desc — THE source for 'how many points does [customer] have', 'top loyal customers', 'who is due a reward'",
      topBalances: loyaltyRows.slice(0, 60),
    };

'''
rep(anchor, loyalty_block + anchor)

# C. mount the block inside digestCore (after expenses, before netProfit)
rep(
    "        rawMaterials: toExp(\"raw_material\"),\n        maintenance: toExp(\"maintenance\"),\n      },\n      netProfit,",
    "        rawMaterials: toExp(\"raw_material\"),\n        maintenance: toExp(\"maintenance\"),\n      },\n      loyalty,\n      netProfit,",
)

# D. encRestBill — points ride every raw bill row
rep(
    '      ph: b.customerPhone || undefined, // 10-digit phone — the reliable identity key\n      items:',
    '      ph: b.customerPhone || undefined, // 10-digit phone — the reliable identity key\n'
    '      pe: Math.round(b.pointsEarned ?? 0) || undefined, // t225 — loyalty points this bill minted\n'
    '      pu: Math.round(b.pointsUsed ?? 0) || undefined, // t225 — loyalty points the discount burned\n      items:',
)

# E. encLodgeBill — same for stays
rep(
    "      in: istDateTime(b.checkInAt), out: istDateTime(b.checkOutAt), hrs: b.hours, t: round2(b.total), d: b.discount || undefined,\n    });",
    "      in: istDateTime(b.checkInAt), out: istDateTime(b.checkOutAt), hrs: b.hours, t: round2(b.total), d: b.discount || undefined,\n"
    "      pe: Math.round(b.pointsEarned ?? 0) || undefined, // t225 — loyalty points minted\n"
    "      pu: Math.round(b.pointsUsed ?? 0) || undefined, // t225 — loyalty points burned\n    });",
)

# F. rawBills legend
rep(
    'hrs=stay hours · t=total ₹ · d=discount",',
    'hrs=stay hours · t=total ₹ · d=discount · pe/pu=loyalty points earned/redeemed (1 pt = ₹1) · restaurant rows add o=order channel + who/ph=customer identity + pe/pu",',
)

# G. t188 omniscience paragraph — identity now mandatory + pe/pu on both books
rep(
    "who=customer name, ph=customer 10-digit phone — who/ph appear when the counter keyed a customer identity above the totals, items=",
    "who=customer name, ph=customer 10-digit phone — mandatory on every bill since t225 (older bills may lack it), pe/pu=loyalty points minted/redeemed, items=",
)
rep(
    "`rawBills.lodge` (EVERY stay bill: n=L-bill#, room, guest, phone, tier, in/out=IST check-in/out, hrs=stay hours, t=total ₹), `expensesAll`",
    "`rawBills.lodge` (EVERY stay bill: n=L-bill#, room, guest, phone, tier, in/out=IST check-in/out, hrs=stay hours, t=total ₹, pe/pu=loyalty points), `expensesAll`",
)

# H. main prompt t221 — identity mandatory + the t225 loyalty instruction
rep(
    "(optional, phone is the reliable key since names collide)",
    "(mandatory since t225 — the counter cannot generate a bill without the name + the 10-digit phone; phone is the reliable key since names collide)",
)
rep(
    "quote real counts/₹/dates, and say so when a bill carries no identity. This is the seed of the owner's customer base — treat every keyed identity as ground truth.",
    "quote real counts/₹/dates, and say so when an OLDER bill (pre-t225) carries no identity. This is the seed of the owner's customer base — treat every keyed identity as ground truth. "
    "t225 — LOYALTY POINTS: `loyalty.earnPct` is the owner's mint rate (x% of what the customer actually pays becomes points, 1 point = ₹1 off a future bill); "
    "`loyalty.topBalances` lists EVERY phone-keyed wallet (earned, used, balance, visits, lastSeen) — it is THE source for 'how many points does [customer] have', 'who are my most loyal customers', 'who is sitting on points'; "
    "per-bill mint/redeem rides on the raw bills (pe=/pu=) and the window's mint/redeem totals sit in `loyalty.mintedThisWindow` / `loyalty.redeemedThisWindow`. "
    "The wallet is SHARED across both books — a lodge stay and a dinner draw the same balance. When asked how the scheme works: customers mint earnPct% of what they pay on every bill, and past the owner's discount limit a reception's discount automatically burns the wallet (that is how points get SPENT).",
)

# I. live-talk prompt — same discipline, spoken-friendly
rep(
    "Bills may also carry a customer identity — who= name, ph= 10-digit phone; group by ph= for repeat-customer / 'who ordered' questions.",
    "Every bill now carries a MANDATORY customer identity — who= name, ph= 10-digit phone — plus loyalty fields pe= points earned and pu= points redeemed (1 pt = ₹1); "
    "group by ph= for repeat-customer, 'who ordered' or points questions. t225 — LOYALTY: `loyalty.earnPct` is the owner's mint rate and `loyalty.topBalances` holds every phone-keyed wallet (earned/used/balance/visits) shared across both books — answer 'how many points does X have' from it.",
)

# J. site knowledge — settings now owns the loyalty lever too
rep(
    "paid holidays limit, discount % limit, hotel name.",
    "paid holidays limit, discount % limit, loyalty earn % (t225), hotel name.",
)

# K. coverage paragraph — wallets join the always-available list
rep(
    "stay mix and revenue by level; net profit per book and combined;",
    "stay mix and revenue by level; loyalty point wallets per customer (earn %, balances, mint/redeem per bill); net profit per book and combined;",
)

io.open(P, "w", encoding="utf-8").write(s)
print(f"AI route patched: {n0} → {len(s)} chars (+{len(s) - n0})")
