/* t229 follow-up — the 3000+ audience tier is empty (top wallet 1745 pts,
 * and 5% mint means ₹60k+ lifetime paid to get there). Backdate a handful of
 * realistic lodge stays for the three biggest regulars over the last ~10
 * weeks so the elite tier reads alive. Also removes the POST probe broadcast.
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const DAY = 86_400_000;
const GST = 0.05;
const r2 = (n) => Math.round(n * 100) / 100;

const STAYS = [
  // [name, phone, room, rate, hours, daysAgo] — spread over ~10 weeks
  ["Priya Nair", "9823411788", 84, 3999, 74, 68],
  ["Priya Nair", "9823411788", 22, 2499, 96, 41],
  ["Priya Nair", "9823411788", 91, 3999, 50, 17],
  ["Meena Iyer", "9741018834", 88, 3999, 70, 63],
  ["Meena Iyer", "9741018834", 45, 2999, 98, 36],
  ["Meena Iyer", "9741018834", 76, 2999, 52, 12],
  ["Ravi Sharma", "9812345670", 95, 3999, 78, 59],
  ["Ravi Sharma", "9812345670", 31, 2499, 94, 33],
  ["Ravi Sharma", "9812345670", 62, 2999, 55, 15],
  ["Ravi Sharma", "9812345670", 12, 2499, 46, 5],
];

async function main() {
  // remove the POST probe row from the API test
  const del = await db.broadcast.deleteMany({ where: { message: { startsWith: "Hi {NAME}, {POINTS} pts" } } });
  console.log("probe broadcasts removed:", del.count);

  const last = await db.lodgeBill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let no = (last?.number ?? 5000) + 1;
  const now = Date.now();
  let minted = 0;
  for (const [name, phone, room, rate, hours, daysAgo] of STAYS) {
    const tier = rate >= 3999 ? "LUXURY" : rate >= 2999 ? "STANDARD" : "BASIC";
    const stay = Math.round((rate * hours) / 24);
    const tax = Math.round(stay * GST * 100) / 100;
    const total = r2(stay + tax);
    const pts = Math.round((total * 5) / 100);
    minted += pts;
    const checkOut = new Date(now - daysAgo * DAY + 10 * 3600_000);
    const checkIn = new Date(checkOut.getTime() - hours * 3600_000);
    await db.lodgeBill.create({
      data: {
        number: no++, room, guestName: name, guestPhone: phone, tier, rate,
        checkInAt: checkIn, checkOutAt: checkOut, hours: r2(hours),
        stay, minApplied: false, discount: 0, tax, total,
        createdAt: checkOut, pointsEarned: pts, pointsUsed: 0,
      },
    });
  }
  console.log("stays backdated:", STAYS.length, "· minted", minted, "pts");

  // final wallet readout
  for (const p of ["9823411788", "9741018834", "9812345670"]) {
    const [r, l] = await Promise.all([
      db.bill.aggregate({ where: { customerPhone: p }, _sum: { pointsEarned: true, pointsUsed: true } }),
      db.lodgeBill.aggregate({ where: { guestPhone: p }, _sum: { pointsEarned: true, pointsUsed: true } }),
    ]);
    console.log(p, "→ balance", Math.round((r._sum.pointsEarned ?? 0) + (l._sum.pointsEarned ?? 0) - (r._sum.pointsUsed ?? 0) - (l._sum.pointsUsed ?? 0)));
  }
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
