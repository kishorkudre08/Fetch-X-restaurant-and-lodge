#!/usr/bin/env python3
"""Remove the unused AbsenceInsightsCard function block from dashboard-view.tsx.
Marker-based: delete from the 'ABSENCE INSIGHTS' comment up to (not including)
the next component's comment ("one book's OWN card")."""

p = "/home/z/my-project/src/components/dashboard-view.tsx"
s = open(p).read()

start_marker = "/* ── t2xx · ABSENCE INSIGHTS"
end_marker = "/* one book's OWN card"

i = s.index(start_marker)
j = s.index(end_marker)
assert i < j, "marker order wrong"
removed = s[i:j]
assert "function AbsenceInsightsCard" in removed, "expected function inside removed block"
s = s[:i] + s[j:]

open(p, "w").write(s)
print(f"removed {removed.count(chr(10))} lines containing AbsenceInsightsCard block")
print("AbsenceInsightsCard still referenced:", "AbsenceInsightsCard" in s)
