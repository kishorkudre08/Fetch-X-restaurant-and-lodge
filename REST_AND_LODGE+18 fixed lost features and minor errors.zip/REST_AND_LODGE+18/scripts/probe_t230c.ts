import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const raw = await db.$queryRaw<Array<{ d: string; n: bigint }>>`
  SELECT date(strftime('%s', "createdAt") + 19800, 'unixepoch') AS d, COUNT(*) AS n
  FROM "Bill" GROUP BY d ORDER BY d DESC LIMIT 6`;
console.log(raw);
const probe = await db.$queryRaw<Array<{ c: string }>>`SELECT "createdAt" AS c FROM "Bill" ORDER BY "createdAt" DESC LIMIT 3`;
console.log(probe);
process.exit(0);
