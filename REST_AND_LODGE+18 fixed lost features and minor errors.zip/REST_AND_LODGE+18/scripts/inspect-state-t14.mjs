// t14 inspect — current DB state before the new seeding round
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const day = (d) => d.toISOString().slice(0, 10);
const now = new Date();
const d30 = new Date(now.getTime() - 30 * 86400000);

const lastBill = await db.bill.findFirst({ orderBy: { createdAt: "desc" }, select: { number: true, createdAt: true, orderType: true } });
const lastLodge = await db.lodgeBill.findFirst({ orderBy: { createdAt: "desc" }, select: { number: true, createdAt: true } });
const cats = await db.category.findMany({ orderBy: { name: "asc" } });
const dishByCat = await db.dish.groupBy({ by: ["category"], _count: true, where: { active: true } });
const lastExp = await db.expense.findFirst({ orderBy: { spentOn: "desc" }, select: { kind: true, book: true, spentOn: true, amount: true } });
const exp30 = await db.expense.groupBy({ by: ["kind"], where: { spentOn: { gte: d30 } }, _count: true, _sum: { amount: true } });
const tasks = await db.task.findMany({ orderBy: { createdAt: "desc" }, take: 6, select: { title: true, book: true, status: true, createdAt: true, maxBudget: true } });
const taskCnt = await db.task.groupBy({ by: ["status"], _count: true });
const emps = await db.employee.findMany({ where: { active: true }, select: { id: true, name: true, book: true } });

// attendance over last 30 days (calendar) per book
const attRows = await db.attendance.findMany({ where: { date: { gte: day(d30) } } });
const attByEmp = new Map();
for (const a of attRows) {
  const e = attByEmp.get(a.employeeId) ?? { present: 0, absent: 0 };
  if (a.status === "present") e.present++; else e.absent++;
  attByEmp.set(a.employeeId, e);
}
let p = 0, ab = 0;
for (const v of attByEmp.values()) { p += v.present; ab += v.absent; }

// bills on candidate closure days
const candidates = ["2026-10-11", "2026-10-12", "2026-10-06", "2026-09-27", "2026-09-23"];
const closureCheck = [];
for (const c of candidates) {
  const s = new Date(c + "T00:00:00.000Z"); // approx; bills stored UTC — check with day bounds via raw compare below
  const e = new Date(s.getTime() + 86400000);
  const rb = await db.bill.count({ where: { createdAt: { gte: s, lt: e } } });
  const rl = await db.lodgeBill.count({ where: { createdAt: { gte: s, lt: e } } });
  closureCheck.push({ day: c, restBills: rb, lodgeBills: rl });
}

// distinct customers
const restIds = await db.bill.findMany({ where: { customerPhone: { not: null } }, select: { customerPhone: true, customerName: true, total: true, pointsEarned: true, pointsUsed: true, createdAt: true } });
const lodgeIds = await db.lodgeBill.findMany({ select: { guestPhone: true, guestName: true, total: true, pointsEarned: true, pointsUsed: true, createdAt: true } });
const phones = new Set([...restIds.map(r => r.customerPhone), ...lodgeIds.map(l => l.guestPhone)]);

// rooms live
const rooms = await db.room.groupBy({ by: ["status"], _count: true });

// menu sample in first category for reference
const sampleDish = await db.dish.findFirst({ orderBy: { createdAt: "asc" }, select: { name: true, price: true, category: true } });

console.log(JSON.stringify({
  today: day(now),
  lastBill, lastLodge,
  categories: cats.map(c => c.name),
  dishByCat: dishByCat.map(d => [d.category, d._count]),
  sampleDish,
  lastExp, exp30: exp30.map(e => [e.kind, e._count, e._sum.amount]),
  tasks, taskCnt: taskCnt.map(t => [t.status, t._count]),
  employees: emps.length, empsByBook: emps.reduce((m, e) => (m[e.book] = (m[e.book] || 0) + 1, m), {}),
  attRows30: attRows.length, attPresent: p, attAbsent: ab,
  attPct: (p + ab) ? Math.round((p / (p + ab)) * 100) : null,
  perEmp: [...attByEmp.entries()].slice(0, 12).map(([id, v]) => { const e = emps.find(x => x.id === id); return [e?.name ?? id, e?.book, v.present, v.absent]; }),
  closureCheck,
  customerPhones: phones.size,
  rooms: rooms.map(r => [r.status, r._count]),
}, null, 1));

await db.$disconnect();
