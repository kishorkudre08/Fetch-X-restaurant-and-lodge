import { db } from "../src/lib/db";

// probe: per-IST-day discount+points grouping via raw SQL
const since = new Date(Date.now() - 7 * 86_400_000);
const rows = await db.$queryRaw<Array<{ d: string; disc: number; pts: number; n: number }>>`
  SELECT date(strftime('%s', "createdAt") + 19800, 'unixepoch') AS d,
         SUM("discount") AS disc, SUM("pointsEarned") AS pts, COUNT(*) AS n
  FROM "Bill"
  WHERE "createdAt" >= ${since}
  GROUP BY d ORDER BY d DESC LIMIT 5`;
console.log("rest:", rows);

const lrows = await db.$queryRaw<Array<{ d: string; disc: number; pts: number; n: number }>>`
  SELECT date(strftime('%s', "createdAt") + 19800, 'unixepoch') AS d,
         SUM("discount") AS disc, SUM("pointsEarned") AS pts, COUNT(*) AS n
  FROM "LodgeBill"
  WHERE "createdAt" >= ${since}
  GROUP BY d ORDER BY d DESC LIMIT 5`;
console.log("lodge:", lrows);

const cnt = await db.bill.count();
console.log("bills total:", cnt);
process.exit(0);
