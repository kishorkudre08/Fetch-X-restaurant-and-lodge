#!/bin/bash
# Guarded dev-server bootstrap for the 4GB-cgroup sandbox.
# Strategy: tighter V8 heap + frequent minor GC (small semi-space) so the cold
# compile of the dashboard page stays under the cgroup limit; once compiled,
# webpack persistent cache makes later restarts light.
cd /home/z/my-project

export NODE_OPTIONS="--max-old-space-size=1792 --max-semi-space-size=16"
export NEXT_TELEMETRY_DISABLED=1

pkill -f "next dev" 2>/dev/null
pkill -f "next-server" 2>/dev/null
sleep 1

for attempt in 1 2 3; do
  echo "[boot] attempt $attempt ..."
  setsid nohup bun run dev > /dev/null 2>&1 < /dev/null &
  sleep 10

  # wait up to 150s for first compile
  ok=0
  for i in $(seq 1 50); do
    code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 8 http://localhost:3000/ 2>/dev/null)
    if [ "$code" = "200" ]; then ok=1; break; fi
    if ! pgrep -f "next dev" > /dev/null; then echo "[boot] process died (code=$code)"; break; fi
    sleep 3
  done

  if [ "$ok" = "1" ]; then
    # second request to confirm stable + warm attendance API
    curl -s -o /dev/null -w "[boot] home: %{http_code}\n" --max-time 30 http://localhost:3000/
    curl -s -o /dev/null -w "[boot] stats api: %{http_code}\n" --max-time 60 "http://localhost:3000/api/attendance/stats?range=lifetime"
    echo "[boot] SUCCESS on attempt $attempt"
    exit 0
  fi
  pkill -f "next dev" 2>/dev/null; pkill -f "next-server" 2>/dev/null
  sleep 3
done

echo "[boot] FAILED after 3 attempts"
exit 1
