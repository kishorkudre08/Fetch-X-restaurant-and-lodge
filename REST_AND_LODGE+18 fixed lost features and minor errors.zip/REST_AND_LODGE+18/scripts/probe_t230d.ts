import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const r = await db.$queryRaw<Array<{ c: unknown; s: unknown }>>`
  SELECT "createdAt" AS c, strftime('%s', "createdAt") AS s FROM "Bill" LIMIT 3`;
console.log(r);
process.exit(0);
