/* t228 — feed the NEW features with living data + fill the recent-day gap.
 *
 * The owner: "generate data of things we have recently added and also from
 * past few days bills have not been generated". The year-seeds stop around
 * 2026-10-12, so TODAY / 7D windows read dead, and the features that went
 * live since (order channels t188, customer identity t221, loyalty points
 * t225) have almost no rows to show. This tops the ledger up:
 *   · restaurant bills for the last few days — every one carries an order
 *     channel + customer identity, meal-hour shaped, real dish snapshots
 *   · wallets that BEHAVE: repeat regulars mint points (loyaltyPct % of what
 *     they pay); some discounts run past the owner's cap and BURN points —
 *     the exact split the bills API performs (regular fills the cap first)
 *   · lodge checkouts whose guests earn on the SAME phone-keyed wallet
 *   · a sprinkle of station expenses so the revenue-split rings have costs
 * Mirrors src/app/api/bills/route.ts math paise-for-paise. All createdAt are
 * backdated; live room state is untouched (LodgeBill rows are history only).
 * Run: node scripts/seed-new-features.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const IST = 330 * 60000;
const GST = 0.05;
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.round(rnd(a, b));
const r2 = (n) => Math.round(n * 100) / 100;

/* settings mirror — same keys and fallbacks as src/lib/settings.ts */
async function numSetting(key, dflt, max) {
  const row = await db.setting.findUnique({ where: { key } });
  const n = Math.floor(Number(row?.value));
  return Number.isFinite(n) && n >= 0 ? Math.min(n, max) : dflt;
}

/* recurring customers — the wallet regulars (phone = identity key; weight =
 * how often they show up, so the top wallet reads like a real regular) */
const REGULARS = [
  ["Ravi Sharma", "9812345670", 22],
  ["Priya Nair", "9823411788", 14],
  ["Arjun Mehta", "9845012397", 12],
  ["Sneha Kulkarni", "9900456712", 12],
  ["Vikram Joshi", "9964001123", 10],
  ["Meena Iyer", "9741018834", 10],
  ["Rahul Verma", "9739055261", 10],
  ["Kavita Rao", "9686990418", 10],
];
const WALKIN_NAMES = [
  "Nikhil Shetty", "Divya Prasad", "Manoj Kamat", "Sarita Hegde", "Deepak Rao",
  "Anjali Bhat", "Harish Nayak", "Lalita Shettigar", "Ganesh Bhandari", "Pooja Shenoy",
  "Amit Sardesai", "Rekha Kunder",
];
/* the 4 order channels from the billing dock (t188) — dine-in still leads */
const CHANNELS = [["dine_in", 45], ["take_away", 20], ["online_order", 20], ["lodge_order", 15]];
function pickChannel() {
  const tot = CHANNELS.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * tot;
  for (const [id, w] of CHANNELS) { r -= w; if (r <= 0) return id; }
  return "dine_in";
}
/* IST hour → order weight (breakfast, lunch, evening peaks) */
const HOUR_W = [2, 1, 0.5, 0.5, 0.5, 1, 3, 8, 10, 8, 8, 14, 16, 12, 8, 8, 10, 12, 14, 15, 12, 8, 5, 3];
const DEFAULT_LEVELS = [
  { from: 1, to: 40, rate: 2499, name: "BASIC" },
  { from: 41, to: 80, rate: 2999, name: "STANDARD" },
  { from: 81, to: 100, rate: 3999, name: "LUXURY" },
];
function stayHours() {
  const tot = [[rnd(6, 12), 20], [rnd(20, 30), 32], [rnd(44, 54), 26], [rnd(68, 100), 22]];
  const w = tot.reduce((s, [, x]) => s + x, 0);
  let r = Math.random() * w;
  for (const [v, x] of tot) { r -= x; if (r <= 0) return v; }
  return tot[tot.length - 1][0];
}

async function main() {
  console.log("── seed-new-features start ──");
  const now = Date.now();
  const istDayStart = new Date(new Date(now + IST).setUTCHours(0, 0, 0, 0)).getTime() - IST;
  const DAYS = 3; // the empty stretch + today on top

  const [discLimit, loyaltyPct, lodgeMin] = await Promise.all([
    numSetting("discountLimit", 10, 100),
    numSetting("loyaltyPct", 5, 100),
    numSetting("lodgeMinStay", 1000, 50000),
  ]);
  console.log("rules: discountLimit", discLimit + "% · loyaltyPct", loyaltyPct + "% · lodgeMin ₹" + lodgeMin);

  const dishes = await db.dish.findMany({ where: { active: true }, select: { id: true, name: true, price: true, category: true } });
  if (dishes.length < 5) throw new Error("menu too small to seed from");
  const lvlRow = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  let levels = DEFAULT_LEVELS;
  try { const p = JSON.parse(lvlRow?.value ?? "null"); if (Array.isArray(p) && p.length) levels = p; } catch { /* defaults */ }

  /* wallets START from what is already in the ledger (both books), exactly
     the way /api/bills aggregates them — the seed only adds the deltas */
  const wallet = new Map();
  for (const [, phone] of REGULARS) {
    const [r, l] = await Promise.all([
      db.bill.aggregate({ where: { customerPhone: phone }, _sum: { pointsEarned: true, pointsUsed: true } }),
      db.lodgeBill.aggregate({ where: { guestPhone: phone }, _sum: { pointsEarned: true, pointsUsed: true } }),
    ]);
    wallet.set(phone,
      Math.round((r._sum.pointsEarned ?? 0) + (l._sum.pointsEarned ?? 0)) -
      Math.round((r._sum.pointsUsed ?? 0) + (l._sum.pointsUsed ?? 0)));
  }

  /* bill numbers — the same dense-series logic as the API (undos tear holes;
     the next bill reuses the first free number so the series never skips) */
  async function nextBillNo() {
    const nums = (await db.bill.findMany({ select: { number: true }, orderBy: { number: "asc" } })).map((b) => b.number);
    const mx = nums.length ? nums[nums.length - 1] : 1000;
    if (nums.length === mx - 1000) return mx + 1;
    let n = 1001;
    for (const x of nums) { if (x === n) n += 1; else break; }
    return n;
  }
  let billNo = await nextBillNo();
  const lastLodge = await db.lodgeBill.findFirst({ orderBy: { number: "desc" }, select: { number: true } });
  let lodgeNo = (lastLodge?.number ?? 5000) + 1;

  /* the counter desk can write a bill while the seed runs — on a number
     collision, recompute the next free number and retry (same dense logic) */
  async function createBill(data) {
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        return await db.bill.create({ data });
      } catch (e) {
        const tgt = JSON.stringify(e?.meta?.target ?? "");
        if (String(e?.code) === "P2002" && tgt.includes("number")) {
          data.number = await nextBillNo();
          continue;
        }
        throw e;
      }
    }
    throw new Error("bill number race did not settle");
  }

  const regTot = REGULARS.reduce((s, r) => s + r[2], 0);
  const pickRegular = () => {
    let r = Math.random() * regTot;
    for (const row of REGULARS) { r -= row[2]; if (r <= 0) return row; }
    return REGULARS[0];
  };
  let walkinSeq = 0;
  const newWalkin = () => {
    const name = WALKIN_NAMES[walkinSeq % WALKIN_NAMES.length] + (walkinSeq >= WALKIN_NAMES.length ? " ji" : "");
    const phone = "96" + String(10000000 + walkinSeq * 7919).slice(0, 8); // unique 10-digit
    walkinSeq += 1;
    return [name, phone];
  };

  /* ── 1 · restaurant bills, chronological so wallets build naturally ── */
  let billCount = 0, burned = 0, minted = 0, walkins = 0;
  for (let d = DAYS; d >= 0; d--) {
    const dayStart = istDayStart - d * DAY;
    const dayEnd = d === 0 ? now : dayStart + DAY;
    const dow = new Date(dayStart).getUTCDay();
    const weekend = dow === 5 || dow === 6 || dow === 0 ? 1.18 : 1;
    const target = Math.max(12, Math.round(24 * weekend + rnd(-4, 4)));
    const buckets = [];
    for (let h = 0; h < 24; h++) {
      const slot = dayStart + h * 3_600_000;
      if (slot >= dayEnd) break;
      buckets.push({ slot, w: HOUR_W[h] * (d === 0 ? Math.max(0.25, (dayEnd - slot) / 3_600_000) : 1) });
    }
    const wTot = buckets.reduce((s, b) => s + b.w, 0);
    for (let k = 0; k < target; k++) {
      let r = Math.random() * wTot, at = buckets[buckets.length - 1].slot;
      for (const b of buckets) { r -= b.w; if (r <= 0) { at = b.slot; break; } }
      at = Math.min(at + Math.random() * 3_600_000, dayEnd - 60_000);

      const lines = irnd(1, 4);
      const picks = [];
      for (let i = 0; i < lines; i++) {
        const dish = dishes[irnd(0, dishes.length - 1)];
        const qty = Math.random() < 0.72 ? 1 : 2;
        picks.push({ dish, qty });
      }
      const subtotal = r2(picks.reduce((s, p) => s + p.dish.price * p.qty, 0));
      const isRegular = Math.random() < 0.6;
      const [name, phone] = isRegular ? pickRegular() : newWalkin();
      if (!isRegular) walkins += 1;
      const roll = Math.random();
      let discount = 0;
      if (roll < 0.12) discount = subtotal * rnd(0.03, 0.08);        // regular, inside the cap
      else if (roll < 0.22) discount = subtotal * rnd(0.1, 0.18);    // asks beyond the cap → points
      const discCap = Math.floor(subtotal * discLimit) / 100;
      const balance = Math.max(0, wallet.get(phone) ?? 0);
      const safeDiscount = Math.min(r2(discount), discCap + balance, subtotal);
      const pointsUsed = Math.min(Math.max(0, safeDiscount - discCap), balance);
      const taxable = Math.max(0, subtotal - safeDiscount);
      const tax = Math.round(taxable * GST * 100) / 100;
      const total = Math.round((taxable + tax) * 100) / 100;
      const pointsEarned = loyaltyPct > 0 ? Math.round((total * loyaltyPct) / 100) : 0;
      wallet.set(phone, (wallet.get(phone) ?? 0) - pointsUsed + pointsEarned);
      burned += pointsUsed;
      minted += pointsEarned;
      await createBill({
        number: billNo++, subtotal, discount: safeDiscount, tax, total,
        itemCount: picks.reduce((s, p) => s + p.qty, 0),
        orderType: pickChannel(), customerName: name, customerPhone: phone,
        pointsEarned, pointsUsed: r2(pointsUsed), createdAt: new Date(at),
        items: { create: picks.map((p) => ({ dishId: p.dish.id, name: p.dish.name, category: p.dish.category, qty: p.qty, price: p.dish.price })) },
      });
      billCount += 1;
    }
  }
  console.log("restaurant bills:", billCount, "· regulars", billCount - walkins, "· walk-ins", walkins,
    "· minted", minted, "pts · burned", r2(burned), "pts");

  /* ── 2 · lodge checkouts — guests earn on the SAME phone-keyed wallet ── */
  const lodgeRows = [];
  let lodgeMinted = 0;
  for (let d = DAYS; d >= 0; d--) {
    const dayStart = istDayStart - d * DAY;
    const dayEnd = d === 0 ? now : dayStart + DAY;
    const dow = new Date(dayStart).getUTCDay();
    const weekend = dow === 5 || dow === 6 || dow === 0 ? 1.18 : 1;
    const count = Math.max(4, Math.round(8 * weekend + rnd(-2, 2)));
    for (let k = 0; k < count; k++) {
      const room = 1 + Math.floor(Math.random() * 100);
      const lv = levels.find((l) => room >= l.from && room <= l.to) ?? levels[0];
      const hours = stayHours();
      const checkOut = new Date(dayStart + Math.random() * (dayEnd - dayStart));
      const checkIn = new Date(checkOut.getTime() - hours * 3_600_000);
      if (checkIn.getTime() > now) continue;
      const raw = Math.round((lv.rate * hours) / 24);
      const min = raw < lodgeMin;
      const stay = min ? lodgeMin : raw;
      const tax = Math.round(stay * GST * 100) / 100;
      const total = r2(stay + tax);
      const isRegular = Math.random() < 0.55;
      const [name, phone] = isRegular ? pickRegular() : newWalkin();
      const pointsEarned = loyaltyPct > 0 ? Math.round((total * loyaltyPct) / 100) : 0;
      wallet.set(phone, (wallet.get(phone) ?? 0) + pointsEarned);
      lodgeMinted += pointsEarned;
      lodgeRows.push({
        number: lodgeNo++, room, guestName: name, guestPhone: phone,
        tier: lv.name, rate: lv.rate, checkInAt: checkIn, checkOutAt: checkOut,
        hours: r2(hours), stay, minApplied: min, discount: 0, tax, total,
        createdAt: checkOut, pointsEarned, pointsUsed: 0,
      });
    }
  }
  for (let i = 0; i < lodgeRows.length; i += 500) await db.lodgeBill.createMany({ data: lodgeRows.slice(i, i + 500) });
  console.log("lodge bills:", lodgeRows.length, "· minted", lodgeMinted, "pts");

  /* ── 3 · a small sprinkle of station expenses so the split rings have costs ── */
  const EXP = [
    ["raw_material", "rest", "Vegetables + dairy top-up"],
    ["raw_material", "rest", "Spices and oil refill"],
    ["maintenance", "lodge", "Plumber — leaking tap, wing 2"],
    ["raw_material", "lodge", "Toiletries + linen restock"],
    ["maintenance", "rest", "Chimney deep-clean service"],
    ["upgrade", "rest", "QR table stands for online orders"],
  ];
  let expCount = 0;
  for (let d = DAYS; d >= 0; d--) {
    if (Math.random() < 0.3) continue;
    const e = EXP[irnd(0, EXP.length - 1)];
    await db.expense.create({
      data: {
        kind: e[0], book: e[1], label: e[2],
        amount: r2(rnd(800, 6000)),
        spentOn: new Date(istDayStart - d * DAY + 6 * 3_600_000),
      },
    });
    expCount += 1;
  }
  console.log("expenses:", expCount);

  console.log("── wallets after the seed (regulars) ──");
  for (const [name, phone] of REGULARS) console.log("  ", name, "·", phone, "→", Math.max(0, Math.round(wallet.get(phone) ?? 0)), "pts");
  console.log("── seed-new-features done ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
