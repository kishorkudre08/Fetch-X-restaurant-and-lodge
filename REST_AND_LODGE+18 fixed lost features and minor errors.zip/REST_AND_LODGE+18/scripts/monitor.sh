#!/bin/bash
# Monitors next-server lifecycle: samples ps every 3s, logs everything.
LOG=/tmp/monitor.log
: > $LOG
echo "[monitor] start $(date +%H:%M:%S)" >> $LOG
for i in $(seq 1 60); do
  TS=$(date +%H:%M:%S)
  MEM=$(free -m | awk '/Mem:/{print $3"MB used"}')
  PROCS=$(ps aux | grep -E 'next-server|next dev|bun run dev' | grep -v grep | awk '{print $2":"$3"%:"int($6/1024)"MB:"$11" "$12" "$13}' | tr '\n' '|')
  echo "[$TS] $MEM procs=[$PROCS]" >> $LOG
  sleep 3
done
