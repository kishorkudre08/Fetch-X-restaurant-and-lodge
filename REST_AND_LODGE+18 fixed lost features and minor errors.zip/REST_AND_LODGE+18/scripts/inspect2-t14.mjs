import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const lastAtt = await db.attendance.findFirst({ orderBy: [{ date: "desc" }], select: { date: true, status: true } });
const lastAttRow = await db.attendance.findMany({ orderBy: [{ date: "desc" }], take: 3, select: { date: true, status: true, employeeId: true } });
const billCnt = await db.bill.count();
const lodgeCnt = await db.lodgeBill.count();
const attCnt = await db.attendance.count();
const todayBills = await db.bill.count({ where: { createdAt: { gte: new Date("2026-10-15T18:30:00Z") } } }); // IST Oct 16 start
const billsOct = await db.bill.count({ where: { createdAt: { gte: new Date("2026-09-30T18:30:00Z") } } });
const oct12 = await db.bill.findMany({ where: { createdAt: { gte: new Date("2026-10-12T00:00:00Z"), lt: new Date("2026-10-13T00:00:00Z") } }, select: { number: true, createdAt: true } });
console.log(JSON.stringify({ lastAtt, lastAttRow, billCnt, lodgeCnt, attCnt, todayBills, billsOct, oct12 }, null, 1));
await db.$disconnect();
