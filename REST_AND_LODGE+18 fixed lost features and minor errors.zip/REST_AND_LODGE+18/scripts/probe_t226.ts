/**
 * t226 probe — seed a KNOWN customer through the real API, then verify the
 * /api/loyalty lookup returns the name the docks will auto-fill.
 * Leaves the bill in place (browser test needs it) — cleanup is a separate run.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const BASE = "http://localhost:3000";
const PHONE = "9812345670";

async function j(path: string, init?: RequestInit) {
  const r = await fetch(BASE + path, init);
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

async function main() {
  const dish = await db.dish.findFirst({ where: { active: true }, orderBy: { price: "asc" } });
  if (!dish) throw new Error("no active dish");
  console.log("dish:", dish.id, dish.name, dish.price);

  const post = await j("/api/bills", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      items: [{ dishId: dish.id, qty: 2 }],
      discount: 0,
      orderType: "dine_in",
      customerName: "RAVI SHARMA",
      customerPhone: PHONE,
    }),
  });
  console.log("POST /api/bills →", post.status, JSON.stringify(post.body?.bill ?? post.body, null, 0).slice(0, 400));

  const wallet = await j(`/api/loyalty?phone=${PHONE}`);
  console.log("GET /api/loyalty →", wallet.status, JSON.stringify(wallet.body));

  const name = wallet.body?.name;
  const ok = wallet.status === 200 && typeof name === "string" && name.trim().toUpperCase() === "RAVI SHARMA";
  console.log(ok ? "PROBE OK — lookup returns the seeded name" : "PROBE FAILED");
  if (!ok) process.exit(1);
}

main()
  .catch((e) => {
    console.error("PROBE ERROR:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
