// t239 — REGENERATE the last 7 days of trading data: wipe bills (both books,
// items cascade) and station expenses inside the window, then let the proven
// t102 seeder rebuild them fresh so TODAY / 7D look like a real week again.
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const IST = 330 * 60000;

async function main() {
  const now = Date.now();
  const istDayStart = new Date(new Date(now + IST).setUTCHours(0, 0, 0, 0)).getTime() - IST;
  const cutoff = new Date(istDayStart - 6 * DAY); // 7 calendar days incl. today
  console.log("cutoff:", cutoff.toISOString());

  const b = await db.bill.deleteMany({ where: { createdAt: { gte: cutoff } } });
  const l = await db.lodgeBill.deleteMany({ where: { createdAt: { gte: cutoff } } });
  const e = await db.expense.deleteMany({ where: { createdAt: { gte: cutoff }, via: null } });
  console.log("deleted — bills:", b.count, "lodgeBills:", l.count, "expenses(manual):", e.count);
}
main().then(() => process.exit(0)).catch((err) => { console.error(err); process.exit(1); });
