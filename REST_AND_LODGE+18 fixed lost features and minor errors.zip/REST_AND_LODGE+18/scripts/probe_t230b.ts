import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const [rest, lodge] = await Promise.all([
  db.bill.groupBy({ by: ["customerPhone"], _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true } }),
  db.lodgeBill.groupBy({ by: ["guestPhone"], _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true } }),
]);
const bal = new Map<string, number>();
for (const r of rest) bal.set(r.customerPhone, (r._sum.pointsEarned ?? 0) - (r._sum.pointsUsed ?? 0) + (r._sum.bonusPoints ?? 0));
for (const l of lodge) bal.set(l.guestPhone, (bal.get(l.guestPhone) ?? 0) + (l._sum.pointsEarned ?? 0) - (l._sum.pointsUsed ?? 0) + (l._sum.bonusPoints ?? 0));
const all = [...bal.values()].map(Math.round);
console.log("customers:", all.length);
console.log("500+:", all.filter((b) => b >= 500).length, "| 1000+:", all.filter((b) => b >= 1000).length, "| 3000+:", all.filter((b) => b >= 3000).length);
console.log("top5:", all.sort((a, b) => b - a).slice(0, 5));
const shelf = await db.dish.findMany({ where: { category: "Ready Made Goods", active: true }, select: { name: true, price: true } });
console.log("shelf:", shelf.length, shelf.slice(0, 4).map((d) => `${d.name} ₹${d.price}`).join(" · "));
const recent = await db.bill.count({ where: { createdAt: { gte: new Date(Date.now() - 4 * 86400000) } } });
const shelfSales = await db.billItem.count({ where: { category: "Ready Made Goods", bill: { createdAt: { gte: new Date(Date.now() - 4 * 86400000) } } } });
console.log("recent-4d bills:", recent, "| shelf items sold:", shelfSales);
const bonus = await db.bill.aggregate({ where: { bonusPoints: { gt: 0 } }, _count: true, _sum: { bonusPoints: true } });
console.log("bonus bills:", bonus._count, "sum:", bonus._sum.bonusPoints);
process.exit(0);
