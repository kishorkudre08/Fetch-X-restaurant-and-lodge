import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const r = await db.$queryRaw<Array<{ t: string; c: unknown }>>`
  SELECT typeof("createdAt") AS t, "createdAt" AS c FROM "Bill" LIMIT 2`;
console.log(r);
process.exit(0);
