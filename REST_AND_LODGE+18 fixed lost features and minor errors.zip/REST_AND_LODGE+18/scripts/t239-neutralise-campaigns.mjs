// t239 — NEUTRALISE the campaigning data: the +15 restore carried probe rows
// ("t236 probe — hardened media test"), same-second duplicates and
// inconsistent audience magnitudes. This rebuilds the Broadcast log as one
// coherent, realistic history (Jul → today): tiered restaurant sends that
// grow with the wallet base, lodge/franchise notices, the manager's franchise
// sends wearing their media, and ONE send this morning so the default TODAY
// view of the live dashboard wears its purple dot again.
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const IST = 330 * 60000; // IST = UTC+5:30

/** IST wall-clock → Date. m: 1-12. */
function ist(y, m, d, h, min) {
  return new Date(Date.UTC(y, m - 1, d, h, min, 0) - IST);
}

const feast2 = [{ url: "/api/media/banner-feast.png", kind: "image", name: "great-feast-week.png" }];
const stayPack = [
  { url: "/api/media/banner-stay.png", kind: "image", name: "stay-3-pay-2.png" },
  { url: "/api/media/clip-staycation.mp4", kind: "video", name: "loyalty-week-teaser.mp4" },
];
const feast1 = [{ url: "/api/media/banner-feast.png", kind: "image", name: "feast.png" }];

const ROWS = [
  // ── Jul–Aug: the early wallet base ──
  { at: ist(2026, 7, 20, 12, 40), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_3000", r: 14,
    msg: "Hi {name}, our chef's tasting evening is on us for the top 20 — you're in with {points} points. See you Friday?" },
  { at: ist(2026, 8, 9, 18, 5), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_500", r: 96,
    msg: "{name}, {points} points on your wallet — double-stamp weekend starts tonight." },
  { at: ist(2026, 8, 24, 11, 30), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 3180,
    notice: "Monsoon rates extended one more week — every room, every night. Front desk holds your favourite floor." },
  // ── Sep: the base grows ──
  { at: ist(2026, 9, 6, 13, 10), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_1000", r: 38,
    msg: "{name} — {points} points, and the new Malabar menu just landed. Reserve at the desk." },
  { at: ist(2026, 9, 14, 10, 45), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 5940,
    notice: "Ganeshotsav week: early check-in from 10 AM for all in-house guests. Safe travels." },
  { at: ist(2026, 9, 21, 12, 20), book: "rest", by: "RESTAURANT RECEPTION", aud: "custom", thr: 750, r: 121,
    msg: "{name}, you're {points} points strong — Navratri thali is complimentary for you this week." },
  { at: ist(2026, 9, 25, 17, 50), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_500", r: 142,
    msg: "Hi {name} — {points} points on the wallet. Chef's biryani Friday, 20% off for members." },
  { at: ist(2026, 9, 26, 16, 20), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 7860,
    notice: "Pool deck reopens Saturday after re-tiling. Timings 7 AM–7 PM as usual." },
  // ── Oct: the current season ──
  { at: ist(2026, 10, 3, 10, 10), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_500", r: 160,
    msg: "{name}, Dussehra week! Your {points} points cover the family combo upgrade — just say the word." },
  { at: ist(2026, 10, 4, 11, 35), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 8470,
    notice: "Festive season: housekeeping slots now bookable from the front desk up to 9 PM." },
  { at: ist(2026, 10, 7, 10, 45), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_1000", r: 52, att: feast2,
    msg: "{name} — GREAT FEAST WEEK is on. Double points till Oct 24; your {points} are ready to spend." },
  { at: ist(2026, 10, 8, 19, 15), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 8590,
    notice: "The lodge gym gets new cardio units this weekend — evening slots move to the terrace deck." },
  { at: ist(2026, 10, 11, 15, 55), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_1000", r: 47,
    msg: "{name}, {points} points and a quiet corner table — booked under your name for this week." },
  { at: ist(2026, 10, 13, 13, 52), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 8760,
    notice: "Water tank cleaning Thursday 9–11 AM; supply stays on via the overhead reserve." },
  { at: ist(2026, 10, 13, 18, 25), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_1000", r: 51,
    msg: "Hi {name} — the grill nights are back. Your {points} points hold a free dessert, all week." },
  { at: ist(2026, 10, 14, 12, 32), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_3000", r: 22,
    msg: "{name}, our top tier: the chef's counter seats are yours on Saturday — {points} points, no bill." },
  { at: ist(2026, 10, 15, 11, 0), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 8830,
    notice: "Diwali decor lights up the atrium from Friday evening — lobby access stays open." },
  { at: ist(2026, 10, 15, 21, 30), book: "franchise", by: "MANAGER", aud: "all", r: 9020, att: stayPack,
    msg: "{name} — STAY 3, PAY 2 across the lodge this month, and {points} points spend everywhere. Teaser inside." },
  { at: ist(2026, 10, 16, 11, 49), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_500", r: 158,
    msg: "{name} — feast week day 3. {points} points double till tonight on dine-in." },
  { at: ist(2026, 10, 16, 16, 15), book: "franchise", by: "MANAGER", aud: "all", r: 9044,
    notice: "Franchise desk: both counters stay open till 11 PM through the festive week." },
  { at: ist(2026, 10, 16, 21, 55), book: "lodge", by: "LODGE RECEPTION", aud: "all", r: 8852,
    notice: "Late checkout till 2 PM available Sunday — confirm at the desk tonight." },
  { at: ist(2026, 10, 17, 12, 11), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_1000", r: 54, att: feast1,
    msg: "{name}, feast week final stretch — {points} points, and the Sunday special is on the house." },
  { at: ist(2026, 10, 17, 12, 21), book: "franchise", by: "MANAGER", aud: "all", r: 9056,
    notice: "Franchise desk: feast-week banners are up at both counters. Media follows in the next send." },
  // ── TODAY — the dot on the default TODAY view ──
  { at: ist(2026, 10, 18, 9, 47), book: "rest", by: "RESTAURANT RECEPTION", aud: "pts_1000", r: 56,
    msg: "Good morning {name} — Devi Puja specials from noon. Your {points} points seat you first." },
];

async function main() {
  const gone = await db.broadcast.deleteMany();
  console.log("cleared broadcasts:", gone.count);
  const rows = ROWS.map((r) => ({
    audience: r.aud,
    threshold: r.thr ?? null,
    message: r.msg ?? "",
    notice: r.notice ?? "",
    recipients: r.r,
    sample: (r.msg ?? r.notice ?? "").slice(0, 90),
    sentBy: r.by,
    book: r.book,
    attachments: JSON.stringify(r.att ?? []),
    createdAt: r.at,
  }));
  for (const row of rows) await db.broadcast.create({ data: row });
  console.log("inserted:", rows.length, "| with media:", rows.filter((r) => r.attachments !== "[]").length);
  const last = rows[rows.length - 1];
  console.log("latest:", last.createdAt.toISOString(), "→", new Date(last.createdAt.getTime() + IST).toISOString(), "IST");
}
main().then(() => process.exit(0)).catch((err) => { console.error(err); process.exit(1); });
