/**
 * t230 — seed: real-customer base + real-world ready-made shelf + campaign log + loyalty ranks.
 *
 * 1. LOYALTY RANKS: seed the owner's default ranges when the table is empty.
 * 2. READY MADE GOODS: deactivate the old packaged-snack shelf and stock REAL
 *    ice creams & cold drinks (Coca-Cola, Sprite, Fanta, Thums Up, Maaza,
 *    Mountain Dew, Red Bull, Amul cones/bars/kulfi/cassata, Dairy Milk…),
 *    then ring up fresh sales of the new shelf over the last few days.
 * 3. CUSTOMERS: ~120 NEW identities (unique names + unique 10-digit phones,
 *    never reusing an existing name), each with restaurant bills (and lodge
 *    stays for the regulars) spread over the last ~100 days — points minted
 *    at the base 5%, wallet totals landing in every tier: enough members for
 *    the 500+/1000+/3000+ audience toggles to look alive.
 * 4. BONUS: a few top-customer bills carry bonusPoints (the reception's
 *    hand-awarded extra, now a first-class field).
 * 5. BROADCASTS: backdated personal messages + notices across the year so the
 *    owner's Mass Messages preview (7d / 1m / 3m / 1y) has a real log.
 * Closure days are respected — no bill is seeded on a recorded closed day.
 *
 * Run: bun scripts/seed-t230.ts
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const IST = 5.5 * 3600 * 1000;

// ── helpers ──────────────────────────────────────────────────────────────────
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const ri = (a: number, b: number) => Math.floor(rnd(a, b + 1));
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const round2 = (n: number) => Math.round(n * 100) / 100;

/** UTC Date for an IST wall-clock moment on a given offset-days-ago. */
function istAgo(daysAgo: number, hour: number, min = ri(0, 59)): Date {
  const now = new Date();
  const base = new Date(now.getTime() - daysAgo * 86_400_000 + IST);
  const y = base.getUTCFullYear(), m = base.getUTCMonth(), d = base.getUTCDate();
  return new Date(Date.UTC(y, m, d, hour - 5, min - 30) - IST + IST) ;
}

/** deterministic IST "day key" (YYYY-MM-DD) for a Date */
const dayKey = (dt: Date) => new Date(dt.getTime() + IST).toISOString().slice(0, 10);

async function main() {
  console.log("── seed-t230 start ──");

  // ── 0. existing landscape ──────────────────────────────────────────────────
  const [existingBills, maxAgg, lgMaxAgg, dishes, closures, tierCount] = await Promise.all([
    db.bill.findMany({ select: { number: true, customerName: true, customerPhone: true, createdAt: true }, orderBy: { createdAt: "desc" }, take: 4000 }),
    db.bill.aggregate({ _max: { number: true }, _count: true }),
    db.lodgeBill.aggregate({ _max: { number: true } }),
    db.dish.findMany({ where: { active: true } }),
    db.closure.findMany({ select: { date: true } }),
    db.loyaltyTier.count(),
  ]);
  const closedDays = new Set(closures.map((c) => c.date));
  const existingNames = new Set(existingBills.map((b) => (b.customerName ?? "").toLowerCase()));
  const existingPhones = new Set(existingBills.map((b) => b.customerPhone));
  const [lodgePhones, lodgeNames] = await Promise.all([
    db.lodgeBill.findMany({ select: { guestPhone: true, guestName: true } }),
    db.lodgeBill.findMany({ select: { guestName: true } }),
  ]);
  for (const p of lodgePhones) existingPhones.add(p.guestPhone);
  for (const n of lodgeNames) if (n.guestName) existingNames.add(n.guestName.toLowerCase());

  let nextBillNo = (maxAgg._max.number ?? 1000) + 1;
  let nextLodgeNo = (lgMaxAgg._max.number ?? 5000) + 1;
  console.log(`bills up to #${nextBillNo - 1}, lodge up to L-${nextLodgeNo - 1}, closed days: ${closedDays.size}`);

  // ── 1. LOYALTY RANKS (owner defaults) ──────────────────────────────────────
  if (tierCount === 0) {
    await db.loyaltyTier.createMany({
      data: [
        { label: "ELITE · TOP 10", fromRank: 1, toRank: 10, earnPct: 10 },
        { label: "GOLD · 11–50", fromRank: 11, toRank: 50, earnPct: 8 },
        { label: "SILVER · 51–200", fromRank: 51, toRank: 200, earnPct: 6 },
      ],
    });
    console.log("loyalty ranks: seeded 3 default ranges");
  } else {
    console.log(`loyalty ranks: ${tierCount} already present`);
  }

  // ── 2. READY MADE GOODS — real ice creams & cold drinks ───────────────────
  const OLD_SHELF = await db.dish.findMany({ where: { category: "Ready Made Goods", active: true } });
  if (OLD_SHELF.length) {
    await db.dish.updateMany({ where: { id: { in: OLD_SHELF.map((d) => d.id) } }, data: { active: false } });
    console.log(`ready made goods: retired ${OLD_SHELF.length} old items → ${OLD_SHELF.map((d) => d.name).join(", ")}`);
  }
  const NEW_SHELF: Array<{ name: string; price: number }> = [
    { name: "Coca-Cola 250ml", price: 40 },
    { name: "Coca-Cola 750ml", price: 95 },
    { name: "Sprite 250ml", price: 40 },
    { name: "Fanta Orange 250ml", price: 40 },
    { name: "Thums Up 250ml", price: 45 },
    { name: "Maaza Mango 250ml", price: 50 },
    { name: "Mountain Dew 250ml", price: 40 },
    { name: "Red Bull Energy 250ml", price: 140 },
    { name: "Amul Vanilla Cone", price: 55 },
    { name: "Amul Choco Bar", price: 40 },
    { name: "Amul Malai Kulfi", price: 50 },
    { name: "Amul Cassata Ice Cream", price: 70 },
    { name: "Cadbury Dairy Milk", price: 45 },
    { name: "Cadbury Dairy Milk Silk", price: 85 },
  ];
  const shelfExisting = await db.dish.findMany({ where: { name: { in: NEW_SHELF.map((n) => n.name) } } });
  const shelfHave = new Set(shelfExisting.map((d) => d.name));
  const toAdd = NEW_SHELF.filter((n) => !shelfHave.has(n.name));
  if (toAdd.length) {
    await db.dish.createMany({ data: toAdd.map((n) => ({ name: n.name, price: n.price, category: "Ready Made Goods", veg: true })) });
  }
  const shelf = await db.dish.findMany({ where: { category: "Ready Made Goods", active: true } });
  console.log(`ready made goods: shelf now ${shelf.length} real items${toAdd.length ? ` (${toAdd.length} added)` : " (already stocked)"}`);

  // fresh sales of the new shelf — last 4 open days, mixed into normal bills
  const kitchen = dishes.filter((d) => d.category !== "Ready Made Goods");
  const shelfBillSpecs: Array<{ daysAgo: number; hour: number; items: Array<{ dishId: string; name: string; category: string; qty: number; price: number }>; customer: CustomerSeed }> = [];
  void shelfBillSpecs;

  // ── 3. CUSTOMERS ───────────────────────────────────────────────────────────
  const FIRST = ["Aarav","Vivaan","Aditya","Vihaan","Arjun","Reyansh","Ishaan","Shaurya","Atharv","Advik","Kabir","Ayaan","Dhruv","Rudra","Aryan","Kartik","Rohan","Nikhil","Sarthak","Mayank","Ananya","Aadhya","Diya","Ira","Myra","Sara","Pari","Anika","Navya","Riya","Saanvi","Tiya","Kiara","Meera","Divya","Pooja","Sneha","Kavya","Nisha","Ritu","Shreya","Neha","Ishita","Tanvi","Simran","Deepa","Gauri","Sunita","Lavanya","Bhavya","Ramesh","Suresh","Mahesh","Rajesh","Vikram","Karan","Arvind","Mohan","Devraj","Pranav","Farhan","Imran","Rehan","Sameer","Junaid","Zoya","Ayesha","Sana","Nida","Murtaza","Faisal","Ganesh","Manoj","Naresh","Omprakash","Pankaj","Qaiser","Raghav","Siddharth","Tushar","Umesh","Varun","Yash","Abhinav","Bhavin","Chirag","Dhaval","Hardik","Jignesh","Kunal","Lalit","Mihir","Nirav","Ojas","Parth","Ronak","Sahil","Tejas","Urvashi","Vandana","Yamini","Akshay","Bharat"];
  const LAST = ["Sharma","Verma","Gupta","Mehta","Patel","Shah","Joshi","Iyer","Nair","Menon","Pillai","Reddy","Rao","Naidu","Das","Ghosh","Bose","Chatterjee","Banerjee","Mukherjee","Singh","Kumar","Yadav","Mishra","Tiwari","Pandey","Agarwal","Bansal","Goel","Malhotra","Kapoor","Chopra","Bhatia","Arora","Khanna","Sethi","Desai","Naik","Kulkarni","Deshpande","Kamble","Jadhav","Pawar","Shinde","Gaikwad","Rathod","Chauhan","Parmar","Solanki","Bhatt","Trivedi","Dave","Acharya","Bhat","Hegde","Shetty","Rai","Poojary","Salian","Balan","Cheeran","Kurup","Warrier","Varma","Menon"];

  type CustomerSeed = { name: string; phone: string; targetPts: number; lodgeStays: number; bonusAt: number[] };
  const usedNames = new Set(existingNames);
  const usedPhones = new Set(existingPhones);
  const nameOf = (): string => {
    for (let i = 0; i < 500; i++) {
      const n = `${pick(FIRST)} ${pick(LAST)}`;
      if (!usedNames.has(n.toLowerCase())) { usedNames.add(n.toLowerCase()); return n; }
    }
    throw new Error("name pool exhausted");
  };
  const phoneOf = (): string => {
    for (let i = 0; i < 500; i++) {
      const p = `${ri(6, 9)}${ri(0, 9)}${String(ri(0, 99_999_999)).padStart(8, "0")}`;
      if (!usedPhones.has(p)) { usedPhones.add(p); return p; }
    }
    throw new Error("phone pool exhausted");
  };

  // tier mix — plenty of members on every audience toggle (was 7/3/3)
  const plan: CustomerSeed[] = [];
  const pushPlan = (n: number, targetPts: [number, number], lodgeStays: [number, number]) => {
    for (let i = 0; i < n; i++) {
      plan.push({
        name: nameOf(),
        phone: phoneOf(),
        targetPts: ri(targetPts[0], targetPts[1]),
        lodgeStays: ri(lodgeStays[0], lodgeStays[1]),
        bonusAt: Math.random() < 0.3 ? [ri(0, 2)] : [],
      });
    }
  };
  pushPlan(14, [3000, 5600], [1, 2]);   // 3000+ tier members
  pushPlan(26, [1000, 2900], [0, 1]);   // 1000+ tier members
  pushPlan(34, [500, 980], [0, 0]);     // 500+ tier members
  pushPlan(52, [60, 470], [0, 0]);      // the long tail below 500
  console.log(`customers: ${plan.length} new identities planned`);

  // bill-day candidates: last 100 days, skipping closed days and the too-recent
  // hours are randomised below
  const dayPool: number[] = [];
  for (let d = 1; d <= 100; d++) {
    const probe = istAgo(d, 13);
    if (!closedDays.has(dayKey(probe))) dayPool.push(d);
  }

  type BillRow = {
    number: number; subtotal: number; discount: number; tax: number; total: number; itemCount: number;
    orderType: string; customerName: string; customerPhone: string;
    pointsEarned: number; pointsUsed: number; bonusPoints: number; createdAt: Date;
    items: Array<{ dishId: string; name: string; category: string; qty: number; price: number }>;
  };
  const billRows: BillRow[] = [];
  const lodgeRows: Array<{
    number: number; room: number; guestName: string; guestPhone: string; tier: string; rate: number;
    checkInAt: Date; checkOutAt: Date; hours: number; stay: number; minApplied: boolean; discount: number;
    pointsEarned: number; pointsUsed: number; bonusPoints: number; tax: number; total: number; createdAt: Date;
  }> = [];
  const ORDER_TYPES = ["dine_in", "dine_in", "dine_in", "take_away", "take_away", "lodge_order", "online_order"];

  const makeRestBill = (c: CustomerSeed, daysAgo: number, forceItems?: "shelf") => {
    const hour = ri(11, 22);
    const items: BillRow["items"] = [];
    if (forceItems === "shelf") {
      for (const s of [pick(shelf), pick(shelf)]) {
        if (!items.find((i) => i.dishId === s.id)) items.push({ dishId: s.id, name: s.name, category: s.category, qty: ri(1, 3), price: s.price });
      }
      if (items.length === 1 && Math.random() < 0.7) {
        const k = pick(kitchen);
        items.push({ dishId: k.id, name: k.name, category: k.category, qty: ri(1, 2), price: k.price });
      }
    } else {
      const n = ri(1, 4);
      for (let i = 0; i < n; i++) {
        const dish = Math.random() < 0.18 ? pick(shelf) : pick(kitchen);
        if (!items.find((x) => x.dishId === dish.id)) items.push({ dishId: dish.id, name: dish.name, category: dish.category, qty: ri(1, 3), price: dish.price });
      }
    }
    const subtotal = round2(items.reduce((s, i) => s + i.qty * i.price, 0));
    if (subtotal < 60) return null;
    const createdAt = istAgo(daysAgo, hour);
    return { c, subtotal, items, createdAt };
  };

  for (const c of plan) {
    // lodge stays first (regulars holiday here, points land in the same wallet)
    for (let s = 0; s < c.lodgeStays; s++) {
      const daysAgo = pick(dayPool);
      const nights = ri(1, 3);
      const room = ri(1, 100);
      const tier = room <= 40 ? { name: "BASIC", rate: 1480 } : room <= 70 ? { name: "STANDARD", rate: 2280 } : { name: "LUXURY", rate: 3380 };
      const checkOut = istAgo(daysAgo, ri(9, 12));
      const checkIn = new Date(checkOut.getTime() - nights * 86_400_000 - ri(0, 5) * 3600_000);
      if (closedDays.has(dayKey(checkOut)) || closedDays.has(dayKey(checkIn))) continue;
      const hours = nights * 24 + rnd(0.5, 4);
      const raw = (tier.rate * hours) / 24;
      const stay = round2(Math.max(raw, 1000));
      const total = round2(stay * 1.05);
      lodgeRows.push({
        number: nextLodgeNo++, room, guestName: c.name, guestPhone: c.phone, tier: tier.name, rate: tier.rate,
        checkInAt: checkIn, checkOutAt: checkOut, hours: Math.round(hours * 100) / 100,
        stay, minApplied: raw < 1000, discount: 0, pointsEarned: Math.round(total * 0.05), pointsUsed: 0, bonusPoints: 0,
        tax: round2(stay * 0.05), total, createdAt: checkOut,
      });
    }

    // restaurant bills until the wallet target (5% of paid total, 1 pt = ₹1)
    let pts = lodgeRows.filter((l) => l.guestPhone === c.phone).reduce((s, l) => s + l.pointsEarned, 0);
    let spend = lodgeRows.filter((l) => l.guestPhone === c.phone).reduce((s, l) => s + l.total, 0);
    let guard = 0;
    const visits = c.targetPts > 2500 ? ri(9, 16) : c.targetPts > 950 ? ri(5, 11) : c.targetPts > 480 ? ri(2, 6) : ri(1, 3);
    while (pts < c.targetPts && guard++ < 30) {
      const daysAgo = pick(dayPool);
      const made = makeRestBill(c, daysAgo);
      if (!made) continue;
      const subtotal = made.subtotal;
      const total = round2(subtotal * 1.05);
      const earned = Math.round(total * 0.05);
      billRows.push({
        number: nextBillNo++, subtotal, discount: 0, tax: round2(subtotal * 0.05), total,
        itemCount: made.items.reduce((s, i) => s + i.qty, 0),
        orderType: pick(ORDER_TYPES), customerName: c.name, customerPhone: c.phone,
        pointsEarned: earned, pointsUsed: 0,
        // t230 — a reception's top-customer bonus lands on a recent bill
        bonusPoints: c.bonusAt.includes(guard - 1) && daysAgo <= 20 ? ri(50, 250) : 0,
        createdAt: made.createdAt, items: made.items,
      });
      pts += earned;
      spend += total;
    }
    // top up the last bill so the wallet lands inside the target band
    if (pts < c.targetPts && billRows.length) {
      const last = billRows[billRows.length - 1];
      if (last.customerPhone === c.phone) last.pointsEarned += c.targetPts - pts;
    }
    void spend;
  }

  // fresh ready-made shelf sales on the 4 most recent open days
  const recentOpen = dayPool.slice(-4);
  for (const d of recentOpen) {
    for (let k = 0; k < 7; k++) {
      const made = makeRestBill(plan[ri(0, plan.length - 1)], d, "shelf");
      if (!made) continue;
      const subtotal = made.subtotal;
      billRows.push({
        number: nextBillNo++, subtotal, discount: 0, tax: round2(subtotal * 0.05), total: round2(subtotal * 1.05),
        itemCount: made.items.reduce((s, i) => s + i.qty, 0),
        orderType: pick(ORDER_TYPES), customerName: made.c.name, customerPhone: made.c.phone,
        pointsEarned: Math.round(subtotal * 1.05 * 0.05), pointsUsed: 0, bonusPoints: 0,
        createdAt: made.createdAt, items: made.items,
      });
    }
  }

  // ── insert bills + items ──────────────────────────────────────────────────
  let billN = 0;
  for (const b of billRows) {
    await db.bill.create({
      data: {
        number: b.number, subtotal: b.subtotal, discount: b.discount, tax: b.tax, total: b.total,
        itemCount: b.itemCount, orderType: b.orderType, customerName: b.customerName, customerPhone: b.customerPhone,
        pointsEarned: b.pointsEarned, pointsUsed: b.pointsUsed, bonusPoints: b.bonusPoints, createdAt: b.createdAt,
        items: { create: b.items },
      },
    });
    billN++;
  }
  await db.lodgeBill.createMany({ data: lodgeRows });
  console.log(`bills: +${billN} · lodge bills: +${lodgeRows.length}`);

  // ── 4. BROADCASTS — a year of campaign history ────────────────────────────
  const existingBc = await db.broadcast.count();
  if (existingBc < 4) {
    const sampleRows = await db.bill.findMany({
      orderBy: { createdAt: "desc" }, take: 40,
      select: { customerName: true, customerPhone: true },
    });
    const names = [...new Set(sampleRows.map((r) => r.customerName).filter((n): n is string => !!n))];
    const campanhas: Array<{ daysAgo: number; audience: string; threshold: number | null; personal: boolean; recipients: number; book: "rest" | "lodge" }> = [
      { daysAgo: 2, audience: "pts_3000", threshold: null, personal: true, recipients: 24, book: "rest" },
      { daysAgo: 3, audience: "all", threshold: null, personal: false, recipients: 232, book: "lodge" },
      { daysAgo: 5, audience: "pts_500", threshold: null, personal: true, recipients: 88, book: "rest" },
      { daysAgo: 9, audience: "custom", threshold: 750, personal: false, recipients: 121, book: "rest" },
      { daysAgo: 12, audience: "pts_1000", threshold: null, personal: true, recipients: 47, book: "lodge" },
      { daysAgo: 20, audience: "all", threshold: null, personal: false, recipients: 205, book: "rest" },
      { daysAgo: 34, audience: "pts_500", threshold: null, personal: true, recipients: 74, book: "rest" },
      { daysAgo: 55, audience: "pts_3000", threshold: null, personal: false, recipients: 18, book: "lodge" },
      { daysAgo: 80, audience: "all", threshold: null, personal: true, recipients: 188, book: "rest" },
      { daysAgo: 130, audience: "custom", threshold: 1200, personal: true, recipients: 39, book: "rest" },
      { daysAgo: 210, audience: "pts_1000", threshold: null, personal: false, recipients: 41, book: "lodge" },
      { daysAgo: 330, audience: "all", threshold: null, personal: true, recipients: 152, book: "rest" },
    ];
    for (const c of campanhas) {
      const who = pick(names) ?? "Guest";
      const text = c.personal
        ? `Hello {NAME}, you have {POINTS} points waiting — 1 pt = ₹1 off your next bill or stay at the hotel. See you soon!`
        : pick([
            "This weekend: the Dussehra special thali counter is back — 12–3 PM and 7–11 PM. Rooms book fast; call the front desk.",
            "New at the counter — real ice creams & cold drinks now on the Ready Made Goods shelf: Amul cones, Dairy Milk, Red Bull and more.",
            "Renovation alert: the garden wing reopens next week with 12 refreshed rooms — early-bird 15% off stays booked this month.",
          ]);
      const tpl = text
        .replaceAll("{NAME}", who)
        .replaceAll("{POINTS}", String(ri(320, 5400)));
      await db.broadcast.create({
        data: {
          audience: c.audience, threshold: c.threshold,
          message: c.personal ? text : "", notice: c.personal ? "" : text,
          recipients: c.recipients, sample: c.personal ? tpl : text,
          sentBy: c.book === "lodge" ? "LODGE RECEPTION" : "RESTAURANT RECEPTION",
          book: c.book, createdAt: istAgo(c.daysAgo, ri(10, 20)),
        },
      });
    }
    console.log(`broadcasts: seeded ${campanhas.length} backdated campaigns`);
  } else {
    console.log(`broadcasts: ${existingBc} rows already present`);
  }

  // ── 5. sanity print ───────────────────────────────────────────────────────
  const [billCount, lgCount, tierRows] = await Promise.all([
    db.bill.count(), db.lodgeBill.count(), db.loyaltyTier.findMany({ orderBy: { fromRank: "asc" } }),
  ]);
  console.log(`totals: ${billCount} bills · ${lgCount} lodge bills · ${tierRows.length} rank ranges`);
  console.log("── seed-t230 done ──");
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
