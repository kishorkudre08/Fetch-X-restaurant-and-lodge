/**
 * t236 — seed: a LIVELIER Mass Messages section (owner's own ask: it "looked dead").
 *
 * 1. CUSTOMERS: ~240 new identities (unique names + 10-digit phones) with
 *    restaurant bills (and lodge stays for the regulars) over the last ~45
 *    open days — points minted at the base 5% so every wallet tier deepens
 *    (500+/1000+/3000+ audiences all grow).
 * 2. POINTS USAGE: real redemption activity — ~54 bills carrying pointsUsed
 *    (the burn side of the ledger), most inside the last 30 days so the
 *    POINTS USED · window and USING POINTS · window cards read alive.
 * 3. BROADCASTS: 5 campaigns across the last ~3 weeks — 3 of them MANAGER
 *    franchise sends WITH MEDIA (2 AI-generated banners + 1 ffmpeg clip in
 *    uploads/broadcasts/, streamed by /api/media), 2 desk sends without —
 *    so the owner's log shows files on rows the moment it loads.
 * Closure days are respected — no bill lands on a recorded closed day.
 *
 * Run: bun scripts/seed-t236.ts
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const IST = 5.5 * 3600 * 1000;

// ── helpers ──────────────────────────────────────────────────────────────────
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const ri = (a: number, b: number) => Math.floor(rnd(a, b + 1));
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const round2 = (n: number) => Math.round(n * 100) / 100;

/** UTC Date for an IST wall-clock moment on a given offset-days-ago. */
function istAgo(daysAgo: number, hour: number, min = ri(0, 59)): Date {
  const now = new Date();
  const base = new Date(now.getTime() - daysAgo * 86_400_000 + IST);
  const y = base.getUTCFullYear(), m = base.getUTCMonth(), d = base.getUTCDate();
  return new Date(Date.UTC(y, m, d, hour - 5, min - 30) - IST + IST);
}

/** deterministic IST "day key" (YYYY-MM-DD) for a Date */
const dayKey = (dt: Date) => new Date(dt.getTime() + IST).toISOString().slice(0, 10);

async function main() {
  console.log("── seed-t236 start ──");

  // ── 0. existing landscape ──────────────────────────────────────────────────
  const [existingBills, maxAgg, lgMaxAgg, dishes, closures] = await Promise.all([
    db.bill.findMany({ select: { number: true, customerName: true, customerPhone: true }, orderBy: { createdAt: "desc" }, take: 6000 }),
    db.bill.aggregate({ _max: { number: true }, _count: true }),
    db.lodgeBill.aggregate({ _max: { number: true } }),
    db.dish.findMany({ where: { active: true } }),
    db.closure.findMany({ select: { date: true } }),
  ]);
  const closedDays = new Set(closures.map((c) => c.date));
  const existingNames = new Set(existingBills.map((b) => (b.customerName ?? "").toLowerCase()));
  const existingPhones = new Set(existingBills.map((b) => b.customerPhone));
  const lodgeMeta = await db.lodgeBill.findMany({ select: { guestPhone: true, guestName: true } });
  for (const p of lodgeMeta) existingPhones.add(p.guestPhone);
  for (const n of lodgeMeta) if (n.guestName) existingNames.add(n.guestName.toLowerCase());

  let nextBillNo = (maxAgg._max.number ?? 1000) + 1;
  let nextLodgeNo = (lgMaxAgg._max.number ?? 5000) + 1;
  console.log(`bills up to #${nextBillNo - 1}, lodge up to L-${nextLodgeNo - 1}, closed days: ${closedDays.size}`);

  // ── 1. NEW CUSTOMERS + their earn bills ───────────────────────────────────
  const FIRST = ["Aarav","Vivaan","Aditya","Vihaan","Arjun","Reyansh","Ishaan","Shaurya","Atharv","Advik","Kabir","Ayaan","Dhruv","Rudra","Aryan","Kartik","Rohan","Nikhil","Sarthak","Mayank","Ananya","Aadhya","Diya","Ira","Myra","Sara","Pari","Anika","Navya","Riya","Saanvi","Tiya","Kiara","Meera","Divya","Pooja","Sneha","Kavya","Nisha","Ritu","Shreya","Neha","Ishita","Tanvi","Simran","Deepa","Gauri","Sunita","Lavanya","Bhavya","Ramesh","Suresh","Mahesh","Rajesh","Vikram","Karan","Arvind","Mohan","Devraj","Pranav","Farhan","Imran","Rehan","Sameer","Junaid","Zoya","Ayesha","Sana","Nida","Murtaza","Faisal","Ganesh","Manoj","Naresh","Omprakash","Pankaj","Qaiser","Raghav","Siddharth","Tushar","Umesh","Varun","Yash","Abhinav","Bhavin","Chirag","Dhaval","Hardik","Jignesh","Kunal","Lalit","Mihir","Nirav","Ojas","Parth","Ronak","Sahil","Tejas","Urvashi","Vandana","Yamini","Akshay","Bharat"];
  const LAST = ["Sharma","Verma","Gupta","Mehta","Patel","Shah","Joshi","Iyer","Nair","Menon","Pillai","Reddy","Rao","Naidu","Das","Ghosh","Bose","Chatterjee","Banerjee","Mukherjee","Singh","Kumar","Yadav","Mishra","Tiwari","Pandey","Agarwal","Bansal","Goel","Malhotra","Kapoor","Chopra","Bhatia","Arora","Khanna","Sethi","Desai","Naik","Kulkarni","Deshpande","Kamble","Jadhav","Pawar","Shinde","Gaikwad","Rathod","Chauhan","Parmar","Solanki","Bhatt","Trivedi","Dave","Acharya","Bhat","Hegde","Shetty","Rai","Poojary","Salian","Balan","Cheeran","Kurup","Warrier","Varma","Menon","Sengupta","Dutta","Ganguly","Sinha","Bhardwaj","Chandra","Iyengar","Rajan","Mohan","Pillai"];

  type CustomerSeed = { name: string; phone: string; targetPts: number; lodgeStays: number; earned: number };
  const usedNames = new Set(existingNames);
  const usedPhones = new Set(existingPhones);
  const nameOf = (): string => {
    for (let i = 0; i < 800; i++) {
      const n = `${pick(FIRST)} ${pick(LAST)}`;
      if (!usedNames.has(n.toLowerCase())) { usedNames.add(n.toLowerCase()); return n; }
    }
    throw new Error("name pool exhausted");
  };
  const phoneOf = (): string => {
    for (let i = 0; i < 800; i++) {
      const p = `${ri(6, 9)}${ri(0, 9)}${String(ri(0, 99_999_999)).padStart(8, "0")}`;
      if (!usedPhones.has(p)) { usedPhones.add(p); return p; }
    }
    throw new Error("phone pool exhausted");
  };

  const plan: CustomerSeed[] = [];
  const pushPlan = (n: number, targetPts: [number, number], lodgeStays: [number, number]) => {
    for (let i = 0; i < n; i++) {
      plan.push({ name: nameOf(), phone: phoneOf(), targetPts: ri(targetPts[0], targetPts[1]), lodgeStays: ri(lodgeStays[0], lodgeStays[1]), earned: 0 });
    }
  };
  pushPlan(12, [3200, 5600], [1, 2]);   // deep 3000+ wallets
  pushPlan(30, [1100, 2900], [0, 1]);   // 1000+ members
  pushPlan(40, [520, 980], [0, 0]);     // 500+ members
  pushPlan(160, [60, 470], [0, 0]);     // the long tail
  console.log(`customers: ${plan.length} new identities planned`);

  // bill-day candidates: last 45 open days
  const dayPool: number[] = [];
  for (let d = 1; d <= 45; d++) {
    if (!closedDays.has(dayKey(istAgo(d, 13)))) dayPool.push(d);
  }

  const ORDER_TYPES = ["dine_in", "dine_in", "dine_in", "take_away", "take_away", "lodge_order", "online_order"];
  const kitchen = dishes.filter((d) => d.category !== "Ready Made Goods");
  const shelf = dishes.filter((d) => d.category === "Ready Made Goods");
  const dishSource = shelf.length ? kitchen.concat(shelf) : kitchen;

  type BillRow = {
    number: number; subtotal: number; discount: number; tax: number; total: number; itemCount: number;
    orderType: string; customerName: string; customerPhone: string;
    pointsEarned: number; pointsUsed: number; bonusPoints: number; createdAt: Date;
    items: Array<{ dishId: string; name: string; category: string; qty: number; price: number }>;
  };
  const billRows: BillRow[] = [];
  const lodgeRows: Array<{
    number: number; room: number; guestName: string; guestPhone: string; tier: string; rate: number;
    checkInAt: Date; checkOutAt: Date; hours: number; stay: number; minApplied: boolean; discount: number;
    pointsEarned: number; pointsUsed: number; bonusPoints: number; tax: number; total: number; createdAt: Date;
  }> = [];

  for (const c of plan) {
    // lodge stays first (regulars holiday here; same phone-keyed wallet)
    for (let s = 0; s < c.lodgeStays; s++) {
      const daysAgo = pick(dayPool);
      const nights = ri(1, 3);
      const room = ri(1, 100);
      const tier = room <= 40 ? { name: "BASIC", rate: 1480 } : room <= 70 ? { name: "STANDARD", rate: 2280 } : { name: "LUXURY", rate: 3380 };
      const checkOut = istAgo(daysAgo, ri(9, 12));
      const checkIn = new Date(checkOut.getTime() - nights * 86_400_000 - ri(0, 5) * 3600_000);
      if (closedDays.has(dayKey(checkOut)) || closedDays.has(dayKey(checkIn))) continue;
      const hours = nights * 24 + rnd(0.5, 4);
      const raw = (tier.rate * hours) / 24;
      const stay = round2(Math.max(raw, 1000));
      const total = round2(stay * 1.05);
      const earned = Math.round(total * 0.05);
      lodgeRows.push({
        number: nextLodgeNo++, room, guestName: c.name, guestPhone: c.phone, tier: tier.name, rate: tier.rate,
        checkInAt: checkIn, checkOutAt: checkOut, hours: Math.round(hours * 100) / 100,
        stay, minApplied: raw < 1000, discount: 0, pointsEarned: earned, pointsUsed: 0, bonusPoints: 0,
        tax: round2(stay * 0.05), total, createdAt: checkOut,
      });
      c.earned += earned;
    }

    // restaurant bills until the wallet target (5% of what they pay)
    let guard = 0;
    const visits = c.targetPts > 2500 ? ri(8, 14) : c.targetPts > 950 ? ri(4, 9) : c.targetPts > 480 ? ri(2, 5) : ri(1, 3);
    while (c.earned < c.targetPts && guard++ < Math.max(20, visits * 3)) {
      const daysAgo = pick(dayPool);
      const hour = ri(11, 22);
      const items: BillRow["items"] = [];
      const n = ri(1, 4);
      for (let i = 0; i < n; i++) {
        const dish = pick(dishSource);
        if (!items.find((x) => x.dishId === dish.id)) items.push({ dishId: dish.id, name: dish.name, category: dish.category, qty: ri(1, 3), price: dish.price });
      }
      const subtotal = round2(items.reduce((s, i) => s + i.qty * i.price, 0));
      if (subtotal < 60) continue;
      const total = round2(subtotal * 1.05);
      const earned = Math.round(total * 0.05);
      billRows.push({
        number: nextBillNo++, subtotal, discount: 0, tax: round2(subtotal * 0.05), total,
        itemCount: items.reduce((s, i) => s + i.qty, 0),
        orderType: pick(ORDER_TYPES), customerName: c.name, customerPhone: c.phone,
        pointsEarned: earned, pointsUsed: 0, bonusPoints: 0, createdAt: istAgo(daysAgo, hour), items,
      });
      c.earned += earned;
    }
  }
  console.log(`earn rows staged: ${billRows.length} bills · ${lodgeRows.length} stays`);

  // ── 2. REDEMPTIONS — the burn side, mostly inside the last 30 days ────────
  // Only wallets with real headroom redeem (never past their earned balance).
  const redeemers = plan.filter((c) => c.earned >= 700).sort(() => Math.random() - 0.5);
  let redemptions = 0;
  const redeem = (c: CustomerSeed, daysAgo: number) => {
    const cap = Math.min(Math.round(c.earned * 0.6), c.earned - 120);
    if (cap < 60) return false;
    const used = Math.min(ri(60, 260), cap);
    const items: BillRow["items"] = [];
    const n = ri(1, 3);
    for (let i = 0; i < n; i++) {
      const dish = pick(dishSource);
      if (!items.find((x) => x.dishId === dish.id)) items.push({ dishId: dish.id, name: dish.name, category: dish.category, qty: ri(1, 2), price: dish.price });
    }
    let subtotal = round2(items.reduce((s, i) => s + i.qty * i.price, 0));
    // the food must plausibly cover the burn
    while (subtotal < used * 1.4) {
      const dish = pick(dishSource);
      items.push({ dishId: dish.id, name: dish.name, category: dish.category, qty: ri(1, 2), price: dish.price });
      subtotal = round2(items.reduce((s, i) => s + i.qty * i.price, 0));
      if (items.length > 8) break;
    }
    const discount = used;
    const tax = round2(subtotal * 0.05);
    const total = round2(subtotal - discount + tax);
    const earned = Math.round(Math.max(total, 0) * 0.05);
    billRows.push({
      number: nextBillNo++, subtotal, discount, tax, total,
      itemCount: items.reduce((s, i) => s + i.qty, 0),
      orderType: pick(ORDER_TYPES), customerName: c.name, customerPhone: c.phone,
      pointsEarned: earned, pointsUsed: used, bonusPoints: 0,
      createdAt: istAgo(daysAgo, ri(12, 21)), items,
    });
    c.earned = c.earned - used + earned;
    redemptions++;
    return true;
  };

  // ~44 redemption bills inside the 1-month window (1-26 days ago)
  let placed = 0;
  for (const c of redeemers) {
    if (placed >= 44) break;
    if (redeem(c, ri(1, 26))) placed++;
  }
  // ~10 older ones (31-85 days) so the 3-month window breathes too
  for (const c of redeemers.slice(44)) {
    if (redemptions >= 54) break;
    redeem(c, ri(31, 85));
  }
  console.log(`redemptions: +${redemptions} bills with pointsUsed`);

  // ── insert bills + stays ──────────────────────────────────────────────────
  let billN = 0;
  for (const b of billRows) {
    await db.bill.create({
      data: {
        number: b.number, subtotal: b.subtotal, discount: b.discount, tax: b.tax, total: b.total,
        itemCount: b.itemCount, orderType: b.orderType, customerName: b.customerName, customerPhone: b.customerPhone,
        pointsEarned: b.pointsEarned, pointsUsed: b.pointsUsed, bonusPoints: b.bonusPoints, createdAt: b.createdAt,
        items: { create: b.items },
      },
    });
    billN++;
  }
  if (lodgeRows.length) await db.lodgeBill.createMany({ data: lodgeRows });
  console.log(`inserted: +${billN} bills · +${lodgeRows.length} lodge bills`);

  // ── 3. BROADCASTS — 5 campaigns, 3 carrying campaign media ────────────────
  // honest recipient counts: recompute every wallet from the bill rows
  const [restAgg, lodgeAgg] = await Promise.all([
    db.bill.groupBy({ by: ["customerPhone"], where: { customerPhone: { not: null } }, _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true } }),
    db.lodgeBill.groupBy({ by: ["guestPhone"], _sum: { pointsEarned: true, pointsUsed: true, bonusPoints: true } }),
  ]);
  const bal = new Map<string, number>();
  const bump = (ph: string | null, earned: number, used: number, bonus: number) => {
    const p = (ph ?? "").replace(/\D/g, "");
    if (p.length !== 10) return;
    bal.set(p, (bal.get(p) ?? 0) + earned + bonus - used);
  };
  for (const r of restAgg) bump(r.customerPhone, r._sum.pointsEarned ?? 0, r._sum.pointsUsed ?? 0, r._sum.bonusPoints ?? 0);
  for (const l of lodgeAgg) bump(l.guestPhone, l._sum.pointsEarned ?? 0, l._sum.pointsUsed ?? 0, l._sum.bonusPoints ?? 0);
  const wallets = [...bal.values()].map((v) => Math.max(0, Math.round(v)));
  const countAt = (min: number) => wallets.filter((v) => v >= min).length;
  const bigWallet = wallets.reduce((mx, v) => Math.max(mx, v), 0);
  const media = {
    feast: [{ url: "/api/media/banner-feast.png", kind: "image" as const, name: "great-feast-week.png" }],
    stay: [{ url: "/api/media/banner-stay.png", kind: "image" as const, name: "stay-3-pay-2.png" }],
    feastClip: [
      { url: "/api/media/banner-feast.png", kind: "image" as const, name: "great-feast-week.png" },
      { url: "/api/media/clip-staycation.mp4", kind: "video" as const, name: "loyalty-week-teaser.mp4" },
    ],
  };

  const campanhas: Array<{
    daysAgo: number; hour: number; audience: string; threshold: number | null;
    personal: boolean; book: "rest" | "lodge" | "franchise";
    atts: Array<{ url: string; kind: "image" | "video"; name: string }>;
    text: string;
  }> = [
    {
      daysAgo: 1, hour: 11, audience: "all", threshold: null, personal: false, book: "franchise", atts: media.feastClip,
      text: "Diwali is coming and the kitchen is firing on all cylinders — the GREAT FEAST WEEK starts Friday: 12% off every thali, a free Amul kulfi with family platters, and live chaat from 7 PM. Your points pay like cash (1 pt = ₹1) at both counters.",
    },
    {
      daysAgo: 4, hour: 18, audience: "pts_1000", threshold: null, personal: true, book: "franchise", atts: media.stay,
      text: "Hello {NAME}, winter nights are calling — as a 1000+ points member your wallet holds {POINTS} pts, ready as ₹ off any stay this month. Stay 3 nights, pay for 2. — The Manager",
    },
    {
      daysAgo: 9, hour: 13, audience: "pts_500", threshold: null, personal: false, book: "franchise", atts: media.feast,
      text: "Weekend Warning: the butter-chicken biryani handi is back for three days only. Show this message at the counter — your loyalty points settle the bill like cash.",
    },
    {
      daysAgo: 14, hour: 10, audience: "all", threshold: null, personal: false, book: "lodge", atts: [],
      text: "The garden wing reopens Monday with 12 refreshed rooms — early-bird 15% off stays booked this week at the front desk.",
    },
    {
      daysAgo: 22, hour: 19, audience: "pts_500", threshold: null, personal: true, book: "rest", atts: [],
      text: "Hello {NAME}, you have {POINTS} points waiting — 1 pt = ₹1 off your next bill or stay. See you soon!",
    },
  ];
  for (const c of campanhas) {
    const recipients = c.audience === "all" ? countAt(0)
      : c.audience === "pts_500" ? countAt(500)
      : c.audience === "pts_1000" ? countAt(1000)
      : c.audience === "pts_3000" ? countAt(3000)
      : countAt(c.threshold ?? 0);
    const sample = c.personal
      ? c.text.replaceAll("{NAME}", "Rohit Malhotra").replaceAll("{POINTS}", String(bigWallet))
      : c.text;
    await db.broadcast.create({
      data: {
        audience: c.audience, threshold: c.threshold,
        message: c.personal ? c.text : "", notice: c.personal ? "" : c.text,
        recipients, sample,
        sentBy: c.book === "franchise" ? "MANAGER" : c.book === "lodge" ? "LODGE RECEPTION" : "RESTAURANT RECEPTION",
        book: c.book,
        attachments: JSON.stringify(c.atts),
        createdAt: istAgo(c.daysAgo, c.hour),
      },
    });
  }
  console.log(`broadcasts: +${campanhas.length} (3 with media)`);

  // ── 4. sanity print ───────────────────────────────────────────────────────
  let used30 = 0;
  const users30 = new Set<string>();
  const [restWin, lodgeWin] = await Promise.all([
    db.bill.findMany({ where: { createdAt: { gte: new Date(Date.now() - 30 * 86_400_000) }, pointsUsed: { gt: 0 } }, select: { customerPhone: true, pointsUsed: true } }),
    db.lodgeBill.findMany({ where: { createdAt: { gte: new Date(Date.now() - 30 * 86_400_000) }, pointsUsed: { gt: 0 } }, select: { guestPhone: true, pointsUsed: true } }),
  ]);
  for (const r of restWin) { used30 += r.pointsUsed ?? 0; if (r.customerPhone) users30.add(r.customerPhone); }
  for (const l of lodgeWin) { used30 += l.pointsUsed ?? 0; if (l.guestPhone) users30.add(l.guestPhone); }
  const live = wallets.reduce((s, v) => s + v, 0);
  const [billCount, lgCount, bcCount] = await Promise.all([db.bill.count(), db.lodgeBill.count(), db.broadcast.count()]);
  console.log(`wallets: ${wallets.length} · live points ≈ ${live}`);
  console.log(`30-day redemptions: ${Math.round(used30)} pts by ${users30.size} customers`);
  console.log(`tiers → 500+: ${countAt(500)} · 1000+: ${countAt(1000)} · 3000+: ${countAt(3000)}`);
  console.log(`totals: ${billCount} bills · ${lgCount} lodge bills · ${bcCount} broadcasts`);
  console.log("── seed-t236 done ──");
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
