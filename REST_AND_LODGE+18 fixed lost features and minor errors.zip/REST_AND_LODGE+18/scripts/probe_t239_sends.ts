// t239 probe — why does getCampaignBucketSends return nothing for every range?
import { getCampaignBucketSends } from "../src/lib/analytics";

async function main() {
  const now = new Date();
  console.log("now:", now.toISOString());
  const since = new Date(now.getTime() - 30 * 86400000);
  for (const bucket of ["hour", "day", "week", "month"] as const) {
    const m = await getCampaignBucketSends(since, bucket);
    const entries = [...m.entries()];
    console.log(`bucket=${bucket} entries=${entries.length}`);
    for (const [k, list] of entries.slice(-6)) {
      console.log("  ", k, "->", list.map((s) => `f=${s.f.toFixed(2)} @${new Date(s.at).toISOString()}`).join(" | "));
    }
  }
}
main().then(() => process.exit(0));
