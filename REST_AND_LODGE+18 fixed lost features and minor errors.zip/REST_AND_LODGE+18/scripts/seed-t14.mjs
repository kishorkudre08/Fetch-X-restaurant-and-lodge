/* t229 — Task 14 seed: closures + ready-made goods + fresh data for every
 * recently added feature, so the dashboard never reads broken.
 *
 *   1 · BUSINESS CLOSURES  — 5 recent days closed outright (a Sunday weekly
 *       off, a 2-day annual staff break, a kitchen deep-clean, a private
 *       whole-property event). Bills + lodge bills on those days are torn
 *       out (wallets heal — they are recomputed from bill rows); Closure
 *       rows explain the zero days to the AI and the owner.
 *   2 · READY MADE GOODS   — new dish category + 8 packaged items, then
 *       fresh bills (Oct 14–16) that carry them so the DISH CATEGORY SPLIT
 *       donut, POS board, items list and AI all see the new shelf.
 *   3 · ATTENDANCE         — marks for Oct 13–16 (the closed days stay
 *       unmarked), per-employee rates mirroring their own history so the
 *       average holds inside the owner's 70–90% band.
 *   4 · TASKS + EXPENSES   — recent owner tasks (one closed with a crown
 *       spend) + station expenses so every metric has living data.
 *   5 · BROADCASTS         — two example mass-message sends (log rows), so
 *       the new composer's history is not empty on first look.
 *
 * Loyalty math mirrors src/app/api/bills/route.ts paise-for-paise.
 * Run: node scripts/seed-t14.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const DAY = 86_400_000;
const IST = 330 * 60000;
const GST = 0.05;
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.round(rnd(a, b));
const r2 = (n) => Math.round(n * 100) / 100;

async function numSetting(key, dflt, max) {
  const row = await db.setting.findUnique({ where: { key } });
  const n = Math.floor(Number(row?.value));
  return Number.isFinite(n) && n >= 0 ? Math.min(n, max) : dflt;
}

const REGULARS = [
  ["Ravi Sharma", "9812345670", 22],
  ["Priya Nair", "9823411788", 14],
  ["Arjun Mehta", "9845012397", 12],
  ["Sneha Kulkarni", "9900456712", 12],
  ["Vikram Joshi", "9964001123", 10],
  ["Meena Iyer", "9741018834", 10],
  ["Rahul Verma", "9739055261", 10],
  ["Kavita Rao", "9686990418", 10],
];
const WALKIN_NAMES = [
  "Nikhil Shetty", "Divya Prasad", "Manoj Kamat", "Sarita Hegde", "Deepak Rao",
  "Anjali Bhat", "Harish Nayak", "Lalita Shettigar", "Ganesh Bhandari", "Pooja Shenoy",
];
const CHANNELS = [["dine_in", 45], ["take_away", 20], ["online_order", 20], ["lodge_order", 15]];
function pickChannel() {
  const tot = CHANNELS.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * tot;
  for (const [id, w] of CHANNELS) { r -= w; if (r <= 0) return id; }
  return "dine_in";
}
const HOUR_W = [2, 1, 0.5, 0.5, 0.5, 1, 3, 8, 10, 8, 8, 14, 16, 12, 8, 8, 10, 12, 14, 15, 12, 8, 5, 3];

/* the closed days — IST business day keys (no sales AT ALL on these) */
const CLOSURES = [
  ["2026-09-23", "PRIVATE EVENT · WHOLE-PROPERTY BOOKING", "A family booked the entire property for a wedding function — kitchen and lodge closed to walk-ins."],
  ["2026-09-27", "WEEKLY OFF · SUNDAY", "Standing Sunday weekly off."],
  ["2026-10-06", "KITCHEN DEEP-CLEAN & PEST CONTROL", "Quarterly deep-clean of the kitchen line and cold storage; pest-control agency on site."],
  ["2026-10-11", "WEEKLY OFF · SUNDAY", "Standing Sunday weekly off."],
  ["2026-10-12", "EXTENDED WEEKLY OFF · ANNUAL STAFF DAY", "The annual staff day follows the Sunday weekly off — property shut two days straight."],
];

/* the packaged shelf — READY MADE GOODS */
const READY_MADE = [
  ["Lays Magic Masala", 20, true],
  ["Hide & Seek Biscuits", 35, true],
  ["Maggi Noodles", 50, true],
  ["Amul Ice Cream Cup", 45, true],
  ["Britannia Cake Slice", 25, true],
  ["Parle-G Family Pack", 30, true],
  ["Instant Cup Soup", 55, true],
  ["Dairy Milk Bar", 60, true],
];

async function main() {
  console.log("── seed-t14 start ──");
  const now = Date.now();
  const istDayStart = new Date(new Date(now + IST).setUTCHours(0, 0, 0, 0)).getTime() - IST;

  const [discLimit, loyaltyPct] = await Promise.all([
    numSetting("discountLimit", 10, 100),
    numSetting("loyaltyPct", 5, 100),
  ]);
  console.log("rules: discountLimit", discLimit + "% · loyaltyPct", loyaltyPct + "%");

  /* ── 1 · CLOSURES — record them, then tear out that day's sales ── */
  let tornRest = 0, tornLodge = 0;
  for (const [day, reason, note] of CLOSURES) {
    const start = new Date(`${day}T00:00:00.000+05:30`);
    const end = new Date(start.getTime() + DAY);
    const rb = await db.bill.deleteMany({ where: { createdAt: { gte: start, lt: end } } });
    const rl = await db.lodgeBill.deleteMany({ where: { createdAt: { gte: start, lt: end } } });
    tornRest += rb.count; tornLodge += rl.count;
    await db.closure.upsert({
      where: { date: day },
      create: { date: day, reason, note },
      update: { reason, note },
    });
    console.log(`closed ${day}: −${rb.count} rest bills · −${rl.count} lodge bills · ${reason}`);
  }
  console.log("torn totals:", tornRest, "restaurant +", tornLodge, "lodge");

  /* ── 2 · READY MADE GOODS — category + dishes ── */
  await db.category.upsert({ where: { name: "Ready Made Goods" }, create: { name: "Ready Made Goods" }, update: {} });
  const rmDishes = [];
  for (const [name, price, veg] of READY_MADE) {
    const existing = await db.dish.findFirst({ where: { name, category: "Ready Made Goods" } });
    if (existing) { rmDishes.push(existing); continue; }
    rmDishes.push(await db.dish.create({ data: { name, price, category: "Ready Made Goods", veg, active: true } }));
  }
  console.log("ready-made dishes:", rmDishes.length);

  const dishes = await db.dish.findMany({ where: { active: true }, select: { id: true, name: true, price: true, category: true } });

  /* wallets START from the (post-closure) ledger — the seed only adds deltas */
  const wallet = new Map();
  for (const [, phone] of REGULARS) {
    const [r, l] = await Promise.all([
      db.bill.aggregate({ where: { customerPhone: phone }, _sum: { pointsEarned: true, pointsUsed: true } }),
      db.lodgeBill.aggregate({ where: { guestPhone: phone }, _sum: { pointsEarned: true, pointsUsed: true } }),
    ]);
    wallet.set(phone,
      Math.round((r._sum.pointsEarned ?? 0) + (l._sum.pointsEarned ?? 0)) -
      Math.round((r._sum.pointsUsed ?? 0) + (l._sum.pointsUsed ?? 0)));
  }

  async function nextBillNo() {
    const nums = (await db.bill.findMany({ select: { number: true }, orderBy: { number: "asc" } })).map((b) => b.number);
    const mx = nums.length ? nums[nums.length - 1] : 1000;
    if (nums.length === mx - 1000) return mx + 1;
    let n = 1001;
    for (const x of nums) { if (x === n) n += 1; else break; }
    return n;
  }
  let billNo = await nextBillNo();
  async function createBill(data) {
    for (let attempt = 0; attempt < 4; attempt++) {
      try { return await db.bill.create({ data }); }
      catch (e) {
        const tgt = JSON.stringify(e?.meta?.target ?? "");
        if (String(e?.code) === "P2002" && tgt.includes("number")) { data.number = await nextBillNo(); continue; }
        throw e;
      }
    }
    throw new Error("bill number race did not settle");
  }

  const regTot = REGULARS.reduce((s, r) => s + r[2], 0);
  const pickRegular = () => {
    let r = Math.random() * regTot;
    for (const row of REGULARS) { r -= row[2]; if (r <= 0) return row; }
    return REGULARS[0];
  };
  let walkinSeq = 0;
  const newWalkin = () => {
    const name = WALKIN_NAMES[walkinSeq % WALKIN_NAMES.length];
    const phone = "95" + String(10000000 + walkinSeq * 6421).slice(0, 8);
    walkinSeq += 1;
    return [name, phone];
  };

  /* ── 2b · fresh bills (Oct 13→16, skipping closed days) — ~1 in 2 carries
        a READY MADE GOODS line so the new category has living sales ── */
  const CLOSED = new Set(CLOSURES.map(([d]) => d));
  let billCount = 0, rmBills = 0, minted = 0, burned = 0;
  const istKey = (t) => new Date(t + IST).toISOString().slice(0, 10);
  for (let d = 3; d >= 0; d--) {
    const dayStart = istDayStart - d * DAY;
    if (CLOSED.has(istKey(dayStart))) { console.log("skip closed", istKey(dayStart)); continue; }
    const dayEnd = d === 0 ? now : dayStart + DAY;
    const target = d === 0 ? 8 : Math.max(10, Math.round(22 + rnd(-4, 4)));
    const buckets = [];
    for (let h = 0; h < 24; h++) {
      const slot = dayStart + h * 3_600_000;
      if (slot >= dayEnd) break;
      buckets.push({ slot, w: HOUR_W[h] * (d === 0 ? Math.max(0.25, (dayEnd - slot) / 3_600_000) : 1) });
    }
    const wTot = buckets.reduce((s, b) => s + b.w, 0);
    for (let k = 0; k < target; k++) {
      let r = Math.random() * wTot, at = buckets[buckets.length - 1].slot;
      for (const b of buckets) { r -= b.w; if (r <= 0) { at = b.slot; break; } }
      at = Math.min(at + Math.random() * 3_600_000, dayEnd - 60_000);

      /* 55% of bills pick up a packaged item — the grab-counter habit */
      const wantsRM = Math.random() < 0.55;
      const lines = irnd(1, 3);
      const picks = [];
      for (let i = 0; i < lines; i++) {
        const dish = dishes[irnd(0, dishes.length - 1)];
        picks.push({ dish, qty: Math.random() < 0.72 ? 1 : 2 });
      }
      if (wantsRM) {
        const rm = rmDishes[irnd(0, rmDishes.length - 1)];
        picks.push({ dish: rm, qty: irnd(1, 3) });
        rmBills += 1;
      } else if (Math.random() < 0.18) {
        /* some bills are ONLY the packaged shelf (take-away snacks) */
        const rm = rmDishes[irnd(0, rmDishes.length - 1)];
        picks.length = 0;
        picks.push({ dish: rm, qty: irnd(1, 2) });
        rmBills += 1;
      }
      const subtotal = r2(picks.reduce((s, p) => s + p.dish.price * p.qty, 0));
      const isRegular = Math.random() < 0.6;
      const [name, phone] = isRegular ? pickRegular() : newWalkin();
      const roll = Math.random();
      let discount = 0;
      if (roll < 0.12) discount = subtotal * rnd(0.03, 0.08);
      else if (roll < 0.22) discount = subtotal * rnd(0.1, 0.18);
      const discCap = Math.floor(subtotal * discLimit) / 100;
      const balance = Math.max(0, wallet.get(phone) ?? 0);
      const safeDiscount = Math.min(r2(discount), discCap + balance, subtotal);
      const pointsUsed = Math.min(Math.max(0, safeDiscount - discCap), balance);
      const taxable = Math.max(0, subtotal - safeDiscount);
      const tax = Math.round(taxable * GST * 100) / 100;
      const total = Math.round((taxable + tax) * 100) / 100;
      const pointsEarned = loyaltyPct > 0 ? Math.round((total * loyaltyPct) / 100) : 0;
      wallet.set(phone, (wallet.get(phone) ?? 0) - pointsUsed + pointsEarned);
      burned += pointsUsed; minted += pointsEarned;
      await createBill({
        number: billNo++, subtotal, discount: safeDiscount, tax, total,
        itemCount: picks.reduce((s, p) => s + p.qty, 0),
        orderType: pickChannel(), customerName: name, customerPhone: phone,
        pointsEarned, pointsUsed: r2(pointsUsed), createdAt: new Date(at),
        items: { create: picks.map((p) => ({ dishId: p.dish.id, name: p.dish.name, category: p.dish.category, qty: p.qty, price: p.dish.price })) },
      });
      billCount += 1;
    }
  }
  console.log("fresh bills:", billCount, "· ready-made on", rmBills, "· minted", minted, "· burned", r2(burned));

  /* ── 3 · ATTENDANCE Oct 13–16, per-employee rates from their own history ── */
  const emps = await db.employee.findMany({ where: { active: true }, select: { id: true, name: true, book: true } });
  const hist = await db.attendance.findMany({
    where: { date: { gte: "2026-09-16", lte: "2026-10-10" } },
    select: { employeeId: true, status: true },
  });
  const rate = new Map();
  for (const h of hist) {
    const r = rate.get(h.employeeId) ?? { p: 0, a: 0 };
    if (h.status === "present") r.p += 1; else r.a += 1;
    rate.set(h.employeeId, r);
  }
  const OPEN_DAYS = [];
  for (let d = 3; d >= 0; d--) {
    const key = istKey(istDayStart - d * DAY);
    if (!CLOSED.has(key)) OPEN_DAYS.push(key);
  }
  let attRows = 0, pres = 0;
  for (const e of emps) {
    const h = rate.get(e.id) ?? { p: 8, a: 2 };
    const p = h.p + h.a > 0 ? h.p / (h.p + h.a) : 0.8;
    for (const day of OPEN_DAYS) {
      const isPresent = Math.random() < Math.min(0.95, Math.max(0.55, p));
      await db.attendance.upsert({
        where: { employeeId_date: { employeeId: e.id, date: day } },
        create: { employeeId: e.id, date: day, status: isPresent ? "present" : "absent" },
        update: { status: isPresent ? "present" : "absent" },
      });
      attRows += 1; if (isPresent) pres += 1;
    }
  }
  console.log("attendance rows:", attRows, "· present", pres, `(${Math.round((pres / Math.max(1, attRows)) * 100)}%) · open days`, OPEN_DAYS.join(","));

  /* ── 4 · TASKS + EXPENSES — recent, so no window reads dead ── */
  const mk = await db.task.create({
    data: {
      title: "Print new QR standees for the tables", book: "rest", kind: "upgrade",
      maxBudget: 1200, description: "Waterproof standees with the new online-ordering QR for all 14 tables.",
      deadline: new Date(istDayStart - 1 * DAY), status: "done",
      createdBy: "Owner", createdAt: new Date(istDayStart - 2 * DAY + 5 * 3_600_000),
      doneAt: new Date(istDayStart - 1 * DAY + 8 * 3_600_000), doneBy: "RESTAURANT RECEPTION",
      actualCost: 980,
      updates: {
        create: [
          { author: "RESTAURANT RECEPTION", role: "reception", message: "Design approved by the printer, proofs attached to the board.", createdAt: new Date(istDayStart - 2 * DAY + 9 * 3_600_000) },
          { author: "RESTAURANT RECEPTION", role: "reception", message: "Delivered and placed on all tables. ₹980 spent of the ₹1,200 cap.", createdAt: new Date(istDayStart - 1 * DAY + 8 * 3_600_000) },
        ],
      },
    },
  });
  await db.expense.create({
    data: { kind: "upgrade", book: "rest", label: "QR standees — 14 tables", amount: 980,
      spentOn: new Date(istDayStart - 1 * DAY + 8 * 3_600_000), via: "task", taskId: mk.id },
  });
  await db.task.create({
    data: {
      title: "Fix the CCTV blind spot at the gate", book: "lodge", kind: "maintenance",
      maxBudget: 3500, description: "The gate camera misses the left lane — needs a re-angle plus a bracket.",
      deadline: new Date(istDayStart + 2 * DAY), status: "open",
      createdBy: "Owner", createdAt: new Date(istDayStart - 1 * DAY + 10 * 3_600_000),
      updates: { create: { author: "LODGE RECEPTION", role: "reception", message: "Technician visiting tomorrow morning.", createdAt: new Date(istDayStart - 1 * DAY + 12 * 3_600_000) } },
    },
  });
  await db.task.create({
    data: {
      title: "Descale the kitchen exhaust", book: "rest", kind: "maintenance",
      maxBudget: 2000, description: "Post-monsoon descale + filter wash for the main exhaust line.",
      deadline: new Date(istDayStart + 3 * DAY), status: "open",
      createdBy: "Owner", createdAt: new Date(istDayStart - 2 * DAY + 6 * 3_600_000),
    },
  });
  const EXP = [
    ["raw_material", "rest", "Festival groceries — ghee, dry fruits, atta", 4200, 1],
    ["maintenance", "lodge", "Geyser repair — room 23", 1850, 1],
    ["raw_material", "lodge", "Toiletries + linen refill", 960, 0],
    ["raw_material", "rest", "Ready-made shelf restock — biscuits, noodles, bars", 1240, 0],
  ];
  for (const [kind, book, label, amount, daysBack] of EXP) {
    await db.expense.create({
      data: { kind, book, label, amount, spentOn: new Date(istDayStart - daysBack * DAY + 7 * 3_600_000) },
    });
  }
  console.log("tasks +2 open /1 done · expenses +4");

  /* ── 5 · BROADCASTS — two example sends so the log isn't empty ── */
  const all = await db.bill.groupBy({
    by: ["customerPhone"], where: { customerPhone: { not: null } },
    _sum: { pointsEarned: true, pointsUsed: true }, _count: { _all: true },
  });
  const lodgeAgg = await db.lodgeBill.groupBy({
    by: ["guestPhone"], _sum: { pointsEarned: true, pointsUsed: true }, _count: { _all: true },
  });
  const bal = new Map();
  for (const r of all) if (r.customerPhone) bal.set(r.customerPhone, (r._sum.pointsEarned ?? 0) - (r._sum.pointsUsed ?? 0));
  for (const l of lodgeAgg) bal.set(l.guestPhone, (bal.get(l.guestPhone) ?? 0) + (l._sum.pointsEarned ?? 0) - (l._sum.pointsUsed ?? 0));
  const bCount = (min) => min > 0 ? [...bal.values()].filter((b) => b >= min).length : bal.size;
  const bcExist = await db.broadcast.count();
  if (bcExist === 0) {
    await db.broadcast.createMany({
      data: [
        {
          audience: "pts_1000", message: "Hello {NAME}, you have {POINTS} loyalty points waiting — 1 pt = ₹1 off your next bill or stay. The Dussehra special thali counter is on all weekend!",
          notice: "", recipients: bCount(1000),
          sample: "Hello Ravi Sharma, you have 1413 loyalty points waiting — 1 pt = ₹1 off your next bill or stay. The Dussehra special thali counter is on all weekend!",
          sentBy: "RESTAURANT RECEPTION", book: "rest",
          createdAt: new Date(istDayStart - 1 * DAY + 11 * 3_600_000),
        },
        {
          audience: "all", message: "",
          notice: "This weekend at the hotel: the Dussehra special thali counter is back — 12–3 PM and 7–11 PM. Pure veg, festival recipes. Rooms book fast — call the front desk.",
          recipients: bal.size, sample: "This weekend at the hotel: the Dussehra special thali counter is back — 12–3 PM and 7–11 PM. Pure veg, festival recipes. Rooms book fast — call the front desk.",
          sentBy: "LODGE RECEPTION", book: "lodge",
          createdAt: new Date(istDayStart + 2 * 3_600_000),
        },
      ],
    });
    console.log("broadcasts seeded: 2 · audiences pts_1000 =", bCount(1000), "· all =", bal.size);
  } else {
    console.log("broadcasts already present:", bcExist);
  }

  console.log("── wallets after seed (regulars) ──");
  for (const [name, phone] of REGULARS) console.log("  ", name, "·", phone, "→", Math.max(0, Math.round(wallet.get(phone) ?? 0)), "pts");
  console.log("── seed-t14 done ──");
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
