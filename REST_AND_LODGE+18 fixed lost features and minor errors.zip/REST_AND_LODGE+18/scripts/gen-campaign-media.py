#!/usr/bin/env python3
"""t239 — regenerate campaign media lost with the workspace rollback.
The +15 zip's db references uploads/broadcasts/{banner-feast.png, banner-stay.png,
clip-staycation.mp4} but the runtime uploads/ dir was never in the zip, so the
Mass Messages attachments 404. Rebuild all three from scratch."""
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import subprocess, os

OUT = "/home/z/my-project/uploads/broadcasts"
os.makedirs(OUT, exist_ok=True)
W, H = 1280, 720
BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def vgrad(w, h, top, bottom):
    base = Image.new("RGB", (1, h))
    for y in range(h):
        t = y / (h - 1)
        base.putpixel((0, y), tuple(int(a + (b - a) * t) for a, b in zip(top, bottom)))
    return base.resize((w, h))


def banner(path, top, bottom, eyebrow, headline, subline, footer, accent):
    img = vgrad(W, H, top, bottom)
    d = ImageDraw.Draw(img, "RGBA")
    # soft accent glow top-right + bottom-left
    glow = Image.new("RGB", (W, H), 0)
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W - 500, -260, W + 260, 420], fill=accent)
    gd.ellipse([-300, H - 380, 320, H + 260], fill=accent)
    glow = glow.filter(ImageFilter.GaussianBlur(180))
    img = Image.blend(img, glow, 0.22)
    d = ImageDraw.Draw(img, "RGBA")
    # thin frame
    d.rectangle([36, 36, W - 37, H - 37], outline=(255, 255, 255, 90), width=2)
    d.rectangle([54, 54, W - 55, H - 55], outline=(255, 255, 255, 45), width=1)
    f_eye = ImageFont.truetype(BOLD, 34)
    f_head = ImageFont.truetype(BOLD, 110)
    f_sub = ImageFont.truetype(REG, 40)
    f_foot = ImageFont.truetype(BOLD, 30)
    cx = W // 2

    def center(txt, font, y, fill):
        tw = d.textlength(txt, font=font)
        d.text((cx - tw / 2, y), txt, font=font, fill=fill)

    center(eyebrow, f_eye, 150, (255, 235, 200, 235))
    center(headline, f_head, 235, (255, 255, 255, 255))
    # accent rule under headline
    d.rectangle([cx - 130, 402, cx + 130, 410], fill=accent)
    center(subline, f_sub, 452, (255, 244, 228, 240))
    center(footer, f_foot, 596, (255, 255, 255, 180))
    img.save(path, "PNG")
    print("wrote", path)


banner(f"{OUT}/banner-feast.png", (126, 45, 18), (62, 16, 8),
       "SPICE ROUTE · RESTAURANT", "GREAT FEAST WEEK",
       "Double loyalty points on every dine-in bill · Oct 10 – 24",
       "RESERVE YOUR TABLE · WALK-INS WELCOME", (255, 176, 59))

banner(f"{OUT}/banner-stay.png", (11, 74, 96), (6, 34, 58),
       "WANDERLUST LODGE", "STAY 3 · PAY 2",
       "The third night is on the house — all month long",
       "LIMITED ROOMS · BOOK AT THE FRONT DESK", (94, 216, 255))

# ---- video teaser: 2s feast + 2s stay with a 0.6s crossfade, 1280x720 ----
subprocess.run([
    "ffmpeg", "-y",
    "-loop", "1", "-t", "2.2", "-i", f"{OUT}/banner-feast.png",
    "-loop", "1", "-t", "2.2", "-i", f"{OUT}/banner-stay.png",
    "-filter_complex",
    "[0:v]scale=1280:720,setsar=1,fps=24[a];"
    "[1:v]scale=1280:720,setsar=1,fps=24[b];"
    "[a][b]xfade=transition=fade:duration=0.6:offset=1.6,format=yuv420p[v]",
    "-map", "[v]", "-c:v", "libx264", "-crf", "30", "-preset", "veryfast",
    "-movflags", "+faststart",
    f"{OUT}/clip-staycation.mp4",
], check=True, capture_output=True)
print("wrote", f"{OUT}/clip-staycation.mp4")

for f in sorted(os.listdir(OUT)):
    print(f, os.path.getsize(f"{OUT}/{f}"), "bytes")
