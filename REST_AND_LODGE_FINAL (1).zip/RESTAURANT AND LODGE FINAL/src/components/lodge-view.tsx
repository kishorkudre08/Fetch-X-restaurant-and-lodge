"use client";

// ── Lodge Front Desk — the room wall ────────────────────────────────────
// Full-stack port of the approved demo engine: green is free, black is
// occupied, red is under maintenance. RECEPTION (the counter): tap a green
// number to check a guest in; tap a black number to settle the stay and
// generate the bill (the room then turns red); tap a red number →
// "Maintenance done?" — yes turns it green, no keeps it red. Stays bill to
// the hour — rate × hours ÷ 24, never below the ₹1,000 floor, then 5% GST.
// OWNER (t116): a monitor only — no expenses block, no check-in / check-out
// management, no bill undo. Tapping any room shows its status (occupied /
// free / maintenance) with the resident's details ONLY when occupied; the
// live donut sits above the rooms; the wall's size is edited below.

import * as React from "react";
import {
  BedDouble,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Clock,
  Loader2,
  Plus,
  Receipt,
  RotateCcw,
  Trash2,
  Wrench,
  X,
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { TierBand, ScrollFadeBox } from "@/components/fx";
import { BillsFeed, lodgeBillToBill } from "@/components/bills-feed";
import { RoomStatusDonut } from "@/components/room-status-donut";
import { RoomLevelsEditor } from "@/components/room-levels-editor";
import { useToast } from "@/hooks/use-toast";
import { useReceipt } from "@/components/receipt-dialog";
import { DEFAULT_LEVELS, fmtDur, fmtHrs, lgStay, levelLabel, tierOfRoom, type Level } from "@/lib/lodge";
import { inr, inr2, istDateTime, istTime } from "@/lib/format";
import type { LodgeBill, Room } from "@/lib/types";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";

type Filter = "all" | "avl" | "occ";
type Dlg =
  | { kind: "checkin"; room: number | null }
  | { kind: "checkout"; room: number }
  | { kind: "mnt"; room: number }
  | { kind: "info"; room: number }
  | null;

const initials = (name: string) =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");

const p2 = (x: number) => (x < 10 ? "0" : "") + x;

/* ── premium floating time picker (ported from the approved demo) ─────────── */
function LgTimeField({
  value,
  onChange,
  label,
}: {
  value: Date;
  onChange: (d: Date) => void;
  label: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [view, setView] = React.useState(() => new Date(value.getFullYear(), value.getMonth(), 1));

  const set = (d: Date) => {
    onChange(d);
    setView(new Date(d.getFullYear(), d.getMonth(), 1));
  };

  const first = new Date(view.getFullYear(), view.getMonth(), 1).getDay();
  const dim = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const today = new Date();
  const h12 = value.getHours() % 12 || 12;
  const ap = value.getHours() >= 12 ? "PM" : "AM";

  const at = (d: number, h = value.getHours(), m = value.getMinutes()) =>
    new Date(view.getFullYear(), view.getMonth(), d, h, m);

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (o) setView(new Date(value.getFullYear(), value.getMonth(), 1));
      }}
    >
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={label}
          className="flex w-full items-center gap-2.5 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-3 py-2.5 text-[13px] font-bold text-[var(--fx-ink)] transition hover:border-[color-mix(in_srgb,var(--fx-purple)_45%,var(--fx-line))] hover:shadow-[0_4px_12px_-6px_rgba(91,79,233,.35)]"
        >
          <Clock className="h-4 w-4 shrink-0 text-[var(--fx-accent-ink)]" />
          <span className="flex-1 truncate text-left">
            {value.getDate()} {value.toLocaleDateString("en-IN", { month: "short" })} {value.getFullYear()} ·{" "}
            {value.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit", hour12: true })}
          </span>
          <ChevronDown className="h-3.5 w-3.5 shrink-0 text-[var(--fx-muted)]" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[292px] rounded-2xl border-[var(--fx-line)] p-3 shadow-[0_18px_40px_-18px_rgba(35,32,72,.45)]" align="start">
        {/* month header */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="icon" aria-label="Previous month" className="h-7 w-7 rounded-lg" onClick={() => setView(new Date(view.getFullYear(), view.getMonth() - 1, 1))}>
            <ChevronLeft className="h-3.5 w-3.5" />
          </Button>
          <b className="text-[11px] font-extrabold tracking-[0.14em] text-[var(--fx-ink)]">
            {["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"][view.getMonth()]}{" "}
            {view.getFullYear()}
          </b>
          <Button variant="ghost" size="icon" aria-label="Next month" className="h-7 w-7 rounded-lg" onClick={() => setView(new Date(view.getFullYear(), view.getMonth() + 1, 1))}>
            <ChevronRight className="h-3.5 w-3.5" />
          </Button>
        </div>
        {/* weekday row */}
        <div className="mt-2 grid grid-cols-7 text-center text-[9px] font-extrabold tracking-wider text-[var(--fx-muted)]">
          {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => (
            <span key={d} className="py-1">{d}</span>
          ))}
        </div>
        {/* day grid */}
        <div className="grid grid-cols-7 gap-0.5">
          {Array.from({ length: first }, (_, i) => (
            <span key={`b${i}`} />
          ))}
          {Array.from({ length: dim }, (_, i) => {
            const d = i + 1;
            const sel = d === value.getDate() && view.getMonth() === value.getMonth() && view.getFullYear() === value.getFullYear();
            const tod = d === today.getDate() && view.getMonth() === today.getMonth() && view.getFullYear() === today.getFullYear();
            return (
              <button
                key={d}
                type="button"
                onClick={() => onChange(at(d))}
                className={`grid h-8 place-items-center rounded-lg text-[11.5px] font-bold transition ${
                  sel
                    ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)]"
                    : tod
                      ? "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
                      : "text-[var(--fx-ink)] hover:bg-[var(--fx-lav)]"
                }`}
              >
                {d}
              </button>
            );
          })}
        </div>
        {/* time row */}
        <div className="mt-3 flex items-center gap-1.5">
          <select
            aria-label="Hour"
            value={h12}
            onChange={(e) => onChange(new Date(value.getFullYear(), value.getMonth(), value.getDate(), (Number(e.target.value) % 12) + (ap === "PM" ? 12 : 0), value.getMinutes()))}
            className="fx-num h-8 min-w-0 flex-1 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-page)] px-1.5 text-[12px] font-bold text-[var(--fx-ink)]"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((x) => (
              <option key={x} value={x}>{p2(x)}</option>
            ))}
          </select>
          <span className="text-[12px] font-extrabold text-[var(--fx-muted)]">:</span>
          <select
            aria-label="Minute"
            value={value.getMinutes()}
            onChange={(e) => onChange(new Date(value.getFullYear(), value.getMonth(), value.getDate(), value.getHours(), Number(e.target.value)))}
            className="fx-num h-8 min-w-0 flex-1 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-page)] px-1.5 text-[12px] font-bold text-[var(--fx-ink)]"
          >
            {[0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55].map((x) => (
              <option key={x} value={x}>{p2(x)}</option>
            ))}
          </select>
          <div className="flex overflow-hidden rounded-lg border border-[var(--fx-line)]">
            {(["AM", "PM"] as const).map((a) => (
              <button
                key={a}
                type="button"
                onClick={() => onChange(new Date(value.getFullYear(), value.getMonth(), value.getDate(), (value.getHours() % 12) + (a === "PM" ? 12 : 0), value.getMinutes()))}
                className={`h-8 px-2 text-[10px] font-extrabold tracking-wider transition ${
                  ap === a ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)]" : "bg-[var(--fx-page)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {a}
              </button>
            ))}
          </div>
        </div>
        {/* footer */}
        <div className="mt-2.5 flex items-center justify-between">
          <Button variant="ghost" size="sm" className="h-8 rounded-lg px-2.5 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-muted)]" onClick={() => set(new Date())}>
            <Clock className="mr-1 h-3 w-3" /> NOW
          </Button>
          <Button size="sm" className="h-8 rounded-lg bg-[var(--fx-purple)] px-4 text-[10.5px] font-extrabold tracking-wider text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]" onClick={() => setOpen(false)}>
            DONE
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

/* ── main view ─────────────────────────────────────────────────────────────── */
export function LodgeView({ role = "reception_lodge" }: { role?: string }) {
  const isOwner = role === "owner"; // t116 — the owner monitors the wall; the desk operates it
  // t184 — view-level toggles cached across section switches + AI-writable.
  // filter (all/avl/occ) supports "show me available rooms" / "occupied rooms".
  // billsOpen is the owner's collapsible bills block. resetArm stays transient
  // (it's a destructive two-step guard, not a view filter).
  const [filter, setFilter] = useCachedToggle<Filter>("lodge", "filter", "all");
  const [billsOpen, setBillsOpen] = useCachedToggle<boolean>("lodge", "billsOpen", true);
  useRegisterScreen("lodge", isOwner ? "Rooms Overview" : "Lodge Front Desk", { filter, billsOpen });
  const { toast } = useToast();
  const { openReceipt } = useReceipt();
  const [rooms, setRooms] = React.useState<Room[]>([]);
  const [bills, setBills] = React.useState<LodgeBill[]>([]);
  const [levels, setLevels] = React.useState<Level[]>(DEFAULT_LEVELS);
  const [loading, setLoading] = React.useState(true);
  const [busy, setBusy] = React.useState(false);
  const [dlg, setDlg] = React.useState<Dlg>(null);
  const [resetArm, setResetArm] = React.useState(false);
  /* t143 — the owner's discount limit % from Settings; the front desk's
     checkout discount is clamped to this % of the stay charge.
     lodgeMin — the owner's minimum-stay floor ₹ from Settings; a short stay
     can never bill below it (0 = no floor). */
  const [discLimit, setDiscLimit] = React.useState(10);
  const [lodgeMin, setLodgeMin] = React.useState(1000);

  const load = React.useCallback(async () => {
    try {
      // t117 — the owner's front desk reads the last 50 bills; the counter keeps its 8
      const res = await fetch(isOwner ? "/api/lodge?bills=50" : "/api/lodge");
      const data = (await res.json()) as { rooms?: Room[]; bills?: LodgeBill[]; levels?: Level[] };
      setRooms(data.rooms ?? []);
      setBills(data.bills ?? []);
      if (Array.isArray(data.levels) && data.levels.length) setLevels(data.levels);
    } catch {
      /* keep the wall as-is on failure */
    } finally {
      setLoading(false);
    }
  }, [isOwner]);

  React.useEffect(() => {
    void load();
  }, [load]);

  /* t143 — every role pulls the owner's Settings levers once: the discount
     limit % caps the checkout discount, and the minimum-stay floor ₹ is what
     the wall footnotes, the check-in hint and the bill preview all show. */
  React.useEffect(() => {
    fetch("/api/settings")
      .then((x) => x.json())
      .then((s) => {
        const n = Math.floor(Number(s?.discountLimit));
        if (Number.isFinite(n) && n >= 0) setDiscLimit(Math.min(n, 100));
        const m = Math.floor(Number(s?.lodgeMinStay));
        if (Number.isFinite(m) && m >= 0) setLodgeMin(Math.min(m, 50000));
      })
      .catch(() => {
        /* the defaults of 10% / ₹1,000 stand */
      });
  }, []);

  // t116 — the rooms & rates editor (below) rebuilds the wall the moment it applies
  React.useEffect(() => {
    const h = () => void load();
    window.addEventListener("fx-lodge-changed", h);
    return () => window.removeEventListener("fx-lodge-changed", h);
  }, [load]);

  // the wall breathes — occupied durations and "now" states refresh every minute
  React.useEffect(() => {
    const t = setInterval(() => void load(), 60000);
    return () => clearInterval(t);
  }, [load]);

  const roomMap = React.useMemo(() => new Map(rooms.map((r) => [r.number, r])), [rooms]);
  const tierOf = React.useCallback((n: number) => tierOfRoom(n, levels), [levels]);
  const counts = React.useMemo(() => {
    let avl = 0, occ = 0, mnt = 0, rev = 0;
    for (const r of rooms) {
      if (r.status === "occ") { occ++; rev += tierOf(r.number).rate; }
      else if (r.status === "mnt") mnt++;
      else avl++;
    }
    return { avl, occ, mnt, rev };
  }, [rooms, tierOf]);

  const op = async (body: Record<string, unknown>): Promise<{ ok: boolean; bill?: LodgeBill; error?: string }> => {
    setBusy(true);
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => ({}))) as { ok?: boolean; bill?: LodgeBill; error?: string };
      if (!res.ok) return { ok: false, error: data.error ?? "Request failed" };
      return { ok: true, bill: data.bill };
    } catch {
      return { ok: false, error: "Network error" };
    } finally {
      setBusy(false);
    }
  };

  const fail = (error?: string) =>
    toast({ title: "Action failed", description: error ?? "Unknown error", variant: "destructive" });

  const done = () => {
    setDlg(null);
    void load();
  };

  const resetWall = async () => {
    if (!resetArm) {
      setResetArm(true);
      setTimeout(() => setResetArm(false), 3000);
      return;
    }
    setResetArm(false);
    const r = await op({ action: "reset" });
    if (!r.ok) return fail(r.error);
    toast({ title: "Wall reset", description: `All ${rooms.length} rooms are available again.` });
    void load();
  };

  const openRoom = (n: number) => {
    const r = roomMap.get(n);
    if (!r) return;
    // t116 — the owner's tap is read-only: status + resident details, no actions
    if (isOwner) return setDlg({ kind: "info", room: n });
    if (r.status === "occ") setDlg({ kind: "checkout", room: n });
    else if (r.status === "mnt") setDlg({ kind: "mnt", room: n });
    else setDlg({ kind: "checkin", room: n });
  };

  // UNDO a stay bill — tears the checkout; the guest walks back into the room
  // if housekeeping hasn't touched it yet (API rewinds the room state itself).
  // A mistaken CHECK-IN (no bill yet) is undone from the room dialog instead —
  // DELETE CHECK-IN there clears the room with no bill at all.
  const undoStay = async (num: number) => {
    try {
      const res = await fetch("/api/lodge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "bill-undo", number: num }),
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error ?? "Undo failed");
      toast({
        title: `Stay L-${num} undone`,
        description: "Bill deleted — the guest is back in the room if housekeeping hadn't touched it yet.",
      });
    } catch (e) {
      toast({
        title: "Undo failed",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    }
    void load();
  };

  const newGuest = () => {
    if (!counts.avl) {
      toast({
        title: "House full",
        description: `All ${rooms.length} rooms are occupied or under maintenance — check a guest out, finish maintenance, or reset the wall.`,
        variant: "destructive",
      });
      return;
    }
    setDlg({ kind: "checkin", room: null });
  };

  const cellCls = (st: string) =>
    st === "occ"
      ? "bg-[linear-gradient(155deg,#16141b,#07060a)] border-[#26232e] hover:border-[#3a3646] hover:shadow-[0_8px_18px_-8px_rgba(0,0,0,.65)]"
      : st === "mnt"
        ? "bg-[color-mix(in_srgb,var(--fx-rose)_10%,transparent)] border-[color-mix(in_srgb,var(--fx-rose)_38%,transparent)] hover:border-[color-mix(in_srgb,var(--fx-rose)_65%,transparent)] hover:shadow-[0_8px_18px_-8px_color-mix(in_srgb,var(--fx-rose)_60%,transparent)]"
        : "bg-[color-mix(in_srgb,var(--fx-green)_7%,transparent)] border-[color-mix(in_srgb,var(--fx-green)_22%,transparent)] hover:border-[color-mix(in_srgb,var(--fx-green)_48%,transparent)] hover:shadow-[0_8px_18px_-8px_color-mix(in_srgb,var(--fx-green)_60%,transparent)]";

  const cell = (r: Room) => {
    const t = tierOf(r.number);
    const numCls =
      r.status === "occ" ? "text-[var(--fx-gold-ondark)]" : r.status === "mnt" ? "text-[var(--fx-rose)]" : "text-[var(--fx-green)]";
    let tip: string;
    if (r.status === "occ" && r.guestName && r.checkInAt) {
      const hrs = (Date.now() - new Date(r.checkInAt).getTime()) / 3600000;
      tip = isOwner
        ? `Room ${r.number} · ${t.name} · occupied by ${r.guestName} · in for ${fmtDur(hrs)} · tap for details`
        : `Room ${r.number} · ${t.name} · ${r.guestName} · in for ${fmtDur(hrs)} · tap to bill & check out`;
    } else if (r.status === "mnt") {
      tip = isOwner
        ? `Room ${r.number} · ${t.name} · under maintenance · tap for details`
        : `Room ${r.number} · ${t.name} · vacated, under maintenance · tap when done`;
    } else {
      tip = isOwner
        ? `Room ${r.number} · ${t.name} · ${inr(t.rate)} / 24 hours · free · tap for details`
        : `Room ${r.number} · ${t.name} · ${inr(t.rate)} / 24 hours · tap to check in`;
    }
    const label = r.status === "occ" ? " — occupied" : r.status === "mnt" ? " — under maintenance" : " — available";
    return (
      <button
        key={r.number}
        onClick={() => openRoom(r.number)}
        aria-label={`Room ${r.number}${label}`}
        /* t136 — the wall is 20-up full-size tiles again (was t129's 1/4-size
           40-up band): ~56px squares on the desktop, numbers and names legible. */
        className={`group/room relative flex aspect-square flex-col items-center justify-center gap-px rounded-[7px] border transition-all duration-200 ease-out will-change-transform hover:z-20 hover:-translate-y-1 hover:scale-[1.08] ${cellCls(r.status)}`}
      >
        <span className={`fx-num text-[clamp(12px,1.05vw,15px)] font-extrabold ${numCls}`}>{r.number}</span>
        {r.status === "occ" && r.guestName && (
          <span className="max-w-[94%] truncate text-[10px] font-bold leading-tight tracking-wide text-[#918da0]">
            {r.guestName.split(/\s+/)[0]}
          </span>
        )}
        {r.status === "mnt" && (
          <span className="text-[color-mix(in_srgb,var(--fx-rose)_80%,var(--fx-muted))]">
            <Wrench className="h-3 w-3" />
          </span>
        )}
        {/* the pop-up — a small detail card that springs in above the block */}
        <span
          role="tooltip"
          className="pointer-events-none absolute bottom-[calc(100%+7px)] left-1/2 z-30 hidden w-max max-w-[150px] -translate-x-1/2 scale-90 rounded-lg border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2.5 py-1.5 text-center text-[9.5px] font-bold leading-snug text-[var(--fx-ink)] opacity-0 shadow-[4px_6px_0_0_var(--fx-hard)] transition-all duration-150 ease-out group-hover/room:scale-100 group-hover/room:opacity-100 sm:block"
        >
          {tip}
        </span>
      </button>
    );
  };

  const stripSeg = (b: React.ReactNode, l: string, cls: string) => (
    <span className="inline-flex items-baseline gap-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-muted)]">
      <b className={`fx-num text-[22px] font-extrabold tracking-tight ${cls}`}>{b}</b>
      {l}
    </span>
  );

  // t91 — live wall snapshot donut (counts mode; the dashboard carries the time-weighted one).
  // t116 — the OWNER sees it ABOVE the rooms; the counter keeps it below the wall.
  const snapshotCard = (
    <div className="fx-card p-5" data-testid="lodge-wall-snapshot">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label">WALL SNAPSHOT · LIVE</span>
        <span className="mut-chip">{rooms.length} ROOMS · {Math.round((counts.occ / Math.max(1, rooms.length)) * 100)}% FILLED</span>
      </div>
      <div className="mt-3">
        <RoomStatusDonut counts={counts} testId="room-status-donut" legendPrefix="lroom" />
      </div>
    </div>
  );

  return (
    <div className="space-y-5">
      <TierBand
        num={FX_TIERS.lodge.num}
        eyebrow={tierEyebrow(FX_TIERS.lodge)}
        /* t129 — the owner's monitor is "Rooms Overview"; the counter keeps "Lodge Front Desk" */
        title={isOwner ? "Rooms Overview" : "Lodge Front Desk"}
        sub={
          isOwner
            ? `The live wall — ${rooms.length || "..."} rooms, green is free, black is occupied, red is under maintenance. Tap any room to see its status; the resident's details appear only while it's occupied.`
            : `One calm wall of ${rooms.length || "..."} rooms — green is free, black is occupied, red is under maintenance. Tap a green number to check a guest in; tap a black number to settle the stay and generate the bill; tap a red number once housekeeping is done.`
        }
        tag={`${rooms.length ? Math.round((counts.occ / rooms.length) * 100) : 0}% FILLED`}
      >
        {/* t116 — check-in / check-out management is the COUNTER's job; the owner monitors */}
        {!isOwner && (
          <div className="flex flex-wrap items-center gap-2">
            <Button
              onClick={newGuest}
              className="h-9 rounded-xl bg-[var(--fx-purple)] px-4 text-[11.5px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
            >
              {busy ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Plus className="mr-1 h-3.5 w-3.5" />}
              ENTER NEW GUEST
            </Button>
            <Button
              variant="outline"
              onClick={() => void resetWall()}
              className={`h-9 rounded-xl border-[var(--fx-line)] bg-[var(--fx-surf)] px-3.5 text-[11.5px] font-extrabold tracking-wide shadow-[2px_3px_0_0_var(--fx-hard)] ${
                resetArm ? "text-[var(--fx-rose)]" : "text-[var(--fx-muted)]"
              }`}
            >
              {resetArm ? <Trash2 className="mr-1 h-3.5 w-3.5" /> : <RotateCcw className="mr-1 h-3.5 w-3.5" />}
              {resetArm ? "SURE? TAP AGAIN" : "RESET WALL"}
            </Button>
          </div>
        )}
      </TierBand>

      {/* t116 — the owner's monitoring order: donut first, rooms below */}
      {isOwner && snapshotCard}

      <div className="fx-card p-5 md:p-6">
        {/* t188 — clearer filter labels: ALL / AVAILABLE / OCCUPIED. The old
            "FREE" / "GUESTS" labels were not obvious — the owner said "no
            toggle in rooms overview" because the chips were too cryptic. */}
        <div className="inline-flex gap-1">
          {([
            ["all", "ALL"],
            ["avl", "AVAILABLE"],
            ["occ", "OCCUPIED"],
          ] as const).map(([f, l]) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`relative px-3 py-2 text-[10.5px] font-extrabold tracking-[0.12em] transition ${
                filter === f ? "text-[var(--fx-ink)]" : "text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
              }`}
            >
              {l}
              {filter === f && <span className="absolute inset-x-3 bottom-1 h-0.5 rounded bg-[var(--fx-purple)]" />}
            </button>
          ))}
        </div>

        {/* live strip */}
        <div className="mb-1.5 mt-3 flex flex-wrap items-center gap-x-6 gap-y-3 border-b border-[var(--fx-line)] pb-4 pt-1">
          {stripSeg(counts.avl, "FREE", "text-[var(--fx-green)]")}
          <span className="hidden h-[26px] w-px bg-[var(--fx-line)] sm:block" />
          {stripSeg(counts.occ, "GUESTS", "text-[var(--fx-gold)]")}
          {counts.mnt > 0 && (
            <>
              <span className="hidden h-[26px] w-px bg-[var(--fx-line)] sm:block" />
              {stripSeg(counts.mnt, "MAINTENANCE", "text-[var(--fx-rose)]")}
            </>
          )}
          <span className="hidden h-[26px] w-px bg-[var(--fx-line)] sm:block" />
          {stripSeg(`${counts.occ}%`, "FILLED", "text-[var(--fx-ink)]")}
          <span className="hidden h-[26px] w-px bg-[var(--fx-line)] sm:block" />
          {stripSeg(inr(counts.rev), "PER NIGHT", "text-[var(--fx-accent-ink)]")}
        </div>

        {/* tier bands + wall */}
        {loading ? (
          <div className="grid place-items-center py-16 text-[var(--fx-muted)]">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : (
          <>
            {levels.map((t) => {
              let occ = 0, mnt = 0;
              const list: Room[] = [];
              for (let n = t.from; n <= t.to; n++) {
                const r = roomMap.get(n);
                if (!r) continue;
                list.push(r);
                if (r.status === "occ") occ++;
                else if (r.status === "mnt") mnt++;
              }
              const shown = list.filter((r) => (filter === "avl" ? r.status === "avl" : filter === "occ" ? r.status === "occ" : true));
              return (
                <div key={t.name}>
                  <div className="mt-7 flex flex-wrap items-baseline gap-x-3 gap-y-1 first:mt-2.5">
                    <span className="text-[13px] font-extrabold tracking-[0.16em] text-[var(--fx-ink)]">{t.name}</span>
                    <span className="text-[10px] font-bold tracking-wide text-[var(--fx-muted)]">
                      {levelLabel(t)} · {inr(t.rate)} / 24 HRS
                    </span>
                    <span className="h-px min-w-[24px] flex-1 border-t border-[var(--fx-line)]" />
                    <span className="text-[10px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">
                      {t.to - t.from + 1 - occ - mnt} of {t.to - t.from + 1} FREE{mnt ? ` · ${mnt} MNT` : ""}
                    </span>
                  </div>
                  {/* t136 — the wall reads 20 rooms per horizontal line in BOTH
                      accounts, matching the owner's reference screenshot: full-size
                      square tiles again (a desktop tile lands ~56px — the footprint
                      of the tracker rows and the AI button — instead of the t129
                      1/4-size 40-up band). Numbers and guest names are readable at
                      arm's length again. NOTE: no md: tier — the t122 theme aliases
                      --breakpoint-md to 640px (= sm), so md: rules LOSE the
                      cascade tie against sm: on the same property. */}
                  <div className="mt-3 grid grid-cols-20 gap-[3px] sm:gap-[4px]">
                    {shown.map(cell)}
                  </div>
                </div>
              );
            })}
            <p className="mt-5 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              {isOwner
                ? `Stays bill to the hour — rate × hours ÷ 24, so 12 hours bills half the 24-hour rate — never below the ${inr(lodgeMin)} minimum, then 5% GST. Check-ins and check-outs happen at the lodge reception.`
                : `Stays bill to the hour — rate × hours ÷ 24, so 12 hours bills half the 24-hour rate — never below the ${inr(lodgeMin)} minimum, then 5% GST. Vacated rooms turn red for housekeeping — tap a red room once maintenance is done.`}
            </p>
          </>
        )}
      </div>

      {/* recent stay bills — the front desk's own feed, reprint + UNDO (counter) */}
      {!loading && !isOwner && (
        <div className="fx-card p-5 md:p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="fx-label flex items-center gap-2">
              <Receipt className="h-3.5 w-3.5" /> RECENT STAY BILLS · TAP TO REPRINT
            </div>
            <span className="mut-chip">{"LODGE BOOK · TAP UNDO TWICE TO TEAR ONE"}</span>
          </div>
          <ScrollFadeBox className="mt-3" maxH={352}>
            <BillsFeed
              rows={bills.map((b) => ({
                key: b.id,
                kind: "lodge" as const,
                bill: lodgeBillToBill(b),
                title: `L-${b.number} · ROOM ${b.room}`,
                sub: `${b.guestName} · ${b.tier} · ${fmtDur(b.hours)} STAY`,
                amt: inr2(b.total),
                at: istTime(b.createdAt),
              }))}
              onReprint={(b) => openReceipt(b, "reprint")}
              onUndo={(r) => void undoStay(r.bill.number)}
            />
          </ScrollFadeBox>
        </div>
      )}

      {/* t129 — the STATION EXPENSES entry block is gone from the desk: the
          lodge reception enters spends on the Expenses page (one block, three
          toggles) instead of here. */}

      {/* t194 — RoomLevelsEditor moved to Settings (with 10s warning lock). */}

      {/* t117 + t129 — stay bills: the owner reads the LAST 50 in a collapsible,
          strictly read-only block (no reprint, no undo) — now at the BOTTOM of
          the section (user: "shift lodge latest bill to the bottom"); the
          counter keeps its own feed with reprint + UNDO exactly as it has
          always been. */}
      {!loading && isOwner && (
        <div className="fx-card p-5 md:p-6" data-testid="lodge-latest-bills">
          <button
            onClick={() => setBillsOpen((o) => !o)}
            aria-expanded={billsOpen}
            data-testid="lodge-latest-bills-toggle"
            className="flex w-full flex-wrap items-center justify-between gap-2 text-left"
          >
            <span className="fx-label flex items-center gap-2">
              <Receipt className="h-3.5 w-3.5" /> LATEST LODGE BILLS
            </span>
            <span className="flex items-center gap-2">
              <span className="mut-chip">LAST {bills.length} · READ ONLY</span>
              <ChevronDown
                aria-hidden
                className={`h-4 w-4 text-[var(--fx-muted)] transition-transform ${billsOpen ? "" : "-rotate-90"}`}
              />
            </span>
          </button>
          {billsOpen && (
            <ScrollFadeBox className="mt-3" maxH={352}>
              <BillsFeed
                rows={bills.map((b) => ({
                  key: b.id,
                  kind: "lodge" as const,
                  bill: lodgeBillToBill(b),
                  title: `L-${b.number} · ROOM ${b.room}`,
                  sub: `${b.guestName} · ${b.tier} · ${fmtDur(b.hours)} STAY`,
                  amt: inr2(b.total),
                  at: istTime(b.createdAt),
                }))}
              />
            </ScrollFadeBox>
          )}
        </div>
      )}

      {/* ── dialogs ── */}
      {dlg?.kind === "checkin" && (
        <CheckinDialog
          preset={dlg.room}
          roomMap={roomMap}
          levels={levels}
          busy={busy}
          minStay={lodgeMin}
          onClose={() => setDlg(null)}
          onDone={done}
          op={op}
          fail={fail}
        />
      )}
      {dlg?.kind === "checkout" && (
        <CheckoutDialog
          roomData={roomMap.get(dlg.room)}
          levels={levels}
          busy={busy}
          discLimit={discLimit}
          minStay={lodgeMin}
          onClose={() => setDlg(null)}
          onDone={done}
          op={op}
          fail={fail}
          onBill={(b) => {
            openReceipt({
              id: b.id,
              number: b.number,
              numberLabel: `L-${b.number}`,
              subtotal: b.stay,
              discount: b.discount,
              tax: b.tax,
              total: b.total,
              itemCount: 1,
              createdAt: b.checkOutAt,
              items: [
                {
                  id: `${b.id}-stay`,
                  dishId: null,
                  name: `Room ${b.room} · ${fmtDur(b.hours)} stay`,
                  category: `${b.tier} · ${inr(b.rate)} / 24 H`,
                  qty: 1,
                  price: b.stay,
                },
              ],
              meta2: `${b.guestName} · ${b.guestPhone}`,
              meta3: `LODGE · ROOM ${b.room}`,
            });
          }}
        />
      )}
      {dlg?.kind === "mnt" && (
        <MaintDialog room={dlg.room} levels={levels} busy={busy} onClose={() => setDlg(null)} onDone={done} op={op} fail={fail} />
      )}
      {dlg?.kind === "info" && (
        <OwnerRoomDialog room={roomMap.get(dlg.room)} levels={levels} onClose={() => setDlg(null)} />
      )}
    </div>
  );
}

/* ── t116 · owner's read-only room card — status + resident details ─────
   Occupied shows WHO is in the room (name, phone, entry, duration);
   free / maintenance show the room's state without any resident block. */
function OwnerRoomDialog({
  room,
  levels,
  onClose,
}: {
  room?: Room;
  levels: Level[];
  onClose: () => void;
}) {
  if (!room) return null;
  const t = tierOfRoom(room.number, levels);
  const occ = room.status === "occ" && room.guestName;
  const hrs = occ && room.checkInAt ? (Date.now() - new Date(room.checkInAt).getTime()) / 3600000 : 0;
  const chip =
    room.status === "occ"
      ? { txt: "OCCUPIED", cls: "bg-[var(--fx-ink)] text-[var(--fx-gold-ondark)]" }
      : room.status === "mnt"
        ? { txt: "MAINTENANCE", cls: "bg-[color-mix(in_srgb,var(--fx-rose)_14%,transparent)] text-[var(--fx-rose)]" }
        : { txt: "FREE", cls: "bg-[color-mix(in_srgb,var(--fx-green)_14%,transparent)] text-[var(--fx-green)]" };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-[20px] sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 text-[16px] font-extrabold tracking-tight text-[var(--fx-ink)]">
            Room {room.number}
            <span className={`rounded-full px-2.5 py-1 text-[9.5px] font-extrabold tracking-[0.1em] ${chip.cls}`} data-testid="owner-room-status">
              {chip.txt}
            </span>
          </DialogTitle>
          <DialogDescription className="text-[12px] font-medium text-[var(--fx-muted)]">
            {t.name} tier · {inr(t.rate)} per 24 hours
          </DialogDescription>
        </DialogHeader>

        {occ ? (
          <div className="mt-1 space-y-2.5" data-testid="owner-room-resident">
            <span className="fx-label block">RESIDENT</span>
            <div className="rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3.5 py-3">
              <div className="flex items-center gap-2.5">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--fx-lav)] text-[12px] font-black text-[var(--fx-accent-ink)]">
                  {initials(room.guestName ?? "")}
                </span>
                <div className="min-w-0">
                  <div className="truncate text-[14px] font-extrabold text-[var(--fx-ink)]">{room.guestName}</div>
                  <div className="fx-num text-[11.5px] font-bold text-[var(--fx-muted)]">{room.guestPhone || "—"}</div>
                </div>
              </div>
              <div className="mt-2.5 flex flex-wrap gap-x-5 gap-y-1 border-t border-dashed border-[var(--fx-line)] pt-2.5 text-[11px] font-bold text-[var(--fx-muted)]">
                <span>
                  CHECKED IN · <b className="text-[var(--fx-ink)]">{room.checkInAt ? istDateTime(new Date(room.checkInAt)) : "—"}</b>
                </span>
                <span>
                  IN FOR · <b className="text-[var(--fx-ink)]">{fmtDur(hrs)}</b>
                </span>
              </div>
            </div>
          </div>
        ) : (
          <p className="mt-1 rounded-xl border border-dashed border-[var(--fx-line)] bg-[var(--fx-page)] px-3.5 py-3 text-[12px] font-semibold text-[var(--fx-muted)]" data-testid="owner-room-no-resident">
            {room.status === "mnt"
              ? "Vacated and waiting for housekeeping — no resident right now."
              : "No resident — the room is free for the reception to check a guest in."}
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ── check-in — green → gold ──────────────────────────────────────────────── */
function CheckinDialog({
  preset,
  roomMap,
  levels,
  busy,
  minStay,
  onClose,
  onDone,
  op,
  fail,
}: {
  preset: number | null;
  roomMap: Map<number, Room>;
  levels: Level[];
  busy: boolean;
  /** the owner's minimum-stay floor ₹ from Settings (shown on the room hint) */
  minStay: number;
  onClose: () => void;
  onDone: () => void;
  op: (b: Record<string, unknown>) => Promise<{ ok: boolean; error?: string }>;
  fail: (e?: string) => void;
}) {
  const free = React.useMemo(() => levels.map((t) => ({
    t,
    rooms: Array.from({ length: t.to - t.from + 1 }, (_, i) => t.from + i).filter((n) => roomMap.get(n)?.status === "avl"),
  })), [roomMap, levels]);
  const { toast } = useToast();
  const [room, setRoom] = React.useState<number>(preset ?? free.find((g) => g.rooms.length)?.rooms[0] ?? 0);
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [entry, setEntry] = React.useState(() => new Date());

  const tier = tierOfRoom(room, levels);
  const submit = async () => {
    const r = await op({ action: "checkin", room, name, phone: phone.replace(/\D/g, "").slice(0, 10), checkInAt: entry.toISOString() });
    if (!r.ok) return fail(r.error);
    toast({ title: `Room ${room} checked in`, description: `${name} · ${tier.name} tier · from ${istTime(entry)}` });
    onDone();
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-[20px] sm:max-w-[440px]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight text-[var(--fx-ink)]">
            {preset == null ? "New guest · check in" : `Room ${preset} · check in`}
          </DialogTitle>
          <DialogDescription className="text-[12px] font-medium text-[var(--fx-muted)]">
            {preset == null
              ? "Pick any green room — the tier sets the rate."
              : `${tier.name} tier · ${inr(tier.rate)} per 24 hours · entry starts the clock.`}
          </DialogDescription>
        </DialogHeader>

        {preset == null && (
          <div className="mt-1">
            <label className="fx-label mb-1.5 block" htmlFor="lg-room">ROOM</label>
            <select
              id="lg-room"
              value={room}
              onChange={(e) => setRoom(Number(e.target.value))}
              className="h-10 w-full rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 pr-8 text-[13px] font-bold text-[var(--fx-ink)]"
            >
              {free.filter((g) => g.rooms.length).map((g) => (
                <optgroup key={g.t.name} label={`${g.t.name} · ${levelLabel(g.t)} · ${inr(g.t.rate)} / 24 H`}>
                  {g.rooms.map((n) => (
                    <option key={n} value={n}>Room {n}</option>
                  ))}
                </optgroup>
              ))}
            </select>
            <p className="mt-1.5 text-[10.5px] font-semibold text-[var(--fx-muted)]">
              Room <b className="text-[var(--fx-ink)]">{room}</b> · <b className="text-[var(--fx-ink)]">{tier.name}</b> —{" "}
              {inr(tier.rate)} / 24 h · billed to the hour, minimum {inr(minStay)}.
            </p>
          </div>
        )}

        <div className="mt-1 grid grid-cols-2 gap-3">
          <div>
            <label className="fx-label mb-1.5 block" htmlFor="lg-name">NAME</label>
            <Input id="lg-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="off" placeholder="Guest full name" className="h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-semibold" />
          </div>
          <div>
            <label className="fx-label mb-1.5 block" htmlFor="lg-phone">PHONE</label>
            <Input
              id="lg-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
              inputMode="numeric"
              autoComplete="off"
              maxLength={10}
              placeholder="10-digit mobile"
              aria-label="Guest phone — digits only, 10 numbers"
              data-testid="lg-phone-input"
              className="fx-num h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
            {phone.length > 0 && phone.length < 10 && (
              <span className="fx-num mt-1 block text-[9.5px] font-extrabold tracking-wider text-[var(--fx-amber)]">
                {10 - phone.length} MORE {10 - phone.length === 1 ? "DIGIT" : "DIGITS"} — NUMBERS ONLY
              </span>
            )}
          </div>
        </div>

        <div className="mt-1">
          <span className="fx-label mb-1.5 block">ENTRY TIME</span>
          <LgTimeField value={entry} onChange={setEntry} label="Entry time" />
        </div>

        <Button
          onClick={() => void submit()}
          disabled={busy}
          className="mt-2 h-11 w-full rounded-xl bg-[var(--fx-purple)] text-[12.5px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Check className="mr-1.5 h-4 w-4" />}
          CHECK IN{preset == null ? "" : ` · ROOM ${preset}`}
        </Button>
      </DialogContent>
    </Dialog>
  );
}

/* ── check-out — gold → red (maintenance), bill generated ─────────────── */
function CheckoutDialog({
  roomData,
  levels,
  busy,
  discLimit,
  minStay,
  onClose,
  onDone,
  op,
  fail,
  onBill,
}: {
  roomData?: Room;
  levels: Level[];
  busy: boolean;
  /** t143 — the owner's discount limit % from Settings */
  discLimit: number;
  /** the owner's minimum-stay floor ₹ from Settings (0 = no floor) */
  minStay: number;
  onClose: () => void;
  onDone: () => void;
  op: (b: Record<string, unknown>) => Promise<{ ok: boolean; bill?: LodgeBill; error?: string }>;
  fail: (e?: string) => void;
  onBill: (b: LodgeBill) => void;
}) {
  const r = roomData;
  const { toast } = useToast();
  const [exit, setExit] = React.useState(() => new Date());
  const [disc, setDisc] = React.useState("");
  /* two-tap arm, same language as the feed's UNDO — no accidental wipes */
  const [delArm, setDelArm] = React.useState(false);

  const calc = React.useMemo(() => {
    if (!r?.checkInAt) return null;
    const entry = new Date(r.checkInAt);
    const hours = (exit.getTime() - entry.getTime()) / 3600000;
    if (!(hours > 0)) return { hours: 0, bad: true } as const;
    const t = tierOfRoom(r.number, levels);
    const s = lgStay(t.rate, hours, minStay);
    /* t143 — never above the owner's discount limit % of the stay charge */
    const d = Math.min(
      Math.max(0, Math.round(Number(disc) || 0)),
      s.stay,
      Math.floor(s.stay * discLimit) / 100,
    );
    const taxable = s.stay - d;
    const tax = Math.round(taxable * 5) / 100;
    const total = Math.round((taxable + tax) * 100) / 100;
    return { hours, bad: false as const, t, s, d, tax, total };
  }, [r, exit, disc, levels, discLimit, minStay]);

  const submit = async () => {
    if (!r) return;
    if (!calc || calc.bad || !calc.total) return fail("Exit time is before entry — it must be after the guest's entry time");
    const res = await op({ action: "checkout", room: r.number, checkOutAt: exit.toISOString(), discount: calc.d });
    if (!res.ok || !res.bill) return fail(res.error);
    toast({
      title: `Room ${r.number} billed`,
      description: `${inr2(res.bill.total)} · ${res.bill.guestName} · ${fmtDur(calc.hours)} · room now under maintenance.`,
    });
    onBill(res.bill);
    onDone();
  };

  /* a mistaken check-in leaves with no bill at all — room straight to green */
  const delCheckin = async () => {
    if (!r) return;
    const res = await op({ action: "delete-checkin", room: r.number });
    if (!res.ok) return fail(res.error);
    toast({
      title: `Check-in deleted · Room ${r.number}`,
      description: `${r.guestName} removed without a bill — the room is free again.`,
    });
    onDone();
  };

  if (!r || !r.guestName) return null;
  const t = tierOfRoom(r.number, levels);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-[20px] sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight text-[var(--fx-ink)]">
            Room {r.number} · check out
          </DialogTitle>
          <DialogDescription className="text-[12px] font-medium text-[var(--fx-muted)]">
            {t.name} tier · billed to the hour — {inr(t.rate)} × hours ÷ 24, minimum {inr(minStay)} — then 5% GST.
          </DialogDescription>
        </DialogHeader>

        {/* guest card */}
        <div className="flex items-center gap-3 rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-4 py-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[var(--fx-lav)] text-[13px] font-black text-[var(--fx-accent-ink)]">
            {initials(r.guestName)}
          </span>
          <div className="min-w-0 flex-1">
            <b className="block truncate text-[13.5px] font-extrabold text-[var(--fx-ink)]">{r.guestName}</b>
            <span className="fx-num text-[11.5px] font-semibold text-[var(--fx-muted)]">
              {r.guestPhone} · in {r.checkInAt ? istDateTime(r.checkInAt) : "—"}
            </span>
          </div>
          <div className="shrink-0 text-right">
            <div className="fx-label">STAYED</div>
            <b className="fx-num text-[12.5px] font-extrabold text-[var(--fx-ink)]">
              {calc && !calc.bad ? fmtDur(calc.hours) : "—"}
            </b>
          </div>
        </div>

        <div className="mt-1 grid grid-cols-2 gap-3">
          <div>
            <span className="fx-label mb-1.5 block">EXIT TIME</span>
            <LgTimeField value={exit} onChange={setExit} label="Exit time" />
          </div>
          <div>
            <label className="fx-label mb-1.5 block" htmlFor="lg-disc">DISCOUNT ₹</label>
            <Input
              id="lg-disc"
              value={disc}
              onChange={(e) => {
                const raw = e.target.value;
                const next = Math.max(0, Number(raw) || 0);
                const cap =
                  calc && !calc.bad ? Math.floor(calc.s.stay * discLimit) / 100 : Infinity;
                if (next > cap) {
                  /* t143 — the owner's rule bites right at the keystroke */
                  setDisc(String(cap));
                  toast({
                    title: "Discount capped by the owner's limit",
                    description: `The front desk can discount at most ${discLimit}% of the stay — ${inr2(cap)} on this bill.`,
                  });
                } else {
                  setDisc(raw);
                }
              }}
              type="number"
              min={0}
              placeholder="0"
              className="fx-num h-10 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] font-bold"
            />
            {calc && !calc.bad && discLimit < 100 && (
              <span className="fx-num mt-1 block text-[9.5px] font-extrabold tracking-wider text-[var(--fx-muted)]">
                MAX {inr2(Math.floor(calc.s.stay * discLimit) / 100)} · {discLimit}% CAP
              </span>
            )}
          </div>
        </div>

        {/* live bill preview */}
        <div className="mt-2 space-y-0.5 rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-4 py-3 text-[12px] font-semibold">
          {!calc || calc.bad ? (
            <div className="py-1 text-[var(--fx-rose)]">
              EXIT BEFORE ENTRY — exit must be after {r.checkInAt ? istDateTime(r.checkInAt) : "entry"}
            </div>
          ) : (
            <>
              <div className="flex justify-between text-[var(--fx-ink)]">
                <span>
                  STAY CHARGE<small className="text-[var(--fx-muted)]">&nbsp; {inr(t.rate)} × {fmtHrs(calc.hours)} ÷ 24</small>
                </span>
                <span className="fx-num font-extrabold">{inr(calc.s.stay)}</span>
              </div>
              {calc.s.min && (
                <div className="flex justify-between text-[var(--fx-amber)]">
                  <span>
                    MINIMUM STAY CHARGE<small>&nbsp; {inr(calc.s.raw)} is below the floor</small>
                  </span>
                  <span className="fx-num font-extrabold">{inr(calc.s.stay)}</span>
                </div>
              )}
              {calc.d > 0 && (
                <div className="flex justify-between text-[var(--fx-ink)]">
                  <span>DISCOUNT</span>
                  <span className="fx-num font-extrabold">− {inr(calc.d)}</span>
                </div>
              )}
              <div className="flex justify-between text-[var(--fx-ink)]">
                <span>
                  GST 5%<small className="text-[var(--fx-muted)]">&nbsp; CGST 2.5% + SGST 2.5%</small>
                </span>
                <span className="fx-num font-extrabold">{inr2(calc.tax)}</span>
              </div>
              <div className="mt-1.5 flex justify-between border-t border-dashed border-[var(--fx-line)] pt-2 text-[13px] font-extrabold text-[var(--fx-ink)]">
                <span className="fx-label">GUEST PAYS</span>
                <b className="fx-num">{inr2(calc.total)}</b>
              </div>
            </>
          )}
        </div>

        <Button
          onClick={() => void submit()}
          disabled={busy}
          className="mt-1 h-11 w-full rounded-xl bg-[var(--fx-purple)] text-[12.5px] font-extrabold tracking-wide text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] hover:bg-[var(--fx-purple-deep)]"
        >
          {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Receipt className="mr-1.5 h-4 w-4" />}
          GENERATE BILL
        </Button>

        {/* undo a mistaken check-in — no bill, room straight back to green;
            two taps to arm so a slip can't wipe a real guest */}
        <Button
          variant="outline"
          disabled={busy}
          aria-label={`Delete check-in room ${r.number}`}
          onClick={() => {
            if (!delArm) {
              setDelArm(true);
              setTimeout(() => setDelArm(false), 3000);
              return;
            }
            void delCheckin();
          }}
          className={`mt-2 h-10 w-full rounded-xl border text-[11.5px] font-extrabold tracking-[0.1em] transition-colors ${
            delArm
              ? "border-transparent bg-[color-mix(in_srgb,var(--fx-rose)_22%,transparent)] text-[var(--fx-rose)] hover:bg-[color-mix(in_srgb,var(--fx-rose)_30%,transparent)]"
              : "border-[color-mix(in_srgb,var(--fx-rose)_32%,transparent)] bg-[color-mix(in_srgb,var(--fx-rose)_6%,transparent)] text-[var(--fx-rose)] hover:bg-[color-mix(in_srgb,var(--fx-rose)_14%,transparent)]"
          }`}
        >
          {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Trash2 className="mr-1.5 h-4 w-4" />}
          {delArm ? "SURE? DELETE THIS CHECK-IN" : "DELETE CHECK-IN"}
        </Button>
      </DialogContent>
    </Dialog>
  );
}

/* ── maintenance done? — red → green (yes) / stays red (no) ───────────── */
function MaintDialog({
  room,
  levels,
  busy,
  onClose,
  onDone,
  op,
  fail,
}: {
  room: number;
  levels: Level[];
  busy: boolean;
  onClose: () => void;
  onDone: () => void;
  op: (b: Record<string, unknown>) => Promise<{ ok: boolean; error?: string }>;
  fail: (e?: string) => void;
}) {
  const { toast } = useToast();
  const t = tierOfRoom(room, levels);
  const yes = async () => {
    const r = await op({ action: "maintenance-done", room });
    if (!r.ok) return fail(r.error);
    toast({ title: `Room ${room} is free again`, description: `${t.name} tier · ${inr(t.rate)} / 24 hours · ready for check-in.` });
    onDone();
  };
  const no = () => {
    toast({
      title: `Room ${room} stays red`,
      description: "Under maintenance — tap it again when housekeeping is done.",
    });
    onClose();
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="rounded-[20px] sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="text-[16px] font-extrabold tracking-tight text-[var(--fx-ink)]">
            Room {room} · maintenance
          </DialogTitle>
          <DialogDescription className="text-[12px] font-medium text-[var(--fx-muted)]">
            {t.name} tier · vacated and waiting for housekeeping.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 rounded-2xl border border-dashed border-[color-mix(in_srgb,var(--fx-rose)_42%,transparent)] bg-[color-mix(in_srgb,var(--fx-rose)_7%,transparent)] px-4 py-3.5">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[13px] bg-[color-mix(in_srgb,var(--fx-rose)_15%,transparent)] text-[var(--fx-rose)]">
            <Wrench className="h-[18px] w-[18px]" />
          </span>
          <p className="text-[12.5px] font-semibold leading-relaxed text-[var(--fx-ink)]">
            <b className="font-extrabold">Maintenance done?</b>
            <br />
            Yes turns the room green and ready for the next guest — no keeps it red.
          </p>
        </div>

        <div className="mt-1 grid grid-cols-2 gap-2.5">
          <Button
            variant="outline"
            disabled={busy}
            onClick={no}
            className="h-11 rounded-xl border-[var(--fx-line)] bg-[var(--fx-page)] text-[11.5px] font-extrabold tracking-[0.1em] text-[var(--fx-muted)] hover:bg-[color-mix(in_srgb,var(--fx-rose)_6%,transparent)] hover:text-[var(--fx-rose)]"
          >
            <X className="mr-1.5 h-4 w-4" /> NO, NOT YET
          </Button>
          <Button
            disabled={busy}
            onClick={() => void yes()}
            className="h-11 rounded-xl border border-[color-mix(in_srgb,var(--fx-green)_35%,transparent)] bg-[color-mix(in_srgb,var(--fx-green)_10%,transparent)] text-[11.5px] font-extrabold tracking-[0.1em] text-[var(--fx-green)] hover:bg-[color-mix(in_srgb,var(--fx-green)_18%,transparent)]"
          >
            {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Check className="mr-1.5 h-4 w-4" />}
            YES, DONE
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
