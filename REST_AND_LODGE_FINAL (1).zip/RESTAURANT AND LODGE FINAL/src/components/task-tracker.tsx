"use client";

// ── t118 · FLOATING TASK TRACKER — back by user request ─────────────────────
// "previously we had a task tracker that was floating and could be
//  enabled/disabled using settings I want that in all three accounts"
// t124 — CONTRACTED: a 56×56 icon launcher on the right (stacked above the
//   owner's AI FAB; each reception takes the AI corner itself), the open-work
//   count as an Android-style badge on the top-right corner, and a TODAY ·
//   3 · 7 · 15 window toggle inside the panel (remembered per browser).
// t129 — the window toggles are DEADLINE-DATE filters (user: "in today toggle
//   the tasks that end today should show up and same goes for rest toggles"):
//   · the due list shows open tasks whose deadline DATE (IST) falls inside
//     [today … today+N−1] — TODAY shows only what ends today;
//   · open tasks whose deadline already passed get their own clearly-labelled
//     "LATE · STILL OPEN" section under the due rows, so they stay visible
//     without flooding the window;
//   · the badge counts due + late (work that needs attention).
// t129 — rows EXPAND (chevron) into the task's details: description, the
//   update trail and the budget. The full board stays where it always was
//   (the Tasks section); SETTINGS carries the on/off switch (localStorage
//   "fx-task-fab", default ON).

import * as React from "react";
import { CalendarClock, ChevronDown, ListChecks, X } from "lucide-react";
import type { FxTask } from "@/lib/types";

export const TASK_FAB_KEY = "fx-task-fab"; // "0" = hidden, absent/"1" = shown
export const TASK_FAB_EVENT = "fx-task-fab-change";

/* t124/t167 — the deadline windows the badge + panel count down to.
   t167 — added "late" as a SEPARATE toggle: when active, shows ONLY overdue
   tasks. Late tasks no longer flood the today/3d/7d/15d windows — the badge
   and the panel list only show the current window's tasks. */
export type TaskWindowId = "today" | "3d" | "7d" | "15d" | "late";
export const TASK_WINDOWS: Array<{ id: TaskWindowId; label: string; days: number }> = [
  { id: "today", label: "TODAY", days: 1 },
  { id: "3d", label: "3 DAYS", days: 3 },
  { id: "7d", label: "7 DAYS", days: 7 },
  { id: "15d", label: "15 DAYS", days: 15 },
  { id: "late", label: "LATE", days: 0 },
];
const WINDOW_KEY = "fx-task-window";
const MODE_KEY = "fx-task-mode"; // t195 — "expire" (default) | "given"
const LATE_CAP = 8;

function readWindow(): TaskWindowId {
  try {
    const raw = localStorage.getItem(WINDOW_KEY) as TaskWindowId | null;
    return raw && TASK_WINDOWS.some((w) => w.id === raw) ? raw : "today";
  } catch {
    return "today";
  }
}

/* t195 — EXPIRE vs GIVEN — what the window counts. EXPIRE (default) = the
   deadline windows (tasks ending inside the unit). GIVEN = tasks the owner
   FORWARDED inside the unit (createdAt, past-looking, today included).
   LATE stays deadline-based in both modes — overdue is overdue. */
type TrackerMode = "expire" | "given";
function readMode(): TrackerMode {
  try {
    return localStorage.getItem(MODE_KEY) === "given" ? "given" : "expire";
  } catch {
    return "expire";
  }
}

/** t129 — IST calendar day (YYYY-MM-DD) of an instant. Deadlines are compared
    as DATES: "ends today" means the deadline's IST day == today's IST day. */
function istDayKey(iso: string): string {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Kolkata" }).format(new Date(iso));
}
function todayKey(): string {
  return istDayKey(new Date().toISOString());
}
function addDays(key: string, n: number): string {
  const [y, m, d] = key.split("-").map(Number);
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Kolkata" }).format(
    new Date(y, m - 1, d + n),
  );
}

/** Shared by the tracker (instant hide/show) and the settings switch. */
export function useTaskFabEnabled(): boolean {
  const [enabled, setEnabled] = React.useState(true);
  React.useEffect(() => {
    const read = () => setEnabled(localStorage.getItem(TASK_FAB_KEY) !== "0");
    read();
    window.addEventListener(TASK_FAB_EVENT, read);
    return () => window.removeEventListener(TASK_FAB_EVENT, read);
  }, []);
  return enabled;
}

const istDue = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
const istStamp = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });

const KIND_CHIP: Record<NonNullable<FxTask["kind"]>, { label: string; cls: string }> = {
  raw_material: { label: "RAW MATERIAL", cls: "bg-[#0d9488]/12 text-[#0d9488]" },
  upgrade: { label: "UPGRADE", cls: "bg-[#7c3aed]/12 text-[#7c3aed]" },
  maintenance: { label: "MAINTENANCE", cls: "bg-[color-mix(in_srgb,var(--fx-amber)_14%,transparent)] text-[var(--fx-amber)]" },
};

/* t129 — one tracker row; the chevron expands the details (description,
   update trail, budget). t129 expansion is plain state — no fx-rise. */
function TrackerRow({ t, expanded, onToggle }: { t: FxTask; expanded: boolean; onToggle: () => void }) {
  const late = istDayKey(t.deadline) < todayKey();
  return (
    <div
      data-testid="task-tracker-row"
      data-status={t.status}
      className="rounded-xl border border-[var(--fx-line)] bg-[var(--fx-page)] px-3 py-2.5"
    >
      <button type="button" onClick={onToggle} aria-expanded={expanded} className="flex w-full items-start gap-2 text-left">
        <span
          aria-hidden
          className={`mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${
            t.status === "done" ? "bg-[var(--fx-muted)]/40" : late ? "bg-[var(--fx-rose)]" : "bg-[var(--fx-green)] fx-live-dot"
          }`}
        />
        <span className="min-w-0 flex-1">
          <span className={`block truncate text-[12.5px] font-bold text-[var(--fx-ink)] ${t.status === "done" ? "line-through opacity-60" : ""}`}>
            {t.title}
          </span>
          <span className="mt-1 flex flex-wrap items-center gap-1.5 text-[9.5px] font-extrabold tracking-[0.07em] text-[var(--fx-muted)]">
            <span
              className={`rounded-full px-2 py-0.5 ${
                t.book === "lodge"
                  ? "bg-[color-mix(in_srgb,var(--fx-gold)_14%,transparent)] text-[var(--fx-gold)]"
                  : "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
              }`}
            >
              {t.book === "lodge" ? "LODGE" : "RESTAURANT"}
            </span>
            {t.kind && <span className={`rounded-full px-2 py-0.5 ${KIND_CHIP[t.kind].cls}`}>{KIND_CHIP[t.kind].label}</span>}
            <span className="inline-flex items-center gap-1">
              <CalendarClock className="h-3 w-3" />
              {t.status === "done" ? `DONE · ${t.doneAt ? istDue(t.doneAt) : "—"}` : `${late ? "LATE" : "DUE"} · ${istDue(t.deadline)}`}
            </span>
            {t.maxBudget !== null && <span className="text-[var(--fx-ink)]">MAX {`₹${t.maxBudget.toLocaleString("en-IN")}`}</span>}
          </span>
        </span>
        <ChevronDown
          aria-hidden
          className={`mt-0.5 h-4 w-4 shrink-0 text-[var(--fx-muted)] transition-transform ${expanded ? "rotate-180" : ""}`}
        />
      </button>

      {/* expanded details — description + the update trail */}
      {expanded && (
        <div className="mt-2.5 space-y-2 border-t border-dashed border-[var(--fx-line)] pt-2.5" data-testid="task-tracker-row-details">
          {t.description && (
            <p className="text-[11px] font-semibold leading-relaxed text-[var(--fx-ink)]">{t.description}</p>
          )}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] font-extrabold tracking-[0.08em] text-[var(--fx-muted)]">
            <span>{t.updates.length} UPDATES</span>
            <span>
              STATUS · <b className={t.status === "open" ? "text-[var(--fx-rose)]" : "text-[var(--fx-green)]"}>{t.status.toUpperCase()}</b>
            </span>
          </div>
          {t.updates.length > 0 && (
            <div className="fx-scroll max-h-[120px] space-y-1.5 overflow-y-auto pr-1">
              {[...t.updates].reverse().map((u) => (
                <div key={u.id} className="rounded-lg bg-[var(--fx-surf)] px-2.5 py-1.5">
                  <b className="text-[10px] font-black text-[var(--fx-ink)]">{u.author}</b>
                  {u.role === "owner" && (
                    <span
                      className="ml-1.5 rounded-full px-1.5 py-px text-[7.5px] font-black tracking-[0.08em] text-[var(--fx-gold)]"
                      style={{ background: "color-mix(in srgb, var(--fx-gold) 14%, transparent)" }}
                    >
                      OWNER
                    </span>
                  )}{" "}
                  <em className="text-[8.5px] font-bold not-italic tracking-[0.06em] text-[var(--fx-muted)]">{istStamp(u.createdAt)}</em>
                  <p className="mt-0.5 text-[10px] font-semibold leading-snug text-[var(--fx-muted)]">{u.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function TaskTracker({
  role,
  onOpenBoard,
}: {
  role: string;
  onOpenBoard: () => void;
}) {
  const enabled = useTaskFabEnabled();
  const [open, setOpen] = React.useState(false);
  const [tasks, setTasks] = React.useState<FxTask[]>([]);
  const [win, setWin] = React.useState<TaskWindowId>("today");
  const [mode, setMode] = React.useState<TrackerMode>("expire");
  const [expandedIds, setExpandedIds] = React.useState<Set<string>>(new Set());
  // t166 — hide the task FAB while the AI panel is open (avoids overlap).
  // The AI panel dispatches 'fx-ai-panel-toggle' with detail=true/false.
  const [aiPanelOpen, setAiPanelOpen] = React.useState(false);
  React.useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<boolean>).detail;
      setAiPanelOpen(detail === true);
    };
    window.addEventListener("fx-ai-panel-toggle", handler);
    return () => window.removeEventListener("fx-ai-panel-toggle", handler);
  }, []);

  /* role → book: the owner watches both books, each reception its own */
  const book = role === "reception_restaurant" ? "rest" : role === "reception_lodge" ? "lodge" : null;

  /* AI is owner-only and owns the bottom-right corner — the tracker stacks
     right above it there; each reception takes the corner to itself */
  const stacked = role === "owner";

  /* t124 — restore the remembered deadline window (default TODAY) + mode */
  React.useEffect(() => {
    setWin(readWindow());
    setMode(readMode());
  }, []);

  React.useEffect(() => {
    if (!enabled) return;
    let alive = true;
    const load = () =>
      fetch(`/api/tasks${book ? `?book=${book}` : ""}`, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : { tasks: [] }))
        .then((d) => {
          if (alive) setTasks(Array.isArray(d?.tasks) ? d.tasks : []);
        })
        .catch(() => undefined);
    void load();
    const t = setInterval(load, 60000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [enabled, book]);

  if (!enabled) return null;

  /* t129/t167 — deadline-DATE windows (IST). due = ends inside the window.
     t167 — late tasks are SEPARATED: when the toggle is on a time window
     (today/3d/7d/15d), only `due` tasks are shown (no late section).
     When the toggle is on "late", only overdue tasks are shown.
     The badge counts ONLY the current window's tasks. */
  const w = TASK_WINDOWS.find((x) => x.id === win) ?? TASK_WINDOWS[0];
  const t0 = todayKey();
  const byDeadline = (a: FxTask, b: FxTask) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
  const openTasks = tasks.filter((t) => t.status === "open");

  // Late tasks = deadline day is BEFORE today (overdue, still open)
  const late = openTasks.filter((t) => istDayKey(t.deadline) < t0).sort(byDeadline);

  // Due tasks = what the selected window + mode count (not late)
  let due: FxTask[] = [];
  if (w.id === "late") {
    // "late" toggle: show only overdue tasks
    due = [];
  } else if (mode === "given") {
    // t195 — GIVEN mode: tasks FORWARDED inside the unit — createdAt IST day
    // in [today−(N−1) … today], newest-given first.
    const firstKey = addDays(t0, -(w.days - 1));
    due = openTasks
      .filter((t) => {
        const k = istDayKey(t.createdAt);
        return k >= firstKey && k <= t0;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } else {
    const lastKey = addDays(t0, w.days - 1);
    due = openTasks
      .filter((t) => {
        const k = istDayKey(t.deadline);
        return k >= t0 && k <= lastKey;
      })
      .sort(byDeadline);
  }

  // The list to show in the panel: due tasks (for time windows) OR late tasks (for "late" toggle)
  const showList = w.id === "late" ? late : due;
  const showCount = w.id === "late" ? late.length : due.length;

  // Badge count: ONLY the current window's count (no more late flooding)
  const badgeCount = showCount;
  const lateShown = late.slice(0, LATE_CAP);
  const beyond = openTasks.length - due.length - late.length;

  const toggleRow = (id: string) =>
    setExpandedIds((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const pickWindow = (id: TaskWindowId) => {
    setWin(id);
    try {
      localStorage.setItem(WINDOW_KEY, id);
    } catch {
      /* private mode */
    }
  };

  /* t195 — remember the window mode per browser, same contract as pickWindow */
  const pickMode = (m: TrackerMode) => {
    setMode(m);
    try {
      localStorage.setItem(MODE_KEY, m);
    } catch {
      /* private mode */
    }
  };

  /* t163/t165 — the owner's launcher sits ABOVE the AI FAB/orb with a
     narrow 12px gap between them (was touching at 80px). Dragged UP by
     12px: desktop 80px→92px, mobile 142px→154px. The gap gives visual
     breathing room between the task tracker (above) and the AI orb/FAB
     (below). */
  const fabPos = stacked
    ? "bottom-[calc(154px+env(safe-area-inset-bottom))] md:bottom-[92px]"
    : "bottom-[calc(84px+env(safe-area-inset-bottom))] md:bottom-6";
  const panelPos = stacked
    ? "bottom-[calc(222px+env(safe-area-inset-bottom))] md:bottom-[160px]"
    : "bottom-[calc(152px+env(safe-area-inset-bottom))] md:bottom-[92px]";

  return (
    <>
      {/* ── launcher — contracted 56×56 icon, RIGHT side, Android-style badge ──
          t166 — hidden while the AI panel is open (listens for the
          fx-ai-panel-toggle event) so the two don't overlap. */}
      {!open && !aiPanelOpen && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open the floating task tracker"
          data-testid="task-fab"
          className={`fixed right-4 z-40 grid h-14 w-14 place-items-center rounded-2xl bg-[var(--fx-ink)] text-[var(--fx-page)] shadow-[3px_4px_0_0_var(--fx-hard)] transition hover:opacity-90 md:right-6 ${fabPos}`}
        >
          <ListChecks className="h-6 w-6" />
          {badgeCount > 0 && (
            <span
              data-testid="task-fab-count"
              className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-[var(--fx-rose)] px-1 text-[10px] font-black text-white shadow-[1px_2px_0_0_rgba(0,0,0,.28)]"
            >
              {badgeCount > 99 ? "99+" : badgeCount}
            </span>
          )}
        </button>
      )}

      {/* ── the floating tracker card — opens above the launcher, right side ── */}
      {open && (
        <aside
          data-testid="task-tracker-panel"
          aria-label="Floating task tracker"
          className={`fixed right-4 z-50 flex max-h-[68vh] w-[min(400px,calc(100vw-2rem))] flex-col rounded-2xl border border-[var(--fx-line)] bg-[var(--fx-surf)] shadow-[3px_4px_0_0_var(--fx-hard)] md:right-6 ${panelPos}`}
        >
          {/* header */}
          <div className="flex items-center gap-3 border-b border-dashed border-[var(--fx-line)] px-4 py-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[var(--fx-ink)] text-[var(--fx-page)] shadow-[2px_3px_0_0_var(--fx-hard)]">
              <ListChecks className="h-4.5 w-4.5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-extrabold tracking-tight text-[var(--fx-ink)]">TASK TRACKER</div>
              <div className="fx-label" data-testid="task-tracker-sub">
                {showCount} {w.id === "late" ? "LATE" : mode === "given" ? "GIVEN" : "DUE"} · {w.label} ·{" "}
                {book ? (book === "lodge" ? "LODGE" : "RESTAURANT") : "BOTH BOOKS"}
              </div>
            </div>
            {/* t195 — EXPIRE / GIVEN mini-toggle — lives in the header so the
                window row below keeps its five chips un-crowded. */}
            <div
              className="inline-flex shrink-0 gap-0.5 rounded-full border border-[var(--fx-line)] bg-[var(--fx-page)] p-0.5"
              role="tablist"
              aria-label="Tracker mode — expiry or given"
              data-testid="task-tracker-mode"
            >
              {([
                ["expire", "EXPIRE"],
                ["given", "GIVEN"],
              ] as const).map(([m, label]) => (
                <button
                  key={m}
                  role="tab"
                  aria-selected={mode === m}
                  onClick={() => pickMode(m)}
                  data-testid={`task-tracker-mode-${m}`}
                  title={m === "expire" ? "List tasks ENDING inside the window (deadline)" : "List tasks GIVEN inside the window (forwarded date)"}
                  className={`rounded-full px-2 py-1 text-[8.5px] font-extrabold tracking-[0.07em] transition ${
                    mode === m
                      ? "bg-[var(--fx-ink)] text-[var(--fx-page)]"
                      : "text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <button
              data-tip="Collapse tracker"
              aria-label="Collapse the floating task tracker"
              onClick={() => setOpen(false)}
              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* t124 — the deadline window toggle: TODAY · 3 · 7 · 15 */}
          <div data-testid="task-window-toggle" className="flex items-center gap-1.5 border-b border-dashed border-[var(--fx-line)] px-3 py-2.5">
            {TASK_WINDOWS.map((x) => (
              <button
                key={x.id}
                data-testid={`task-window-${x.id}`}
                onClick={() => pickWindow(x.id)}
                aria-pressed={win === x.id}
                className={`flex-1 rounded-full px-1 py-1.5 text-[9px] font-extrabold tracking-[0.06em] transition ${
                  win === x.id
                    ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
                    : "border border-[var(--fx-line)] bg-[var(--fx-page)] text-[var(--fx-muted)] hover:text-[var(--fx-ink)]"
                }`}
              >
                {x.label}
              </button>
            ))}
          </div>

          {/* t167 — rows: show ONLY the current toggle's tasks.
              Time windows (today/3d/7d/15d) show due tasks only (no late).
              "LATE" toggle shows only overdue tasks. No more mixing. */}
          <div className="fx-scroll min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
            {showCount === 0 && (
              <p className="px-2 pt-4 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                {w.id === "late"
                  ? "No overdue tasks — everything is on time."
                  : mode === "given"
                    ? w.id === "today"
                      ? "No tasks were given today."
                      : `No tasks were given in the last ${w.days} days.`
                    : w.id === "today"
                      ? "No work ends today."
                      : `No work ends within the next ${w.days} days.`}
              </p>
            )}
            {showList.map((t) => (
              <TrackerRow key={t.id} t={t} expanded={expandedIds.has(t.id)} onToggle={() => toggleRow(t.id)} />
            ))}
          </div>

          {/* footer — into the full board */}
          <div className="border-t border-dashed border-[var(--fx-line)] p-3">
            <button
              onClick={() => {
                setOpen(false);
                onOpenBoard();
              }}
              data-testid="task-tracker-open-board"
              className="w-full rounded-xl bg-[var(--fx-purple)] py-2.5 text-[11px] font-extrabold tracking-[0.1em] text-[var(--fx-on-accent)] shadow-[2px_3px_0_0_var(--fx-hard)] transition hover:bg-[var(--fx-purple-deep)]"
            >
              OPEN THE FULL TASKS BOARD
            </button>
            <p className="mt-2 text-center text-[9.5px] font-bold tracking-[0.06em] text-[var(--fx-muted)]">
              {beyond > 0 ? `${beyond} MORE OPEN BEYOND ${w.label} · ` : ""}
              TURN IT OFF ANYTIME · SETTINGS → FLOATING TASK TRACKER
            </p>
          </div>
        </aside>
      )}
    </>
  );
}
