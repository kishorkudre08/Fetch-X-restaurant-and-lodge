import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";
import {
  LG_ROOMS_MIN,
  LG_ROOMS_MAX,
  MAX_ROOMS_KEY,
  lgStay,
  parseLevels,
  parseMaxRooms,
  fitLevelsToMax,
  tierOfRoom,
  DEFAULT_LEVELS,
  type Level,
} from "@/lib/lodge";
import { getDiscountLimit, getLodgeMinStay } from "@/lib/settings";

export const dynamic = "force-dynamic";

async function loadMax(): Promise<number> {
  const s = await db.setting.findUnique({ where: { key: MAX_ROOMS_KEY } });
  return parseMaxRooms(s?.value);
}

async function loadLevels(max: number): Promise<Level[]> {
  const s = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  return parseLevels(s?.value, max) ?? fitLevelsToMax(DEFAULT_LEVELS, max);
}

// GET /api/lodge — the whole wall (1..maxRooms) + levels + live stats + recent bills
// t117 — ?bills=N raises the bills window (the owner's front desk reads the last 50);
// the default stays 8 so the counter's feed is untouched.
export async function GET(req: NextRequest) {
  const maxRooms = await loadMax();
  const billsTake = Math.min(Math.max(Number(req.nextUrl.searchParams.get("bills") ?? 8) || 8, 1), 50);
  let [rooms, bills, levels] = await Promise.all([
    db.room.findMany({ orderBy: { number: "asc" } }),
    db.lodgeBill.findMany({ orderBy: { number: "desc" }, take: billsTake }),
    loadLevels(maxRooms),
  ]);
  // self-heal — if the wall grew (or a row was lost by hand), conjure the
  // missing rooms as free so the DB always covers 1..maxRooms exactly
  if (rooms.length < maxRooms) {
    const have = new Set(rooms.map((r) => r.number));
    const missing = Array.from({ length: maxRooms }, (_, i) => i + 1).filter((n) => !have.has(n));
    await db.room.createMany({ data: missing.map((number) => ({ number })) });
    rooms = await db.room.findMany({ orderBy: { number: "asc" } });
  }
  const occ = rooms.filter((r) => r.status === "occ");
  const mnt = rooms.filter((r) => r.status === "mnt");
  // tonight = what the guests currently in house are being billed per hour, projected to 24 h
  const tonight = occ.reduce((sum, r) => sum + tierOfRoom(r.number, levels).rate, 0);
  // stay mix — share of checkouts by duration bucket (last 90 days)
  const since = new Date(Date.now() - 90 * 86400000);
  const stays = await db.lodgeBill.findMany({
    where: { createdAt: { gte: since } },
    select: { hours: true },
  });
  const buckets = [
    { label: "UNDER 6 H", test: (h: number) => h < 6 },
    { label: "6 – 12 H", test: (h: number) => h >= 6 && h < 12 },
    { label: "12 – 24 H", test: (h: number) => h >= 12 && h < 24 },
    { label: "24 H +", test: (h: number) => h >= 24 },
  ];
  const total = stays.length || 1;
  const stayMix = buckets.map((b) => ({
    label: b.label,
    share: Math.round((stays.filter((s) => b.test(s.hours)).length / total) * 100),
  }));
  return NextResponse.json({
    rooms,
    bills,
    levels,
    maxRooms,
    counts: { occ: occ.length, mnt: mnt.length, avl: maxRooms - occ.length - mnt.length },
    tonight,
    stayMix,
  });
}

type Body = {
  action?: "checkin" | "checkout" | "maintenance-done" | "levels-apply" | "bill-undo" | "delete-checkin" | "reset" | "max-rooms";
  room?: number;
  name?: string;
  phone?: string;
  checkInAt?: string;
  checkOutAt?: string;
  discount?: number;
  levels?: Level[];
  number?: number;
  maxRooms?: number;
};

// POST /api/lodge — action-based front-desk operations.
// Every path re-reads the room inside a transaction, so two cashiers can
// never check the same green room in twice.
export async function POST(req: NextRequest) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const action = body.action;

  try {
    /* ── CHECK IN — green → gold ─────────────────────────────────────────── */
    if (action === "checkin") {
      const maxNow = await loadMax();
      const room = Number(body.room);
      const name = String(body.name ?? "").trim();
      const phone = String(body.phone ?? "").trim();
      if (!Number.isInteger(room) || room < 1 || room > maxNow)
        return NextResponse.json({ error: `Pick a room between 1 and ${maxNow}` }, { status: 400 });
      if (name.length < 2)
        return NextResponse.json({ error: "Enter the guest's name to check in" }, { status: 400 });
      // Phone = digits only, exactly 10 (the input field already filters as
      // you type — this re-check keeps a hand-crafted request honest too).
      const phoneDigits = phone.replace(/\D/g, "").slice(0, 10);
      if (phoneDigits.length !== 10)
        return NextResponse.json({ error: "Enter a valid 10-digit mobile number" }, { status: 400 });
      const checkInAt = body.checkInAt ? new Date(body.checkInAt) : new Date();
      if (isNaN(checkInAt.getTime()))
        return NextResponse.json({ error: "Invalid entry time" }, { status: 400 });

      const taken = await db.$transaction(async (tx) => {
        const r = await tx.room.findUnique({ where: { number: room } });
        if (!r) return "Room not found";
        if (r.status !== "avl") return `Room ${room} is no longer free — pick another green room`;
        await tx.room.update({
          where: { number: room },
          data: { status: "occ", guestName: name, guestPhone: phoneDigits, checkInAt },
        });
        return null;
      });
      if (taken) return NextResponse.json({ error: taken }, { status: 409 });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true });
    }

    /* ── CHECK OUT — gold → amber, bill generated ────────────────────────── */
    if (action === "checkout") {
      const maxNow = await loadMax();
      const room = Number(body.room);
      if (!Number.isInteger(room) || room < 1 || room > maxNow)
        return NextResponse.json({ error: "Invalid room" }, { status: 400 });
      const checkOutAt = body.checkOutAt ? new Date(body.checkOutAt) : new Date();
      if (isNaN(checkOutAt.getTime()))
        return NextResponse.json({ error: "Invalid exit time" }, { status: 400 });
      const levels = await loadLevels(maxNow);

      const bill = await db.$transaction(async (tx) => {
        const r = await tx.room.findUnique({ where: { number: room } });
        if (!r) throw new Error("Room not found");
        if (r.status !== "occ" || !r.checkInAt || !r.guestName)
          throw new Error(`Room ${room} has no guest to check out`);
        if (checkOutAt.getTime() <= r.checkInAt.getTime())
          throw new Error("Exit time is before entry — it must be after the guest's entry time");

        const tier = tierOfRoom(room, levels);
        const hours = (checkOutAt.getTime() - r.checkInAt.getTime()) / 3600000;
        // The owner's minimum-stay floor (Settings → LODGE RULE) re-checked
        // server-side: a short stay can never bill below it, whatever the
        // front desk tries.
        const minStay = await getLodgeMinStay();
        const s = lgStay(tier.rate, hours, minStay);
        // t143 — the owner's discount rule re-checked server-side: the front
        // desk can never write a discount above the limit % of the stay charge.
        const discLimit = await getDiscountLimit();
        const disc = Math.min(
          Math.max(0, Math.round(Number(body.discount) || 0)),
          s.stay,
          Math.floor(s.stay * discLimit) / 100,
        );
        const taxable = s.stay - disc;
        const tax = Math.round(taxable * 5) / 100; // paise-exact, as printed
        const total = Math.round((taxable + tax) * 100) / 100;

        // Successive numbering (L-5001…): reuse the first free number when a
        // bill-undo tore a hole, so stay-bill numbers never skip.
        const maxAgg = await tx.lodgeBill.aggregate({ _max: { number: true } });
        const cnt = await tx.lodgeBill.count();
        const maxNum = maxAgg._max.number ?? 5000;
        let number: number;
        if (cnt === maxNum - 5000) {
          number = maxNum + 1; // dense series — keep counting up
        } else {
          const nums = await tx.lodgeBill.findMany({ select: { number: true }, orderBy: { number: "asc" } });
          number = 5001;
          for (const n of nums) {
            if (n.number === number) number += 1;
            else break;
          }
        }

        await tx.room.update({
          where: { number: room },
          data: { status: "mnt", guestName: null, guestPhone: null, checkInAt: null },
        });
        return tx.lodgeBill.create({
          data: {
            number,
            room,
            guestName: r.guestName,
            guestPhone: r.guestPhone ?? "",
            tier: tier.name,
            rate: tier.rate,
            checkInAt: r.checkInAt,
            checkOutAt,
            hours: Math.round(hours * 100) / 100,
            stay: s.stay,
            minApplied: s.min,
            discount: disc,
            tax,
            total,
          },
        });
      });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true, bill });
    }

    /* ── MAINTENANCE DONE — amber → green (the housekeeping loop) ────────── */
    if (action === "maintenance-done") {
      const maxNow = await loadMax();
      const room = Number(body.room);
      if (!Number.isInteger(room) || room < 1 || room > maxNow)
        return NextResponse.json({ error: "Invalid room" }, { status: 400 });
      const room0 = await db.room.findUnique({ where: { number: room } });
      if (!room0) return NextResponse.json({ error: "Room not found" }, { status: 404 });
      if (room0.status === "mnt")
        await db.room.update({
          where: { number: room },
          data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null },
        });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true, status: "avl" });
    }

    /* ── LEVELS APPLY — save the graded-rate config (Management editor) ──── */
    if (action === "levels-apply") {
      const maxNow = await loadMax();
      const parsed = parseLevels(JSON.stringify(body.levels ?? null), maxNow);
      if (!parsed)
        return NextResponse.json(
          { error: `Levels must cover rooms 1 – ${maxNow} with no gaps or overlaps, rates ≥ ₹100` },
          { status: 400 },
        );
      await db.setting.upsert({
        where: { key: "lodgeLevels" },
        create: { key: "lodgeLevels", value: JSON.stringify(parsed) },
        update: { value: JSON.stringify(parsed) },
      });
      return NextResponse.json({ ok: true, levels: parsed });
    }

    /* ── MAX ROOMS — t116: the flexible wall size ─────────────────────────── */
    // Grow anytime — new rooms arrive green and the last level stretches to
    // cover them. Shrink ONLY when every room being cut is free: if a single
    // one is still occupied or under maintenance the owner waits (409 + the
    // busy list) until the wall's own loop turns them green.
    if (action === "max-rooms") {
      const next = Math.round(Number(body.maxRooms));
      if (!Number.isInteger(next) || next < LG_ROOMS_MIN || next > LG_ROOMS_MAX)
        return NextResponse.json(
          { error: `The wall runs between ${LG_ROOMS_MIN} and ${LG_ROOMS_MAX} rooms` },
          { status: 400 },
        );
      const cur = await loadMax();
      if (next === cur) return NextResponse.json({ ok: true, maxRooms: cur, levels: await loadLevels(cur) });

      const curLevels = await loadLevels(cur);
      if (next > cur) {
        const nextLevels = fitLevelsToMax(curLevels, next);
        await db.$transaction(async (tx) => {
          const have = await tx.room.findMany({ where: { number: { gt: cur } }, select: { number: true } });
          const haveSet = new Set(have.map((r) => r.number));
          const missing = Array.from({ length: next - cur }, (_, i) => cur + i + 1).filter((n) => !haveSet.has(n));
          if (missing.length) await tx.room.createMany({ data: missing.map((number) => ({ number })) });
          await tx.setting.upsert({
            where: { key: "lodgeLevels" },
            create: { key: "lodgeLevels", value: JSON.stringify(nextLevels) },
            update: { value: JSON.stringify(nextLevels) },
          });
          await tx.setting.upsert({
            where: { key: MAX_ROOMS_KEY },
            create: { key: MAX_ROOMS_KEY, value: String(next) },
            update: { value: String(next) },
          });
        });
        invalidateDashboardCache();
        return NextResponse.json({ ok: true, maxRooms: next, levels: nextLevels });
      }

      // shrinking — every room in the cut band must be green
      const busy = await db.room.findMany({
        where: { number: { gt: next, lte: cur }, NOT: { status: "avl" } },
        orderBy: { number: "asc" },
        select: { number: true, status: true },
      });
      if (busy.length) {
        const list = busy.map((r) => `Room ${r.number} (${r.status === "occ" ? "occupied" : "maintenance"})`).join(", ");
        return NextResponse.json(
          { error: `The wall can't shrink yet — ${list} must be free first.`, busy: busy.map((r) => r.number) },
          { status: 409 },
        );
      }
      const nextLevels = fitLevelsToMax(curLevels, next);
      await db.$transaction(async (tx) => {
        await tx.room.deleteMany({ where: { number: { gt: next } } });
        await tx.setting.upsert({
          where: { key: "lodgeLevels" },
          create: { key: "lodgeLevels", value: JSON.stringify(nextLevels) },
          update: { value: JSON.stringify(nextLevels) },
        });
        await tx.setting.upsert({
          where: { key: MAX_ROOMS_KEY },
          create: { key: MAX_ROOMS_KEY, value: String(next) },
          update: { value: String(next) },
        });
      });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true, maxRooms: next, levels: nextLevels });
    }

    /* ── STAY BILL UNDO — tear a wrong checkout bill ─────────────────────── */
    // Deletes the LodgeBill and, when the room still sits in the exact state
    // that checkout left it in (amber, waiting for housekeeping), puts the
    // guest straight back in — status gold, same name, same entry time.
    // Housekeeping already turned it green? It stays green. A new guest
    // already checked in? They keep the room; only the bill is removed.
    if (action === "bill-undo") {
      const num = Number(body.number);
      if (!Number.isInteger(num))
        return NextResponse.json({ error: "Invalid stay bill number" }, { status: 400 });
      const err = await db.$transaction(async (tx) => {
        const b = await tx.lodgeBill.findUnique({ where: { number: num } });
        if (!b) return `Stay bill L-${num} not found`;
        const r = await tx.room.findUnique({ where: { number: b.room } });
        if (r && r.status === "mnt") {
          await tx.room.update({
            where: { number: b.room },
            data: {
              status: "occ",
              guestName: b.guestName,
              guestPhone: b.guestPhone,
              checkInAt: b.checkInAt,
            },
          });
        }
        // avl (housekeeping already done) or occ (room re-used): only remove the bill
        await tx.lodgeBill.delete({ where: { number: num } });
        return null;
      });
      if (err) return NextResponse.json({ error: err }, { status: 404 });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true });
    }

    /* ── DELETE CHECK-IN — undo a mistaken check-in, no bill ─────────────── */
    // The front desk checked a guest into the wrong room (or a ghost): clear
    // the room straight back to green. No bill is raised or touched — a
    // check-in is only ever billed at checkout.
    if (action === "delete-checkin") {
      const maxNow = await loadMax();
      const room = Number(body.room);
      if (!Number.isInteger(room) || room < 1 || room > maxNow)
        return NextResponse.json({ error: "Invalid room" }, { status: 400 });
      const err = await db.$transaction(async (tx) => {
        const r = await tx.room.findUnique({ where: { number: room } });
        if (!r) return "Room not found";
        if (r.status !== "occ") return `Room ${room} has no check-in to delete`;
        await tx.room.update({
          where: { number: room },
          data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null },
        });
        return null;
      });
      if (err) return NextResponse.json({ error: err }, { status: 409 });
      invalidateDashboardCache();
      return NextResponse.json({ ok: true });
    }

    /* ── RESET WALL — demo lever: everything back to green ───────────────── */
    if (action === "reset") {
      await db.room.updateMany({ data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null } });
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Lodge operation failed";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
