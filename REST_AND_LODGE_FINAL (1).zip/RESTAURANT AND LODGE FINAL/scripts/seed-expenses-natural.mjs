/* ── seed-expenses-natural.mjs ───────────────────────────────────────────
 * The user asked for "expenses data too, natural". The ledger had only
 * 1-2 entries/day (mechanical). This tops up the last ~45 days with the
 * natural rhythm of a 100-room lodge + busy restaurant:
 *   · raw_material  — near-daily, 1-3 entries (morning market run, dairy,
 *                     gas cylinder, weekly wholesale, lodge toiletries…)
 *   · maintenance   — 1-2/week (plumbing, electric, pest control monthly…)
 *   · upgrade       — roughly fortnightly (blender, artwork, signage…)
 *   · DOW rhythm    — weekends stock heavier; Sunday light (many suppliers off)
 *   · amounts follow the existing ledger's scale (₹200 … ₹12,000)
 * Existing entries are KEPT — we only add complementary ones, and never
 * the same label twice on the same day. ────────────────────────────────── */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const MIN = 60_000, DAY = 24 * 60 * MIN;
const IST = 330 * 60_000;
const istAt = (dayOffset, h, m) => {
  const nowIst = new Date(Date.now() + IST);
  const day0 = Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate());
  return new Date(day0 + dayOffset * DAY + (h * 60 + m) * MIN - IST);
};
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.floor(rnd(a, b + 1));
const pick = (arr) => arr[irnd(0, arr.length - 1)];
const r2 = (n) => Math.round(n * 100) / 100;

/* label banks — the owner's own shorthand */
const RAW_REST = [
  "Morning market run — vegetables", "Vegetables + dairy top-up", "Onion & potato sacks (wholesale)",
  "Atta + rice wholesale run", "Fresh paneer and curd stock", "Cooking-gas cylinder swap",
  "Tea, coffee & sugar restock", "Cooking oils refill", "Spices replenishment — masala box",
  "Cold drinks + water crates", "Eggs and bread for breakfast", "Chicken and mutton — weekly meat run",
  "Fish delivery — evening special", "Fruits for the juice counter", "Packaging boxes + tissues",
];
const RAW_LODGE = [
  "Toiletries refill — soaps & shampoo", "Laundry detergent top-up", "Bathroom tissue + face towels",
  "Bed-sheet restock (2 torn)", "Drinking-water cans for rooms", "Dustbins + room fresheners",
  "Key blanks + lanyards", "Housekeeping floor cleaner",
];
const MAINT_REST = [
  "Plumber — sink choke in the kitchen", "Electrician — counter light fix", "Exhaust fan motor rewiring",
  "Fridge gas top-up", "Water filter cartridge change", "Pest control — monthly spray",
  "Tandoor burner cleaning", "AC service — dining hall unit",
];
const MAINT_LODGE = [
  "Geyser repair — room 34", "Corridor tube-light batch change", "Water pump bearing grease",
  "Door lock fix — room 51", "Drain clean — floor 2 washroom", "Pest control — monthly spray",
  "Painter — touch-up lobby wall", "Generator servicing",
];
const UPGRADE_REST = [
  "New heavy-duty mixer grinder", "Crocery set for family section", "Wall art — dining hall frames",
  "LED menu board panel", "Service trolley (steel)", "Chimney filter upgrade",
  "Counter bell + card machine stand",
];
const UPGRADE_LODGE = [
  "Room artwork — corridor prints", "New keytag + lock batch", "Lobby planter set",
  "Curtain fabric — floor 3 rooms", "Reception chair set", "Wi-Fi router upgrade — wing 2",
  "Signage — floor direction plates",
];

/* ── collect what already exists to avoid label/day duplicates ── */
const existing = await db.expense.findMany({ select: { label: true, spentOn: true } });
const seen = new Set(existing.map((e) => `${e.label}@${new Date(e.spentOn).toISOString().slice(0, 10)}`));
const freeLabel = (bank, day) => {
  for (let i = 0; i < 12; i++) {
    const l = pick(bank);
    if (!seen.has(`${l}@${day}`)) { seen.add(`${l}@${day}`); return l; }
  }
  return null;
};

const rows = [];
const push = (kind, book, label, amount, when) => {
  if (!label) return;
  rows.push({ kind, book, label, amount: r2(amount), spentOn: when, createdAt: when });
};

/* ── generate the last 45 days (offset 45 → 0 = today) ── */
for (let off = 45; off >= 0; off--) {
  const when = istAt(-off, 0, 0);           // the IST day anchor
  const dow = when.getUTCDay();             // 0 Sun … 6 Sat (anchor is midnight IST → UTC 18:30 prev day; use IST date instead)
  const istDate = new Date(when.getTime() + IST);
  const dowIst = istDate.getUTCDay();
  const weekend = dowIst === 0 || dowIst === 6;

  // raw_material — restaurant: 1-2/day normally, 2-3 on Fri/Sat; Sunday lighter
  const restRawN = dowIst === 0 ? irnd(0, 1) : weekend ? irnd(2, 3) : irnd(1, 2);
  for (let i = 0; i < restRawN; i++) {
    const heavy = Math.random() < 0.18;                 // weekly wholesale run
    push("raw_material", "rest",
      freeLabel(RAW_REST, istDate.toISOString().slice(0, 10)),
      heavy ? rnd(2500, 6000) : rnd(280, 2400),
      istAt(-off, irnd(7, 11), irnd(0, 59)));
  }
  // raw_material — lodge: ~4/week
  if (Math.random() < 0.55) {
    push("raw_material", "lodge",
      freeLabel(RAW_LODGE, istDate.toISOString().slice(0, 10)),
      rnd(250, 1900),
      istAt(-off, irnd(9, 18), irnd(0, 59)));
  }
  // maintenance — ~1.4/week split across books
  if (Math.random() < 0.2) {
    const book = Math.random() < 0.5 ? "rest" : "lodge";
    push("maintenance", book,
      freeLabel(book === "rest" ? MAINT_REST : MAINT_LODGE, istDate.toISOString().slice(0, 10)),
      rnd(450, 3800),
      istAt(-off, irnd(10, 17), irnd(0, 59)));
  }
  // upgrade — roughly one every 10-12 days across both books
  if (Math.random() < 0.09) {
    const book = Math.random() < 0.45 ? "rest" : "lodge";
    push("upgrade", book,
      freeLabel(book === "rest" ? UPGRADE_REST : UPGRADE_LODGE, istDate.toISOString().slice(0, 10)),
      rnd(1500, 11500),
      istAt(-off, irnd(11, 18), irnd(0, 59)));
  }
}

/* today gets a guaranteed pair (market run + a lodge refill) so the TODAY
   window is never empty — morning + afternoon slots (now ~19:00 IST) */
const todayISO = istAt(0, 0, 0).toISOString().slice(0, 10);
if (!seen.has("Morning market run — vegetables@" + todayISO)) {
  push("raw_material", "rest", "Morning market run — vegetables", rnd(900, 2600), istAt(0, 8, 40));
}
push("raw_material", "lodge", freeLabel(RAW_LODGE, todayISO) ?? "Drinking-water cans for rooms", rnd(300, 1400), istAt(0, 17, 20));

/* never duplicate an identical (label, day) that already exists */
const final = rows.filter((r) => !seen.has(`${r.label}@${r.spentOn.toISOString().slice(0, 10)}`) || true);
// (push/freeLabel already de-duped; keep all)
for (const r of final) {
  await db.expense.create({ data: r });
}

/* ── report ── */
const all = await db.expense.findMany();
const dayKey = (d) => Math.floor((new Date(d).getTime() + IST) / 86_400_000);
const todayK = dayKey(new Date());
const inWin = (lo, hi) => all.filter((e) => { const k = dayKey(e.spentOn); return k >= todayK + lo && k <= todayK + hi; });
console.log(`added ${final.length} expenses · ledger now ${all.length}`);
console.log(`TODAY ${inWin(0, 0).length} · 7D ${inWin(-6, 0).length} · 1M ${inWin(-29, 0).length}`);
const perDay = {};
for (const e of all) { const k = dayKey(e.spentOn); if (k >= todayK - 13) perDay[k] = (perDay[k] ?? 0) + 1; }
console.log("last-14-days counts:", Object.values(perDay).join(","));
await db.$disconnect();
