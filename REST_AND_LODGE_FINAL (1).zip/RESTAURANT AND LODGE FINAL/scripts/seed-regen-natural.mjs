/* Fetch-X · natural data regeneration — one shot, 2020-01-01 → NOW (IST).
 *
 * What it does
 *   1. Wipes ALL transactional data: TaskUpdate, Task, SalaryPayment,
 *      Attendance, BillItem, Bill, LodgeBill, Expense.
 *   2. KEEPS the master data: dishes, categories, employees, settings
 *      (lodgeLevels, hotelName) and the Room rows (wall re-dressed below).
 *   3. Regenerates everything with NATURAL distributions and dates that run
 *      right up to the current IST moment:
 *        · restaurant bills  — era growth curve, weekday/weekend shape,
 *                              meal-hour peaks, festival spikes & rainy lulls
 *        · lodge stay bills  — same growth curve, morning-biased checkouts,
 *                              tier rates, minimum-stay floor honoured
 *        · expenses          — station costs in both books, task spends too
 *        · owner tasks       — RATIONALISED: ~1-2/wk (2020-24) → 2-3/wk (2025)
 *                              → 4-5/wk in 2026, with only 2-4 tasks OPEN
 *                              right now and no stale backlog
 *        · attendance        — every employee's register from join date
 *                              (Sundays off, deterministic 88% present)
 *        · salaries          — every settled month through last month,
 *                              derived from the attendance marks
 *        · room wall         — a live-looking ~55% occupancy snapshot
 *
 * Run:  node scripts/seed-regen-natural.mjs
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient({
  datasources: { db: { url: "file:/home/z/my-project/db/custom.db" } },
});

const DAY = 86_400_000;
const IST = 330 * 60_000;
const NOW = Date.now();

/* ── tiny helpers ─────────────────────────────────────────────────────── */
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.round(rnd(a, b));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const r2 = (n) => Math.round(n * 100) / 100;
const hash = (s) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h) % 100;
};
const istDayKey = (ts) => new Date(ts + IST).toISOString().slice(0, 10);
const istDayStart = (ts) => {
  const d = new Date(ts + IST);
  d.setUTCHours(0, 0, 0, 0);
  return d.getTime() - IST;
};
const istDow = (ts) => new Date(ts + IST).getUTCDay(); // 0=Sun … 6=Sat
const localISO = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

/* ── name banks ───────────────────────────────────────────────────────── */
const GUESTS = [
  "Ramesh Kulkarni", "Priya Deshpande", "Arjun Mehta", "Sneha Patil", "Vikram Joshi",
  "Anita Desai", "Rahul Verma", "Kavita Rao", "Suresh Babu", "Meena Nair",
  "Prakash Gowda", "Shobha Kamath", "Mohan Pai", "Lata Hegde", "Girish Prabhu",
  "Deepak Iyer", "Farida Sheikh", "Bhaskar Reddy", "Nisha Pillai", "Anand Subramaniam",
  "Tejas Bhat", "Sowmya Krishnan", "Manjunath Hegde", "Rekha Suresh", "Nagaraj Kini",
  "Vinayak Shenoy", "Asha Rani", "Dinesh Shetty", "Lalitha Rao", "Harish Pai",
  "Ganesh Achar", "Malathi Krishnan", "Sudhakar Rao", "Yashoda Devi", "Karthik Menon",
];
const phone = () => String(pick([6, 7, 8, 9])) + String(irnd(100000000, 999999999));

/* ── restaurant bill hour weights (IST) — breakfast/lunch/evening peaks ── */
const HOUR_W = [
  2, 1, 0.5, 0.5, 0.5, 1, 3, 8, 10, 8, 8, 14, 16, 12, 8, 8, 10, 12, 14, 15, 12, 8, 5, 3,
];
/* weekday multipliers from the old register's own DOW spread */
const DOW_REST = [1.7, 1.0, 0.95, 1.0, 1.1, 1.35, 1.55]; // Sun..Sat
const DOW_LODGE = [1.45, 0.9, 0.9, 0.95, 1.0, 1.3, 1.5];

/* ── era growth curves — per-IST-day bases ────────────────────────────── */
function restBase(dayStart) {
  const t = new Date(dayStart + IST);
  const y = t.getUTCFullYear();
  const doy = (t.getTime() - Date.UTC(y, 0, 1)) / DAY;
  if (y <= 2024) return 4.0 + (doy / 366) * 0.6 + (y - 2020) * 0.25; // 4.0 → ~5.6
  if (y === 2025) return 7 + (doy / 365) * 6; // 7 → 13
  return 26 + (doy / 365) * 7; // 26 → 33
}
function lodgeBase(dayStart) {
  const t = new Date(dayStart + IST);
  const y = t.getUTCFullYear();
  const doy = (t.getTime() - Date.UTC(y, 0, 1)) / DAY;
  if (y <= 2024) return 0.55 + (doy / 366) * 0.12 + (y - 2020) * 0.05; // 0.55 → ~0.9
  if (y === 2025) return 3.5 + (doy / 365) * 3; // 3.5 → 6.5
  return 15 + (doy / 365) * 4; // 15 → 19
}

/* ── lodge stay length (hours) — short-eats-heavy, some long residents ── */
function stayHours() {
  const table = [
    [rnd(5, 9), 22],
    [rnd(10, 14), 20],
    [rnd(20, 28), 26],
    [rnd(30, 50), 18],
    [rnd(52, 76), 9],
    [rnd(80, 120), 5],
  ];
  const w = table.reduce((s, [, x]) => s + x, 0);
  let r = Math.random() * w;
  for (const [v, x] of table) {
    r -= x;
    if (r <= 0) return v;
  }
  return table[table.length - 1][0];
}
/* checkout leans to late morning */
function checkoutSlot(dayStart, dayEnd) {
  const morning = Math.random() < 0.55;
  if (morning) return dayStart + rnd(7, 12) * 3_600_000;
  return dayStart + rnd(12, 22) * 3_600_000;
}

/* ── expense banks ────────────────────────────────────────────────────── */
const EXP_BANK = {
  raw_material: {
    rest: [
      "Vegetables + dairy top-up", "Spices and oil refill", "Rice + atta sacks for the week",
      "Paneer and curd stock", "Cooking-gas cylinder swap", "Tea, coffee & sugar restock",
      "Cold-drink crate refill", "Banana leaf + tissue stock",
    ],
    lodge: [
      "Toiletries + linen restock", "Guest soap & shampoo refill", "Drinking-water cans for the floors",
      "Bleach + floor cleaner stock", "Laundry detergent top-up",
    ],
  },
  maintenance: {
    rest: [
      "Chimney deep-clean service", "Wet-grinder bearing repair", "Fridge gas top-up",
      "Exhaust fan motor rewiring", "Plumber — sink drain choke", "Mixer jar replacement",
      "Water purifier filter service",
    ],
    lodge: [
      "Plumber — leaking tap, room wing 2", "AC service — summer prep", "Geyser repair — floor 3",
      "Door-lock carpentry — wing 1", "Pest control — ground floor", "Corridor light rewiring",
      "Water-pump servicing",
    ],
  },
  upgrade: {
    rest: [
      "New counter LED sign", "Steel serving trays (dozen)", "Crockery set for the mezzanine",
      "Billing-counter shelf", "Ceiling fans — dining hall",
    ],
    lodge: [
      "Replace corridor carpet — wing 1", "Smart TV for the luxury wing", "New keytag + lock batch",
      "Lobby sofa re-upholstery", "Room-number plates — floor 2", "Security camera — parking bay",
    ],
  },
};

/* ── task banks — the owner's real voice ──────────────────────────────── */
const TASK_BANK = [
  { title: "Restock the reception stationery drawer", book: "lodge", kind: "raw_material", budget: 1500, desc: "Printed forms, pens, key tags — needs ~150 prints." },
  { title: "Print this week's specials cards", book: "rest", kind: null, budget: null, desc: "Table cards for the 3 new starters — 40 prints." },
  { title: "Service the kitchen mixer", book: "rest", kind: "maintenance", budget: 2000, desc: "Planetary mixer — bearing noise, needs lubrication." },
  { title: "Refill lobby drinking-water dispenser", book: "lodge", kind: null, budget: null, desc: "Stock the dispenser + spare bottles at reception." },
  { title: "Replace blown corridor bulb (wing 2)", book: "lodge", kind: "maintenance", budget: 600, desc: "Bulb above room 207 — flickered out overnight." },
  { title: "Polish the brass bell at the entrance", book: "lodge", kind: "upgrade", budget: 800, desc: "Tarnished — needs brass polish + soft cloth." },
  { title: "Fix the geysers on floor 2", book: "lodge", kind: "maintenance", budget: 3500, desc: "Two bathrooms report cold water — check heating elements." },
  { title: "Steam-clean the tandoor corner", book: "rest", kind: "maintenance", budget: 1800, desc: "Monthly deep clean before the weekend rush." },
  { title: "Refill the paneer stock for dinner service", book: "rest", kind: "raw_material", budget: 2500, desc: "Fresh stock from the dairy before 6 pm." },
  { title: "Repaint the reception notice board", book: "lodge", kind: "upgrade", budget: 2500, desc: "Fresh coat on the notice board beside the front desk." },
  { title: "Restock menu printouts for the counter", book: "rest", kind: "raw_material", budget: 1000, desc: "200 menu sheets — counter ran out yesterday." },
  { title: "Replace the front-desk chair caster", book: "lodge", kind: "maintenance", budget: 500, desc: "One wheel snapped off — replace the caster set." },
  { title: "Refill cooking-gas cylinder", book: "rest", kind: "raw_material", budget: 2200, desc: "Swap the empty cylinder before lunch service." },
  { title: "Deep-clean the kitchen exhaust", book: "rest", kind: "maintenance", budget: 3000, desc: "Quarterly degrease — book the vendor for a Monday." },
  { title: "Keycard locks for floors 3-4", book: "lodge", kind: "upgrade", budget: 12000, desc: "Replace the old mechanical locks — 20 doors." },
  { title: "Smart TVs for the luxury wing", book: "lodge", kind: "upgrade", budget: 15000, desc: "Two 43-inch panels for rooms 93 and 95." },
  { title: "Repaint room 12 doors", book: "lodge", kind: "upgrade", budget: 2000, desc: "Scuffed doors — sand and enamel both faces." },
  { title: "Service the corridor air-coolers", book: "lodge", kind: "maintenance", budget: 2400, desc: "Pre-summer check — pads, fans and tanks." },
  { title: "Upgrade the counter LED menu board", book: "rest", kind: "upgrade", budget: 4500, desc: "Backlit board above the counter — 3 panels." },
  { title: "Restock dry goods", book: "rest", kind: "raw_material", budget: 3000, desc: "Atta, rice, dal — the weekly wholesale run." },
  { title: "Sound system for the mezzanine", book: "rest", kind: "upgrade", budget: 8000, desc: "Two speakers + amp for family evenings." },
  { title: "Deep clean dining area", book: "rest", kind: "maintenance", budget: 1600, desc: "Tables, chairs, floor polish after the weekend." },
  { title: "Replace worn room-number plates", book: "lodge", kind: "upgrade", budget: 1200, desc: "Numbers 41-60 — brass plates fading." },
  { title: "Fix the wobbling counter chair set", book: "rest", kind: "maintenance", budget: 700, desc: "Four chairs — tighten or replace the bolts." },
  { title: "Laundry contract for bed linen", book: "lodge", kind: "raw_material", budget: 2800, desc: "Monthly bulk wash for sheets and towels." },
  { title: "Repaint the entrance signboard", book: "rest", kind: "upgrade", budget: 3500, desc: "Faded lettering — same colours, fresh coat." },
];

/* past employees' leave dates (must mirror seed-rebuild-2020) */
const LEFT_MAP = {
  "Ramesh Shetty": "2022-08-31",
  "Geeta Rao": "2023-03-31",
  "Mohan Das": "2024-01-15",
  "Fatima Sheikh": "2024-06-30",
};

/* ── batch writers ────────────────────────────────────────────────────── */
async function writeMany(fn, rows, size = 800) {
  for (let i = 0; i < rows.length; i += size) {
    await fn(rows.slice(i, i + size));
  }
}

async function main() {
  const t0 = Date.now();
  console.log("── natural regeneration start ──");

  /* ── 1 · wipe ─────────────────────────────────────────────────────── */
  console.log("wiping transactional data…");
  await db.taskUpdate.deleteMany({});
  await db.task.deleteMany({});
  await db.salaryPayment.deleteMany({});
  await db.attendance.deleteMany({});
  await db.billItem.deleteMany({});
  await db.bill.deleteMany({});
  await db.lodgeBill.deleteMany({});
  await db.expense.deleteMany({});

  /* ── 2 · load master data ─────────────────────────────────────────── */
  const dishes = await db.dish.findMany({
    where: { active: true },
    select: { id: true, name: true, price: true, category: true },
  });
  if (dishes.length < 5) throw new Error("menu too small — seed the menu first");
  const employees = await db.employee.findMany();
  const lvlRow = await db.setting.findUnique({ where: { key: "lodgeLevels" } });
  let levels = [
    { from: 1, to: 40, rate: 2499, name: "BASIC" },
    { from: 41, to: 80, rate: 2999, name: "STANDARD" },
    { from: 81, to: 100, rate: 3999, name: "LUXURY" },
  ];
  try {
    const parsed = JSON.parse(lvlRow?.value ?? "null");
    if (Array.isArray(parsed) && parsed.length) levels = parsed;
  } catch { /* defaults */ }
  const minRow = await db.setting.findUnique({ where: { key: "lodgeMinStay" } });
  const LODGE_MIN = Number.isFinite(Math.floor(Number(minRow?.value)))
    ? Math.max(0, Math.floor(Number(minRow?.value)))
    : 1000;
  // make sure the Settings screen shows a real stored value (₹1,000 classic floor)
  await db.setting.upsert({
    where: { key: "lodgeMinStay" },
    update: {},
    create: { key: "lodgeMinStay", value: String(LODGE_MIN) },
  });
  console.log(`menu: ${dishes.length} dishes · staff: ${employees.length} · levels: ${levels.length} · lodge floor: ₹${LODGE_MIN}`);

  /* ── 3 · walk every IST day ───────────────────────────────────────── */
  const todayStart = istDayStart(NOW);
  let dayStart = Date.UTC(2020, 0, 1) - IST; // IST midnight of 1 Jan 2020

  let billNo = 1001;
  let lodgeNo = 5001;
  const bills = [];
  const billItems = [];
  const lodgeRows = [];
  const expenseRows = [];
  const taskRows = [];
  const updateRows = [];
  let taskSeq = 0;
  let updSeq = 0;
  let expSeq = 0;

  /* tasks per week: 2020-24 → 1-2 · 2025 → 2-3 · 2026 → 4-5 (the owner's ask) */
  const weekTasks = new Map(); // weekKey → count created
  let weekKey = "";
  const openSlotsTotal = 2 + irnd(0, 1); // 2-3 open tasks total, spread over the last days
  let openTaskSlots = openSlotsTotal;
  while (dayStart <= todayStart) {
    const key = istDayKey(dayStart);
    const dow = istDow(dayStart);
    const isToday = key === istDayKey(NOW);
    const dayEnd = Math.min(dayStart + DAY, NOW);

    /* ── restaurant bills ── */
    let target = restBase(dayStart) * DOW_REST[dow];
    if (Math.random() < 0.04) target *= 0.35; // rainy / slow day
    else if (Math.random() < 0.03) target *= 1.55; // festival bump
    target = Math.max(2, Math.round(target + rnd(-3, 3)));
    if (isToday) target = Math.max(2, Math.round(target * ((dayEnd - dayStart) / DAY))); // partial day

    const buckets = [];
    for (let h = 0; h < 24; h++) {
      const slot = dayStart + h * 3_600_000;
      if (slot >= dayEnd) break;
      buckets.push({ slot, w: HOUR_W[h] });
    }
    const wTot = buckets.reduce((s, b) => s + b.w, 0);
    for (let k = 0; k < target; k++) {
      let r = Math.random() * wTot;
      let at = buckets[buckets.length - 1].slot;
      for (const b of buckets) {
        r -= b.w;
        if (r <= 0) { at = b.slot; break; }
      }
      at = Math.min(at + Math.random() * 3_600_000, dayEnd - 60_000);

      const lines = [1, 2, 3, 4][Math.floor(Math.random() * (Math.random() < 0.7 ? 2 : 4))] ?? 1;
      const picks = [];
      for (let i = 0; i < lines; i++) {
        const dish = pick(dishes);
        const qty = Math.random() < 0.72 ? 1 : Math.random() < 0.75 ? 2 : 3;
        picks.push({ dish, qty });
      }
      const subtotal = r2(picks.reduce((s, p) => s + p.dish.price * p.qty, 0));
      const discount = Math.random() < 0.12 ? r2(subtotal * 0.05) : 0;
      const tax = r2((subtotal - discount) * 0.05);
      const total = r2(subtotal - discount + tax);
      const units = picks.reduce((s, p) => s + p.qty, 0);
      const id = `bx${billNo}`;
      bills.push({
        id, number: billNo++, subtotal, discount, tax, total,
        itemCount: units, createdAt: new Date(at),
      });
      picks.forEach((p, i) =>
        billItems.push({
          id: `${id}_${i}`, billId: id, dishId: p.dish.id,
          name: p.dish.name, category: p.dish.category, qty: p.qty, price: p.dish.price,
        }),
      );
    }

    /* ── lodge checkouts ── */
    let lodgeCount = lodgeBase(dayStart) * DOW_LODGE[dow];
    if (Math.random() < 0.05) lodgeCount *= 0.5;
    lodgeCount = Math.max(0, Math.round(lodgeCount + rnd(-1, 1)));
    for (let k = 0; k < lodgeCount; k++) {
      const room = irnd(1, 100);
      const lv = levels.find((l) => room >= l.from && room <= l.to) ?? levels[0];
      const hours = stayHours();
      const checkOut = new Date(Math.min(checkoutSlot(dayStart, dayEnd), dayEnd - 60_000));
      const checkIn = new Date(checkOut.getTime() - hours * 3_600_000);
      if (checkIn.getTime() >= NOW) continue;
      const raw = Math.round((lv.rate * hours) / 24);
      const min = LODGE_MIN > 0 && raw < LODGE_MIN;
      const stay = min ? LODGE_MIN : raw;
      const tax = Math.round(stay * 5) / 100;
      lodgeRows.push({
        id: `lb${lodgeNo}`, number: lodgeNo++, room,
        guestName: pick(GUESTS), guestPhone: phone(),
        tier: lv.name, rate: lv.rate, checkInAt: checkIn, checkOutAt: checkOut,
        hours: r2(hours), stay, minApplied: min, discount: 0, tax,
        total: r2(stay + tax), createdAt: checkOut,
      });
    }

    /* ── expenses (station costs, ~natural pace) ── */
    const y = new Date(dayStart + IST).getUTCFullYear();
    const expProb = y <= 2024 ? 0.21 : y === 2025 ? 0.36 : 1.2;
    if (Math.random() < expProb) {
      const kind = Math.random() < 0.55 ? "raw_material" : Math.random() < 0.65 ? "maintenance" : "upgrade";
      const book = Math.random() < 0.6 ? "rest" : "lodge";
      const amount =
        kind === "raw_material" ? r2(rnd(500, 6000)) :
        kind === "maintenance" ? r2(rnd(400, 4500)) :
        r2(rnd(1500, 12000));
      expenseRows.push({
        id: `ex${expSeq++}`, kind, book,
        label: pick(EXP_BANK[kind][book]),
        amount, spentOn: new Date(dayStart + rnd(8, 12) * 3_600_000),
      });
    }

    /* ── owner tasks — RATIONALISED ── */
    const wkISO = isoWeek(key);
    if (wkISO !== weekKey) {
      weekKey = wkISO;
      weekTasks.set(weekKey, 0);
    }
    const made = weekTasks.get(weekKey) ?? 0;
    const cap = y <= 2024 ? (hash("w" + weekKey) < 45 ? 2 : 1) : y === 2025 ? (hash("w" + weekKey) < 50 ? 3 : 2) : (hash("w" + weekKey) < 45 ? 5 : 4);
    if (made < cap && dow !== 0 && Math.random() < 0.75) {
      weekTasks.set(weekKey, made + 1);
      const tpl = pick(TASK_BANK);
      const createdAt = new Date(dayStart + rnd(8.5, 12) * 3_600_000);
      const budgeted = tpl.kind !== null && Math.random() < 0.8;
      const maxBudget = budgeted ? tpl.budget : null;
      const kind = budgeted ? tpl.kind : null;
      // current week keeps 2-3 OPEN tasks (fresh, future deadlines) — every
      // older task closed on time, so the board never floods with stale work
      const ageDays = (NOW - createdAt.getTime()) / DAY;
      const tooFresh = NOW - createdAt.getTime() < 10 * 3_600_000; // just forwarded
      // deterministic: the FIRST tasks created inside the last 6 days take the
      // open slots — so the board always ends with exactly 2-3 fresh opens.
      // Horizons are SPREAD (today / +2 / +10 / +26 / +40 / +150 days) so the
      // deadline windows stay distinct: TODAY never empty, and 7d/1m/3m/1y
      // each reveal NEW work as the funnel widens (t194 fix).
      const openSlotNo = openSlotsTotal - openTaskSlots;
      const OPEN_HORIZONS_DAYS = [0, 2, 10, 26, 40, 150];
      const horizon = OPEN_HORIZONS_DAYS[openSlotNo % OPEN_HORIZONS_DAYS.length];
      const forceOpen = ageDays <= 6 && openTaskSlots > 0;
      const isDone = !forceOpen;
      if (forceOpen) openTaskSlots--;

      const task = {
        id: `tk${taskSeq++}`, title: tpl.title, book: tpl.book, kind,
        maxBudget, description: tpl.desc,
        deadline: isDone
          ? new Date(createdAt.getTime() + irnd(2, 5) * DAY)
          : new Date(NOW + horizon * DAY + (horizon === 0 ? 6 * HOUR : 0)),
        status: isDone ? "done" : "open",
        createdBy: "Owner", createdAt,
        doneAt: null, doneBy: null, actualCost: null,
      };
      if (isDone) {
        const rawDone = createdAt.getTime() + irnd(1, 2.5) * DAY;
        task.doneAt = new Date(Math.max(
          createdAt.getTime() + 1_800_000,
          Math.min(rawDone, NOW - 1_800_000),
        ));
        task.doneBy = tpl.book === "lodge" ? "Lodge reception" : "Restaurant counter";
        task.actualCost = budgeted ? r2(rnd(0.45, 0.95) * maxBudget) : null;
      }
      taskRows.push(task);
      updateRows.push({
        id: `tu${updSeq++}`, taskId: task.id, author: "Owner", role: "owner",
        message: budgeted
          ? `Forwarded with a max budget of ₹${maxBudget.toLocaleString("en-IN")} — close with the actual spend.`
          : "Forwarded from the back office — no budget needed, just get it done.",
        createdAt,
      });
      if (isDone) {
        if (Math.random() < 0.35) {
          updateRows.push({
            id: `tu${updSeq++}`, taskId: task.id,
            author: task.doneBy, role: tpl.book === "lodge" ? "reception_lodge" : "reception_rest",
            message: "Work in progress — parts arranged, will close by the deadline.",
            createdAt: new Date(createdAt.getTime() + 0.6 * DAY),
          });
        }
        updateRows.push({
          id: `tu${updSeq++}`, taskId: task.id,
          author: task.doneBy, role: tpl.book === "lodge" ? "reception_lodge" : "reception_rest",
          message: task.actualCost
            ? `Marked DONE — ₹${task.actualCost.toLocaleString("en-IN")} spent, inside the budget.`
            : "Marked DONE — no spend needed.",
          createdAt: task.doneAt,
        });
        if (task.actualCost) {
          expenseRows.push({
            id: `ex${expSeq++}`, kind: task.kind ?? "raw_material", book: task.book,
            label: task.title, amount: task.actualCost,
            spentOn: task.doneAt, via: "task", taskId: task.id,
          });
        }
      }
    }

    dayStart += DAY;
  }

  /* ── 4 · write the day-generated tables ───────────────────────────── */
  console.log(`writing ${bills.length} bills + ${billItems.length} items…`);
  await writeMany((rows) => db.bill.createMany({ data: rows }), bills);
  await writeMany((rows) => db.billItem.createMany({ data: rows }), billItems);

  console.log(`writing ${lodgeRows.length} lodge bills…`);
  await writeMany((rows) => db.lodgeBill.createMany({ data: rows }), lodgeRows);

  console.log(`writing ${expenseRows.length} expenses…`);
  await writeMany((rows) => db.expense.createMany({ data: rows }), expenseRows);

  console.log(`writing ${taskRows.length} tasks + ${updateRows.length} updates…`);
  await writeMany((rows) => db.task.createMany({ data: rows }), taskRows);
  await writeMany((rows) => db.taskUpdate.createMany({ data: rows }), updateRows);

  /* ── 5 · attendance — every employee, join → (left | today) ───────── */
  console.log("generating attendance marks…");
  const attendance = [];
  employees.forEach((e, idx) => {
    const joined = e.createdAt ? localISO(new Date(e.createdAt)) : "2020-01-01";
    const left = e.active ? null : LEFT_MAP[e.name] ?? "2024-06-30";
    let d = new Date(joined + "T00:00:00Z");
    const end = left ? new Date(left + "T00:00:00Z") : new Date(todayStart + IST);
    while (d.getTime() <= end.getTime()) {
      const dow = d.getUTCDay();
      if (dow !== 0) {
        const iso = d.toISOString().slice(0, 10);
        const present = hash(e.id + ":" + iso) < 88;
        attendance.push({
          id: `at${idx}_${iso}`, employeeId: e.id, date: iso,
          status: present ? "present" : "absent",
        });
      }
      d = new Date(d.getTime() + DAY);
    }
  });
  console.log(`writing ${attendance.length} attendance marks…`);
  await writeMany((rows) => db.attendance.createMany({ data: rows }), attendance);

  /* ── 6 · salaries — every settled month through last month ────────── */
  console.log("settling salaries…");
  const attByEmpMonth = new Map();
  for (const a of attendance) {
    const m = a.date.slice(0, 7);
    const k = a.employeeId + "|" + m;
    const rec = attByEmpMonth.get(k) ?? { present: 0, absent: 0 };
    if (a.status === "present") rec.present++;
    else rec.absent++;
    attByEmpMonth.set(k, rec);
  }
  const months = [];
  {
    let y = 2020, m = 1;
    const cur = new Date(todayStart + IST);
    while (y < cur.getUTCFullYear() || (y === cur.getUTCFullYear() && m < cur.getUTCMonth() + 1)) {
      months.push(`${y}-${String(m).padStart(2, "0")}`);
      m++;
      if (m > 12) { m = 1; y++; }
    }
  }
  const salaryRows = [];
  let spIdx = 0;
  for (const month of months) {
    const [yy, mm] = month.split("-").map(Number);
    const days = new Date(yy, mm, 0).getDate();
    const monthEnd = new Date(Date.UTC(yy, mm, 1) - DAY); // last day of month
    for (const e of employees) {
      const joined = e.createdAt ? new Date(e.createdAt) : new Date("2020-01-01");
      const left = e.active ? null : new Date((LEFT_MAP[e.name] ?? "2024-06-30") + "T23:59:59Z");
      if (joined > monthEnd) continue;
      if (left && left < new Date(Date.UTC(yy, mm - 1, 1))) continue;
      const rec = attByEmpMonth.get(e.id + "|" + month) ?? { present: 0, absent: 0 };
      const paidHolidays = Math.max(0, Math.min(3, rec.absent));
      const cut = Math.max(0, rec.absent - paidHolidays);
      const deduction = r2(cut * (e.salary / days));
      const netPaid = r2(e.salary - deduction);
      salaryRows.push({
        id: `sp${spIdx++}`, employeeId: e.id, month, base: e.salary,
        presentDays: rec.present, absentDays: rec.absent,
        paidHolidays, deduction, netPaid, status: "paid",
        paidAt: new Date(Date.UTC(yy, mm, 1, 5, 0, 0)), paidBy: "OWNER",
      });
    }
  }
  console.log(`writing ${salaryRows.length} salary settlements…`);
  await writeMany((rows) => db.salaryPayment.createMany({ data: rows }), salaryRows);

  /* ── 7 · dress the room wall — a live-looking snapshot ────────────── */
  console.log("dressing the room wall…");
  await db.room.updateMany({
    data: { status: "avl", guestName: null, guestPhone: null, checkInAt: null },
  });
  const occCount = irnd(48, 58);
  const roomNumbers = Array.from({ length: 100 }, (_, i) => i + 1).sort(() => Math.random() - 0.5);
  const occRooms = roomNumbers.slice(0, occCount);
  const mntRooms = roomNumbers.slice(occCount, occCount + 4);
  if (mntRooms.length) {
    await db.room.updateMany({ where: { number: { in: mntRooms } }, data: { status: "mnt" } });
  }
  for (const n of occRooms) {
    await db.room.update({
      where: { number: n },
      data: {
        status: "occ",
        guestName: pick(GUESTS),
        guestPhone: phone(),
        checkInAt: new Date(NOW - rnd(4, 70) * 3_600_000),
      },
    });
  }

  /* make sure the board never ends up with zero fresh work */
  if (openTaskSlots === openSlotsTotal) {
    /* none of the draws fired — reopen the newest task (and undo its spend) */
    const newestDone = await db.task.findFirst({ where: { status: "done" }, orderBy: { createdAt: "desc" } });
    if (newestDone) {
      await db.task.update({
        where: { id: newestDone.id },
        data: {
          status: "open", doneAt: null, doneBy: null, actualCost: null,
          deadline: new Date(NOW + irnd(2, 4) * DAY),
        },
      });
      await db.taskUpdate.deleteMany({ where: { taskId: newestDone.id, author: { not: "Owner" } } });
      await db.expense.deleteMany({ where: { taskId: newestDone.id, via: "task" } });
    }
  }

  /* ── 8 · summary ──────────────────────────────────────────────────── */
  const [b, lb, t, o, e, a, s] = await Promise.all([
    db.bill.count(), db.lodgeBill.count(), db.task.count(), db.task.count({ where: { status: "open" } }),
    db.expense.count(), db.attendance.count(), db.salaryPayment.count(),
  ]);
  console.log("");
  console.log("── REGENERATION SUMMARY ──");
  console.log(`bills: ${b} · lodge bills: ${lb} · expenses: ${e}`);
  console.log(`tasks: ${t} (open: ${o}) · attendance: ${a} · salaries: ${s}`);
  console.log(`rooms: ${occCount} occupied · ${mntRooms.length} maintenance`);
  console.log(`done in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  console.log("── natural regeneration done ──");

  await db.$disconnect();
}

function chunks(arr, n) {
  const out = [];
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
}

/* ISO week key like 2026-W41 (Monday-based) for the weekly task cap */
function isoWeek(dateISO) {
  const [y, m, d] = dateISO.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  const dayNum = (date.getUTCDay() + 6) % 7; // Mon=0
  date.setUTCDate(date.getUTCDate() - dayNum + 3); // Thursday of this week
  const firstThursday = new Date(Date.UTC(date.getUTCFullYear(), 0, 4));
  const fDayNum = (firstThursday.getUTCDay() + 6) % 7;
  firstThursday.setUTCDate(firstThursday.getUTCDate() - fDayNum + 3);
  const week = 1 + Math.round((date.getTime() - firstThursday.getTime()) / (7 * DAY));
  return `${date.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
