/* ── fix-task-windows.mjs ────────────────────────────────────────────────
 * The Tasks board (and dashboard tracker) are DEADLINE windows:
 *   TODAY = deadline IST day == today; 7D/1M/3M/1Y = deadline between
 *   today and the window's last day; LATE = separate tab (deadline<today).
 * The regeneration clustered every open deadline at +1..+4 days, so
 * TODAY was empty and 7D/1M/3M/1Y all showed the same handful.
 *
 * This script redistributes the OPEN tasks across natural horizons so
 * every window gains its own distinct work:
 *   TODAY  2 (rest + lodge, evening deadlines)
 *   +2d    1 · +10d 1 · +26d 1 · +40d 1 · +150d 1
 * → TODAY=2, 7D=3, 1M=5, 3M=6, 1Y=7, LATE=0 (each tab widens the funnel)
 * ───────────────────────────────────────────────────────────────────────── */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const MIN = 60_000, HOUR = 60 * MIN, DAY = 24 * HOUR;
const IST = 330 * 60_000;
// IST wall-clock → UTC instant for a given offset from "today" (IST day)
const istAt = (dayOffset, h, m) => {
  const nowIst = new Date(Date.now() + IST);
  const day0 = Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate());
  return new Date(day0 + dayOffset * DAY + (h * 60 + m) * MIN - IST);
};

console.log("── redistribute open task deadlines ──");

/* 1 · re-deadline the 3 existing opens onto distinct horizons */
const moves = [
  { title: "Refill lobby drinking-water dispenser", deadline: istAt(0, 20, 0) },   // TODAY evening
  { title: "Replace the front-desk chair caster",  deadline: istAt(2, 18, 0) },    // +2d
  { title: "Smart TVs for the luxury wing",        deadline: istAt(40, 17, 0) },   // +40d (3M)
];
for (const m of moves) {
  const r = await db.task.updateMany({ where: { title: m.title, status: "open" }, data: { deadline: m.deadline } });
  console.log(`moved ${r.count} × "${m.title}" → ${m.deadline.toISOString()}`);
}

/* 2 · four new opens covering the empty horizons (owner's voice, desk trails) */
const NEW = [
  {
    title: "Refill the paneer stock for dinner service", book: "rest",
    kind: "raw_material", maxBudget: 2500,
    description: "Fresh stock from the dairy before the 8 pm dinner rush.",
    createdAt: istAt(0, 10, 5), deadline: istAt(0, 20, 30),          // TODAY
    updates: [], // just forwarded this morning
  },
  {
    title: "Plan the Dussehra special thali counter", book: "rest",
    kind: null, maxBudget: null,
    description: "Vijayadashami falls on Oct 20 — plan the counter, prints and extra hands.",
    createdAt: istAt(-2, 11, 0), deadline: istAt(10, 18, 0),         // +10d → 1M
    updates: [{ author: "Restaurant counter", role: "reception_rest",
      message: "Noted — thali draft and print count will reach you by Friday.", at: istAt(-1, 12, 0) }],
  },
  {
    title: "Diwali light-up for the lobby and entrance", book: "lodge",
    kind: "upgrade", maxBudget: 8000,
    description: "Rope lights and lanterns for the facade — Deepavali is Nov 8.",
    createdAt: istAt(-1, 12, 0), deadline: istAt(26, 18, 0),         // +26d → 1M
    updates: [{ author: "Lodge reception", role: "reception_lodge",
      message: "Vendor quote received — 120 metres of rope lights, inside the budget.", at: istAt(0, 11, 30) }],
  },
  {
    title: "Renew the FSSAI food-safety licence", book: "rest",
    kind: "maintenance", maxBudget: 3000,
    description: "Annual renewal — forms, inspection fee and the registration copy.",
    createdAt: istAt(-5, 10, 0), deadline: istAt(150, 17, 0),        // +150d → 1Y
    updates: [],
  },
];

for (const t of NEW) {
  const created = await db.task.create({
    data: {
      title: t.title, book: t.book, kind: t.kind, maxBudget: t.maxBudget,
      description: t.description, deadline: t.deadline, status: "open",
      createdBy: "Owner", createdAt: t.createdAt,
      updates: {
        create: [{
          author: "Owner", role: "owner",
          message: t.maxBudget
            ? `Forwarded with a max budget of ₹${t.maxBudget.toLocaleString("en-IN")} — close with the actual spend.`
            : "Forwarded from the back office — no budget needed, just get it done.",
          createdAt: t.createdAt,
        }],
      },
    },
  });
  for (const u of t.updates) {
    await db.taskUpdate.create({
      data: { taskId: created.id, author: u.author, role: u.role, message: u.message, createdAt: u.at },
    });
  }
  console.log(`created "${t.title}" (${t.book}) deadline=${t.deadline.toISOString()}`);
}

/* 3 · verify the final window funnel (mirrors the UI's IST dayKey math) */
const tasks = await db.task.findMany();
const dayKey = (d) => Math.floor((new Date(d).getTime() + IST) / 86_400_000);
const todayK = dayKey(new Date());
const open = tasks.filter((t) => t.status === "open");
const inWin = (lo, hi) => tasks.filter((t) => { const k = dayKey(t.deadline); return k >= todayK + lo && k <= todayK + hi; }).length;
const late = open.filter((t) => dayKey(t.deadline) < todayK).length;
console.log("\n--- window funnel (after fix) ---");
console.log(`TODAY ${inWin(0, 0)} · 7D ${inWin(0, 6)} · 1M ${inWin(0, 29)} · 3M ${inWin(0, 90)} · 1Y ${inWin(0, 364)} · LATE(open) ${late}`);
console.log(`total tasks ${tasks.length} · open ${open.length}`);

await db.$disconnect();
