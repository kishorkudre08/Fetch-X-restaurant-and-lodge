"use client";

/**
 * Live Dashboard — ported 1:1 from the approved demo (Tasks 30–37):
 * ALL BUSINESS shows every pair as TWO independent book blocks under ONE
 * common header (REVENUE, REVENUE TREND, ONE DAY · TWO ENGINES,
 * REVENUE BREAKDOWN, TEAM); RESTAURANT / LODGE scopes keep single blocks.
 */

import * as React from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Banknote,
  Receipt,
  ShoppingBag,
  Flame,
  KeyRound,
  BedDouble,
  UtensilsCrossed,
  Wallet,
  Clock,
  Hotel,
  ListChecks,
  TrendingDown,
  CalendarCheck,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { FxDatePicker, TierBand } from "@/components/fx";
import { RoomStatusDonut } from "@/components/room-status-donut";
import { useDonutMode } from "@/components/donut-toggle";
import { useToast } from "@/hooks/use-toast";
import type { Bill, CampSend, DashboardData, FxTask, RangeKey } from "@/lib/types";
import { FX_TIERS, tierEyebrow } from "@/lib/tiers";
import { useFxColors } from "@/lib/fx-colors";
import { deltaChip, inr, inr2, istTime, num } from "@/lib/format";
import { useRegisterScreen } from "@/lib/screen-context";
import { useCachedToggle } from "@/lib/view-state-cache";

/* t75 → t76: the old hard-coded purple/gold hexes are gone — every dot, bar,
   donut and chart stroke now reads the account theme through useFxColors(). */

const TABS: Array<{ key: RangeKey; short: string }> = [
  { key: "today", short: "TODAY" },
  { key: "7d", short: "7 DAYS" },
  { key: "1m", short: "1 MONTH" },
  { key: "3m", short: "3 MONTHS" },
  { key: "1y", short: "1 YEAR" },
  // t192 — new long ranges the owner asked for
  { key: "3y", short: "3 YEARS" },
  { key: "lifetime", short: "LIFETIME" },
  { key: "custom", short: "CUSTOM" },
];

const PERIOD: Record<RangeKey, string> = {
  today: "TODAY",
  "7d": "LAST 7 DAYS",
  "1m": "LAST 30 DAYS",
  "3m": "LAST 3 MONTHS",
  "1y": "LAST 12 MONTHS",
  "3y": "LAST 3 YEARS",
  lifetime: "LIFETIME (ALL-TIME)",
  custom: "CUSTOM RANGE",
};

const PREV: Record<RangeKey, string> = {
  today: "yesterday",
  "7d": "previous 7 days",
  "1m": "previous 30 days",
  "3m": "previous 90 days",
  "1y": "previous year",
  "3y": "previous 3 years",
  lifetime: "previous equal-length period",
  custom: "previous equal-length period",
};

type Scope = "all" | "rest" | "lodge";
/* t184 — scope now persisted through useCachedToggle("dashboard","scope")
 * under the fx-vs:* namespace; the legacy SCOPE_KEY constant was retired. */

/* ── micro pieces ─────────────────────────────────────────────────────────── */

function SecHead({
  icon,
  title,
  sub,
  chip,
}: {
  icon?: React.ReactNode;
  title: string;
  sub?: string;
  chip?: string;
}) {
  return (
    <div className="sec-head">
      <span className="sec-t">
        {icon}
        {title}
      </span>
      {sub ? <span className="sec-sub">{sub}</span> : null}
      <span className="hline" />
      {chip ? <span className="mut-chip">{chip}</span> : null}
    </div>
  );
}

function VTag({ kind, label }: { kind: "rest" | "lodge"; label: string }) {
  const C = useFxColors();
  return (
    <span className={`vtag ${kind}`}>
      <i className="scope-dot" style={{ background: kind === "rest" ? C.purple : C.gold }} />
      {label}
    </span>
  );
}

function Pk({ children, mut }: { children: React.ReactNode; mut?: boolean }) {
  return <span className={`pk-chip${mut ? " mut" : ""}`}>{children}</span>;
}

function ic(El: React.ComponentType<{ className?: string }>, cls = "h-3.5 w-3.5") {
  return <El className={cls} />;
}

/* ── charts (recharts, Fetch-X dressed) ───────────────────────────────────── */

function compactINR(v: number): string {
  if (v >= 1e7) return `₹${(v / 1e7).toFixed(1)}Cr`;
  if (v >= 1e5) return `₹${(v / 1e5).toFixed(1)}L`;
  if (v >= 1e3) {
    const k = v / 1e3;
    return `₹${k >= 10 ? Math.round(k) : Math.round(k * 10) / 10}k`;
  }
  return `₹${Math.round(v)}`;
}

type CampCluster = { x: number; y: number; n: number; kind: "personal" | "notice" };

/**
 * t238 — CAMPAIGN DOTS ON THE REAL CURVE. The t237 renderer placed each send's
 * dot at its bucket's own (cx, cy) — right x, but on a SLOPED segment the
 * curve's y at that x is not the bucket's y, so dots floated off the line.
 * This sampler reads the chart's actual rendered curve path (recharts
 * .recharts-area-curve) and drops every dot exactly ON it: invisible anchor
 * circles from the dot renderer give each bucket's true centre, the send's
 * bucket fraction (t237) gives the x, and a binary search over the path's arc
 * length gives the curve's y at that x. Close sends still share one dot
 * (9px merge, halo fattens with the crowd).
 */
function sampleCampClusters(
  root: HTMLElement | null,
  data: Array<{ sends?: CampSend[] }>,
  slicePx: number,
): { clusters: CampCluster[]; sig: string } | null {
  if (!root || slicePx <= 0) return null;
  const svg = root.querySelector("svg.recharts-surface");
  const path = svg?.querySelector(".recharts-area-curve");
  if (!svg || !(path instanceof SVGPathElement)) return null;
  const holders = [...svg.querySelectorAll("circle[data-bucket]")]
    .map((el) => ({
      i: Number(el.getAttribute("data-bucket")),
      x: Number(el.getAttribute("cx") ?? NaN),
      y: Number(el.getAttribute("cy") ?? NaN),
    }))
    .filter((h) => h.i >= 0 && h.i < data.length && Number.isFinite(h.x) && Number.isFinite(h.y))
    .sort((a, b) => a.i - b.i);
  if (holders.length < data.length) return null; // chart not fully painted yet
  const x0 = holders[0].x;
  const xN = holders[holders.length - 1].x;
  const L = path.getTotalLength();
  if (!(L > 0) || !(xN > x0)) return null;
  // length where the TOP curve ends (the outline then runs home along the
  // baseline) — the first arc position that reaches the last bucket's x
  let sTop = -1;
  let prev = 0;
  for (let k = 1; k <= 64 && sTop < 0; k++) {
    const s = (k / 64) * L;
    if (path.getPointAtLength(s).x >= xN - 0.01) {
      let lo = prev;
      let hi = s;
      for (let j = 0; j < 18; j++) {
        const mid = (lo + hi) / 2;
        if (path.getPointAtLength(mid).x >= xN - 0.01) hi = mid;
        else lo = mid;
      }
      sTop = hi;
    }
    prev = s;
  }
  if (sTop <= 0) return null;
  const yOnCurve = (x: number): number => {
    const xc = Math.min(Math.max(x, x0), xN);
    let lo = 0;
    let hi = sTop;
    for (let j = 0; j < 22; j++) {
      const mid = (lo + hi) / 2;
      if (path.getPointAtLength(mid).x < xc) lo = mid;
      else hi = mid;
    }
    return path.getPointAtLength((lo + hi) / 2).y;
  };
  const MERGE_PX = 9; // dots closer than this read as one blob
  const usable = Math.max(slicePx - 6, 0); // keep dots off the slice seams
  const clusters: CampCluster[] = [];
  for (const h of holders) {
    const sends = data[h.i]?.sends ?? [];
    if (!sends.length) continue;
    const placed = sends
      .map((s) => ({ s, x: h.x + (Math.min(Math.max(s.f ?? 0.5, 0), 1) - 0.5) * usable }))
      .sort((a, b) => a.x - b.x);
    const bucketClusters: Array<{ x: number; n: number; kind: "personal" | "notice" }> = [];
    for (const pt of placed) {
      const last = bucketClusters[bucketClusters.length - 1];
      if (last && pt.x - last.x < MERGE_PX) {
        last.x = (last.x * last.n + pt.x) / (last.n + 1); // settle on the crowd's centre
        last.n += 1;
      } else {
        bucketClusters.push({ x: pt.x, n: 1, kind: pt.s.kind });
      }
    }
    for (const c of bucketClusters) clusters.push({ x: c.x, y: yOnCurve(c.x), n: c.n, kind: c.kind });
  }
  return { clusters, sig: clusters.map((c) => `${c.x.toFixed(1)},${c.y.toFixed(1)},${c.n}`).join("|") };
}

/** t238 — paints the campaign dots (sampled ON the curve) above the chart. */
function CampDots({
  rootRef,
  data,
  slicePx,
}: {
  rootRef: React.RefObject<HTMLDivElement | null>;
  data: Array<{ sends?: CampSend[] }>;
  slicePx: number;
}) {
  const [pos, setPos] = React.useState<CampCluster[]>([]);
  React.useEffect(() => {
    let raf = 0;
    let alive = true;
    let stable = 0;
    let lastSig = "";
    let frames = 0;
    const tick = () => {
      if (!alive || ++frames > 900) return; // safety cap — never spin forever
      const res = sampleCampClusters(rootRef.current, data, slicePx);
      if (!res) {
        stable = 0; // chart not ready (mount / resize) — keep looking
      } else if (res.sig !== lastSig) {
        stable = 0;
        lastSig = res.sig;
        setPos(res.clusters); // tracks the entry animation frame by frame
      } else if (++stable >= 10) {
        return; // settled — stop the loop until the next data/slice change
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
    };
  }, [rootRef, data, slicePx]);
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" data-testid="camp-dots-overlay">
      {pos.map((c, i) => (
        <g key={i}>
          <circle cx={c.x} cy={c.y} r={5.5 + Math.min(c.n - 1, 3) * 0.7} fill="var(--fx-purple)" fillOpacity={0.16} />
          <circle
            cx={c.x}
            cy={c.y}
            r={2.6}
            fill={c.kind === "personal" ? "var(--fx-purple)" : "var(--fx-surf)"}
            stroke="var(--fx-purple)"
            strokeWidth={c.kind === "personal" ? 1.2 : 1.6}
          />
        </g>
      ))}
    </svg>
  );
}

function FxTip({
  active,
  payload,
  label,
  fmt,
}: {
  active?: boolean;
  // t235 — payload rows may carry the full data row (payload.camps)
  // t238 — the tip shows the SEND COUNT only; the per-send details moved to
  // the tap strip under the chart (hover must stay light)
  payload?: Array<{ value?: number; payload?: { camps?: number; sends?: CampSend[] } }>;
  label?: string;
  fmt?: (v: number) => string;
}) {
  if (!active || !payload || !payload.length) return null;
  const v = Number(payload[0].value ?? 0);
  const camps = payload[0].payload?.camps ?? 0;
  return (
    <div className="chart-tip">
      <span className="ct-l">{label}</span>
      <span className="ct-v fx-num">{fmt ? fmt(v) : inr(Math.round(v))}</span>
      {/* t238 — hover stays light: the COUNT only. The per-send details live
          in the tap strip under the chart (AreaTrend tap state). */}
      {camps > 0 && (
        <span className="ct-c" style={{ color: "var(--fx-purple)" }}>
          ● {camps} CAMPAIGN {camps === 1 ? "SEND" : "SENDS"} · TAP FOR DETAILS
        </span>
      )}
    </div>
  );
}

function AreaTrend({
  data,
  color,
  fmt,
  tall,
}: {
  // t235 — rows may carry camps: the number of mass-message campaigns that
  // fired inside this bucket (rendered as a small marker dot on the line,
  // styled like the hourly trend's dots but in the campaigning purple)
  // t236 — rows carry the SEND LIST: every send is marked on the line
  // (solid = personal, ring = notice).
  // t237 — each send's dot sits at its true time inside the bucket's slice of
  // the axis, and sends that fired within a small gap share ONE dot — stacked
  // beads used to collide into a blob when campaigns went out back-to-back.
  // t238 — dots are SAMPLED onto the real rendered curve (CampDots), and the
  // per-send details open in a strip under the chart when a bucket is TAPPED
  // (hover shows the count only).
  data: Array<{ label: string; value: number; camps?: number; sends?: CampSend[] }>;
  color: string;
  fmt?: (v: number) => string;
  tall?: boolean;
}) {
  const id = React.useId();
  // t237 — positioning dots inside a bucket's slice needs the pixel width of
  // one slice: measured off the chart box (the Y-axis 54px + margins leave
  // the plot 46px narrower; one slice = plotWidth ÷ bucket count).
  const boxRef = React.useRef<HTMLDivElement | null>(null);
  const [boxW, setBoxW] = React.useState(0);
  React.useEffect(() => {
    const el = boxRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width ?? 0;
      setBoxW((prev) => (Math.abs(prev - w) > 0.5 ? w : prev));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const slicePx = data.length > 0 ? Math.max((boxW - 46) / data.length, 0) : 0;
  // t238 — the tapped bucket whose campaign details are open (-1 = shut)
  const [tap, setTap] = React.useState(-1);
  // t238 — reset on CONTENT change only (labels/camp counts): the dashboard
  // re-fetches every 15s and re-parses the same rows — a fresh array identity
  // must not yank an open strip away while the owner is reading it.
  const dataSig = React.useMemo(
    () => data.map((d) => `${d.label}:${d.camps ?? 0}:${(d.sends ?? []).length}`).join("|"),
    [data],
  );
  React.useEffect(() => setTap(-1), [dataSig]);
  const tapped = tap >= 0 ? data[tap] : null;
  const tappedSends = tapped?.sends ?? [];
  // t238 — NATIVE click handling: any tap/click bubbling out of the chart
  // resolves to its nearest bucket via the anchor circles (mouse, touch and
  // scripted events alike — no reliance on recharts' own onClick plumbing).
  React.useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const onChartClick = (e: MouseEvent) => {
      const holders = el.querySelectorAll("circle[data-bucket]");
      if (!holders.length) return;
      const rect = el.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      let best = -1;
      let bestD = Infinity;
      holders.forEach((h) => {
        const bx = Number(h.getAttribute("cx") ?? NaN);
        if (!Number.isFinite(bx)) return;
        const d = Math.abs(bx - cx);
        if (d < bestD) {
          bestD = d;
          best = Number(h.getAttribute("data-bucket"));
        }
      });
      setTap((prev) => (best >= 0 && (data[best]?.sends?.length ?? 0) > 0 ? (best === prev ? -1 : best) : -1));
    };
    el.addEventListener("click", onChartClick);
    return () => el.removeEventListener("click", onChartClick);
  }, [data]);
  return (
    <>
      <div ref={boxRef} className={`relative cursor-pointer ${tall ? "h-[240px]" : "h-[190px]"}`}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 6, right: 6, left: -14, bottom: 0 }}>
          <defs>
            <linearGradient id={`g${id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.34} />
              <stop offset="100%" stopColor={color} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="var(--fx-line)" strokeDasharray="3 6" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            interval="preserveStartEnd"
            minTickGap={22}
          />
          <YAxis
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: number) => compactINR(v)}
            width={54}
          />
          <Tooltip
            content={<FxTip fmt={fmt} />}
            cursor={{ stroke: color, strokeDasharray: "4 4" }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2.5}
            fill={`url(#g${id})`}
            /* t238 — this renderer only drops INVISIBLE anchor circles now
               (one per bucket, carrying its exact cx/cy): CampDots reads them,
               samples the real rendered curve and paints every campaign dot
               exactly ON the line at its true time (t237 placement + merge). */
            dot={(p: { cx?: number; cy?: number; index?: number }) => (
              <circle key={`nd-${p.index}`} data-bucket={p.index ?? -1} cx={p.cx} cy={p.cy} r={0} />
            )}
            activeDot={{ r: 4, fill: color }}
          />
        </AreaChart>
      </ResponsiveContainer>
      <CampDots rootRef={boxRef} data={data} slicePx={slicePx} />
      </div>
      {/* t238 — campaign details open ON TAP, not on hover: the strip lists
          every send of the tapped bucket (time · kind · reach) and a HIDE
          chip closes it. */}
      {tappedSends.length > 0 && (
        <div
          className="mt-2 rounded-lg border border-[var(--fx-line)] px-3 py-2"
          style={{ background: "color-mix(in srgb, var(--fx-purple) 7%, var(--fx-surf))" }}
          data-testid="camp-send-strip"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="fx-label" style={{ color: "var(--fx-purple)" }}>
              ● {tappedSends.length} CAMPAIGN {tappedSends.length === 1 ? "SEND" : "SENDS"} · {tapped?.label}
            </span>
            <button
              type="button"
              onClick={() => setTap(-1)}
              className="mut-chip inline-flex items-center gap-1"
              data-testid="camp-strip-close"
              aria-label="Hide campaign details"
            >
              {ic(X, "h-3 w-3")} HIDE
            </button>
          </div>
          {tappedSends.slice(0, 6).map((s, i) => (
            <div key={i} className="mt-1 flex flex-wrap items-center gap-x-2 text-[11.5px] font-medium text-[var(--fx-muted)]">
              <span style={{ color: "var(--fx-purple)" }}>{s.kind === "personal" ? "●" : "○"}</span>
              <span className="fx-num">
                {new Date(s.at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "numeric", minute: "2-digit", hour12: true }).toUpperCase()}
              </span>
              <span>{s.kind === "personal" ? "PERSONAL" : "NOTICE"}</span>
              <span>· {num(s.recipients)} WALLETS</span>
            </div>
          ))}
          {tappedSends.length > 6 && (
            <div className="mt-1 text-[11px] font-semibold text-[var(--fx-muted)]">+ {tappedSends.length - 6} MORE SENDS</div>
          )}
        </div>
      )}
    </>
  );
}

function LineTrend({
  data,
  color,
  fmt,
  max,
  tall,
}: {
  data: Array<{ label: string; value: number }>;
  color: string;
  fmt: (v: number) => string;
  max?: number;
  tall?: boolean;
}) {
  return (
    <div className={tall ? "h-[240px]" : "h-[190px]"}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 6, right: 6, left: -14, bottom: 0 }}>
          <CartesianGrid stroke="var(--fx-line)" strokeDasharray="3 6" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            interval="preserveStartEnd"
            minTickGap={22}
          />
          <YAxis
            tick={{ fontSize: 9.5, fontWeight: 700, fill: "var(--fx-muted)" }}
            axisLine={false}
            tickLine={false}
            domain={max ? [0, max] : undefined}
            tickFormatter={(v: number) => fmt(v)}
            width={54}
          />
          <Tooltip content={<FxTip fmt={fmt} />} cursor={{ stroke: color, strokeDasharray: "4 4" }} />
          <Line
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2.5}
            dot={{ r: 2.2, fill: color, strokeWidth: 0 }}
            activeDot={{ r: 4.5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function Donut({
  data,
  colors,
  centerTop,
  centerLabel,
  valueIsMoney = true,
}: {
  data: Array<{ name: string; value: number }>;
  colors: string[];
  centerTop: string;
  centerLabel: string;
  /** t170 — when false, legend values are plain numbers (no ₹ prefix).
   *  Used by the task-completion donut which shows counts, not money. */
  valueIsMoney?: boolean;
}) {
  /* t227 — the shape is UNIVERSAL: one PIE ⇄ DONUT lever in the owner's
     Settings rules every diagram (this hook only reads it). Between modes
     NOTHING on the page may shift — the squeezed legend stays on the right,
     exactly as the owner asked. The figure keeps riding the chart's centre:
     in the ring's hole (donut) or ON the pie, smaller (a pie has no hole). */
  const [mode] = useDonutMode();
  const pie = mode === "pie";
  // the donut hole is 124px wide — scale the figure down as it grows so a
  // ₹4,07,08,000 month never spills over the ring. t227 — in PIE mode the
  // figure rides ON the pie a size smaller, so it sits lightly on the slices.
  const fit = pie
    ? centerTop.length <= 8
      ? 13
      : centerTop.length <= 10
        ? 12
        : centerTop.length <= 12
          ? 11
          : 10
    : centerTop.length <= 8
      ? 20
      : centerTop.length <= 10
        ? 17
        : centerTop.length <= 12
          ? 15
          : 13;
  /* t146 — every numeral in the legend also shows the share of the ring's
     total it occupies (user: "*NUMERALS* also show the % of total revenue
     they occupy"). ≥10% rounds whole, below shows 1 decimal, .0 trimmed. */
  const ringTotal = data.reduce((s, d) => s + d.value, 0) || 1;
  const pct = (v: number) => {
    const p = (v / ringTotal) * 100;
    return `${p >= 10 ? String(Math.round(p)) : p.toFixed(1).replace(/\.0$/, "")}%`;
  };
  /* t229 → t230 — the hover deal is FLIPPED: the centre figure never moves
     anymore — the TOOLTIP is what steps outside. Hovering a slice prints the
     tooltip (category · value · share) on the floating pill just ABOVE the
     chart box, outside the figure, so the two can never collide. Mouse off
     the slice, the pill fades. */
  const [hovIdx, setHovIdx] = React.useState<number | null>(null);
  const figure = (
    <>
      <div
        className="dc-v fx-num whitespace-nowrap"
        style={{ fontSize: `${fit}px`, letterSpacing: "-0.02em" }}
      >
        {centerTop}
      </div>
      <div className="fx-label">{centerLabel}</div>
    </>
  );
  return (
    <div>
      <div className="donut-flex">
        {/* t126 — FIXED-SIZE chart (no ResponsiveContainer): the ring renders at
           exactly 240×170 on every screen, zoom and DPR — the two revenue-split
           donuts can never come out different sizes again */}
        <div className="donut-w">
          {/* t230 — the TOOLTIP pill: hovers OUTSIDE the figure, above the
              chart; the centre text below stays put the whole time */}
          <span className={`donut-out${hovIdx !== null ? " is-on" : ""}`} aria-hidden={hovIdx === null}>
            {hovIdx !== null && data[hovIdx] ? (
              <>
                <span className="ct-l">{data[hovIdx].name}</span>
                <span className="ct-v fx-num">
                  {valueIsMoney ? inr(Math.round(data[hovIdx].value)) : num(Math.round(data[hovIdx].value))} · {pct(data[hovIdx].value)}
                </span>
              </>
            ) : null}
          </span>
          <PieChart width={240} height={170} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <Pie
              data={data}
              dataKey="value"
              innerRadius={pie ? 0 : 62}
              outerRadius={84}
              paddingAngle={2}
              stroke="none"
              onMouseEnter={(_: unknown, i: number) => setHovIdx(i)}
              onMouseLeave={() => setHovIdx(null)}
            >
              {data.map((_, i) => (
                <Cell key={i} fill={colors[i % colors.length]} />
              ))}
            </Pie>
          </PieChart>
          {/* t227 — the figure rides the chart's centre in BOTH shapes: in the
             ring's hole (donut) or ON the pie, one size smaller, on a soft
             chip so it stays readable over the solid slices (pie — no hole).
             t230 — it NEVER moves, not even on hover; the tooltip is what
             goes outside (the pill above the chart). */}
          <div className="donut-c">
            <div className={pie ? "on-pie" : undefined}>{figure}</div>
          </div>
        </div>
        <div className="donut-legend">
          {data.map((d, i) => (
            <div className="dl-row" key={d.name}>
              <i className="scope-dot" style={{ background: colors[i % colors.length] }} />
              {d.name}
              <span className="dl-v fx-num">
                {valueIsMoney ? inr(Math.round(d.value)) : num(Math.round(d.value))}
                <span className="ml-1 whitespace-nowrap text-[9px] font-bold text-[var(--fx-muted)]">
                  · {pct(d.value)}
                </span>
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── stat card with optional net-profit line (the revenue duo) ────────────── */

function Stat({
  label,
  value,
  icon,
  delta,
  footnote,
  gold,
  net,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  delta?: { text: string; up: boolean } | null;
  footnote?: string;
  gold?: boolean;
  net?: number;
}) {
  return (
    <div className="fx-card fx-pop fx-rise px-5 py-4">
      <div className="flex items-center justify-between gap-3">
        <span className="fx-label">{label}</span>
        <span
          className={`grid h-8 w-8 place-items-center rounded-xl ${
            gold ? "bg-[color-mix(in_srgb,var(--fx-gold)_16%,transparent)] text-[var(--fx-gold)]" : "bg-[var(--fx-lav)] text-[var(--fx-accent-ink)]"
          }`}
        >
          {icon}
        </span>
      </div>
      <div className="d-val fx-num mt-2 text-2xl font-extrabold tracking-tight text-[var(--fx-ink)] md:text-[26px]">
        {value}
      </div>
      <div className="mt-1 h-4 text-[11px] font-semibold">
        {delta ? (
          <span className={delta.up ? "text-[var(--fx-green)]" : "text-[var(--fx-rose)]"}>{delta.text}</span>
        ) : (
          <span className="text-[var(--fx-muted)]">{footnote ?? ""}</span>
        )}
      </div>
      {typeof net === "number" ? (
        <div className="mt-1.5">
          <span className="net-mini" style={net < 0 ? { color: "var(--fx-rose)" } : undefined}>
            NET PROFIT · {inr(net)}
          </span>
        </div>
      ) : null}
    </div>
  );
}

/* ── cost book card (REVENUE BREAKDOWN pair) ─────────────────────────────── */

type CostRow = { label: string; note: string; amount: number; color: string };

function BookCard({
  title,
  tag,
  kind,
  rev,
  rows,
  net,
  margin,
  note,
}: {
  title: string;
  tag: string;
  kind: "rest" | "lodge";
  rev: number;
  rows: CostRow[];
  net: number;
  margin: number | null;
  note: string;
}) {
  // t168 — bars are scaled relative to REVENUE (not relative to the max
  // cost), so each bar visually matches its % of revenue. The old algorithm
  // used (amount / maxCost) * 100 which made the largest cost always 100%
  // wide even if it was only 33% of revenue — confusing.
  return (
    <div className="fx-card fx-rise p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          {ic(Wallet)}
          {title}
        </span>
        <span className="flex flex-wrap items-center gap-1.5">
          <VTag kind={kind} label={tag} />
          {margin !== null ? <span className="mut-chip">{margin}% MARGIN</span> : null}
        </span>
      </div>
      <div className="bd-rows mt-4">
        <div className="bd-row">
          <div className="bd-top">
            <span className="bd-l">TOTAL REVENUE</span>
            <span className="flex items-baseline gap-2">
              <span className="bd-v rev fx-num">{inr(rev)}</span>
              <span className="text-[10px] font-bold text-[var(--fx-muted)]">100%</span>
            </span>
          </div>
          <div className="bd-bar">
            <i style={{ width: "100%", background: kind === "rest" ? "var(--fx-chart-a)" : "var(--fx-gold-hi)" }} />
          </div>
        </div>
        {rows.map((r) => {
          const pct = rev > 0 ? Math.round((r.amount / rev) * 100) : 0;
          return (
            <div className="bd-row" key={r.label}>
              <div className="bd-top">
                <span className="bd-l">
                  {r.label}
                  <span className="bd-note">{r.note}</span>
                </span>
                <span className="flex items-baseline gap-2">
                  <span className="bd-v fx-num">− {inr(r.amount)}</span>
                  <span className="text-[10px] font-bold text-[var(--fx-muted)]">{pct}%</span>
                </span>
              </div>
              <div className="bd-bar">
                <i style={{ width: `${Math.max(2, Math.min(100, pct))}%`, background: r.color }} />
              </div>
            </div>
          );
        })}
      </div>
      <div className="bd-total">
        <span className="fx-label">NET PROFIT</span>
        <span className="bt-v fx-num" style={{ color: net >= 0 ? "var(--fx-green)" : "var(--fx-rose)" }}>
          {inr(net)}
        </span>
      </div>
      <p className="mt-2 text-[11.5px] font-medium leading-relaxed text-[var(--fx-muted)]">{note}</p>
    </div>
  );
}

/* ── t117 — the REVENUE SPLIT donut that sits just above each REVENUE BREAKDOWN
   band card: that book's total revenue divided into its four cost heads
   (raw materials · upgrades · maintenance · employee salaries).
   t118 — NET PROFIT joins the ring: whatever the costs leave behind is the
   fifth slice (green), so the ring now accounts for EVERY rupee of the book's
   revenue — costs first, the owner's take last. A loss shows a note instead. ── */

function CostDonutCard({
  tag,
  kind,
  rev,
  rows,
  centerLabel,
}: {
  tag: string;
  kind: "rest" | "lodge";
  rev: number;
  rows: CostRow[];
  centerLabel: string;
}) {
  const costs = rows.reduce((s, r) => s + r.amount, 0);
  const net = Math.round((rev - costs) * 100) / 100;
  const slices = [
    ...rows.map((r) => ({ name: r.label, value: r.amount })),
    ...(net > 0 ? [{ name: "NET PROFIT", value: net }] : []),
  ];
  const colors = [...rows.map((r) => r.color), ...(net > 0 ? ["var(--fx-green)"] : [])];
  return (
    <div className="fx-card fx-rise flex h-full flex-col p-5" data-testid={`rev-split-donut-${kind}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          {ic(Wallet)}
          REVENUE SPLIT
        </span>
        <VTag kind={kind} label={tag} />
      </div>
      <p className="mt-1 text-[11.5px] font-medium leading-relaxed text-[var(--fx-muted)]">
        {tag === "RESTAURANT" ? "The kitchen's" : "The rooms'"} total revenue divided across its cost heads — with the net profit left over — so every rupee of this book is on the ring.
      </p>
      <div className="my-auto mt-3 pt-3">
        {rev > 0 || costs > 0 ? (
          <Donut
            data={slices}
            colors={colors}
            centerTop={inr(rev)}
            centerLabel={centerLabel}
          />
        ) : (
          <p className="py-10 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
            NO REVENUE OR COSTS YET — the split appears the moment this book records its first entry.
          </p>
        )}
      </div>
      {net <= 0 && costs > 0 && (
        <p className="mt-2 rounded-xl bg-[color-mix(in_srgb,var(--fx-rose)_8%,transparent)] px-3 py-2 text-[11px] font-bold text-[var(--fx-rose)]">
          THIS BOOK RAN AT A LOSS OF {inr(Math.abs(net))} IN THIS WINDOW — costs outweighed revenue.
        </p>
      )}
    </div>
  );
}

/* ── t150 — the t133 DISCOUNT HISTORY tables (restaurant + lodge) are REMOVED
   from the live dashboard at the owner's ask: the DiscountHistoryCard and its
   render slot below are gone. The discount money still shows where it always
   did — the DISCOUNTS GIVEN lines of each book's revenue breakdown — only the
   per-bill history feed is out. The API still returns discountLog untouched. */

/* ── t98 — horizontal task-rate bars (moved from the tasks board) ────────── */

function RateBar({
  label,
  pct,
  sub,
  color,
  testId,
}: {
  label: string;
  pct: number;
  sub: string;
  color: string;
  testId: string;
}) {
  return (
    <div data-testid={testId}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="fx-label">{label}</span>
        <span className="fx-num text-[15px] font-extrabold tracking-tight text-[var(--fx-ink)]">{pct}%</span>
      </div>
      <div
        className="mt-1.5 h-[14px] overflow-hidden rounded-full"
        style={{ background: "var(--fx-track)" }}
        role="meter"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={pct}
        aria-label={label}
      >
        <i
          className="dash-rate-fill block h-full rounded-full"
          style={{ width: `${Math.max(pct > 0 ? 4 : 0, Math.min(100, pct))}%`, background: color }}
        />
      </div>
      <div className="mt-1 text-[10px] font-bold tracking-[0.05em] text-[var(--fx-muted)]">{sub}</div>
    </div>
  );
}

function TaskRateCard({
  book,
  title,
  stats,
}: {
  book: "rest" | "lodge";
  title: string;
  stats: { total: number; done: number; completionPct: number; completed: number; lateCompleted: number; notCompleted: number; lateNotCompleted: number; assumed: number; spent: number; budgetPct: number };
}) {
  const C = useFxColors();
  // t169/t170 — task completion donut: 4 slices. t170 — keep ALL slices
  // (even 0-value ones like LATE COMPLETED) so the user sees every category.
  const completionData = [
    { name: "COMPLETED", value: stats.completed },
    { name: "LATE COMPLETED", value: stats.lateCompleted },
    { name: "INCOMPLETE", value: stats.notCompleted },
    { name: "LATE INCOMPLETE", value: stats.lateNotCompleted },
  ];
  const completionColors = ["var(--fx-green)", "var(--fx-amber)", book === "rest" ? C.purple : C.gold, "var(--fx-rose)"];
  return (
    <div className="fx-card fx-rise p-5" data-testid={`dash-tasks-${book}`} data-fx-motion="1">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-1.5">
          <ListChecks className="h-3.5 w-3.5" /> TASKS · {title}
        </span>
        <span className="flex flex-wrap items-center gap-1.5">
          <VTag kind={book} label={book === "rest" ? "FOOD & BEV" : "ROOMS & STAYS"} />
          <span className="mut-chip">{stats.total} FORWARDED</span>
        </span>
      </div>
      {/* t169 — task completion as a DONUT (was a horizontal bar).
          4 slices: completed (green), late completed (amber),
          not completed (purple/gold), late & open (rose). */}
      <div className="mt-4">
        <span className="fx-label">TASK COMPLETION</span>
        {stats.total > 0 ? (
          <div className="donut-flex mt-2">
            <Donut
              data={completionData}
              colors={completionColors}
              centerTop={`${stats.completionPct}%`}
              centerLabel="CLOSED"
              valueIsMoney={false}
            />
          </div>
        ) : (
          <p className="py-6 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
            NO TASKS FORWARDED IN THIS WINDOW
          </p>
        )}
      </div>
      {/* Budget utilization stays as a horizontal bar (unchanged) */}
      <div className="mt-4">
        <RateBar
          label="BUDGET UTILIZATION RATE"
          pct={stats.budgetPct}
          sub={stats.assumed ? `${inr(stats.spent)} OF ${inr(stats.assumed)} SPENT` : "NO BUDGETED TASKS IN THIS WINDOW"}
          color={book === "rest" ? C.purple : C.gold}
          testId={`dash-bar-budget-${book}`}
        />
      </div>
      <p className="mt-3 text-[11.5px] font-medium leading-relaxed text-[var(--fx-muted)]">
        The donut shows task completion — green is closed on time, amber is closed late, {" "}
        {book === "rest" ? "purple" : "gold"} is incomplete (deadline not yet passed), rose is
        late incomplete (overdue, still open). Budget utilization below shows how much of the owner's assumed
        consumed.
      </p>
    </div>
  );
}

/* ── t120 · attendance graph card (bottom of the live dashboard) ───────────── */

type AttStats = {
  range: RangeKey;
  days: number;
  from: string;
  to: string;
  employees: Array<{
    id: string;
    name: string;
    role: string;
    book: "rest" | "lodge";
    present: number;
    absent: number;
    absentMarked?: number;
    unmarked?: number;
    total: number;
  }>;
  insights?: AbsenceInsights | null;
};

/* t2xx — the API's absence-intelligence block: real-row answers to the
   owner's "why are employees very absent?" — marked leave vs unmarked days,
   weekday rhythm, heaviest dates and per-employee rates. */
type AbsenceInsights = {
  windowStart: string;
  windowEnd: string;
  days: number;
  requestedDays: number;
  clamped: boolean;
  employees: number;
  markedDays: number;
  unmarkedDays: number;
  markedAbsent: number;
  markedPresent: number;
  absenceRatePct: number;
  unmarkedPct: number;
  byWeekday: Array<{ label: string; present: number; absent: number; ratePct: number | null }>;
  topDates: Array<{ date: string; absent: number; present: number }>;
  perEmployee: Array<{
    id: string;
    name: string;
    role: string;
    book: "rest" | "lodge";
    present: number;
    absent: number;
    absentMarked: number;
    unmarked: number;
    days: number;
    ratePct: number;
  }>;
};

/* t124 — the graph splits into TWO panels: restaurant on the LEFT, lodge on the
   RIGHT (stacked on small screens). Bar direction stays left-to-right. The
   separate employee list is gone — the graph itself carries every name. */
/* t138 — the owner asked to divide the blended attendance wall into TWO
   SEPARATE cards with their own motions ("divide that block into 2 … I want
   their separate motions"). Each book now owns a full .fx-card of its own:
   independent fx-rise entrance (staggered via data-fx-delay — restaurant pops
   first, lodge answers 70ms later) and independent cursor drift, because
   FxMotion arms and follows every .fx-card element individually. */
function AttendanceCard({ stats, scope }: { stats: AttStats | null; scope: Scope }) {
  if (!stats) return null;
  const restRows = (stats?.employees ?? []).filter((e) => e.book === "rest");
  const lodgeRows = (stats?.employees ?? []).filter((e) => e.book === "lodge");

  /* ALL BUSINESS — two independent book cards, side by side (stacked on small screens) */
  const wall =
    scope === "all" ? (
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2" data-testid="attendance-graph">
        <AttCard book="rest" rows={restRows} days={stats.days} delay={0} />
        <AttCard book="lodge" rows={lodgeRows} days={stats.days} delay={1} />
      </div>
    ) : (
      /* single-book scope — that book's card alone, full width */
      <AttCard
        book={scope}
        rows={scope === "rest" ? restRows : lodgeRows}
        days={stats.days}
        delay={0}
      />
    );

  return (
    <div className="flex flex-col gap-5">
      {wall}
    </div>
  );
}

/* one book's OWN card — its own border, header, entrance pop and cursor drift;
   same left-to-right bars; per-book PRESENT/ABSENT total chips were removed at
   t129; numbers live in the hover tooltip */
function AttCard({ book, rows, days, delay }: { book: "rest" | "lodge"; rows: AttStats["employees"]; days: number; delay: number }) {
  const title = book === "rest" ? "RESTAURANT" : "LODGE";
  /* t229 — the card's average attendance % across THIS window (present ÷
     total marked days), so the 70–90% band is visible at a glance. */
  const avgPct =
    rows.length && days
      ? Math.round((rows.reduce((s, e) => s + e.present, 0) / (rows.length * days)) * 100)
      : null;
  return (
    <div className="fx-card fx-rise p-5" data-fx-delay={delay} data-testid={`attendance-graph-${book}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="fx-label inline-flex items-center gap-2">
          {ic(CalendarCheck)}
          ATTENDANCE · {title} · {days} {days === 1 ? "DAY" : "DAYS"}
        </span>
        <span className="mut-chip">{days} TOTAL DAYS / EMPLOYEE</span>
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <VTag kind={book} label={title} />
        <span className="flex items-center gap-1.5">
          {/* t229 — the owner asked the average to hold the 70–90% band: it
              lives on the card now, per book, computed on the same window. */}
          <span
            className="mut-chip"
            data-testid={`att-avg-${book}`}
            style={
              avgPct !== null && (avgPct < 70 || avgPct > 90)
                ? { color: "var(--fx-rose)" }
                : { color: "var(--fx-green)" }
            }
          >
            AVG ATTENDANCE · {avgPct}%
          </span>
          <span className="mut-chip">{rows.length} EMPLOYEES</span>
        </span>
      </div>
      <div className="mt-3 space-y-2" data-testid={`attendance-graph-bars-${book}`}>
        {rows.length === 0 && (
          <p className="py-6 text-center text-[11.5px] font-semibold text-[var(--fx-muted)]">
            No employees in this book yet — add them in the Employee section.
          </p>
        )}
        {rows.map((e) => {
          const pPct = days ? (e.present / days) * 100 : 0;
          const aPct = days ? (e.absent / days) * 100 : 0;
          return (
            <div key={e.id} className="att-row group relative flex items-center gap-3" data-testid={`att-row-${e.name.toLowerCase().replace(/[^a-z]+/g, "-")}`}>
              <span className="w-[118px] shrink-0 truncate text-[11.5px] font-bold text-[var(--fx-ink)]" data-tip={e.name}>
                {e.name}
              </span>
              <span className="flex h-5 flex-1 overflow-hidden rounded-lg bg-[var(--fx-lav)]" aria-hidden>
                <span className="h-full transition-all" style={{ width: `${pPct}%`, background: "var(--fx-green)" }} />
                <span className="h-full transition-all" style={{ width: `${aPct}%`, background: "var(--fx-rose)" }} />
              </span>
              {/* hover tooltip — the full sentence the owner asked for.
                  t127 — text uses --fx-page (defined in ALL 20 themes) — the old
                  --fx-paper never existed, so the text inherited the ink color and
                  the pill read as a solid black box with no words in it.
                  t129 — opacity is ALSO driven by a plain .att-row:hover rule in
                  globals.css that is NOT gated behind @media(hover:hover) —
                  Tailwind v4 gates group-hover that way, which killed the tooltip
                  on devices that report hover:none (user had to CLICK for it). */}
              <span className="att-tip pointer-events-none absolute -top-8 right-0 z-30 rounded-xl bg-[var(--fx-ink)] px-3 py-1.5 text-[10px] font-extrabold tracking-[0.06em] text-[var(--fx-page)] opacity-0 shadow-[2px_3px_0_0_rgba(0,0,0,0.25)] transition-opacity">
                {e.present} present, {e.absent} absent · {e.total} total days
              </span>
            </div>
          );
        })}
      </div>
      <p className="mt-2 text-[10.5px] font-semibold text-[var(--fx-muted)]">
        {book === "rest"
          ? "The restaurant's own attendance wall — hover a bar for the exact split: green is present, red is absent."
          : "The lodge's own attendance wall — hover a bar for the exact split: green is present, red is absent."}{" "}
        Total days always equal the selected window — 1 day today, 7 a week, the month's true length, ~91 three months, 365 a year — so every employee is measured on the SAME calendar.
      </p>
    </div>
  );
}

/* ── small helpers ───────────────────────────────────────────────────────── */

function fmtHrsLabel(hours: number): string {
  const mins = Math.max(0, Math.round(hours * 60));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  let txt = h >= 24 ? `${Math.floor(h / 24)} d ${h % 24} h` : `${h} h`;
  if (m) txt += ` ${m} m`;
  return txt;
}

type Wall = {
  rooms: Array<{ number: number; status: string; guestName: string | null; checkInAt: string | null }>;
  bills: Bill[];
  levels: Array<{ from: number; to: number; rate: number; name: string }>;
  counts: { occ: number; mnt: number; avl: number };
  tonight: number;
};

/* ── the view ────────────────────────────────────────────────────────────── */

export function DashboardView({
  onRangeChange,
}: {
  onGoToPos?: () => void;
  onRangeChange: (r: RangeKey) => void;
}) {
  // t184 — both toggles (range + scope) now persist across section switches
  // AND live-update when the AI writes a hint ("open dashboard in yearly
  // view" → range=1y is written to cache before navigation, the dashboard
  // either reads it on mount or — if already mounted — gets it via the
  // in-memory pub/sub inside useCachedToggle).
  const [range, setRange] = useCachedToggle<RangeKey>("dashboard", "range", "today");
  const [scope, setScope] = useCachedToggle<Scope>("dashboard", "scope", "all");
  // Expose both toggles to the AI's screen context so it can answer
  // "what am I looking at?" with the full view state.
  useRegisterScreen("dashboard", "Live Dashboard", { range, scope });
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [wall, setWall] = React.useState<Wall | null>(null);
  const [tasks, setTasks] = React.useState<FxTask[]>([]);
  const [failed, setFailed] = React.useState(false);
  const { toast } = useToast();
  const C = useFxColors();

  // t194 — read the master toggle from Settings. When OFF, the CUSTOM tab
  // is hidden from the dashboard (the owner only sees standard ranges).
  const [useCustomRange] = useCachedToggle<boolean>("global", "useCustomRange", false);

  // t193 — custom date range now lives in Settings (global).
  const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const [customStart, setCustomStart] = useCachedToggle<string>("global", "customStart", "2020-01-01");
  const [customEnd, setCustomEnd] = useCachedToggle<string>("global", "customEnd", todayISO());

  const load = React.useCallback(async (r: RangeKey) => {
    try {
      let url = `/api/dashboard?range=${r}`;
      if (r === "custom") {
        if (!customStart || !customEnd) return; // owner hasn't picked yet
        url += `&start=${customStart}&end=${customEnd}`;
      }
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error("bad status");
      setData(await res.json());
      setFailed(false);
    } catch {
      setFailed(true);
    }
  }, [customStart, customEnd]);

  React.useEffect(() => {
    void load(range);
    onRangeChange(range);
    const t = setInterval(() => void load(range), 15000);
    return () => clearInterval(t);
  }, [range, load, onRangeChange]);

  // t192 — when the custom start/end change, reload (only if range=custom)
  React.useEffect(() => {
    if (range === "custom" && customStart && customEnd) void load("custom");
  }, [customStart, customEnd, range, load]);

  React.useEffect(() => {
    fetch("/api/lodge", { cache: "no-store" })
      .then((r) => r.json())
      .then(setWall)
      .catch(() => { /* wall is optional on the dashboard */ });
  }, [data?.lodge.inHouse, data?.lodge.mnt]);

  /* t98 — the task board feeds the horizontal rate bars above the team list */
  React.useEffect(() => {
    const loadTasks = () =>
      fetch("/api/tasks", { cache: "no-store" })
        .then((r) => r.json())
        .then((d) => setTasks(d.tasks ?? []))
        .catch(() => { /* bars are optional */ });
    loadTasks();
    const t = setInterval(loadTasks, 20000);
    return () => clearInterval(t);
  }, []);

  /* t120 — attendance graph data: consistent per-employee day math (window =
     the selected dashboard range; total days = 1 · 7 · 30 · 91 · 365). */
  const [att, setAtt] = React.useState<AttStats | null>(null);
  React.useEffect(() => {
    let live = true;
    const loadAtt = () =>
      fetch(`/api/attendance/stats?range=${range}`, { cache: "no-store" })
        .then((r) => r.json())
        .then((j) => { if (live) setAtt(j); })
        .catch(() => { /* attendance graph is optional */ });
    loadAtt();
    const t = setInterval(loadAtt, 30000);
    return () => { live = false; clearInterval(t); };
  }, [range]);

  const setRangeSafe = (k: RangeKey) => setRange(k);

  if (failed && !data) {
    return (
      <div className="flex flex-col gap-5">
        <TierBand num={FX_TIERS.dashboard.num} eyebrow={tierEyebrow(FX_TIERS.dashboard)} title="Live Dashboard" sub="Could not reach the kitchen — check the connection and retry." />
        <div className="fx-card grid place-items-center px-6 py-20 text-center">
          <div>
            <div className="fx-label">SIGNAL LOST</div>
            <Button className="mt-4 rounded-xl" onClick={() => void load(range)}>RETRY NOW</Button>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex flex-col gap-5">
        <TierBand num={FX_TIERS.dashboard.num} eyebrow={tierEyebrow(FX_TIERS.dashboard)} title="Live Dashboard" sub="Every bill and every stay feeds this wall by itself." />
        <div className="fx-card grid place-items-center px-6 py-20 text-center">
          <div className="flex flex-col items-center gap-3">
            <span className="fx-label flex items-center gap-2"><Clock className="h-3.5 w-3.5 animate-pulse" /> LOADING FETCH-X…</span>
          </div>
        </div>
      </div>
    );
  }

  const R = data;
  const L = data.lodge;
  const staffRest = (data.team?.employees ?? []).filter((e) => e.book === "rest");
  const staffLodge = (data.team?.employees ?? []).filter((e) => e.book === "lodge");
  const revTot = data.stats.revenue + L.revenue;
  const rp = revTot > 0 ? Math.round((data.stats.revenue / revTot) * 100) : 50;
  const period = PERIOD[range];
  const inrFmt = (v: number) => inr(Math.round(v));
  const pctFmt = (v: number) => `${Math.round(v)}%`;

  // t235 — the trend rows carry the campaign-send counts so AreaTrend can
  // drop its marker dots (and the tooltip can count the sends)
  // t236 — rows carry the full SEND LIST so every send is marked
  // t237 — each send rides its bucket fraction `f` for true-time placement
  const trendRest = (data.buckets ?? []).map((b) => ({ label: b.label, value: b.revenue, camps: b.camps ?? 0, sends: b.sends ?? [] }));
  const trendLodge = (L.buckets ?? []).map((b) => ({ label: b.label, value: b.revenue, camps: b.camps ?? 0, sends: b.sends ?? [] }));
  const campsInRange = (data.buckets ?? []).reduce((s, b) => s + (b.camps ?? 0), 0) + (L.buckets ?? []).reduce((s, b) => s + (b.camps ?? 0), 0);
  const CampMark = () => (
    <span className="mut-chip inline-flex items-center gap-1.5" data-testid="dash-campaign-mark-legend">
      <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: "var(--fx-purple)" }} />
      CAMPAIGN SENDS · ONE DOT EACH · CLOSE SENDS SHARE
      <span className="ml-1 inline-block h-2 w-2 rounded-full border-[1.5px]" style={{ borderColor: "var(--fx-purple)" }} />
      <span className="inline-block h-2 w-2 rounded-full" style={{ background: "var(--fx-purple)" }} />
      RING NOTICE · SOLID PERSONAL
    </span>
  );
  const hourlyRest = (data.hourly?.series ?? []).map((s) => ({ label: s.label, value: s.avg }));
  const dayCurve = (L.dayCurve ?? []).map((c) => ({ label: c.label, value: c.pct }));

  /* t98/t169 — per-book task rates inside the selected window.
     t169 — task completion now broken into 4 categories for a donut:
       completed (done on time), lateCompleted (done past deadline),
       notCompleted (open, deadline not yet passed), lateNotCompleted (open, overdue) */
  const RANGE_DAYS: Record<RangeKey, number> = { today: 1, "7d": 7, "1m": 30, "3m": 91, "1y": 365, "3y": 1095, lifetime: 365 * 50, custom: 30 };
  const since = Date.now() - RANGE_DAYS[range] * 86_400_000;
  const nowMs = Date.now();
  const taskStatsOf = (book: "rest" | "lodge") => {
    const list = tasks.filter((t) => t.book === book && new Date(t.createdAt).getTime() >= since);
    const done = list.filter((t) => t.status === "done");
    const open = list.filter((t) => t.status === "open");
    // 4-way breakdown
    const completed = done.filter((t) => {
      const dl = new Date(t.deadline).getTime() + 86_400_000; // deadline + 1 day grace
      const doneAt = t.doneAt ? new Date(t.doneAt).getTime() : nowMs;
      return doneAt <= dl;
    }).length;
    const lateCompleted = done.length - completed;
    const notCompleted = open.filter((t) => new Date(t.deadline).getTime() + 86_400_000 >= nowMs).length;
    const lateNotCompleted = open.length - notCompleted;
    const budgeted = list.filter((t) => t.maxBudget !== null);
    const assumed = budgeted.reduce((s, t) => s + (t.maxBudget ?? 0), 0);
    const spent = budgeted.reduce((s, t) => s + (t.actualCost ?? 0), 0);
    return {
      total: list.length,
      done: done.length,
      completionPct: list.length ? Math.round((done.length / list.length) * 100) : 0,
      completed,
      lateCompleted,
      notCompleted,
      lateNotCompleted,
      assumed,
      spent,
      budgetPct: assumed ? Math.round((spent / assumed) * 100) : 0,
    };
  };
  const restTaskStats = taskStatsOf("rest");
  const lodgeTaskStats = taskStatsOf("lodge");

  /* scope chips row */
  const scopeRow = (
    <div className="fx-card flex flex-wrap items-center gap-2.5 p-3" role="tablist" aria-label="Business view">
      <span className="fx-label inline-flex items-center gap-1.5">{ic(Hotel, "h-3.5 w-3.5")}BUSINESS VIEW</span>
      {([
        { id: "all", label: "ALL BUSINESS", dot: `linear-gradient(90deg,${C.purple} 50%,${C.gold} 50%)` },
        { id: "rest", label: "RESTAURANT", dot: C.purple },
        { id: "lodge", label: "LODGE", dot: C.gold },
      ] as const).map((c) => (
        <button
          key={c.id}
          role="tab"
          aria-selected={scope === c.id}
          onClick={() => setScope(c.id)}
          className={`scope-chip${scope === c.id ? " on" : ""}`}
        >
          <i className="scope-dot" style={{ background: c.dot }} />
          {c.label}
        </button>
      ))}
      <span className="scope-spacer" />
      {scope === "all" ? (
        <>
          <span className="split-leg"><i className="scope-dot" style={{ background: C.purple }} />RESTAURANT {rp}%</span>
          <span className="split-bar" aria-hidden>
            <i style={{ width: `${rp}%`, background: C.purple }} />
            <i style={{ width: `${100 - rp}%`, background: C.gold }} />
          </span>
          <span className="split-leg"><i className="scope-dot" style={{ background: C.gold }} />LODGE {100 - rp}%</span>
          <span className="mut-chip">{inr(revTot)} COMBINED</span>
        </>
      ) : (
        <span className="mut-chip">{scope === "rest" ? "FOOD & BEV ONLY" : "ROOMS & STAYS ONLY"} · {period}</span>
      )}
    </div>
  );

  /* range tabs — t194: the CUSTOM tab only appears when the Settings
     toggle is ON. When OFF, the owner just sees standard ranges. */
  // t194 — CUSTOM tab is always visible. The Settings toggle controls
  // whether the INLINE DATE PICKER appears (not whether the tab shows).
  const visibleTabs = TABS;
  const tabs = (
    <div className="fx-card inline-flex flex-wrap items-center gap-1.5 p-1.5" role="tablist" aria-label="Dashboard time range">
      {visibleTabs.map((t) => (
        <button
          key={t.key}
          role="tab"
          aria-selected={range === t.key}
          onClick={() => setRangeSafe(t.key)}
          className={`rounded-xl px-4 py-2.5 text-[11px] font-extrabold tracking-[0.08em] transition ${
            range === t.key
              ? "bg-[var(--fx-purple)] text-[var(--fx-on-accent)] shadow-[2px_2px_0_0_var(--fx-hard)]"
              : "text-[var(--fx-muted)] hover:bg-[var(--fx-lav)] hover:text-[var(--fx-ink)]"
          }`}
        >
          {t.short}
        </button>
      ))}
      {/* t194 — when range=custom:
          toggle ON  → show INLINE date pickers (FROM/TO) right here in the dashboard
          toggle OFF → show a hint chip pointing to Settings (dates pre-set there) */}
      {range === "custom" && useCustomRange && (
        <div className="ml-2 flex items-center gap-2 rounded-xl border border-[var(--fx-line)] bg-[var(--fx-surf)] px-2.5 py-1.5 shadow-[1px_2px_0_0_var(--fx-hard)]">
          <span className="fx-label whitespace-nowrap">FROM</span>
          <FxDatePicker compact value={customStart} min="2020-01-01" max={customEnd} onChange={setCustomStart} ariaLabel="Custom start date" />
          <span className="fx-label whitespace-nowrap">TO</span>
          <FxDatePicker compact value={customEnd} min={customStart} max={todayISO()} onChange={setCustomEnd} ariaLabel="Custom end date" />
        </div>
      )}
      {range === "custom" && !useCustomRange && (
        <span className="ml-auto inline-flex items-center gap-2 rounded-full bg-[var(--fx-lav)] px-3.5 py-1.5 text-[10px] font-extrabold tracking-[0.06em] text-[var(--fx-muted)] shadow-[inset_0_0_0_1px_var(--fx-line)]">
          {customStart} → {customEnd}
          <span className="rounded-full bg-[var(--fx-surf)] px-2 py-0.5 text-[8.5px] text-[var(--fx-accent-ink)] shadow-[inset_0_0_0_1px_var(--fx-line)]">
            SET IN SETTINGS
          </span>
        </span>
      )}
    </div>
  );

  /* ── shared card builders ── */
  // t230 — the two give-away lines merged into ONE: DISCOUNT & REWARDS = the
  // discounts typed at the counters + the loyalty points minted/redeemed on
  // the same bills (1 pt = ₹1). Registered automatically from the bills —
  // the receptions never enter it (owner Expenses reads the same ledger).
  const restRows: CostRow[] = [
    { label: "DISCOUNT & REWARDS", note: "BILL DISCOUNTS + LOYALTY POINTS · AUTO", amount: data.books.rest.discounts, color: "#0ea5e9" },
    { label: "EMPLOYEE SALARIES", note: `${staffRest.length} STAFF · AS PER ATTENDANCE`, amount: data.books.rest.salaries, color: "var(--fx-amber)" },
    { label: "RAW MATERIALS", note: "HOTEL BOOK ENTRIES", amount: data.books.rest.rawMaterials, color: "var(--fx-teal)" },
    { label: "UPGRADES", note: "HOTEL BOOK ENTRIES", amount: data.books.rest.upgrades, color: "#7c3aed" },
    { label: "MAINTENANCE", note: "HOTEL BOOK ENTRIES", amount: data.books.rest.maintenance, color: "var(--fx-rose)" },
  ];
  const lodgeRows: CostRow[] = [
    { label: "DISCOUNT & REWARDS", note: "STAY DISCOUNTS + LOYALTY POINTS · AUTO", amount: data.books.lodge.discounts, color: "#0ea5e9" },
    { label: "EMPLOYEE SALARIES", note: `${staffLodge.length} STAFF · AS PER ATTENDANCE`, amount: data.books.lodge.salaries, color: "var(--fx-amber)" },
    { label: "RAW MATERIALS", note: "LODGE BOOK ENTRIES", amount: data.books.lodge.rawMaterials, color: "var(--fx-teal)" },
    { label: "UPGRADES", note: "LODGE BOOK ENTRIES", amount: data.books.lodge.upgrades, color: "#7c3aed" },
    { label: "MAINTENANCE", note: "LODGE BOOK ENTRIES", amount: data.books.lodge.maintenance, color: "var(--fx-rose)" },
  ];
  const marginOf = (rev: number, book: "rest" | "lodge") => {
    const b = data.books[book];
    return rev > 0 ? Math.round((b.profit / rev) * 100) : null;
  };

  return (
    <div className="flex flex-col gap-5">
      <TierBand
        num={FX_TIERS.dashboard.num}
        eyebrow={tierEyebrow(FX_TIERS.dashboard)}
        title="Live Dashboard"
        sub="Every bill and every stay feeds this wall by itself — restaurant and lodge on one screen, zero data entry, forever."
        live
      >
        <span className="rounded-full border border-[var(--fx-line)] bg-[var(--fx-lav)] px-4 py-2 text-[10px] font-extrabold tracking-[0.12em] text-[var(--fx-ink)]">
          <span className="fx-live-dot mr-1.5" aria-hidden />LIVE · UPDATED {istTime(new Date())}
        </span>
      </TierBand>
      {tabs}
      {scopeRow}

      {/* ══════════ ALL BUSINESS — two independent book blocks per section ══════════ */}
      {scope === "all" && (
        <>
          {/* t91 — business-wide divider, above every analytics section */}
          <div className="books-head fx-pop-in" data-testid="business-wide-heading">
            <span className="bh-t">{ic(Hotel, "h-5 w-5")}BUSINESS-WIDE ANALYTICS</span>
            <span className="bh-sub">RESTAURANT + LODGE · EVERY SECTION BELOW</span>
            <span className="hline" />
          </div>

          <section>
            <SecHead icon={ic(Banknote)} title={`REVENUE · ${period}`} sub="FOOD & BEV + ROOMS & STAYS" />
            <div className="rev-duo">
              <Stat
                label="HOTEL"
                value={inr(data.stats.revenue)}
                icon={ic(UtensilsCrossed)}
                delta={deltaChip(data.stats.revenueDeltaPct, PREV[range])}
                footnote={`FOOD & BEV · ${num(data.stats.bills)} BILLS`}
                net={data.books.rest.profit}
              />
              <Stat
                label="LODGE"
                value={inr(L.revenue)}
                icon={ic(Hotel)}
                gold
                delta={deltaChip(L.deltaPct, PREV[range])}
                footnote={`ROOMS & STAYS · ${num(L.stays)} STAYS`}
                net={data.books.lodge.profit}
              />
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <Stat label={`RESTAURANT BILLS · ${period}`} value={num(data.stats.bills)} icon={ic(Receipt)} delta={deltaChip(data.stats.billDeltaPct, PREV[range])} footnote={`AVG TICKET · ${inr(data.stats.avgTicket)}`} />
              <Stat label={`LODGE STAYS · ${period}`} value={num(L.stays)} icon={ic(KeyRound)} gold delta={deltaChip(L.deltaPct, PREV[range])} footnote={`AVG STAY · ${inr(L.avgStay)}`} />
              <Stat label="IN-HOUSE NOW" value={num(L.inHouse)} icon={ic(BedDouble)} gold footnote={`${L.pctFull}% FULL · ${inr(L.tonight)} / NIGHT${L.mnt ? ` · ${L.mnt} MNT` : ""}`} />
            </div>
          </section>

          {/* t229 — THREE in this row: ORDER MIX (left, new) · REVENUE SPLIT ·
              LODGE WALL (right). The order-mix ring sizes each of the four
              billing channels by the REVENUE it brings, not bill count. */}
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
            <div className="fx-card fx-rise p-5" data-testid="order-mix-donut">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label">ORDER MIX · {period}</span>
                <span className="flex items-center gap-1.5"><VTag kind="rest" label="RESTAURANT" /></span>
              </div>
              <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                Every bill arrives under one of four channels — dine in, take away, lodge order (an in-house guest ordering to the room) or online. Each slice is sized by the channel's REVENUE.
              </p>
              <div className="mt-3">
                {data.stats.revenue > 0 ? (
                  <Donut
                    data={(data.orderTypes ?? []).map((o) => ({ name: o.label, value: o.revenue }))}
                    colors={[C.purple, "#f59e0b", "#0d9488", "#e11d48"]}
                    centerTop={inr(data.stats.revenue)}
                    centerLabel="FOOD & BEV"
                  />
                ) : (
                  <p className="py-10 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                    NO ORDERS IN THIS WINDOW YET — the mix appears with the first bill.
                  </p>
                )}
              </div>
            </div>
            <div className="fx-card p-5" data-testid="revenue-split-card">
              <span className="fx-label">REVENUE SPLIT · {period}</span>
              {/* t230 — the middle ring wears the same one-liner the rings
                  beside it have, so the trio sits on one line (it used to look
                  lifted because its card was the only one without a blurb) */}
              <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                The house total split by its two engines — every rupee the restaurant counter rings up beside every rupee the lodge front desks bill.
              </p>
              <div className="mt-3">
                <Donut
                  data={[{ name: "RESTAURANT", value: data.stats.revenue }, { name: "LODGE", value: L.revenue }]}
                  colors={[C.purple, C.gold]}
                  centerTop={inr(revTot)}
                  centerLabel="COMBINED"
                />
              </div>
            </div>
            {/* t91/t92 — the 100-room wall in rooms (24 room-hours = 1 room) */}
            <div className="fx-card fx-rise p-5" data-testid="room-status-dash">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label">LODGE WALL · {L.roomHours.windowLabel}</span>
                <span className="flex items-center gap-1.5"><VTag kind="lodge" label="LODGE" /></span>
              </div>
              <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                Time-weighted wall — 24 room-hours fold into one room, so the three slices always sum to the 100-room house.
              </p>
              <div className="mt-3">
                <RoomStatusDonut
                  counts={{ avl: 100 - L.inHouse - L.mnt, occ: L.inHouse, mnt: L.mnt }}
                  hours={L.roomHours}
                  testId="room-status-donut-dash"
                  legendPrefix="lroomdash"
                />
              </div>
            </div>
          </div>

          {/* t91 — the two-book divider the owner asked to keep */}
          <div className="books-head fx-pop-in" data-testid="books-heading">
            <span className="bh-t">{ic(UtensilsCrossed, "h-5 w-5")}RESTAURANT AND LODGE</span>
            <span className="bh-sub">TWO BOOKS · SIDE BY SIDE</span>
            <span className="hline" />
          </div>

          <section>
            <SecHead icon={ic(Banknote)} title={`REVENUE TREND · ${period}`} sub="BOTH BOOKS · SIDE BY SIDE" />
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label">RESTAURANT</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="rest" label="FOOD & BEV" />
                    {data.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {data.peakLabel.toUpperCase()}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                  {range === "today" ? "Today's food bills as they land — live from the POS, bill by bill." : `The restaurant's food flow across the ${period.toLowerCase()} — averaged from the POS register.`}
                  {campsInRange > 0 ? " Purple dots mark every mass-message send at its own time — sends that fired within a blink share one dot; tap the bucket to see the send list. Solid = personal, ring = notice." : ""}
                </p>
                <div className="mt-2"><AreaTrend data={trendRest} color={C.purple} tall /></div>
                {campsInRange > 0 && <div className="mt-1.5"><CampMark /></div>}
              </div>
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label">LODGE</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="lodge" label="ROOMS & STAYS" />
                    {L.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}{range === "today" ? "PEAK HOUR" : "PEAK"} · {L.peakLabel.toUpperCase()}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
                  {range === "today" ? "Stay revenue settling hour by hour — checkout-heavy late morning, a smaller evening wave." : `The lodge's stay revenue across the ${period.toLowerCase()} — billed to the hour, floor ₹1,000, 5% GST.`}
                  {campsInRange > 0 ? " Purple dots mark every campaign send at its own time — one franchise, one audience, so both lines wear them." : ""}
                </p>
                <div className="mt-2"><AreaTrend data={trendLodge} color={C.gold} tall /></div>
                {campsInRange > 0 && <div className="mt-1.5"><CampMark /></div>}
              </div>
            </div>
          </section>

          <section>
            <SecHead icon={ic(Clock)} title="ONE DAY · TWO ENGINES" sub="SAME HOURS · SEPARATE BOOKS" />
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}HOURLY RHYTHM · ₹ PER HOUR</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="rest" label="RESTAURANT" />
                    {data.hourly.peak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {data.hourly.peak}</Pk> : null}
                    {data.hourly.quiet ? <Pk mut>{ic(TrendingDown, "h-3 w-3")}QUIET · {data.hourly.quiet}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">The restaurant's day has a sharp lunch hump — the kitchen carries the afternoon, dinner runs a smaller second wave.</p>
                <div className="mt-2"><LineTrend data={hourlyRest} color={C.purple} fmt={inrFmt} /></div>
              </div>
              <div className="fx-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}AVERAGE DAY · ROOMS IN HOUSE</span>
                  <span className="flex flex-wrap items-center gap-1.5">
                    <VTag kind="lodge" label="LODGE" />
                    {L.dayPeak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {L.dayPeak.toUpperCase()}</Pk> : null}
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">The lodge runs a gentler fill curve of its own — checkouts empty the morning, arrivals refill the evening. Same hours, separate book.</p>
                <div className="mt-2"><LineTrend data={dayCurve} color={C.gold} fmt={pctFmt} max={100} /></div>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <div className="fx-card p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label">ITEMS SOLD · {period}</span>
                <span className="flex items-center gap-1.5"><VTag kind="rest" label="RESTAURANT" /><span className="mut-chip">{data.itemsSold.length} DISHES</span></span>
              </div>
              <div className="scrollfade mt-3">
                <div className="fx-scroll max-h-[260px] min-h-[200px] overflow-y-auto pr-1">
                  {(data.itemsSold ?? []).slice(0, 12).map((d, i) => (
                    <div className="rank" key={d.name}>
                      <span className="rk-n fx-num">{String(i + 1).padStart(2, "0")}</span>
                      <div className="rk-main">
                        <div className="rk-top"><span className="rk-name">{d.name}</span><span className="rk-rev fx-num">{inr(d.revenue)}</span></div>
                        <div className="rk-bar-w"><span className="rk-bar"><i style={{ width: `${Math.max(5, Math.round((d.qty / ((data.itemsSold?.[0]?.qty ?? 1) || 1)) * 100))}%` }} /></span><span className="rk-qty">{num(d.qty)} sold</span></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="fx-card p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}STAY MIX · {period}</span>
                <span className="flex items-center gap-1.5"><VTag kind="lodge" label="LODGE" /><span className="mut-chip">{num(L.stays)} STAYS</span></span>
              </div>
              <div className="mt-4">
                {(L.stayMix ?? []).map((m) => (
                  <div className="rank" key={m.label}>
                    <div className="rk-main">
                      <div className="rk-top"><span className="rk-name">{m.label}</span><span className="rk-rev fx-num">{m.share}%</span></div>
                      <div className="rk-bar-w"><span className="rk-bar"><i style={{ width: `${Math.max(6, m.share)}%`, background: C.gold }} /></span><span className="rk-qty">of stays</span></div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] font-medium text-[var(--fx-muted)]">Your rooms bill around the clock — short stays dominate, long stays anchor the month.</p>
            </div>
          </div>

          {/* revenue-distribution donuts — just below ITEMS SOLD + STAY MIX:
              the restaurant ring divides its revenue across DISH CATEGORIES,
              the lodge ring across ROOM CATEGORIES (room levels). */}
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <div className="fx-card fx-rise p-5" data-testid="dish-category-donut">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label inline-flex items-center gap-2">{ic(UtensilsCrossed)}DISH CATEGORY SPLIT · {period}</span>
                <VTag kind="rest" label="RESTAURANT" />
              </div>
              <div className="mt-3">
                {(data.categoryMix ?? []).length > 0 ? (
                  <Donut
                    data={(data.categoryMix ?? []).map((c) => ({ name: c.category.toUpperCase(), value: c.revenue }))}
                    colors={[C.purple, "#f59e0b", "#0d9488", "#e11d48", C.accent3, "#65a30d"]}
                    centerTop={inr(data.stats.revenue)}
                    centerLabel="FOOD & BEV"
                  />
                ) : (
                  <p className="py-10 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                    NO DISH SALES IN THIS WINDOW YET — the split appears with the first bill.
                  </p>
                )}
              </div>
              <p className="mt-2 text-[11.5px] font-medium text-[var(--fx-muted)]">
                Every dish bills into one of six kitchen categories — the ring shows where the menu's money actually comes from, share of the ring on each row.
              </p>
            </div>
            <div className="fx-card fx-rise p-5" data-testid="room-category-donut">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label inline-flex items-center gap-2">{ic(BedDouble)}ROOM CATEGORY SPLIT · {period}</span>
                <VTag kind="lodge" label="LODGE" />
              </div>
              <div className="mt-3">
                {(L.tierMix ?? []).length > 0 ? (
                  <Donut
                    data={(L.tierMix ?? []).map((t) => ({ name: t.tier, value: t.revenue }))}
                    colors={[C.gold, C.purple, "#0d9488"]}
                    centerTop={inr(L.revenue)}
                    centerLabel="ROOMS & STAYS"
                  />
                ) : (
                  <p className="py-10 text-center text-[12px] font-semibold text-[var(--fx-muted)]">
                    NO STAYS IN THIS WINDOW YET — the split appears with the first checkout.
                  </p>
                )}
              </div>
              <p className="mt-2 text-[11.5px] font-medium text-[var(--fx-muted)]">
                Each stay bills at its level's hourly rate — the ring shows which room tiers carry the house, share of the ring on each row.
              </p>
            </div>
          </div>

          <section>
            <SecHead icon={ic(Wallet)} title={`REVENUE BREAKDOWN · ${period}`} sub="COSTS & NET · PER BOOK" />
            {/* t117 — each book's revenue-split donut sits just above its own band graph;
                t126 — no content-start: both stacks stretch so the paired cards come out EQUAL */}
            {/* t133 — the paired-book grids run md: (side by side on mobile too,
                matching the desktop the owner described) */}
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="grid gap-5">
                <CostDonutCard tag="RESTAURANT" kind="rest" rev={data.stats.revenue} rows={restRows} centerLabel="FOOD & BEV" />
                <BookCard title="RESTAURANT BOOK" tag="FOOD & BEV" kind="rest" rev={data.stats.revenue} rows={restRows} net={data.books.rest.profit} margin={marginOf(data.stats.revenue, "rest")} note="The kitchen's own ledger — food revenue minus this book's discounts & loyalty redemptions, salaries, ingredients and upkeep." />
              </div>
              <div className="grid gap-5">
                <CostDonutCard tag="LODGE" kind="lodge" rev={L.revenue} rows={lodgeRows} centerLabel="ROOMS & STAYS" />
                <BookCard title="LODGE BOOK" tag="ROOMS & STAYS" kind="lodge" rev={L.revenue} rows={lodgeRows} net={data.books.lodge.profit} margin={marginOf(L.revenue, "lodge")} note="The rooms' own ledger — stay revenue minus front-desk discounts & loyalty redemptions, salaries, supplies and repairs." />
              </div>
            </div>
            {/* t150 — the discount history tables that sat here are removed (owner's ask) */}
          </section>

          {/* t98 — the tasks board's double bars, now horizontal, side by side above the team */}
          <section>
            <SecHead icon={ic(ListChecks)} title={`TASKS · COMPLETION & BUDGET · ${period}`} sub="HORIZONTAL RATE BARS · PER BOOK · FROM THE TASKS BOARD" />
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <TaskRateCard book="rest" title="RESTAURANT" stats={restTaskStats} />
              <TaskRateCard book="lodge" title="LODGE" stats={lodgeTaskStats} />
            </div>
          </section>

          {/* t120/t124 — the attendance wall, bottom of the live dashboard;
              t138 — the blended block is now TWO separate book cards, each with
              its own entrance motion and cursor drift (owner's ask) */}
          <AttendanceCard stats={att} scope={scope} />
        </>
      )}

      {/* ══════════ RESTAURANT scope — single blocks ══════════ */}
      {scope === "rest" && (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Stat label={`REVENUE · ${period}`} value={inr(data.stats.revenue)} icon={ic(Banknote)} delta={deltaChip(data.stats.revenueDeltaPct, PREV[range])} footnote="vs previous period" net={data.books.rest.profit} />
            <Stat label={`BILLS · ${period}`} value={num(data.stats.bills)} icon={ic(Receipt)} delta={deltaChip(data.stats.billDeltaPct, PREV[range])} footnote="counting every generated bill" />
            <Stat label="AVG TICKET" value={inr(data.stats.avgTicket)} icon={ic(UtensilsCrossed)} footnote="revenue ÷ bills" />
            <Stat label={`ITEMS SOLD · ${period}`} value={num(data.stats.items)} icon={ic(ShoppingBag)} footnote={data.stats.discounts > 0 ? `DISCOUNT & REWARDS · ${inr(data.stats.discounts)}` : `LIFETIME · ${inr(data.allTime.revenue)} / ${num(data.allTime.bills)} BILLS`} />
          </div>
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label">{range === "today" ? "SALES CURVE · TODAY (IST)" : `REVENUE · ${period}`}</span>
              <span className="flex items-center gap-1.5"><VTag kind="rest" label="RESTAURANT" />{campsInRange > 0 && <CampMark />}{data.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}{range === "today" ? "PEAK HOUR" : "PEAK"} · {data.peakLabel.toUpperCase()}</Pk> : null}</span>
            </div>
            <div className="mt-2"><AreaTrend data={trendRest} color={C.purple} tall /></div>
          </div>
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}HOURLY RHYTHM · AVG REVENUE PER HOUR</span>
              <span className="flex flex-wrap items-center gap-1.5">
                {data.hourly.peak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {data.hourly.peak}</Pk> : null}
                {data.hourly.quiet ? <Pk mut>{ic(TrendingDown, "h-3 w-3")}QUIET · {data.hourly.quiet}</Pk> : null}
              </span>
            </div>
            <div className="mt-2"><LineTrend data={hourlyRest} color={C.purple} fmt={inrFmt} /></div>
          </div>
          <div className="fx-card p-5">
            <span className="fx-label">CATEGORY MIX · {period}</span>
            <div className="mt-3">
              <Donut
                data={(data.categoryMix ?? []).slice(0, 5).map((c) => ({ name: c.category.toUpperCase(), value: c.revenue }))}
                colors={[C.purple, "#f59e0b", "#0d9488", "#e11d48", C.accent3]}
                centerTop={inr(data.stats.revenue)}
                centerLabel="FOOD & BEV"
              />
            </div>
          </div>
          <CostDonutCard tag="RESTAURANT" kind="rest" rev={data.stats.revenue} rows={restRows} centerLabel="FOOD & BEV" />
          <BookCard title={`REVENUE BREAKDOWN · ${period}`} tag="RESTAURANT" kind="rest" rev={data.stats.revenue} rows={restRows} net={data.books.rest.profit} margin={marginOf(data.stats.revenue, "rest")} note="The restaurant's own ledger — food revenue minus discounts & loyalty redemptions, salaries, ingredients and upkeep." />
          {/* t127 — the tasks rates used to live ONLY in the ALL BUSINESS view,
              so switching this dashboard to RESTAURANT made the tasks vanish.
              Every scope now carries its book's task card, right above attendance. */}
          <section>
            <SecHead icon={ic(ListChecks)} title={`TASKS · COMPLETION & BUDGET · ${period}`} sub="HORIZONTAL RATE BARS · FROM THE TASKS BOARD" />
            <TaskRateCard book="rest" title="RESTAURANT" stats={restTaskStats} />
          </section>
          <AttendanceCard stats={att} scope={scope} />
        </>
      )}

      {/* ══════════ LODGE scope — single blocks ══════════ */}
      {scope === "lodge" && (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Stat label={`LODGE REVENUE · ${period}`} value={inr(L.revenue)} icon={ic(Hotel)} gold delta={deltaChip(L.deltaPct, PREV[range])} footnote="ROOMS & STAYS · HOURLY BILLING" net={data.books.lodge.profit} />
            <Stat label={`STAYS · ${period}`} value={num(L.stays)} icon={ic(KeyRound)} gold delta={deltaChip(L.deltaPct, PREV[range])} footnote="CHECKOUTS THAT BILLED" />
            <Stat label="AVG STAY VALUE" value={inr(L.avgStay)} icon={ic(Banknote)} gold footnote="REVENUE ÷ STAYS" />
            <Stat label="OCCUPANCY NOW" value={`${L.pctFull}%`} icon={ic(BedDouble)} gold footnote={`${L.inHouse} OF 100 ROOMS IN HOUSE${L.mnt ? ` · ${L.mnt} UNDER MAINTENANCE` : ""}`} />
          </div>
          <div className="fx-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label">{range === "today" ? "OCCUPANCY THROUGH THE DAY · TODAY" : `LODGE REVENUE · ${period}`}</span>
              <span className="flex items-center gap-1.5"><VTag kind="lodge" label="LODGE" />{range !== "today" && campsInRange > 0 && <CampMark />}{range === "today" ? L.dayPeak ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {L.dayPeak.toUpperCase()}</Pk> : null : L.peakLabel ? <Pk>{ic(Flame, "h-3 w-3")}PEAK · {L.peakLabel.toUpperCase()}</Pk> : null}</span>
            </div>
            <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
              {range === "today" ? "Rooms in house, hour by hour — checkout hour empties the wall, the evening wave refills it." : `Stay revenue across the ${period.toLowerCase()} — billed to the hour, floor ₹1,000, 5% GST.`}
            </p>
            <div className="mt-2">
              {range === "today"
                ? <LineTrend data={dayCurve} color={C.gold} fmt={pctFmt} max={100} />
                : <AreaTrend data={trendLodge} color={C.gold} tall />}
            </div>
          </div>
          {/* t91/t92 — the 100-room wall in rooms (24 room-hours = 1 room) */}
          <div className="fx-card fx-rise p-5" data-testid="room-status-dash">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="fx-label">LODGE WALL · {L.roomHours.windowLabel}</span>
              <span className="flex items-center gap-1.5"><VTag kind="lodge" label="LODGE" /></span>
            </div>
            <p className="mt-1 text-[11.5px] font-medium text-[var(--fx-muted)]">
              Time-weighted wall — 24 room-hours fold into one room, so the three slices always sum to the 100-room house.
            </p>
            <div className="mt-3">
              <RoomStatusDonut
                counts={{ avl: 100 - L.inHouse - L.mnt, occ: L.inHouse, mnt: L.mnt }}
                hours={L.roomHours}
                testId="room-status-donut-dash"
                legendPrefix="lroomdash"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <div className="fx-card p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="fx-label inline-flex items-center gap-2">{ic(Clock)}STAY MIX · {period}</span>
                <span className="flex items-center gap-1.5"><span className="mut-chip">{num(L.stays)} STAYS</span></span>
              </div>
              <div className="mt-4">
                {(L.stayMix ?? []).map((m) => (
                  <div className="rank" key={m.label}>
                    <div className="rk-main">
                      <div className="rk-top"><span className="rk-name">{m.label}</span><span className="rk-rev fx-num">{m.share}%</span></div>
                      <div className="rk-bar-w"><span className="rk-bar"><i style={{ width: `${Math.max(6, m.share)}%`, background: C.gold }} /></span><span className="rk-qty">of stays</span></div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] font-medium text-[var(--fx-muted)]">Most guests stay under a day — hourly billing keeps short stays honest, the ₹1,000 floor keeps them fair.</p>
            </div>
            <div className="fx-card p-5">
              <span className="fx-label">GUESTS IN HOUSE · LIVE</span>
              <div className="scrollfade mt-3">
                <div className="team-list fx-scroll max-h-[300px] overflow-y-auto pr-1">
                  {(wall?.rooms ?? []).filter((r) => r.status === "occ" && r.guestName).slice(0, 40).map((r) => (
                    <div className="emp-row" key={r.number}>
                      <span className="eav">{r.guestName?.slice(0, 1).toUpperCase()}</span>
                      <span className="e-main">
                        <span className="e-n">{r.guestName}</span>
                        <span className="e-r">ROOM {r.number} · {levelNameOf(wall, r.number)} · IN FOR {fmtHrsLabel(hoursSince(r.checkInAt))}</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="fx-card p-5">
            <span className="fx-label">REVENUE BY LEVEL · {period}</span>
            <div className="mt-3">
              <Donut
                data={(L.tierMix ?? []).map((t) => ({ name: t.tier, value: t.revenue }))}
                colors={[C.gold, C.purple, "#0d9488"]}
                centerTop={inr(L.revenue)}
                centerLabel="ROOMS & STAYS"
              />
            </div>
          </div>
          <CostDonutCard tag="LODGE" kind="lodge" rev={L.revenue} rows={lodgeRows} centerLabel="ROOMS & STAYS" />
          <BookCard title={`REVENUE BREAKDOWN · LODGE`} tag="LODGE" kind="lodge" rev={L.revenue} rows={lodgeRows} net={data.books.lodge.profit} margin={marginOf(L.revenue, "lodge")} note="Stays bill as RATE × HOURS ÷ 24 — never below the ₹1,000 minimum — then 5% GST. Costs come from the lodge book in the Employee section." />
          {/* t127 — lodge scope gets its task card too (see the rest-scope note) */}
          <section>
            <SecHead icon={ic(ListChecks)} title={`TASKS · COMPLETION & BUDGET · ${period}`} sub="HORIZONTAL RATE BARS · FROM THE TASKS BOARD" />
            <TaskRateCard book="lodge" title="LODGE" stats={lodgeTaskStats} />
          </section>
          <AttendanceCard stats={att} scope={scope} />
        </>
      )}

      {/* t231 — the TOP CUSTOMERS ledger moved OFF the dashboard: it now
          lives in the owner's Mass Messages section (the campaigning
          audience), fetched from /api/top-customers. */}

    </div>
  );
}

function levelNameOf(wall: Wall | null, room: number): string {
  const lv = wall?.levels?.find((l) => room >= l.from && room <= l.to);
  return lv ? lv.name : "BASIC";
}

function hoursSince(iso: string | null): number {
  if (!iso) return 0;
  return (Date.now() - new Date(iso).getTime()) / 3600000;
}
