#!/usr/bin/env python3
"""Zip the restaurant+lodge dashboard project into download/.

- Whitelist of app content (src, prisma, seeded db, public, scripts, configs).
- Excludes environment noise: node_modules, .next, .git, skills, .zscripts, logs, worklog.
- Rewrites .env to a portable DATABASE_URL (relative to prisma/schema.prisma).
- Wraps everything in a top-level folder like a GitHub-style archive.
"""

import os
import zipfile

ROOT = "/home/z/my-project"
OUT = os.path.join(ROOT, "download", "REST_AND_LODGE+15.zip")
WRAP = "REST_AND_LODGE+15"

INCLUDE_DIRS = ["src", "prisma", "db", "public", "scripts", "tests"]
INCLUDE_FILES = [
    "package.json",
    "bun.lock",
    "next.config.ts",
    "tailwind.config.ts",
    "tsconfig.json",
    "postcss.config.mjs",
    "eslint.config.mjs",
    "components.json",
    "next-env.d.ts",
    ".gitignore",
]
SKIP_BASENAMES = {"dev-boot.log", "dev.pid", "__pycache__", ".DS_Store"}

os.makedirs(os.path.dirname(OUT), exist_ok=True)
if os.path.exists(OUT):
    os.remove(OUT)

count = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    # dirs
    for d in INCLUDE_DIRS:
        base = os.path.join(ROOT, d)
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [x for x in dirnames if x not in SKIP_BASENAMES]
            for fn in filenames:
                if fn in SKIP_BASENAMES or fn.endswith((".log", ".pid")):
                    continue
                full = os.path.join(dirpath, fn)
                arc = os.path.join(WRAP, os.path.relpath(full, ROOT))
                z.write(full, arc)
                count += 1
    # root files
    for f in INCLUDE_FILES:
        full = os.path.join(ROOT, f)
        if os.path.isfile(full):
            z.write(full, os.path.join(WRAP, f))
            count += 1
    # portable .env
    z.writestr(
        os.path.join(WRAP, ".env"),
        "DATABASE_URL=file:../db/custom.db\n",
    )
    count += 1

bad = zipfile.ZipFile(OUT).testzip()
size = os.path.getsize(OUT)
print(f"entries: {count}")
print(f"bad entry: {bad}")
print(f"zip size: {size/1024/1024:.1f} MB -> {OUT}")
