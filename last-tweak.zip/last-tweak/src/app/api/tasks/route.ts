import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { invalidateDashboardCache } from "@/lib/analytics";

export const dynamic = "force-dynamic";

const BOOKS = ["rest", "lodge"] as const;
/* t99 — upgrades join the expense types everywhere */
const KINDS = ["raw_material", "upgrade", "maintenance"] as const;
type Book = (typeof BOOKS)[number];
type Kind = (typeof KINDS)[number];

const KIND_NOTE: Record<Kind, string> = {
  raw_material: "raw-material spend",
  upgrade: "upgrade spend",
  maintenance: "maintenance spend",
};

const round2 = (n: number) => Math.round(n * 100) / 100;

// GET /api/tasks?book=rest|lodge — every owner task (+ its updates).
// Open tasks lead (soonest deadline first), done tasks follow (newest first).
// t98 — take raised to 2000 so a full year of forwarded work stays queryable.
export async function GET(req: NextRequest) {
  const book = req.nextUrl.searchParams.get("book");
  const tasks = await db.task.findMany({
    where: book && BOOKS.includes(book as Book) ? { book } : {},
    include: { updates: { orderBy: { createdAt: "asc" } } },
    orderBy: [{ createdAt: "desc" }],
    take: 2000,
  });
  tasks.sort((a, b) => {
    if (a.status !== b.status) return a.status === "open" ? -1 : 1;
    if (a.status === "open") return a.deadline.getTime() - b.deadline.getTime();
    return (b.doneAt?.getTime() ?? 0) - (a.doneAt?.getTime() ?? 0);
  });
  return NextResponse.json({ tasks });
}

// POST /api/tasks — the owner forwards work to one of the two receptions.
// Budget rules: no maxBudget (or 0) = FREE task; a budgeted task MUST carry
// an expense type (kind) and a description saying what the budget covers.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const title = String(body.title ?? "").trim().slice(0, 120);
    if (title.length < 2)
      return NextResponse.json({ error: "Give the task a short title" }, { status: 400 });

    const book = String(body.book ?? "") as Book;
    if (!BOOKS.includes(book))
      return NextResponse.json(
        { error: "Forward the task to LODGE or RESTAURANT" },
        { status: 400 },
      );

    const deadline = new Date(String(body.deadline ?? ""));
    if (!Number.isFinite(deadline.getTime()))
      return NextResponse.json({ error: "Set a deadline for the task" }, { status: 400 });

    const description = String(body.description ?? "").trim().slice(0, 600);

    let maxBudget: number | null = null;
    const rawBudget = Number(body.maxBudget);
    if (body.maxBudget !== undefined && body.maxBudget !== null && body.maxBudget !== "") {
      if (!Number.isFinite(rawBudget) || rawBudget <= 0)
        return NextResponse.json({ error: "Max budget must be above zero" }, { status: 400 });
      maxBudget = round2(rawBudget);
    }

    let kind: Kind | null = null;
    if (body.kind !== undefined && body.kind !== null && body.kind !== "") {
      kind = String(body.kind) as Kind;
      if (!KINDS.includes(kind))
        return NextResponse.json(
          { error: "Expense type must be raw_material, upgrade or maintenance" },
          { status: 400 },
        );
    }

    if (maxBudget !== null) {
      if (!kind)
        return NextResponse.json(
          { error: "Pick the expense type — a budgeted task books its spend into the cost ledger" },
          { status: 400 },
        );
      if (description.length < 3)
        return NextResponse.json(
          { error: "Describe what the budget covers — budgeted tasks need a description" },
          { status: 400 },
        );
    }

    const createdBy = String(body.createdBy ?? "OWNER").trim().slice(0, 60) || "OWNER";

    const task = await db.task.create({
      data: {
        title,
        book,
        kind,
        maxBudget,
        description,
        deadline,
        createdBy,
        updates: {
          create: {
            author: createdBy,
            role: "owner",
            message:
              maxBudget !== null
                ? `Task forwarded with a max budget of ₹${maxBudget.toLocaleString("en-IN")}${kind ? ` · ${KIND_NOTE[kind]}` : ""}.`
                : "Task forwarded as a FREE task — no budget attached.",
          },
        },
      },
      include: { updates: { orderBy: { createdAt: "asc" } } },
    });
    return NextResponse.json({ task }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create the task" }, { status: 500 });
  }
}

type PatchBody = {
  id?: string;
  action?: "note" | "done";
  message?: string;
  cost?: number;
  kind?: string;
  author?: string;
  role?: string;
};

// PATCH /api/tasks — progress notes + the completion flow.
//   action=note : append a progress update the owner monitors.
//   action=done : close the task with the money it cost. The reception may
//                 spend LESS than the owner's max budget, never MORE. A
//                 non-zero cost auto-registers an expense in the task's book
//                 wearing the owner's crown (via="task").
export async function PATCH(req: NextRequest) {
  let body: PatchBody;
  try {
    body = (await req.json()) as PatchBody;
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const id = String(body.id ?? "");
  if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

  const author = String(body.author ?? "").trim().slice(0, 60) || "RECEPTION";
  const role = String(body.role ?? "").trim().slice(0, 30);

  try {
    /* ── PROGRESS NOTE / OWNER REPLY (t130) ─────────────────────────────── */
    if (body.action === "note") {
      // t98 — the receptions post progress updates. t130 — the owner answers:
      // a desk query on a task deserves a reply on the same trail, so the
      // owner may now post too (role="owner" renders with the crown dot).
      const message = String(body.message ?? "").trim().slice(0, 400);
      if (message.length < 2)
        return NextResponse.json({ error: "Write the update first" }, { status: 400 });
      const note = await db.taskUpdate.create({ data: { taskId: id, author, role, message } });
      return NextResponse.json({ note });
    }

    /* ── MARK DONE — with the money it cost ─────────────────────────────── */
    if (body.action === "done") {
      const task = await db.task.findUnique({ where: { id } });
      if (!task) return NextResponse.json({ error: "Task not found" }, { status: 404 });
      if (task.status === "done")
        return NextResponse.json({ error: "Task is already done" }, { status: 409 });

      const cost = round2(Number(body.cost ?? 0));
      if (!Number.isFinite(cost) || cost < 0)
        return NextResponse.json({ error: "Cost must be zero or more" }, { status: 400 });
      if (task.maxBudget !== null && cost > task.maxBudget)
        return NextResponse.json(
          {
            error: `Above the owner's assumption — this task was budgeted at ₹${task.maxBudget.toLocaleString("en-IN")} max. Enter ₹${task.maxBudget.toLocaleString("en-IN")} or less, or ask the owner to raise the budget.`,
          },
          { status: 400 },
        );

      let kind: Kind | null = null;
      const rawKind = task.kind ?? (body.kind ? String(body.kind) : null);
      if (rawKind) {
        kind = rawKind as Kind;
        if (!KINDS.includes(kind))
          return NextResponse.json(
            { error: "Expense type must be raw_material, upgrade or maintenance" },
            { status: 400 },
          );
      }
      if (cost > 0 && !kind)
        return NextResponse.json(
          { error: "Pick the expense type — the spend books into the cost ledger" },
          { status: 400 },
        );

      const done = await db.$transaction(async (tx) => {
        if (cost > 0 && kind) {
          await tx.expense.create({
            data: {
              kind,
              book: task.book,
              label: `TASK · ${task.title}`.slice(0, 120),
              amount: cost,
              spentOn: new Date(),
              via: "task",
              taskId: task.id,
            },
          });
        }
        await tx.taskUpdate.create({
          data: {
            taskId: task.id,
            author,
            role: role || "reception",
            message:
              cost > 0
                ? `Marked DONE — ₹${cost.toLocaleString("en-IN")} spent${task.maxBudget !== null ? ` of the ₹${task.maxBudget.toLocaleString("en-IN")} budget` : ""}. The spend is booked in the ${task.book === "lodge" ? "LODGE" : "RESTAURANT"} ledger with the owner's crown.`
                : "Marked DONE — nothing was spent.",
          },
        });
        return tx.task.update({
          where: { id: task.id },
          data: { status: "done", doneAt: new Date(), doneBy: author, actualCost: cost },
          include: { updates: { orderBy: { createdAt: "asc" } } },
        });
      });

      invalidateDashboardCache();
      return NextResponse.json({ task: done });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Task update failed" }, { status: 500 });
  }
}
