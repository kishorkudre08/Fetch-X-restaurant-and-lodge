@echo off
setlocal
title Fetch-X - Restaurant OS
cd /d "%~dp0"

rem ---- 1) ask Windows PATH first ----------------------------------------
set "PX="
set "PKG="
where bun >nul 2>nul && set "PX=bunx"
if defined PX set "PKG=bun"
if not defined PX (
  where npm >nul 2>nul && set "PX=npx"
)
if defined PX if not defined PKG set "PKG=npm"

rem ---- 2) PATH can be stale - probe the usual install spots directly ----
if not defined PX call :deepscan

if defined PX goto :haspkg

:nonode
cls
echo  ==============================================
echo    FETCH-X  -  RESTAURANT OS
echo  ==============================================
echo.
echo  [!] Node.js was not found on this PC.
echo.
choice /c 12 /n /m "  Press 1 to install Node.js automatically, or 2 to install it yourself: "
if errorlevel 2 goto :manual
if errorlevel 1 goto :autonode

:autonode
echo.
echo  Installing Node.js LTS (needs internet, a few minutes)...
echo  If a Windows permission window appears, click YES.
echo.
winget install -e --id OpenJS.NodeJS.LTS --silent --accept-source-agreements --accept-package-agreements
if errorlevel 1 (
  echo.
  echo  [!] Automatic install did not work on this PC.
  echo      Switching to the manual way...
  goto :manual
)
set "PATH=%PATH%;%ProgramFiles%\nodejs"
where node >nul 2>nul
if errorlevel 1 goto :manual
set "PX=npx"
set "PKG=npm"
echo.
echo  Node.js installed successfully.
goto :haspkg

:manual
start "" "https://nodejs.org"
echo.
echo  The Node.js website just opened in your browser.
echo    1. Click the big green button marked LTS and install it
echo       (keep clicking Next until Finish).
echo    2. Double-click start.bat again.
echo.
pause
exit /b 1

:haspkg
cls
echo  ==============================================
echo    FETCH-X  -  RESTAURANT OS
echo  ==============================================
echo.
if "%PKG%"=="npm" (
  for /f "usebackq delims=" %%v in (`node -v 2^>nul`) do echo   Engine found: Node.js %%v
) else (
  for /f "usebackq delims=" %%v in (`bun --version 2^>nul`) do echo   Engine found: Bun %%v
)
echo.
echo  [1/3] Checking dependencies... (first run downloads packages)
if not exist "node_modules" (
  echo        installing - this can take a few minutes, please wait...
  if "%PKG%"=="npm" (call npm install) else (call bun install)
  if errorlevel 1 goto :fail
) else (
  echo        dependencies OK
)

echo  [2/3] Preparing the database client...
if not exist "node_modules\.prisma\client" (
  %PX% prisma generate
  if errorlevel 1 goto :fail
) else (
  echo        database client OK
)

echo  [3/3] Starting Fetch-X...
echo        Your browser will open at  http://localhost:3000
echo        Keep this window OPEN while using Fetch-X.
echo        Close this window to stop the server.
echo.
start "Fetch-X browser" cmd /c "timeout /t 12 /nobreak >nul & start "" http://localhost:3000"
%PX% next dev -p 3000
goto :eof

:fail
echo.
echo  [!] A step above failed. Read the error message,
echo      then run this file again. (Internet needed on first run.)
pause
exit /b 1

:deepscan
rem Bun (official installer lands in the user profile)
if exist "%USERPROFILE%\.bun\bin\bun.exe" (
  set "PATH=%PATH%;%USERPROFILE%\.bun\bin"
  set "PX=bunx"
  set "PKG=bun"
  goto :eof
)
rem Node.js - machine-wide MSI (64-bit, then 32-bit)
if exist "%ProgramFiles%\nodejs\node.exe" set "NODEHOME=%ProgramFiles%\nodejs"
if not defined NODEHOME if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODEHOME=%ProgramFiles(x86)%\nodejs"
rem Node.js - per-user installs
if not defined NODEHOME if exist "%LocalAppData%\Programs\nodejs\node.exe" set "NODEHOME=%LocalAppData%\Programs\nodejs"
rem version managers
if not defined NODEHOME if exist "%USERPROFILE%\scoop\apps\nodejs\current\node.exe" set "NODEHOME=%USERPROFILE%\scoop\apps\nodejs\current"
if not defined NODEHOME if exist "%LocalAppData%\Volta\bin\node.exe" set "NODEHOME=%LocalAppData%\Volta\bin"
if not defined NODEHOME if exist "%AppData%\nvm" (
  for /d %%d in ("%AppData%\nvm\v*") do if exist "%%d\node.exe" set "NODEHOME=%%d"
)
if defined NODEHOME (
  set "PATH=%PATH%;%NODEHOME%"
  set "PX=npx"
  set "PKG=npm"
)
goto :eof
